import {writeFile}from'node:fs/promises';import{join}from'node:path';
export async function waterfrontVisual({page,review,errors,httpErrors}){
 await page.evaluate(async()=>{const q=__lagoonQA;q.drawPaused=true;q.reviewHour=12;document.querySelector('[data-biome="autumn"]').click();await Promise.all([q.mall().ensure(),q.resortSpa().ensure()]);await q.waterfront().ensure();});
 await page.waitForFunction(()=>__lagoonQA.waterfront().ready&&__lagoonQA.shaderWarmup.idle()&&!__lagoonQA.islands.get('autumn').userData.lowOnly,null,{timeout:600000});
 console.log('Waterfront ready',await page.evaluate(()=>__lagoonQA.waterfront().diagnostics()));
 await page.evaluate(()=>{const q=__lagoonQA;q.submarine().releaseControl();q.mall().exit(false);q.resortSpa().exit(false);});
 const views=[{id:'overview',eye:[430,380,700],target:[0,9,140]},{id:'restaurant',eye:[180,96,190],target:[0,14,0]},{id:'interior',eye:[72,17,43],target:[-5,9,-2],inside:false},{id:'trampoline',eye:[145,158,510],target:[-10,3,350]}];
 for(const v of views){await page.evaluate(v=>{const q=__lagoonQA,o=q.waterfront().origin;q.waterfront().root.userData.restaurant.userData.roof.visible=!v.inside;q.oceanReviewCamera={eye:[o.x+v.eye[0],v.eye[1],o.z+v.eye[2]],target:[o.x+v.target[0],v.target[1],o.z+v.target[2]],fov:40,far:6000};q.targetFrames=q.frames+3;q.drawPaused=false;},v);await page.waitForFunction(()=>__lagoonQA.frames>=__lagoonQA.targetFrames,null,{timeout:240000});await page.evaluate(()=>{__lagoonQA.drawPaused=true;});await page.screenshot({path:join(review,v.id+'.png')});console.log('Captured',v.id);}
 await writeFile(join(review,'visual-stage.json'),JSON.stringify({stage:'visual-silhouette-materials-stage3',diagnostics:await page.evaluate(()=>__lagoonQA.waterfront().diagnostics()),errors,httpErrors},null,2));
}
