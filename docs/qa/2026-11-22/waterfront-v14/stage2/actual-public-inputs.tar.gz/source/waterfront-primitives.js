import * as T from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { mallSurfaceMaps } from "./mall-surfaces.js";
export function waterfrontMaterials() {
  const standard = (color, roughness = 0.5, extra = {}) =>
    new T.MeshStandardMaterial({ color, roughness, ...extra });
  return {
    ivory: standard(0xffe7cc, 0.34, mallSurfaceMaps("marble", 6)),
    rose: standard(0xeec4c6, 0.47),
    dark: standard(0x303154, 0.38),
    wood: standard(0x785b44, 0.65),
    gold: standard(0xd3aa55, 0.24, {
      metalness: 0.72,
      emissive: 0x976322,
      emissiveIntensity: 0.09,
    }),
    light: standard(0xffd99a, 0.3, {
      emissive: 0xffb855,
      emissiveIntensity: 0.85,
    }),
    violet: standard(0xa88ad5, 0.5),
    pink: standard(0xf3b1d9, 0.43),
    green: standard(0x438552, 0.78),
    flower: standard(0xf4a0d2, 0.63),
    glass: standard(0xc5eced, 0.09, {
      metalness: 0.16,
      transparent: true,
      opacity: 0.16,
      depthWrite: false,
      side: T.DoubleSide,
      forceSinglePass: true,
    }),
    floorGlass: standard(0xd4f6f1, 0.07, {
      metalness: 0.18,
      transparent: true,
      opacity: 0.12,
      depthWrite: false,
      side: T.DoubleSide,
      forceSinglePass: true,
    }),
    water: standard(0x24bdbb, 0.15, {
      transparent: true,
      opacity: 0.67,
      metalness: 0.18,
    }),
    rock: standard(0x738b85, 0.91),
    sand: standard(0xc9bb91, 0.98),
  };
}
export function roundedShape(w, d, r = 8) {
  const s = new T.Shape(),
    x = -w / 2,
    z = -d / 2;
  s.moveTo(x + r, z);
  s.lineTo(x + w - r, z);
  s.quadraticCurveTo(x + w, z, x + w, z + r);
  s.lineTo(x + w, z + d - r);
  s.quadraticCurveTo(x + w, z + d, x + w - r, z + d);
  s.lineTo(x + r, z + d);
  s.quadraticCurveTo(x, z + d, x, z + d - r);
  s.lineTo(x, z + r);
  s.quadraticCurveTo(x, z, x + r, z);
  return s;
}
export function flatShape(shape, y = 0) {
  const g = new T.ShapeGeometry(shape, 40);
  g.rotateX(-Math.PI / 2);
  g.translate(0, y, 0);
  return g;
}
export function slab(shape, height = 1) {
  const g = new T.ExtrudeGeometry(shape, {
    depth: height,
    bevelEnabled: true,
    bevelSize: 0.12,
    bevelThickness: 0.12,
    bevelSegments: 1,
    steps: 1,
    curveSegments: 32,
  });
  g.rotateX(-Math.PI / 2);
  return g;
}
export function parts(root, materials) {
  const batches = new Map();
  function put(
    geometry,
    key,
    x = 0,
    y = 0,
    z = 0,
    sx = 1,
    sy = 1,
    sz = 1,
    rotation = null,
  ) {
    const matrix = new T.Matrix4(),
      q = new T.Quaternion();
    if (rotation) q.setFromEuler(new T.Euler(...rotation));
    matrix.compose(new T.Vector3(x, y, z), q, new T.Vector3(sx, sy, sz));
    geometry.applyMatrix4(matrix);
    geometry.deleteAttribute("uv1");
    const material = materials[key];
    if (!batches.has(material)) batches.set(material, []);
    batches.get(material).push(geometry);
  }
  return {
    put,
    box: (key, x, y, z, w, h, d, rot = null) =>
      put(new T.BoxGeometry(w, h, d), key, x, y, z, 1, 1, 1, rot),
    sphere: (key, x, y, z, rx, ry = rx, rz = rx) =>
      put(new T.SphereGeometry(1, 12, 8), key, x, y, z, rx, ry, rz),
    cylinder: (key, x, y, z, r, h, r2 = r) =>
      put(new T.CylinderGeometry(r, r2, h, 24), key, x, y, z),
    torus: (key, x, y, z, r, t = 0.2, rotation = [Math.PI / 2, 0, 0]) =>
      put(new T.TorusGeometry(r, t, 6, 64), key, x, y, z, 1, 1, 1, rotation),
    tube: (key, points, r = 0.2) =>
      put(
        new T.TubeGeometry(
          new T.CatmullRomCurve3(points.map((p) => new T.Vector3(...p))),
          Math.min(160, Math.max(8, points.length * 2)),
          r,
          6,
          false,
        ),
        key,
      ),
    *finish() {
      for (const [mat, list] of batches) {
        yield;
        const geometries = list.map((g) => (g.index ? g.toNonIndexed() : g));
        const merged = mergeGeometries(geometries);
        if (!merged) throw Error("Waterfront batch format mismatch");
        const mesh = new T.Mesh(merged, mat);
        mesh.castShadow = !mat.transparent && mat !== materials.light;
        mesh.receiveShadow = true;
        if (mat === materials.floorGlass) mesh.renderOrder = 3;
        root.add(mesh);
        for (const g of new Set([...list, ...geometries])) g.dispose();
      }
      batches.clear();
    },
  };
}
export function* flowers(root, materials, sites) {
  const petal = new T.SphereGeometry(1, 7, 5),
    leaf = new T.SphereGeometry(1, 7, 4),
    trunk = new T.CylinderGeometry(0.45, 0.72, 1, 7),
    bark = new T.MeshStandardMaterial({ color: 0x75604c, roughness: 0.9 }),
    counts = sites.length * 32,
    blossoms = new T.InstancedMesh(petal, materials.flower, counts),
    leaves = new T.InstancedMesh(leaf, materials.green, sites.length * 12),
    trunks = new T.InstancedMesh(trunk, bark, sites.length),
    dummy = new T.Object3D();
  let p = 0,
    l = 0;
  for (let i = 0; i < sites.length; i++) {
    yield;
    const s = sites[i],
      height = s.palm ? 13 : 7;
    dummy.position.set(s.x, s.y + height / 2, s.z);
    dummy.scale.set(s.palm ? 0.75 : 1, height, 1);
    dummy.rotation.set(0, 0, s.palm ? 0.07 : 0);
    dummy.updateMatrix();
    trunks.setMatrixAt(i, dummy.matrix);
    for (let j = 0; j < 32; j++) {
      const a = j * 2.399963,
        r = (s.palm ? 3 : 4) * Math.sqrt((j + 0.5) / 32);
      dummy.position.set(
        s.x + Math.cos(a) * r,
        s.y + height + Math.sin(j * 2.1) * 1.2,
        s.z + Math.sin(a) * r,
      );
      dummy.rotation.set(0, a, 0.25 * Math.sin(a));
      dummy.scale.set(
        s.palm ? 0.38 : 0.82,
        s.palm ? 0.3 : 0.65,
        s.palm ? 3.4 : 0.82,
      );
      dummy.updateMatrix();
      if (s.palm) {
        blossoms.setColorAt(p, new T.Color(0x8da86b));
      } else
        blossoms.setColorAt(
          p,
          new T.Color().setHSL(
            0.88 + (j % 5) * 0.008,
            0.42,
            0.66 + (j % 3) * 0.04,
          ),
        );
      blossoms.setMatrixAt(p++, dummy.matrix);
    }
    for (let j = 0; j < 12; j++) {
      const a = (j * Math.PI) / 6;
      dummy.position.set(
        s.x + Math.sin(a) * 1.7,
        s.y + 0.65,
        s.z + Math.cos(a) * 1.7,
      );
      dummy.scale.set(0.35, 0.3, 1.6);
      dummy.rotation.set(0.25, a, 0.3);
      dummy.updateMatrix();
      leaves.setMatrixAt(l++, dummy.matrix);
    }
  }
  for (const mesh of [blossoms, leaves, trunks]) {
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    root.add(mesh);
  }
  return { trees: sites.length, blossoms: counts };
}
export function signMesh(text, width, height, color = "#ffe1a6") {
  if (typeof document === "undefined") return new T.Group();
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 256;
  const c = canvas.getContext("2d");
  c.fillStyle = "#3c3043";
  c.fillRect(0, 0, 1024, 256);
  c.strokeStyle = "#d6b16d";
  c.lineWidth = 5;
  c.strokeRect(8, 8, 1008, 240);
  c.fillStyle = color;
  c.textAlign = "center";
  c.textBaseline = "middle";
  c.font = "bold 66px sans-serif";
  const lines = text.split("\n");
  lines.forEach((s, i) =>
    c.fillText(s, 512, 128 + (i - (lines.length - 1) / 2) * 75, 990),
  );
  const t = new T.CanvasTexture(canvas);
  t.colorSpace = T.SRGBColorSpace;
  const m = new T.MeshBasicMaterial({ map: t, toneMapped: false });
  return new T.Mesh(new T.PlaneGeometry(width, height), m);
}
