import {mallPressureDistance,mallPressureContact} from './mall-pressure.js';
import {normalizeOceanExplorer} from './ocean-explorer-state.js';
import {submarineAirborne} from './submarine-controls.js';
import {MOSA_SEA} from './mosasaur-data.js';
import {expansionBedY as mosaBedY} from './mosasaur-expansion.js';
import {mosaTerrainObstacles} from './mosasaur-collision.js';
import {mosaActiveReefClearance as mosaReefClearance} from './mosasaur-reef-data.js';
export const SUBMARINE_DOCK=Object.freeze({x:-6,y:-.85,z:92,yaw:Math.PI});
export const SUBMARINE_MAX_SPEED=36;
export const SUBMARINE_BOOST_SPEED=26.6; // Dock-to-apex height is ~4× after underwater drag and gravity.
export const SUBMARINE_FLIP_SPEED=5.6;
export const SUBMARINE_BOARDING_POINT=Object.freeze({x:0,y:.16,z:96});
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
const hullOffsets=[-1.9,0,1.9];
function overlapsReef(s){return hullOffsets.some(offset=>mosaReefClearance(s.x+Math.sin(s.yaw)*offset,s.y,s.z+Math.cos(s.yaw)*offset)<1.25);}
function overlapsMall(s,radius=1.25){return hullOffsets.some(offset=>mallPressureDistance(s.x+Math.sin(s.yaw)*offset,s.y,s.z+Math.cos(s.yaw)*offset)<radius);}
function escapeChangedMall(raw){
 if(!Number.isFinite(raw.x+raw.y+raw.z+raw.yaw)||!overlapsMall(raw))return raw;
 // A once-valid saved pilot can be inside the newly built glass shell. Keep
 // the pilot active and at the same depth; find nearby open water, never erase
 // its save or silently turn it into an unpiloted docked boat.
 for(let radius=2;radius<=190;radius+=2)for(let i=0;i<32;i++){
  const a=i*Math.PI/16,p={...raw,x:raw.x+Math.sin(a)*radius,z:raw.z+Math.cos(a)*radius};
  if(Math.hypot(p.x/(MOSA_SEA.rx-4),p.z/(MOSA_SEA.rz-4))>=1||p.y<=mosaBedY(p.x,p.z)+1.4||overlapsMall(p,1.5)||overlapsReef(p))continue;
  return p;
 }
 return raw;
}
export function normalizeSubmarine(raw={}){
 raw=escapeChangedMall(raw);
 const valid=Number.isFinite(raw.x+raw.y+raw.z+raw.yaw)&&Math.hypot(raw.x/(MOSA_SEA.rx-4),raw.z/(MOSA_SEA.rz-4))<1&&raw.y>mosaBedY(raw.x,raw.z)+1.1&&raw.y<60&&!overlapsReef(raw)&&!overlapsMall(raw);
 const explorer=normalizeOceanExplorer(raw.explorer);
 return {...(valid?{x:raw.x,y:raw.y,z:raw.z,yaw:wrap(raw.yaw),...(Number.isFinite(raw.pitch)&&Math.abs(raw.pitch)<100000?{pitch:wrap(raw.pitch)}:{})}:SUBMARINE_DOCK),speed:0,vertical:0,turn:0,active:valid&&raw.active===true,mode:raw.mode==='cockpit'?'cockpit':'chase',...(raw.explorerVersion===1?{explorerVersion:1,explorer}:explorer?{explorer}:{}),...(raw.returning===true?{returning:true}:{}),...(raw.released===true?{released:true}:{})};
}
export function submarineAtDock(s){return Math.hypot(s.x-SUBMARINE_DOCK.x,s.z-SUBMARINE_DOCK.z)<4&&Math.abs(s.y-SUBMARINE_DOCK.y)<2.5&&Math.abs(s.speed)<1.1;}
export function submarineSnapshot(s){return {x:s.x,y:s.y,z:s.z,yaw:s.yaw,active:!!s.active,...(Number.isFinite(s.pitch)&&Math.abs(wrap(s.pitch))>1e-7?{pitch:wrap(s.pitch)}:{}),mode:s.mode==='cockpit'?'cockpit':'chase',...(s.explorerVersion===1?{explorerVersion:1,explorer:normalizeOceanExplorer(s.explorer)}:s.explorer?{explorer:normalizeOceanExplorer(s.explorer)}:{}),...(s.returning===true?{returning:true}:{}),...(s.released===true?{released:true}:{})};}
export function pushCapsule(p,o,radius){
 const ax=o.a[0],ay=o.a[1],az=o.a[2],dx=o.b[0]-ax,dy=o.b[1]-ay,dz=o.b[2]-az,t=clamp(((p.x-ax)*dx+(p.y-ay)*dy+(p.z-az)*dz)/(dx*dx+dy*dy+dz*dz||1),0,1),x=p.x-ax-dx*t,y=p.y-ay-dy*t,z=p.z-az-dz*t,d=Math.hypot(x,y,z),gap=radius+o.radius;
 if(d>=gap)return false;if(d<1e-8){p.x+=gap;return true;}const k=(gap-d)/d;p.x+=x*k;p.y+=y*k;p.z+=z*k;return true;
}
export function createSubmarinePhysics(raw,obstacles=mosaTerrainObstacles()){
 const state=normalizeSubmarine(raw);state.pitch||=0;state.flipSpeed=0;let boostCooldown=0;
 function hullFloor(){let floor=-Infinity;for(const offset of [-1.9,0,1.9])floor=Math.max(floor,mosaBedY(state.x+Math.sin(state.yaw)*offset,state.z+Math.cos(state.yaw)*offset)+1.3);return floor;}
 function constrain(previous=null){
  let hit=false;const r=Math.hypot(state.x/(MOSA_SEA.rx-3.5),state.z/(MOSA_SEA.rz-3.5));if(r>1){state.x/=r;state.z/=r;hit=true;}
  let floor=hullFloor();
  if(state.y<floor){
   if(previous&&floor>previous.y+Math.max(.02,Math.hypot(state.x-previous.x,state.z-previous.z)*.8)){state.x=previous.x;state.z=previous.z;state.yaw=previous.yaw;state.speed=0;floor=hullFloor();}
   state.y=Math.max(state.y,floor);state.vertical=Math.max(0,state.vertical);hit=true;
  }
  for(let pass=0;pass<2;pass++)for(const offset of [-1.9,0,1.9]){
   const p={x:state.x+Math.sin(state.yaw)*offset,y:state.y,z:state.z+Math.cos(state.yaw)*offset};
   for(const o of obstacles)if(pushCapsule(p,o,1.25)){state.x=p.x-Math.sin(state.yaw)*offset;state.y=p.y;state.z=p.z-Math.cos(state.yaw)*offset;hit=true;}
  }
  for(let pass=0;pass<3;pass++)for(const offset of hullOffsets){
   const contact=mallPressureContact(state.x+Math.sin(state.yaw)*offset,state.y,state.z+Math.cos(state.yaw)*offset);
   if(!contact)continue;state.x+=contact.nx*(contact.depth+.005);state.y+=contact.ny*(contact.depth+.005);state.z+=contact.nz*(contact.depth+.005);if(contact.ny*state.vertical<0)state.vertical=0;hit=true;
  }
  if(previous&&hit&&hullOffsets.some(offset=>mallPressureContact(state.x+Math.sin(state.yaw)*offset,state.y,state.z+Math.cos(state.yaw)*offset,1.245))){state.x=previous.x;state.y=previous.y;state.z=previous.z;state.yaw=previous.yaw;state.speed=0;state.vertical=0;hit=true;}
  if(previous&&overlapsReef(state)){
   const candidate={x:state.x,y:state.y,z:state.z,yaw:state.yaw};state.x=previous.x;state.z=previous.z;state.yaw=previous.yaw;
   if(overlapsReef(state))state.y=previous.y;
   state.x=candidate.x;state.z=candidate.z;state.yaw=candidate.yaw;
   if(overlapsReef(state)){state.x=previous.x;state.z=previous.z;state.yaw=previous.yaw;state.speed=0;}
   if(state.y===previous.y)state.vertical=0;hit=true;
  }
  if(hit)state.speed*=.72;state.y=Math.max(-198,state.y,hullFloor());return hit;
 }
 function step(dt,input={}){
  dt=clamp(dt,0,.1);if(!state.active)return state;const steps=Math.max(1,Math.ceil(dt*Math.max(10,Math.hypot(state.speed,state.vertical),input.boost?SUBMARINE_BOOST_SPEED:0)/ .45)),h=dt/steps;
  for(let i=0;i<steps;i++){
   const previous={x:state.x,y:state.y,z:state.z,yaw:state.yaw};
   boostCooldown=Math.max(0,boostCooldown-h);const throttle=clamp(input.forward||0,-1,1),steer=clamp(input.turn||0,-1,1),dive=clamp(input.vertical||0,-1,1),submerged=!submarineAirborne(state);
   state.speed+=(throttle*(throttle<0?18:30)-state.speed*(submerged?(throttle?.65:2.5):.12))*h;state.speed=clamp(state.speed,-13.5,SUBMARINE_MAX_SPEED);
   const wantedTurn=steer*(.8+Math.abs(state.speed)*.015);state.turn+=(wantedTurn-state.turn)*(1-Math.exp(-7*h));state.yaw=wrap(state.yaw+state.turn*h);
   if(input.boost&&boostCooldown===0&&submerged){state.vertical=Math.max(state.vertical,SUBMARINE_BOOST_SPEED);boostCooldown=.9;}
   if(submerged){
    state.vertical+=(dive*15-state.vertical*(dive?1.5:3))*h;
    state.flipSpeed=0;state.pitch=wrap(state.pitch)*Math.exp(-7*h);
   }else{
    state.vertical-=9.81*h;
    const wantedFlip=clamp(input.flip||0,-1,1)*SUBMARINE_FLIP_SPEED;
    state.flipSpeed+=(wantedFlip-state.flipSpeed)*(1-Math.exp(-(wantedFlip?9:3)*h));state.pitch+=state.flipSpeed*h;
   }
   state.x+=Math.sin(state.yaw)*state.speed*h;state.z+=Math.cos(state.yaw)*state.speed*h;state.y+=state.vertical*h;
   constrain(previous);
  }return state;
 }
 return {state,step,constrain,snapshot:()=>submarineSnapshot(state),atDock:()=>submarineAtDock(state)};
}
