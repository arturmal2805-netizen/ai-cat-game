import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {SquishSoftBody} from './squish-soft-body.js';
const colours={jelly:0xff75c9,butter:0xffd479,slime:0x9d7aff,cloud:0xffd5ee,foam:0xda8bbf,crunchy:0xff94d5,mochi:0xffcfdf,giant:0xffdccd};
export function squishSurfaceMaterial(type){const matte=['cloud','foam','giant'].includes(type),m=new T.MeshPhysicalMaterial({color:colours[type]||colours.jelly,roughness:matte?.86:type==='butter'?.33:.15,metalness:0,clearcoat:matte?0:1,clearcoatRoughness:.14,sheen:matte?.8:0,sheenColor:new T.Color(0xffe0ee),emissive:colours[type]||colours.jelly,emissiveIntensity:matte?.1:.18,transparent:['jelly','slime','crunchy'].includes(type),opacity:['jelly','slime','crunchy'].includes(type)?.83:1,depthWrite:true});
 m.onBeforeCompile=s=>{s.fragmentShader=s.fragmentShader.replace('#include <fog_fragment>',T.ShaderChunk.fog_fragment.replace('fogFactor );','min(fogFactor,0.08) );'));};m.customProgramCacheKey=()=> 'warehouse-local-squish-pbr-v1';return m;}
// A new toy prop, never a replacement for an approved live cat mesh.
export function createSquishToy({material='jelly',size=[5,4.4,4.5],resolution=[7,7,7]}={}){
 const root=new T.Group();root.name='SquishPhysics · '+material;root.userData.squishPhysics=true;const solver=new SquishSoftBody({material,size,resolution}),meshes=[],sources=[];
 const attach=(geometry,mat,name)=>{const mesh=new T.Mesh(geometry,mat);mesh.name=name;mesh.castShadow=mesh.receiveShadow=true;root.add(mesh);meshes.push(mesh);sources.push(geometry.attributes.position.array.slice());return mesh;};
 const body=new T.SphereGeometry(1,48,32);body.scale(size[0]*.49,size[1]*.37,size[2]*.49);body.translate(0,size[1]*.38,0);attach(body,squishSurfaceMaterial(material),'Soft cat body · volumetric cage skin');
 const earGeos=[];for(const side of [-1,1]){const g=new T.SphereGeometry(1,24,20);g.scale(size[0]*.105,size[1]*.2,size[2]*.13);g.rotateZ(-side*.38);g.translate(side*size[0]*.32,size[1]*.77,0);earGeos.push(g);}const ear=mergeGeometries(earGeos);earGeos.forEach(g=>g.dispose());attach(ear,squishSurfaceMaterial(material),'Independent soft ear regions');
 const dark=new T.MeshStandardMaterial({color:0x542c51,roughness:.4,emissive:0x542c51,emissiveIntensity:.2}),pink=new T.MeshStandardMaterial({color:0xf067b8,roughness:.5,emissive:0x8d275e,emissiveIntensity:.15});
 const face=[];const curve=(points,r=.025)=>{const c=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p)));face.push(new T.TubeGeometry(c,16,r,6,false));};
 const y=size[1]*.47,z=size[2]*.463;for(const side of [-1,1]){const x=side*size[0]*.19;curve([[x-.22,y-.01,z],[x-.13,y+.1,z+.025],[x,y+.15,z+.04],[x+.13,y+.1,z+.025],[x+.22,y-.01,z]],.045);}
 const nose=new T.SphereGeometry(.09,12,8);nose.scale(1,.65,.5);nose.translate(0,y-.15,z+.08);face.push(nose);for(const side of [-1,1])curve([[0,y-.18,z+.08],[side*.14,y-.32,z+.09],[side*.28,y-.25,z+.05]],.033);
 const f=mergeGeometries(face);face.forEach(g=>g.dispose());attach(f,dark,'Smile eyes and nose · surface bound');
 const cheeks=[];for(const side of [-1,1])for(let i=0;i<3;i++){const g=new T.SphereGeometry(1,8,6);g.scale(.14,.018,.015);g.rotateZ(side*.2);g.translate(side*(size[0]*.28),y-.25-i*.09,size[2]*.407);cheeks.push(g);}const cg=mergeGeometries(cheeks);cheeks.forEach(g=>g.dispose());attach(cg,pink,'Pastel cheek marks · surface bound');
 let lastStep=-1;const scratch=new Float64Array(3);
 const update=()=>{if(lastStep===solver.steps)return;lastStep=solver.steps;for(let n=0;n<meshes.length;n++){const g=meshes[n].geometry,a=g.attributes.position,base=sources[n];for(let j=0;j<base.length;j+=3){solver.sample(base[j],base[j+1],base[j+2],scratch);a.array[j]=scratch[0];a.array[j+1]=scratch[1];a.array[j+2]=scratch[2];}a.needsUpdate=true;g.computeVertexNormals();g.computeBoundingSphere();g.computeBoundingBox();}};
 root.userData={...root.userData,solver,meshes,sources,update,material,dispose(){const materials=new Set();for(const m of meshes){m.geometry.dispose();materials.add(m.material);}materials.forEach(m=>m.dispose());root.removeFromParent();}};return root;
}
