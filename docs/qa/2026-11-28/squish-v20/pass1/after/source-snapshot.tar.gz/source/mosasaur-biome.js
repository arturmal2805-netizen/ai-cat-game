import {warehouseExteriorSteps as expansionWarehouseSteps} from './warehouse-exterior.js';
import {WAREHOUSE} from './mosasaur-expansion-data.js';
import {warehouseHabitatSteps} from './warehouse-habitat.js';
import {expansionShorePath,expansionOuterPoint,expansionCoastDecorPoint,expandMosaSeaSteps} from './mosasaur-expansion.js';
import {mosaPierPoles,mosaPierRails} from './resort-pier-link-data.js';
import {floorStoneSteps} from './mosasaur-floor-stones.js';
import {installSandRegionSteps} from './mosasaur-sand-region.js';
import {createCoastMeadowGrass} from './meadow-coast-grass.js';
import {installCoastMeadowSurfaceSteps} from './meadow-coast-surface.js';
import {mosaCoastGardenSteps} from './mosasaur-coast-garden.js';
import {mosaRockReefSteps} from './mosasaur-rock-reefs.js';
import {mosaSeabedPatchSteps} from './mosasaur-seabed-patch.js';
import {mosaOpticalBedY} from './mosasaur-reef-data.js';
import {mosaTerrainSteps} from './mosasaur-terrain.js';
import {createMosaFish} from './mosasaur-fish.js';
import {retainedMosaLand} from './mosasaur-retained-land.js';
import { deepOceanSteps } from "./mosasaur-ocean.js";
import { createGroundCover, placementClearance } from "./landscape-detail.js";
import { mosasaurRideSteps } from "./mosasaur-assets.js";
import * as THREE from "three";
import {
  MOSA_RADIUS,
  MOSA_SEA,
  MOSA_DEPTH,
  MOSA_AREA_EXPANSION,
  MOSA_WATER_AREA_MULTIPLIER,
  MOSA_SHORE_GATE,
  mosaBedY,
  mosaCoastFactor,
  mosaWaterRadius,
  mosaReservations,
} from "./mosasaur-data.js";
import { lagoonSteps, waterfallSteps } from "./lagoon.js";
import {
  shape,
  flowerCluster,
  lantern,
  surfaceTexture,
} from "./fantasy-scenery.js";
import { batchModelSteps } from "./model-batching.js";
import { runSceneSteps } from "./scene-tasks.js";
import {
  sceneryModelSteps,
  positionScenery,
  disposeScenery,
} from "./scenery-models.js";
import { BIOME_STYLES } from "./biome-styles.js";
import { junglePalmSteps, jungleFlowers } from "./jungle-props.js";
function coastPath(path,margin=0){return expansionShorePath(path,margin);}
function shoreGeometry() {
  const shape = new THREE.Shape();
  expansionShorePath(shape,0,true);
  const hole = new THREE.Path();
  coastPath(hole);
  shape.holes.push(hole);
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.3,
    bevelEnabled: false,
    curveSegments: 64,
  });
  geo.rotateX(-Math.PI / 2);
  geo.translate(0, -0.16, 0);
  return geo;
}
function* bake(source, parent) {
  const result = yield* batchModelSteps(source, { combineColors: true });
  parent.add(result);
  source.traverse((o) => {
    if (o.isMesh && !o.geometry.userData.sharedScenery) o.geometry.dispose();
  });
  return result;
}
export function* mosasaurBiomeSteps(
  biome,
  { preview = false, lowOnly = false, placements = [], scenery = [] } = {},
) {
  const root = new THREE.Group(),
    base = new THREE.Group(),
    detail = new THREE.Group(),
    low = new THREE.Group(),
    lagoons = new Map(),
    sceneryObjects = new Map(),
    animations = [],
    props = new THREE.Group();
  root.name = "Biome-autumn-Sky-Mosasaur-Sea";
  root.add(base, detail, low);
  root.userData = {
    biomeId: "autumn",
    navigationSurface: base,
    detail,
    lowDetail: low,
    lowOnly,
    lagoons,
    sceneryObjects,
    style: BIOME_STYLES.autumn,
    stats: { fishCount: lowOnly ? 0 : 48, staticMeshes: 0, sourceMeshes: 0 },
    ocean: { depth: MOSA_DEPTH, areaMultiplier: 25*MOSA_AREA_EXPANSION, waterArea: Math.PI*MOSA_SEA.rx*MOSA_SEA.rz },
  };
  const shore = new THREE.Mesh(
    shoreGeometry(),
    new THREE.MeshStandardMaterial({
      color: 0xa4bf80,
      roughness: 0.92,
      map: surfaceTexture("lawn"),
    }),
  );
  const navigation = new THREE.Group();navigation.name='Dry shore, original pier and retained owned plots';
  base.add(navigation);root.userData.navigationSurface=navigation;
  shore.name = "Wide dry beaches and walkable island ring";
  shore.receiveShadow = true;
  const meadowSurface=!lowOnly&&(yield* installCoastMeadowSurfaceSteps(shore));
  navigation.add(shore);
  const beachOutline = new THREE.Shape();
  coastPath(beachOutline,3.7);
  const beachHole = new THREE.Path();
  coastPath(beachHole);
  beachOutline.holes.push(beachHole);
  const sandGeometry = new THREE.ShapeGeometry(beachOutline, 64);
  sandGeometry.rotateX(-Math.PI / 2);
  const sand = new THREE.Mesh(
    sandGeometry,
    new THREE.MeshStandardMaterial({
      color: 0xe9dcbb,
      roughness: 0.93,
      map: surfaceTexture("ground"),
    }),
  );
  sand.position.y = 0.15;
  sand.receiveShadow = true;
  base.add(sand);
  const pier=new THREE.Mesh(new THREE.BoxGeometry(2.2,.17,MOSA_SHORE_GATE.z-23+1),new THREE.MeshStandardMaterial({color:0xc39860,map:surfaceTexture('wood'),roughness:.72}));
  pier.position.set(0,.19,(23+MOSA_SHORE_GATE.z+1)/2);pier.name='Extended dry approach to the original pickup pier';pier.receiveShadow=true;navigation.add(pier);
  const arrivalSupport=new THREE.Mesh(new THREE.BoxGeometry(9,.3,9),pier.material);arrivalSupport.position.set(MOSA_SHORE_GATE.x,.03,MOSA_SHORE_GATE.z);arrivalSupport.name='Preserved original pressure-lift shore landing';navigation.add(arrivalSupport);
  const rail=new THREE.Group();
  for(const {x,z}of mosaPierPoles(MOSA_SHORE_GATE.z))shape(rail,'pole',0x9a7648,x,.65,z,.055,.9,.055);
  for(const {x,a,b}of mosaPierRails(MOSA_SHORE_GATE.z))shape(rail,'cube',0xc7a16a,x,1.04,(a+b)/2,.055,.055,b-a);
  // A real side gangplank reaches the submarine's hatch. The original pickup
  // pier remains at its released coordinates; the boarding walk stays dry.
  const gangplank=new THREE.Mesh(new THREE.BoxGeometry(1.65,.17,Math.hypot(3.8,2.5)),pier.material);
  gangplank.position.set(-1.9,.19,94.75);gangplank.rotation.y=Math.atan2(3.8,2.5);gangplank.name='Submarine side gangplank';gangplank.receiveShadow=true;navigation.add(gangplank);
  yield* bake(rail,base);

  const cliff = new THREE.Mesh(
    new THREE.CylinderGeometry(
      MOSA_RADIUS - 0.1,
      MOSA_RADIUS - 3,
      MOSA_DEPTH+3,
      384,
      6,
      true,
    ),
    new THREE.MeshStandardMaterial({
      color: 0x8d9996,
      roughness: 0.9,
      map: surfaceTexture("stone"),
      side: THREE.DoubleSide,
    }),
  );
  const cliffPositions = cliff.geometry.attributes.position,
    cliffColors = [];
  for (let i = 0; i < cliffPositions.count; i++) {
    const x = cliffPositions.getX(i),
      y = cliffPositions.getY(i),
      z = cliffPositions.getZ(i),
      a = Math.atan2(x, z),
      t = ((MOSA_DEPTH+3)/2 - y) / (MOSA_DEPTH+3);
    const noise =
      (Math.sin(a * 7 + t * 3) + Math.cos(a * 11 - t * 5)) *
      0.055 *
      (0.25 + t * 0.75);
    cliffPositions.setX(i, x * (1 + noise));
    cliffPositions.setZ(i, z * (1 + noise));
    const c = new THREE.Color(
      [0xb1b0a0, 0x8d9c99, 0xa6a999][Math.floor((a + Math.PI) * 9) % 3],
    );
    c.multiplyScalar(0.82 + Math.sin(a * 13 + t * 8) * 0.08 + t * 0.12);
    cliffColors.push(c.r, c.g, c.b);
  }
  cliff.geometry.setAttribute(
    "color",
    new THREE.Float32BufferAttribute(cliffColors, 3),
  );
  for(let i=0;i<cliffPositions.count;i++){const x=cliffPositions.getX(i),z=cliffPositions.getZ(i),a=Math.atan2(z/MOSA_SEA.rz,x/MOSA_SEA.rx),p=expansionOuterPoint(a),ratio=1+Math.min(1.5/Math.hypot(p.x,p.z),Math.max(0,Math.hypot(x,z)/(MOSA_RADIUS-.1)-1)*.2);cliffPositions.setX(i,p.x*ratio);cliffPositions.setZ(i,p.z*ratio);}
  cliff.geometry.computeVertexNormals();
  cliff.material.color.set(0xffffff);
  cliff.material.vertexColors = true;
  cliff.material.flatShading = true;
  cliff.position.y = -(MOSA_DEPTH+3)/2-.15;
  base.add(cliff);
  const bottom = shape(
    base,
    "cone",
    0x828c99,
    0,
    -MOSA_DEPTH-12,
    0,
    MOSA_RADIUS - 3,
    24,
    MOSA_RADIUS - 3,
  );
  bottom.rotation.z = Math.PI;
  // The expanded bed dips below the old -200m cone cap. Bury this purely
  // decorative underside so it cannot show as a grey patch through the sand.
  bottom.position.y = Math.min(bottom.position.y-12, WAREHOUSE.y-32);
  bottom.name = 'Buried decorative island underside';
  yield;
  // The same water/fish engine, with a physically much deeper basin. Nothing
  // changes for the pre-existing lagoon material or basin defaults.
  const sea = yield* lagoonSteps({
    rx: MOSA_SEA.rx,
    rz: MOSA_SEA.rz,
    depth: MOSA_DEPTH,
    bedHeight:mosaBedY,
    opticalBedHeight:mosaOpticalBedY,
    // Keep the released metre-scale sampling when WATER area doubles. Other
    // lagoons retain their native topology and the shared shader/texture core.
    bedResolution:(lowOnly?[96,48]:[256,160]).map(n=>Math.ceil(n*Math.sqrt(MOSA_WATER_AREA_MULTIPLIER)/4)*4),
    surfaceResolution:[192,128].map(n=>Math.ceil(n*Math.sqrt(MOSA_WATER_AREA_MULTIPLIER)/4)*4),
    coastFactor:mosaCoastFactor,
    fishCount: 0,
    color: 0x12bed8,
    bedColor: 0xc8d5bb,
    wallColor: 0x69adbf,
    shoreColor: 0xb8efff,
  });
  sea.name = "Deep ocean · 40 times the previous sea depth";
  sea.userData.water.uniforms.uOpacity.value = 0.46;
  root.userData.ocean.expansion=yield* expandMosaSeaSteps(sea);root.userData.ocean.releasedWaterArea=root.userData.ocean.waterArea;root.userData.ocean.waterArea=root.userData.ocean.expansion.waterAreaM2;
  const warehouse=yield* expansionWarehouseSteps();base.add(warehouse);root.userData.ocean.warehouse=warehouse;
  root.userData.ocean.sea = sea;
  lagoons.set("lake-autumn", sea);
  base.add(sea);
  if(!lowOnly){root.userData.ocean.sandRegion=yield* installSandRegionSteps(sea.userData.bed);const stones=yield* floorStoneSteps(sea.userData.bed);detail.add(stones);root.userData.ocean.floorStones=stones;}
  animations.push(sea);
  if (!lowOnly) {
    const reefs=yield* mosaRockReefSteps();detail.add(reefs);animations.push(reefs);root.userData.ocean.reefs=reefs;
    const coastline=yield* mosaCoastGardenSteps(placements);detail.add(coastline);animations.push(coastline);root.userData.ocean.coastline=coastline;
    const terrain=yield* mosaTerrainSteps();detail.add(terrain);animations.push(terrain);root.userData.ocean.terrain=terrain;
    const fish=createMosaFish();sea.add(fish);animations.push(fish);sea.userData.fishCount=48;sea.userData.tropicalFish=fish;const disturb=sea.userData.disturb;sea.userData.disturb=(...args)=>{disturb(...args);fish.userData.disturb(...args);};
    const depths = yield* deepOceanSteps();
    detail.add(depths);
    animations.push(depths);
    const reefPatch=yield* mosaSeabedPatchSteps();detail.add(reefPatch);animations.push(reefPatch);root.userData.ocean.reefPatch=reefPatch;
    const habitat=yield* warehouseHabitatSteps();detail.add(habitat);animations.push(habitat);root.userData.ocean.warehouseHabitat={colonies:habitat.userData.colonies,fishCount:habitat.userData.fishCount,pockets:habitat.userData.reefPockets};
    root.userData.ocean.extraDrawCalls = depths.userData.drawCalls;
  }
  yield;
  // Visible rock ribs run all the way down to the basin, not a shallow decal.
  for (let i = 0; i < 56; i++) {
    yield;
    const a = (i / 56) * Math.PI * 2,
      x = Math.sin(a),
      z = Math.cos(a),
      r = MOSA_RADIUS - 0.65;
    shape(
      props,
      "stone",
      [0x9faaa0, 0xb6b6a2, 0x7d8f96][i % 3],
      x * r,
      -4.7 - (i % 4) * 1.2,
      z * r,
      1.45,
      1.7 + (i % 5) * 0.35,
      1.7,
    );
    if (i % 3 === 0)
      shape(
        props,
        "stone",
        0x6f8190,
        x * (r - 1),
        -21 - (i % 4),
        z * (r - 1),
        1.5,
        4.3,
        1.7,
      );
    if (!lowOnly && i % 2 === 0)
      for (let j = 0; j < 4; j++)
        shape(
          props,
          "petal",
          [0x6c9e64, 0x86ad79][j % 2],
          x * (MOSA_RADIUS - 0.1 - j * 0.04),
          -0.35 - j * 0.73,
          z * (MOSA_RADIUS - 0.1 - j * 0.04),
          0.35,
          0.54,
          0.38,
        );
    // Soft vegetation is concentrated on outer shores, leaving the sea open.
    if (!lowOnly && i % 3 === 0) {
      const px = x * (MOSA_SEA.rx+4),
        pz = z * (MOSA_SEA.rz+4);
      jungleFlowers(
        props,
        px,
        0.15,
        pz,
        1.05,
        [0xffd0b2, 0xf4b4cd, 0xe8e1b0][i % 3],
      );
      if (i % 6 === 0) lantern(props, px - 0.8, 0.15, pz, 0.65);
    }
  }
  for(const o of props.children){const p=expansionCoastDecorPoint(o.position.x,o.position.z,{outer:o.position.y<0});o.position.x=p.x;o.position.z=p.z;}
  const cliffs = yield* bake(props, base);
  root.userData.stats.staticMeshes = cliffs.children.length;
  root.userData.stats.sourceMeshes = cliffs.userData.sourceMeshes;
  if (!lowOnly) {
    const gardens = new THREE.Group();
    for (const a of [0.8, 2.8, 4.6]) {
      const patch = shape(
        gardens,
        "sphere",
        0x8eb47a,
        Math.sin(a) * (MOSA_SEA.rx+4.1),
        0.12,
        Math.cos(a) * (MOSA_SEA.rz+4.1),
        3.5,
        0.055,
        2.1,
      );
      patch.rotation.y = a;
    }
    for (let i = 0; i < 100; i++) {
      yield;
      const a = i * 2.399,
        r = MOSA_SEA.rx+2.2 + (i % 7) * 0.55,
        x = Math.sin(a) * r,
        z = Math.cos(a) * r;
      if (Math.abs(x) < 2 && z > 19) continue;
      flowerCluster(gardens, x, z, [0xffcdd6, 0xffe4ac, 0xd3edc0][i % 3], 0.65);
      // A gently curving walking route circles the shore.
      if (i % 2 === 0)
        shape(
          gardens,
          "stone",
          0xf3e8ce,
          Math.sin(a) * (MOSA_SEA.rx+2.2),
          0.16,
          Math.cos(a) * (MOSA_SEA.rz+2.2),
          0.52,
          0.04,
          0.42,
        );
    }
    for(const o of gardens.children){const p=expansionCoastDecorPoint(o.position.x,o.position.z);o.position.x=p.x;o.position.z=p.z;}
    const flowers = yield* bake(gardens, detail);
    root.userData.stats.staticMeshes += flowers.children.length;
    root.userData.stats.sourceMeshes += flowers.userData.sourceMeshes;
  }
  for (const [a, width, height] of [
    [0.4, 3.1, 32],
    [1.8, 2.5, 30],
    [3.3, 3.7, 35],
    [4.8, 2.8, 31],
    [5.7, 2, 28],
  ]) {
    yield;
    const fall = yield* waterfallSteps(
      Math.sin(a) * (MOSA_RADIUS - 0.2),
      Math.cos(a) * (MOSA_RADIUS - 0.2),
      width,
      height + 18,
      { color: 0x83dced },
    );
    const coastFall=expansionCoastDecorPoint(fall.position.x,fall.position.z,{outer:true});fall.position.x=coastFall.x;fall.position.z=coastFall.z;
    fall.rotation.y = a;
    detail.add(fall);
    animations.push(fall);
  }
  // Below-island clouds make the large floating foundation legible at a glance.
  const clouds = new THREE.Group();
  clouds.name = "Cloud bank far beneath the floating ocean";
  for (let i = 0; i < 15; i++) {
    yield;
    const a = i * 2.4;
    shape(
      clouds,
      "sphere",
      0xe1e7f6,
      Math.sin(a) * (MOSA_RADIUS*.8),
      -MOSA_DEPTH-26 - (i % 4) * 1.4,
      Math.cos(a) * (MOSA_RADIUS*.8),
      7 + (i % 3),
      1.4,
      4.8,
    );
  }
  yield* bake(clouds, base);
  root.userData.scenerySteps = function* (records = []) {
    const visible = records.filter((r) => !r.stored && r.biome === "autumn");
    for (const [id, g] of sceneryObjects)
      if (!visible.some((r) => r.id === id)) {
        detail.remove(g);
        disposeScenery(g);
        sceneryObjects.delete(id);
        yield;
      }
    if (!lowOnly)
      for (const r of visible) {
        yield;
        let g = sceneryObjects.get(r.id);
        if (!g) {
          g = yield* sceneryModelSteps(r);
          detail.add(g);
          sceneryObjects.set(r.id, g);
        }
        positionScenery(g, r);
      }
    root.userData.trees = visible.filter((r) =>
      r.type.startsWith("scenery-tree-"),
    );
  };
  root.userData.updateScenery = (...args) =>
    runSceneSteps(root.userData.scenerySteps(...args));
  let meadowServices=null,meadowEye=null,meadowActive=false;
  let sod = null, cover = null,
    coverKey = "", retained=null;
  root.userData.placementSteps = function* (items = [], records = []) {
    yield* root.userData.scenerySteps(records);
    const key = JSON.stringify([items, records]);
    if (lowOnly || key === coverKey) return;
    coverKey = key;
    if(retained){navigation.remove(retained);disposeScenery(retained);}
    const zones=retainedMosaLand(items,records),source=new THREE.Group();
    for(const p of zones){const mesh=shape(source,'cube',p.kind==='pad'?0xd8d5bc:0xbf985e,p.x,.055,p.z,p.w,.17,p.d);mesh.rotation.y=p.yaw;}
    retained=yield* bake(source,navigation);retained.name='Dry land supporting existing owned shoreline addresses';root.userData.retainedDryZones=zones;
    yield;
    if (cover) {
      detail.remove(cover);
      disposeScenery(cover);
    }
    const clear = placementClearance([
      ...items,
      ...records
        .filter((r) => !r.stored)
        .map((r) => ({ ...r, footprint: [2.4, 2.4] })),
    ]);
    cover = createGroundCover(BIOME_STYLES.autumn, "mosasaur-shore", {
      radius: MOSA_RADIUS - 1,
      density: 0.8,
      clearance: (x, z, w, d) =>
        clear(x, z, w, d) &&
        mosaWaterRadius(x,z)>1.045 &&
        expansionCoastDecorPoint(x,z).x===x &&
        !(Math.abs(x) < 2 && z > 18),
    });
    detail.add(cover);
    const nextSod=meadowSurface?createCoastMeadowGrass(clear):null;
    if(sod){sod.userData.dispose?.();detail.remove(sod);disposeScenery(sod);}
    sod=nextSod;if(sod){detail.add(sod);if(meadowServices)sod.userData.configureMeadow(meadowServices);if(meadowEye)sod.userData.updateView(meadowEye,meadowActive);}
  };
  root.userData.configureMeadow=services=>{meadowServices=services;sod?.userData.configureMeadow?.(services);};
  root.userData.updateMeadowView=(eye,active)=>{if(!meadowEye)meadowEye=new THREE.Vector3();meadowEye.copy(eye);meadowActive=active;sod?.userData.updateView?.(eye,active);};
  root.userData.meadowState=()=>sod?.userData.meadowState?.();
  root.userData.updatePlacements = (...args) =>
    runSceneSteps(root.userData.placementSteps(...args));
  yield* root.userData.placementSteps(placements, scenery);
  if (preview && !lowOnly) {
    const ride = yield* mosasaurRideSteps("ride-mosasaur");
    ride.userData.rideElapsed = 32;
    ride.userData.update(0, true);
    detail.add(ride);
    animations.push(ride);
  }
  root.userData.update = (time, reduced = false) => {
    for (const g of animations) g.userData.update?.(time, reduced);
    cover?.userData.update?.(time, reduced);
    sod?.userData.update?.(time, reduced);
  };
  detail.visible = !lowOnly;
  low.visible = lowOnly;
  root.userData.dispose = () => {sod?.userData.dispose?.();disposeScenery(root);};
  return root;
}
