import {isStaticSubmissionShader,registerPositionPreservingShader} from './static-submissions.js';
import {MALL_FINISH_REFLECTION} from './mall-surfaces.js';
import {mallSurfaceUVKey,writeMallSurfaceUVsSteps} from './mall-surface-uv.js';
import * as T from 'three';
import {copyGeometryBuffers} from './geometry-tasks.js';
import {mosaWaterReflection} from './mosasaur-water-probe.js';

// One immutable 2 KiB light table for the new rooms. A byte per vertex chooses
// its own room, so a warm shop never lights through the next shop's wall.
// Native cats retain their approved materials and the normal scene lighting.
export function createMallRoomLights(){
  const size=64,data=new Float32Array(size*2*4),texture=new T.DataTexture(data,size,2,T.RGBAFormat,T.FloatType);
  texture.name='Mall bounded room lamps';texture.magFilter=texture.minFilter=T.NearestFilter;texture.generateMipmaps=false;
  let next=1;const copies=new Map();
  return {texture,
    register(x,z,color=0xffd6a0){
      if(next>=size)throw Error('Mall room light table is full');
      const id=next++,c=new T.Color(color);data.set([x,6.4,z,21],id*4);data.set([c.r,c.g,c.b,2.8],(size+id)*4);return id;
    },
    *stamp(root,id=0){
      root.updateWorldMatrix(true,true);const meshes=[];root.traverse(o=>{if(o.isMesh&&!o.geometry.hasAttribute('aMallRoom'))meshes.push(o);});
      for(const mesh of meshes){
        yield;let cut=!!mesh.userData.mallCutaway;mesh.traverseAncestors(p=>{if(p.userData.mallCutaway)cut=true;});const variant=(id*2+Number(cut))+':'+mallSurfaceUVKey(mesh);
        let variants=copies.get(mesh.geometry);if(!variants)copies.set(mesh.geometry,variants=new Map());
        let geometry=variants.get(variant);
        if(!geometry){geometry=copyGeometryBuffers(mesh.geometry);geometry.userData={...geometry.userData,sharedScenery:false};yield* writeMallSurfaceUVsSteps(mesh,geometry);const count=geometry.attributes.position.count;geometry.setAttribute('aMallRoom',new T.Uint8BufferAttribute(new Uint8Array(count).fill(id),1));geometry.setAttribute('aMallCutaway',new T.Uint8BufferAttribute(new Uint8Array(count).fill(Number(cut)),1));variants.set(variant,geometry);}
        mesh.geometry=geometry;
      }
    },
    finishFloor(){copies.clear();},finish(){copies.clear();texture.needsUpdate=true;},
  };
}
const roomPrograms=new WeakMap();
export function mallRoomLightMaterial(material,lights,gain=.18){
  const known=roomPrograms.get(material);if(known?.lights===lights&&known.gain===gain&&known.hook===material.onBeforeCompile)return material;
  const composeStatic=isStaticSubmissionShader(material),probe=mosaWaterReflection(),previous=material.onBeforeCompile,previousKey=material.customProgramCacheKey,key=previousKey.call(material);
  material.onBeforeCompile=function(s,...args){
    if(composeStatic)previous.call(this,s,...args);
    s.uniforms.uMallRoomLamps={value:lights.texture};s.uniforms.uMallProbe={value:probe.texture};s.uniforms.uMallProbeGain={value:probe.gain*gain};
    s.vertexShader='attribute float aMallRoom;uniform sampler2D uMallRoomLamps;varying vec3 vMallLamp;varying vec4 vMallLampColor;varying float vMallLampRange;\n'+s.vertexShader;
    s.vertexShader=s.vertexShader.replace('#include <project_vertex>',`#include <project_vertex>
      vec4 roomLamp=texture2D(uMallRoomLamps,vec2((aMallRoom+.5)/64.,.25));
      vMallLamp=(modelViewMatrix*vec4(roomLamp.xyz,1.)).xyz-mvPosition.xyz;
      vMallLampColor=texture2D(uMallRoomLamps,vec2((aMallRoom+.5)/64.,.75));
      vMallLampRange=roomLamp.w;`);
    s.fragmentShader='uniform sampler2D uMallProbe;uniform float uMallProbeGain;varying vec3 vMallLamp;varying vec4 vMallLampColor;varying float vMallLampRange;\n'+s.fragmentShader;
    s.fragmentShader=s.fragmentShader.replace('#include <opaque_fragment>',`
      float lampDistance=length(vMallLamp);
      vec3 lampDirection=vMallLamp/max(.001,lampDistance);
      float lampFalloff=pow(max(0.,1.-lampDistance/max(.001,vMallLampRange)),2.);
      float lampDiffuse=max(0.,dot(normal,lampDirection));
      vec3 lampHalf=normalize(lampDirection+normalize(vViewPosition));
      float lampSpecular=pow(max(0.,dot(normal,lampHalf)),mix(90.,8.,roughnessFactor));
      outgoingLight+=vMallLampColor.rgb*vMallLampColor.a*(diffuseColor.rgb*(.18+lampFalloff*.88*lampDiffuse)+lampFalloff*lampSpecular*(.12+.3*metalnessFactor));
      ${MALL_FINISH_REFLECTION}
      #include <opaque_fragment>`);
  };
  material.customProgramCacheKey=()=>key+`-mall-room-finish-v2-${gain}`;if(composeStatic)registerPositionPreservingShader(material,previous,previousKey);roomPrograms.set(material,{lights,gain,hook:material.onBeforeCompile});return material;
}
