import { NEIGHBORS } from "./game-data.js";
import { catSex } from "./cat-sex.js";
export const FAMILY_REVIEW_DAYS = 14;
export const FAMILY_SHARE = 4;
const clone = (value) => structuredClone(value);
const idValid = (id) => typeof id === "string" && /^[\w-]{1,40}$/.test(id);
const integer = (n) => Number.isSafeInteger(n) && n >= 0;
const dateFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Europe/Kyiv",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});
const dayFormatter = new Intl.DateTimeFormat("uk-UA", {
  day: "numeric",
  month: "long",
  timeZone: "UTC",
});
const kyivDate = (now) => dateFormatter.format(now);
export function newFamily(day, now = Date.now()) {
  return {
    version: 1,
    calendar: { startDay: day, startedAt: now, startDate: kyivDate(now) },
    lastReviewDay: day - 1,
    couples: {},
  };
}
export function familySnapshotValid(family) {
  if (family == null) return true;
  if (
    family.version !== 1 ||
    !integer(family.calendar?.startDay) ||
    !Number.isFinite(family.calendar.startedAt) ||
    !/^\d{4}-\d{2}-\d{2}$/.test(family.calendar.startDate || "") ||
    !Number.isFinite(Date.parse(family.calendar.startDate + "T12:00:00Z")) ||
    !Number.isSafeInteger(family.lastReviewDay) ||
    !family.couples ||
    typeof family.couples !== "object" ||
    Array.isArray(family.couples)
  )
    return false;
  const members = new Set();
  for (const [id, pair] of Object.entries(family.couples)) {
    if (
      !pair ||
      id !== pair.id ||
      id !== `family-${pair.male}-${pair.female}` ||
      !idValid(pair.male) ||
      !idValid(pair.female) ||
      pair.male === pair.female ||
      catSex(pair.male) !== "male" ||
      catSex(pair.female) !== "female" ||
      members.has(pair.male) ||
      members.has(pair.female) ||
      !integer(pair.formedDay) ||
      !Number.isFinite(pair.formedAt) ||
      pair.source !== "ai" ||
      typeof pair.reason !== "string" ||
      pair.reason.length > 160
    )
      return false;
    members.add(pair.male);
    members.add(pair.female);
  }
  return true;
}
export function normalizeFamily(raw) {
  if (raw == null) return null;
  if (!familySnapshotValid(raw)) throw Error("Пошкоджено збереження сімей");
  return clone(raw);
}
export function ensureFamily(game, day, now = Date.now()) {
  if (!game.jobCity || game.family) return game;
  return { ...game, family: newFamily(day, now) };
}
export function familyPartners(game) {
  const partners = new Map();
  for (const pair of Object.values(game.family?.couples || {})) {
    partners.set(pair.male, pair.female);
    partners.set(pair.female, pair.male);
  }
  return partners;
}
export function familyPartner(game, id) {
  return familyPartners(game).get(id) || null;
}
// Every cat can eventually find a family. The quarter-roster rule controls
// the pace of NEW introductions, never the lifetime number of families.
export const familyLimit = (profiles) =>
  Math.min(
    profiles.filter((p) => catSex(p) === "male").length,
    profiles.filter((p) => catSex(p) === "female").length,
  );
export const familyReviewLimit = (profiles) =>
  Math.max(1, Math.floor(profiles.length / (FAMILY_SHARE * 2)));
export function familyReview(game, day) {
  const state = game.family;
  const profiles = Object.values(game.jobCity?.profiles || {});
  const partners = familyPartners(game);
  const capacity = familyLimit(profiles.filter((p) => !partners.has(p.id)));
  // Released clients counted an empty AI answer as a completed review. If no
  // family ever formed, keep the original first introduction due instead of
  // postponing it another fortnight. Calendar and permanent pairs stay intact.
  const lastReview = state && Object.keys(state.couples).length === 0
    ? Math.min(state.lastReviewDay, state.calendar.startDay - 1)
    : state?.lastReviewDay;
  return {
    due:
      !!state &&
      day >= lastReview + FAMILY_REVIEW_DAYS &&
      capacity > 0,
    slots: Math.min(familyReviewLimit(profiles), capacity),
    nextDay: state
      ? lastReview + FAMILY_REVIEW_DAYS
      : day + FAMILY_REVIEW_DAYS - 1,
    interval: FAMILY_REVIEW_DAYS,
  };
}
export function familyCalendar(game, day) {
  const calendar = game.family?.calendar;
  const number = Math.max(1, day - (calendar?.startDay ?? day) + 1);
  const date = new Date(
    (calendar?.startDate || kyivDate(Date.now())) + "T12:00:00Z",
  );
  date.setUTCDate(date.getUTCDate() + number - 1);
  return {
    number,
    date: date.toISOString().slice(0, 10),
    label: `День ${number} · ${dayFormatter.format(date)}`,
  };
}
export function validateFamilyProposals(
  proposals,
  profiles,
  slots = familyReviewLimit(profiles),
) {
  if (!Array.isArray(proposals) || proposals.length > slots)
    throw Error("Некоректний вибір сімей");
  const people = new Map(profiles.map((p) => [p.id, p]));
  const used = new Set();
  return proposals.map((pair) => {
    const male = people.get(pair?.male),
      female = people.get(pair?.female);
    if (
      !male ||
      !female ||
      catSex(male) !== "male" ||
      catSex(female) !== "female" ||
      male.partner ||
      female.partner ||
      used.has(male.id) ||
      used.has(female.id)
    )
      throw Error("AI має вибрати двох вільних сумісних котиків");
    used.add(male.id);
    used.add(female.id);
    return {
      male: male.id,
      female: female.id,
      reason: String(pair.reason || "Подобаються одне одному").slice(0, 160),
    };
  });
}
// Called only for a successful real-AI daily response. Local fallbacks cannot
// create families, and replayed responses cannot change a lifelong partner.
export function applyFamilyDecisions(
  game,
  day,
  proposals = [],
  now = Date.now(),
) {
  const review = familyReview(game, day);
  if (!review.due) return game;
  const partners = familyPartners(game);
  const profiles = Object.values(game.jobCity.profiles).map((p) => ({
    ...p,
    partner: partners.get(p.id) || null,
  }));
  const valid = validateFamilyProposals(proposals, profiles, review.slots);
  if (!valid.length) return game;
  const next = clone(game);
  next.family.lastReviewDay = day;
  for (const pair of valid) {
    const id = `family-${pair.male}-${pair.female}`;
    next.family.couples[id] = {
      ...pair,
      id,
      formedDay: day,
      formedAt: now,
      source: "ai",
    };
    // A venue kitten becomes a permanent resident when it starts a family.
    // Storing the counter must never remove someone's lifelong partner.
    for (const member of [pair.male, pair.female])
      if (
        NEIGHBORS.find((n) => n.id === member)?.venue &&
        !next.unlocked.includes(next.catDestinations[member])
      )
        next.catDestinations[member] = next.unlocked.includes("jobcity")
          ? "jobcity"
          : "moon";
  }
  return reconcileFamilyHomes(next);
}
// A permanent couple shares its earliest purchased home. Retain removed
// duplicates in a receipt archive so cached devices cannot resurrect them.
function firstFamilyHome(game, members) {
  let first = null;
  for (const home of Object.values(game.housing?.homes || {}))
    if (members.includes(home.owner) && (!first || home.at < first.at || (home.at === first.at && home.id < first.id))) first = home;
  return first;
}
export function familyHome(game, id) {
  const partner = familyPartner(game, id);
  return partner ? firstFamilyHome(game,[id,partner]) : null;
}
export function reconcileFamilyHomes(game) {
  if (!game.family || !game.housing) return game;
  const housing = game.housing;
  for (const pair of Object.values(game.family.couples)) {
    const members = [pair.male, pair.female], home = firstFamilyHome(game, members);
    if (!home) continue;
    for (const old of Object.values(housing.homes)) {
      if (old.id === home.id) continue;
      if (members.includes(old.owner)) {
        housing.retiredHomes ||= {};
        housing.retiredHomes[old.id] ||= { ...clone(old), replacedBy: home.id };
        delete housing.homes[old.id];
        for (const [cat, id] of Object.entries(housing.residences))
          if (id === old.id) delete housing.residences[cat];
      } else if (members.includes(old.roommate)) old.roommate = null;
    }
    const spouse = members.find(id => id !== home.owner);
    if (home.roommate && home.roommate !== spouse && housing.residences[home.roommate] === home.id)
      delete housing.residences[home.roommate];
    home.roommate = spouse;
    for (const id of members) housing.residences[id] = home.id;
  }
  return game;
}
export function mergeFamily(base, current, incoming) {
  if (!incoming) return current ? clone(current) : null;
  if (!current) return normalizeFamily(incoming);
  if (!familySnapshotValid(incoming) || !familySnapshotValid(current))
    throw Error("Неповна сім'я у збереженні");
  const next = clone(current),
    members = familyPartners({ family: current });
  for (const [id, pair] of Object.entries(incoming.couples)) {
    if (next.couples[id]) {
      if (JSON.stringify(next.couples[id]) !== JSON.stringify(pair))
        throw Error("Постійну сім'ю вже збережено з іншими даними");
      continue;
    }
    if (members.has(pair.male) || members.has(pair.female))
      throw Error("Партнера вже обрано на іншому пристрої");
    next.couples[id] = clone(pair);
    members.set(pair.male, pair.female);
    members.set(pair.female, pair.male);
  }
  next.lastReviewDay = Math.max(current.lastReviewDay, incoming.lastReviewDay);
  return next;
}

// Concurrent phones must not each spend the same introduction budget. Use a
// rolling review interval so responses arriving on adjacent days cannot bypass
// it. Older saved couples remain valid, even if an old client exceeded today's
// pacing rule; only additional families can be rejected.
export function checkFamilyPace(current, merged, profiles) {
  if (!current) return; // Import a pre-existing world without losing its history.
  const before = Object.values(current?.couples || {}),
    after = Object.values(merged?.couples || {}),
    limit = familyReviewLimit(profiles);
  for (const pair of after) {
    const inWindow = (p) =>
      p.formedDay <= pair.formedDay &&
      p.formedDay > pair.formedDay - FAMILY_REVIEW_DAYS;
    if (
      after.filter(inWindow).length >
      Math.max(limit, before.filter(inWindow).length)
    )
      throw Error(
        "Нові сім’ї вже обрано на іншому пристрої. Наступні знайомства — через 14 ігрових днів.",
      );
  }
}
