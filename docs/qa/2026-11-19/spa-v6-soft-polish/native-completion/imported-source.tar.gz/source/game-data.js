import {SHOWCASE_WATER_RIDES} from './showcase-water-data.js';
import {ZOO_BIOME,ZOO_EXHIBITS,ZOO_RADIUS} from './zoo-data.js';
import { WORLD_CENTERS, isRetiredBiome } from './world-layout.js';
import { HOMESTEAD_RADIUS, HOMESTEAD_EXPANSION } from "./homestead-expansion.js";
import { HOUSING_ID, HOUSING_RADIUS, HOUSING_CENTER } from "./housing-data.js";
import {
  JOB_CITY_ID,
  JOB_CITY_RADIUS,
  JOB_CITY_CENTER,
  JOB_BUSINESSES,
  JOB_CITY_LOCALS,
  jobReservations,
} from "./jobcity-data.js";
import {
  AQUARIUM_RADIUS,
  AQUARIUM_GATE,
  AQUARIUM_TANKS,
  AQUARIUM_LOCALS,
  AQUARIUM_BUILDING,
} from "./aquarium-data.js";
import { DIAMOND_MINE } from "./diamond-data.js";
import { waterRideSpec } from "./water-ride-data.js";
import { REFERENCE_SLIDES } from "./reference-slide-data.js";
import { ATOLL_SLIDES, ATOLL_PARK } from "./atoll-slide-data.js";
import { MAGIC_FARMS, MAGIC_FRUITS, magicFarmLayout } from './magic-farms-data.js';
import {MAGIC_BED,MAGIC_BED_CROPS,MAGIC_BED_SEEDS} from './magic-bed-data.js';
import {
  BUILDING_EXPANSIONS,
  expandedBuildingRadius,
} from "./building-expansions.js";
import {
  BIKINI_RADIUS,
  BIKINI_GATE,
  BIKINI_RESTAURANT,
  BIKINI_FRIENDS,
  BIKINI_LOCALS,
  bikiniReservations,
} from "./bikini-data.js";
import {
  COURT_RADIUS,
  COURT_GATE,
  COURT_VENUES,
  COURT_LOCALS,
  courtReservations,
} from "./foodcourt-data.js";
import { MOSA_RADIUS, MOSA_SHORE_GATE, mosaReservations } from "./mosasaur-data.js";
import { CHILL_RADIUS, CHILL_GATE, chillReservations } from "./chill-data.js";
import {
  CAPYBARA_RADIUS,
  CAPYBARA_RIDES,
  capybaraReservations,
} from "./capybara-data.js";
import { RENEWED_ISLANDS, ISLAND_RIDES } from "./renewal-data.js";
import { BIOME_STYLES } from "./biome-styles.js";
import { ADOPTION_CATS } from "./cat-breeds.js";
import { BUSINESSES } from "./business-data.js";
import { CITY_RIDES } from "./city-ride-data.js";
import { MEGA_RIDES } from "./mega-ride-data.js";
import { COTTON_RIDES, cottonReservations } from "./cotton-data.js";
import { separateIslandCenters } from "./world-layout.js";
import { SPA_RADIUS, spaReservations } from "./spa-data.js";
export const BIOMES = [
  {
    id: "moon",
    name: "Лунный сад",
    subtitle: "Дом Чичи · звёзды и мягкий мох",
    icon: "☾",
    price: 0,
    center: [0, 0],
    ground: 0x526b68,
    edge: 0x303d54,
    foliage: 0x809d91,
    accent: 0xe8c791,
  },
  {
    id: "autumn",
    name: "Медовая осень",
    subtitle: "Золотые листья и грибные домики",
    icon: "🍁",
    price: 240,
    center: [-27, 0],
    ground: 0x907c61,
    edge: 0x514358,
    foliage: 0xd8975f,
    accent: 0xf4cd89,
  },
  {
    id: "winter",
    name: "Снежная сказка",
    subtitle: "Тихий снег и сияние северных огней",
    icon: "❄",
    price: 380,
    center: [27, 0],
    ground: 0xc8d8dc,
    edge: 0x52647b,
    foliage: 0x9bbfc1,
    accent: 0xbdebf3,
  },
  {
    id: "beach",
    name: "Жемчужный пляж",
    subtitle: "Ракушки, пальмы и тёплый прибой",
    icon: "🐚",
    price: 300,
    center: [0, 27],
    ground: 0xd2bb92,
    edge: 0x766a80,
    foliage: 0x83ab8f,
    accent: 0xf5ddba,
  },
  {
    id: "water",
    name: "Cat SPA",
    subtitle: "Басейн, тепле джакузі, спільний лежак і котячий бар",
    radius: SPA_RADIUS,
    arrival: [0, 15.6],
    icon: "🪷",
    price: 420,
    center: [0, -27],
    ground: 0x70a7a3,
    edge: 0x3c596e,
    foliage: 0x9bbbb0,
    accent: 0x9fe6d5,
  },
  {
    id: "wizard",
    name: "Ведьмин лес",
    subtitle: "Кристаллы, заклинания и лунные грибы",
    icon: "🔮",
    price: 550,
    center: [-27, -27],
    ground: 0x665774,
    edge: 0x3c3155,
    foliage: 0x9c82b3,
    accent: 0xc7acf1,
  },
  {
    id: "summer",
    name: "Блакитна лагуна капібар",
    subtitle: "Блакитні каскади, соковиті джунглі й пухкенькі капібари",
    radius: CAPYBARA_RADIUS,
    arrival: [-11, 10],
    icon: "🌴",
    price: 340,
    center: [-27, 27],
    ground: 0x80b94d,
    edge: 0x535f55,
    foliage: 0x69ba39,
    accent: 0xf3d49c,
  },
  {
    id: "nature",
    name: "Изумрудная роща",
    subtitle: "Папоротники, лесные мосты и друзья",
    icon: "🌿",
    price: 460,
    center: [27, 27],
    ground: 0x577966,
    edge: 0x304b4d,
    foliage: 0x7da187,
    accent: 0xb8d5ab,
  },
  {
    id: "sakura",
    name: "Chill Land",
    subtitle: "Затишні особняки, спільні сни та теплі ванни серед квітів",
    icon: "🏡",
    price: 580,
    center: [-54, 0],
    ground: 0xa7bd8a,
    edge: 0x85838b,
    foliage: 0x7c9b5d,
    accent: 0xffd9ae,
  },
  {
    id: "clouds",
    name: "Облачное королевство",
    subtitle: "Белые облака и золотые воздушные дворцы",
    icon: "☁",
    price: 720,
    center: [54, 0],
    ground: 0xcccadb,
    edge: 0x787596,
    foliage: 0xd2cae9,
    accent: 0xffedc2,
  },
  {
    id: "desert",
    name: "Карамельные дюны",
    subtitle: "Звёздный оазис и сказки тёплых песков",
    icon: "🏜",
    price: 520,
    center: [0, 54],
    ground: 0xc89973,
    edge: 0x7b5366,
    foliage: 0xaaa280,
    accent: 0xf5d5a2,
  },
  {
    id: "stars",
    name: "Звёздная долина",
    subtitle: "Ночная магия и праздник среди облаков",
    icon: "✦",
    price: 650,
    center: [27, -27],
    ground: 0x63647f,
    edge: 0x343552,
    foliage: 0x9098bd,
    accent: 0xe7ccfa,
  },
];
const item = (
  id,
  name,
  category,
  price,
  icon,
  description,
  footprint,
  actions,
) => ({ id, name, category, price, icon, description, footprint, actions });
export const CATALOG = [
  item(
    "yarn",
    "Клубочек луны",
    "toys",
    35,
    "🧶",
    "Чичи гоняется за мягким сияющим клубком.",
    [2, 2],
    ["play"],
  ),
  item(
    "mouse",
    "Мышка с секретом",
    "toys",
    45,
    "🐭",
    "Маленькая заводная мышь для большой охоты.",
    [2, 2],
    ["play"],
  ),
  item(
    "feather",
    "Перо феникса",
    "toys",
    55,
    "🪶",
    "Прыгнуть, поймать, отпустить и снова поймать.",
    [2, 2],
    ["play"],
  ),
  item(
    "tunnel",
    "Туннель приключений",
    "toys",
    75,
    "🌀",
    "Нырнуть в один конец и выскочить с другого.",
    [3, 2],
    ["play"],
  ),
  item(
    "scratch",
    "Башня коготков",
    "toys",
    65,
    "🐾",
    "Уютная башенка: забраться и осмотреть владения.",
    [2, 2],
    ["play"],
  ),
  item(
    "trampoline",
    "Облачный батут",
    "rides",
    115,
    "☁",
    "Мягкие прыжки почти до звёзд.",
    [3, 3],
    ["ride"],
  ),
  item(
    "swing",
    "Лунные качели",
    "rides",
    100,
    "☾",
    "Плавно качаться на арке из лунного дерева.",
    [3, 3],
    ["ride"],
  ),
  item(
    "carousel",
    "Карусель созвездий",
    "rides",
    180,
    "🎠",
    "Крутиться среди золотых звёзд и друзей.",
    [4, 4],
    ["ride"],
  ),
  item(
    "coaster",
    "Американские горки",
    "rides",
    260,
    "🎢",
    "Настоящий извилистый путь с маленькой вагонеткой.",
    [6, 5],
    ["ride"],
  ),
  item(
    "waterslide",
    "Горка русалочки",
    "rides",
    220,
    "🛝",
    "Взобраться на башню и скользнуть в мягкий бассейн.",
    [5, 5],
    ["ride"],
  ),
  item(
    "ferris",
    "Колесо желаний",
    "rides",
    240,
    "🎡",
    "Подняться в кабинке и посмотреть на весь мир.",
    [4, 4],
    ["ride"],
  ),
  item(
    "teacup",
    "Чайная чашечка",
    "rides",
    135,
    "🫖",
    "Кружиться в огромной волшебной чашке.",
    [3, 3],
    ["ride"],
  ),
  item(
    "train",
    "Котопоезд",
    "transport",
    210,
    "🚂",
    "Ехать по круговой железной дороге.",
    [5, 5],
    ["ride"],
  ),
  item(
    "boat",
    "Лодочка-листик",
    "transport",
    120,
    "🍃",
    "Плавать в собственном прудике под светлячками.",
    [4, 3],
    ["ride"],
  ),
  item(
    "balloon",
    "Воздушный шар",
    "transport",
    200,
    "🎈",
    "Подняться над островом в уютной корзине.",
    [3, 3],
    ["ride"],
  ),
  item(
    "broom",
    "Метла котоведьмы",
    "transport",
    150,
    "🧹",
    "Полёт по кругу: Чичи теперь немного волшебница.",
    [4, 4],
    ["ride"],
  ),
  item(
    "scooter",
    "Мур-скутер",
    "transport",
    90,
    "🛴",
    "Кататься по маленькой дорожке вокруг флажка.",
    [3, 3],
    ["ride"],
  ),
  item(
    "party",
    "Площадка вечеринок",
    "social",
    160,
    "🪩",
    "Танцы, гирлянда и целая компания котиков.",
    [4, 4],
    ["party"],
  ),
  item(
    "cafe",
    "Котокафе",
    "social",
    150,
    "☕",
    "Посидеть с друзьями за чашечкой тёплого молока.",
    [4, 3],
    ["party", "eat"],
  ),
  item(
    "picnic",
    "Пикник друзей",
    "social",
    95,
    "🧺",
    "Вкусный перекус и тихие разговоры на пледе.",
    [3, 3],
    ["party", "eat"],
  ),
  item(
    "stage",
    "Сцена мур-концертов",
    "social",
    190,
    "🎶",
    "Кошачий концерт под луной.",
    [4, 3],
    ["party"],
  ),
  item(
    "fountain",
    "Фонтан желаний",
    "decor",
    80,
    "⛲",
    "Журчание воды и серебристые искры.",
    [3, 3],
    ["explore"],
  ),
  item(
    "mushroom",
    "Грибной домик",
    "decor",
    85,
    "🍄",
    "Крошечный дом с тёплыми окошками.",
    [3, 3],
    ["rest"],
  ),
  item(
    "crystal",
    "Кристальный сад",
    "decor",
    70,
    "💎",
    "Сияющие кристаллы и место для мечтаний.",
    [2, 2],
    ["explore"],
  ),
  item(
    "lantern",
    "Фонарики светлячков",
    "decor",
    40,
    "🏮",
    "Мягкий свет и немного волшебства.",
    [2, 2],
    ["explore"],
  ),
  item(
    "flowers",
    "Лунная клумба",
    "decor",
    50,
    "🌸",
    "Цветы, которые раскрываются только для котиков.",
    [2, 2],
    ["explore"],
  ),
  item(
    "bed",
    "Ложе облаков",
    "decor",
    60,
    "🛏",
    "Круглая подушка для самых сладких снов.",
    [2, 2],
    ["rest"],
  ),
  item(
    "pond",
    "Пруд с лилиями",
    "decor",
    90,
    "🪷",
    "Наблюдать за рыбками и слушать тихий плеск.",
    [3, 3],
    ["explore"],
  ),
];
export const CATEGORIES = [
  { id: "all", name: "Всё", icon: "✦" },
  { id: "toys", name: "Игрушки", icon: "🧶" },
  { id: "rides", name: "Аттракционы", icon: "🎡" },
  { id: "transport", name: "Транспорт", icon: "🎈" },
  { id: "social", name: "Компания", icon: "🐈" },
  { id: "decor", name: "Уют", icon: "🌸" },
  { id: "lands", name: "Биомы", icon: "🌍" },
  { id: "bag", name: "Моя сумка", icon: "▣" },
];
export const NEIGHBORS = [
  {
    id: "luna",
    name: "Луна",
    biome: "moon",
    color: 0xaaa7bb,
    personality: "Мечтательная любительница звёзд",
    hat: true,
  },
  {
    id: "moti",
    name: "Моти",
    biome: "moon",
    color: 0xf4e4cb,
    personality: "Обожает вечеринки и объятия",
  },
  {
    id: "pixel",
    name: "Пиксель",
    biome: "moon",
    color: 0x717c88,
    personality: "Игривый изобретатель приключений",
  },
  {
    id: "peach",
    name: "Персик",
    biome: "moon",
    color: 0xe6a183,
    personality: "Добрый сосед и мастер пикников",
  },
  {
    id: "bagel",
    name: "Бублик",
    biome: "moon",
    color: 0xc3ab8c,
    personality: "Любитель музыки и качелей",
  },
  {
    id: "salem",
    name: "Салем",
    biome: "wizard",
    color: 0x545064,
    personality: "Котоволшебник с огромным сердцем",
    hat: true,
  },
  {
    id: "snow",
    name: "Снежка",
    biome: "winter",
    color: 0xe8ebed,
    personality: "Ловит снежинки и дарит тёплые улыбки",
  },
  {
    id: "nori",
    name: "Нори",
    biome: "beach",
    color: 0x91a29d,
    personality: "Моряк, который знает все ракушки",
  },
  {
    id: "honey",
    name: "Мёд",
    biome: "autumn",
    color: 0xc39356,
    personality: "Угощает друзей и собирает листья",
  },
  {
    id: "flora",
    name: "Флора",
    biome: "nature",
    color: 0xacb68d,
    personality: "Подруга бабочек и лесных котиков",
  },
  {
    id: "sunny",
    name: "Лучик",
    biome: "summer",
    color: 0xedd59c,
    personality: "Бегает по лугу и любит воздушные шары",
  },
  {
    id: "astra",
    name: "Астра",
    biome: "stars",
    color: 0xb4a4cb,
    personality: "Устраивает лучшие ночные праздники",
    hat: true,
  },
  {
    id: "sakura",
    name: "Сакура",
    biome: "sakura",
    color: 0xe6baca,
    personality: "Собирает лепестки и мечтает о дружбе",
  },
  {
    id: "cloud",
    name: "Облачко",
    biome: "clouds",
    color: 0xefebf6,
    personality: "Мягкий котик из воздушного королевства",
  },
  {
    id: "cinnamon",
    name: "Корица",
    biome: "desert",
    color: 0xc09064,
    personality: "Добрая путешественница по дюнам",
  },
  {
    id: "lily",
    name: "Лили",
    biome: "water",
    color: 0xa2cecb,
    personality: "Плавает на листиках и танцует у воды",
  },
];
export const byItem = (id) => CATALOG.find((x) => x.id === id);
export const byBiome = (id) => BIOMES.find((x) => x.id === id);
export const RESERVATIONS = [
  { x: -6, z: -5, w: 4, d: 4 },
  { x: 5, z: 4, w: 4, d: 3 },
  { x: 5, z: -5, w: 3, d: 3 },
  { x: -2, z: 5, w: 3, d: 3 },
  { x: 0, z: 0, w: 2, d: 2 },
];
export const ACTIONS = [
  "explore",
  "play",
  "ride",
  "meet",
  "party",
  "rest",
  "eat",
  "swim",
];
export function biomeReservations(id) {
  if(id===ZOO_BIOME.id)return[{x:0,z:0,w:ZOO_RADIUS*2,d:ZOO_RADIUS*2}];
  if (isRetiredBiome(id)) return [];
  const farm=magicFarmLayout(id);if(farm){const [x,z,rx,rz]=farm.pond;return [...farm.plants.map(p=>({x:p.x,z:p.z,w:p.radius*2+1.5,d:p.radius*2+1.5})),{x,z,w:rx*2+4,d:rz*2+4},{x:0,z:71,w:78,d:14}];}
  if (id === JOB_CITY_ID) return jobReservations();
  if (id === "aquarium")
    return [
      { x: 0, z: 0, w: AQUARIUM_BUILDING.w + 1, d: AQUARIUM_BUILDING.d + 1 },
    ];
  if (id === "bikini") return bikiniReservations();
  if (id === "foodcourt") return courtReservations();
  if (id === "autumn") return mosaReservations();
  if (id === "sakura") return chillReservations();
  if (id === "water") return spaReservations();
  if (id === "clockwork") return cottonReservations();
  if (id === "summer") return capybaraReservations();
  const fixed =
    id === "moon"
      ? [
          { x: -6, z: -4, w: 1.8, d: 1.8 },
          { x: -2, z: 5, w: 2.5, d: 2.5 },
        ]
      : [];
  if (id === "aquapark")
    fixed.push(
      { x: -3, z: -8, w: 11, d: 10 },
      { x: 8, z: 6, w: 10, d: 8 },
      { x: 9, z: -7, w: 10, d: 9 },
      { x: -10, z: -8, w: 9, d: 8 },
    );
  if (RENEWED_ISLANDS[id]) {
    const upper = RENEWED_ISLANDS[id].upper;
    fixed.push({
      x: upper[0],
      z: upper[1],
      w: upper[2] * 2 + 0.7,
      d: upper[3] * 2 + 0.7,
      rx: upper[2] + 0.12,
      rz: upper[3] + 0.12,
    });
    for (const ride of ISLAND_RIDES.filter((r) => r.biome === id)) {
      const item = byItem(ride.type);
      fixed.push({
        x: ride.x,
        z: ride.z,
        w: item.footprint[0],
        d: item.footprint[1],
      });
    }
  }
  const river = BIOME_STYLES[id]?.river;
  if (river)
    fixed.push({
      x: river[0],
      z: river[1],
      w: river[2] * 2,
      d: river[3] * 2,
      rx: river[2] + 0.12,
      rz: river[3] + 0.12,
    });
  const water = BIOME_STYLES[id]?.water;
  if (water)
    fixed.push({
      x: water[0],
      z: water[1],
      w: water[2] * 2 + 0.4,
      d: water[3] * 2 + 0.4,
      rx: water[2] + 0.12,
      rz: water[3] + 0.12,
    });
  return fixed;
}
BIOMES.push(
  {
    id: "volcano",
    name: "Остров драконьих искр",
    subtitle: "Обсидиан, тёплые светящиеся трещины и драконы",
    icon: "🌋",
    price: 900,
    center: [-54, -27],
    ground: 0x685366,
    edge: 0x3b304c,
    foliage: 0xb97c8d,
    accent: 0xffb17e,
    quest: { harvests: 6 },
  },
  {
    id: "crystal",
    name: "Кристальное королевство",
    subtitle: "Радужные шпили и самоцветные пещеры",
    icon: "💎",
    price: 820,
    center: [54, -27],
    ground: 0x8da6ba,
    edge: 0x52627e,
    foliage: 0xa8c7df,
    accent: 0xd9f6ff,
  },
  {
    id: "candy",
    name: "Сладкая страна",
    subtitle: "Мармеладные деревья и сахарные облака",
    icon: "🍭",
    price: 640,
    center: [-54, 27],
    ground: 0xc4a2b8,
    edge: 0x916484,
    foliage: 0xecbdd9,
    accent: 0xffe0b0,
  },
  {
    id: "rainbow",
    name: "Долина радуг",
    subtitle: "Семь цветов, воздушные мосты и тихий дождь",
    icon: "🌈",
    price: 760,
    center: [54, 27],
    ground: 0xa2b8ba,
    edge: 0x727796,
    foliage: 0xc1b0db,
    accent: 0xffd2e5,
  },
  {
    id: "bamboo",
    name: "Бамбуковый шёпот",
    subtitle: "Зелёные рощи, фонарики и чайные беседки",
    icon: "🎋",
    price: 590,
    center: [-27, 54],
    ground: 0x729583,
    edge: 0x3b635d,
    foliage: 0xa3c58b,
    accent: 0xe4efb5,
  },
  {
    id: "mushrooms",
    name: "Грибное королевство",
    subtitle: "Гигантские грибы и маленькие лесные чудеса",
    icon: "🍄",
    price: 620,
    center: [27, 54],
    ground: 0x897a9d,
    edge: 0x55446d,
    foliage: 0xba9ec5,
    accent: 0xf1b8d3,
  },
  {
    id: "galaxy",
    name: "Космическая гавань",
    subtitle: "Планеты, кометы и кошачьи космолёты",
    icon: "🪐",
    price: 1200,
    center: [0, -54],
    ground: 0x706b9a,
    edge: 0x353259,
    foliage: 0xb0a2d5,
    accent: 0xe2c6ff,
    quest: { friends: 1 },
  },
  {
    id: "coral",
    name: "Коралловая сказка",
    subtitle: "Перламутровая вода и волшебные кораллы",
    icon: "🪸",
    price: 700,
    center: [-27, -54],
    ground: 0x88b9bd,
    edge: 0x4b778b,
    foliage: 0xc7a5cc,
    accent: 0xffc4c7,
  },
  {
    id: "lotus",
    name: "Лотосовый храм",
    subtitle: "Цветущие лотосы и зеркальная гладь",
    icon: "🪷",
    price: 680,
    center: [27, -54],
    ground: 0x80b5ac,
    edge: 0x477b77,
    foliage: 0xabcabc,
    accent: 0xf5d6ea,
  },
  {
    id: "ice",
    name: "Дворец северного сияния",
    subtitle: "Ледяные башни и переливы полярной ночи",
    icon: "🏔",
    price: 1000,
    center: [-54, -54],
    ground: 0xb5d4e1,
    edge: 0x637caa,
    foliage: 0xb6dbe4,
    accent: 0xc1f4ed,
    quest: { harvests: 10 },
  },
  {
    id: "clockwork",
    name: "Остров сладкой ваты",
    subtitle: "Легендарный парк хрюшек · розовые водопады и сахарные горки",
    icon: "🍭",
    radius: 23,
    legendary: true,
    arrival: [0, 9],
    price: 1100,
    center: [68, -68],
    ground: 0xffdac8,
    edge: 0xc56b97,
    foliage: 0xf5a8d3,
    accent: 0xffe0a2,
    quest: { friends: 2 },
  },
  {
    id: "dusk",
    name: "Сумеречная библиотека",
    subtitle: "Зачарованные книги и острова вечного вечера",
    icon: "📚",
    price: 860,
    center: [-54, 54],
    ground: 0x857895,
    edge: 0x4b3d65,
    foliage: 0xa59abb,
    accent: 0xe8d1aa,
    quest: { harvests: 3 },
  },
);
CATALOG.push(
  item(
    "farm-field",
    "Фермерские грядки",
    "farm",
    80,
    "🌱",
    "Посадить, дождаться урожая и продать его за котомонеты.",
    [4, 3],
    ["farm"],
  ),
  item(
    "greenhouse",
    "Звёздная теплица",
    "farm",
    260,
    "🏡",
    "Выращивать волшебные культуры под стеклянной крышей.",
    [5, 4],
    ["farm"],
  ),
  item(
    "barn",
    "Амбар урожая",
    "farm",
    160,
    "🌾",
    "Тёплое фермерское местечко для работы Чичи.",
    [4, 3],
    ["farm"],
  ),
  item(
    "orchard",
    "Сад лунных яблок",
    "farm",
    180,
    "🍎",
    "Маленький фруктовый сад с собственными грядками.",
    [4, 4],
    ["farm"],
  ),
  item(
    "coaster-epic",
    "Эпические небесные горки",
    "rides",
    580,
    "🎢",
    "Высокие подъёмы, спирали и эффектный полёт.",
    [9, 8],
    ["ride"],
  ),
  item(
    "coaster-legendary",
    "Легендарные драконьи горки",
    "rides",
    1600,
    "🐉",
    "Огромный маршрут над всем островом. Стройка — сутки.",
    [15, 14],
    ["ride"],
  ),
  item(
    "coaster-mystic",
    "Мистический полёт",
    "rides",
    1200,
    "🔮",
    "Полёт над светящимися порталами и головокружительное падение.",
    [14, 13],
    ["ride"],
  ),
  item(
    "coaster-dragon",
    "Огненная спираль",
    "rides",
    950,
    "🔥",
    "Сверкающая спираль вокруг драконьей башни.",
    [12, 10],
    ["ride"],
  ),
  item(
    "water-river",
    "Ленивая волшебная река",
    "rides",
    420,
    "🌊",
    "Плыть по извилистому каналу в маленькой лодке.",
    [8, 7],
    ["ride"],
  ),
  item(
    "water-whirlpool",
    "Радужный водоворот",
    "rides",
    750,
    "🌀",
    "Вода закручивается в огромную мягкую воронку.",
    [10, 9],
    ["ride"],
  ),
  item(
    "water-extreme",
    "Водная горка титанов",
    "rides",
    1100,
    "💦",
    "Взобраться на высоченную башню и пролететь к бассейну.",
    [12, 10],
    ["ride"],
  ),
  item(
    "zipline",
    "Звёздный зиплайн",
    "rides",
    340,
    "🌠",
    "Промчаться по воздушному канату между двумя башнями.",
    [7, 4],
    ["ride"],
  ),
  item(
    "drop-tower",
    "Башня комет",
    "rides",
    700,
    "☄",
    "Подняться в небо и мягко упасть на облачную подушку.",
    [4, 4],
    ["ride"],
  ),
  item(
    "bumpercars",
    "Мур-автодром",
    "rides",
    320,
    "🚗",
    "Весёлые машинки кружатся на освещённой площадке.",
    [6, 5],
    ["ride"],
  ),
  item(
    "rocket",
    "Лунная ракета",
    "transport",
    650,
    "🚀",
    "Облететь остров на маленькой пушистой ракете.",
    [5, 5],
    ["ride"],
  ),
  item(
    "ufo",
    "Летающая мур-тарелка",
    "transport",
    520,
    "🛸",
    "Парить среди звёзд в сияющем кораблике.",
    [5, 5],
    ["ride"],
  ),
  item(
    "airship",
    "Небесный котодирижабль",
    "transport",
    480,
    "🎈",
    "Плавный полёт над садами и игрушками.",
    [6, 5],
    ["ride"],
  ),
  item(
    "skate",
    "Радужный скейт",
    "transport",
    160,
    "🛹",
    "Кататься и совершать маленькие прыжки.",
    [4, 4],
    ["ride"],
  ),
  item(
    "catbus",
    "Сказочный котобус",
    "transport",
    420,
    "🚌",
    "Путешествовать по кольцевой дороге.",
    [6, 5],
    ["ride"],
  ),
  item(
    "maze",
    "Лабиринт любопытства",
    "toys",
    240,
    "🌳",
    "Искать дорогу среди мягких зелёных стен.",
    [5, 5],
    ["play"],
  ),
  item(
    "laser",
    "Звёздный огонёк",
    "toys",
    110,
    "✦",
    "Поймать убегающую искорку.",
    [3, 3],
    ["play"],
  ),
  item(
    "fireflies",
    "Баночка светлячков",
    "toys",
    95,
    "🫙",
    "Следить за волшебными огоньками и играть с ними.",
    [2, 2],
    ["play"],
  ),
  item(
    "toy-fish",
    "Рыбка-попрыгунья",
    "toys",
    90,
    "🐟",
    "Ловить подпрыгивающую мягкую рыбку.",
    [2, 2],
    ["play"],
  ),
  item(
    "library",
    "Дом сказок",
    "social",
    240,
    "📖",
    "Встречи друзей и чтение волшебных историй.",
    [4, 4],
    ["party", "rest"],
  ),
  item(
    "observatory",
    "Обсерватория желаний",
    "social",
    380,
    "🔭",
    "Наблюдать за звёздами в компании котиков.",
    [5, 4],
    ["party", "explore"],
  ),
  item(
    "spa",
    "Лунные термы",
    "social",
    290,
    "🫧",
    "Отдохнуть в тёплом бассейне среди цветов.",
    [4, 4],
    ["rest"],
  ),
  item(
    "festival",
    "Фестиваль созвездий",
    "social",
    600,
    "🎆",
    "Музыка, сияющие гирлянды и большая вечеринка.",
    [6, 5],
    ["party"],
  ),
  item(
    "portal",
    "Портал чудес",
    "decor",
    330,
    "🪄",
    "Сверкающий круг для маленького магического приключения.",
    [4, 3],
    ["play"],
  ),
);
CATEGORIES.splice(
  CATEGORIES.findIndex((c) => c.id === "lands"),
  0,
  { id: "farm", name: "Ферма", icon: "🌱" },
);
const extraCats = [
  "Искра",
  "Опал",
  "Зефир",
  "Ирис",
  "Панда",
  "Трюфель",
  "Космо",
  "Кора",
  "Лотти",
  "Айс",
  "Тик",
  "Сумрак",
];
for (let i = 12; i < BIOMES.length; i++) {
  const b = BIOMES[i];
  NEIGHBORS.push({
    id: "neighbor-" + b.id,
    name: extraCats[i - 12],
    biome: b.id,
    color: b.foliage,
    personality: "Хранитель " + b.name.toLowerCase(),
    hat: i % 3 === 0,
  });
}
ACTIONS.push("farm");
CATALOG.push(
  item(
    "coaster-lagoon",
    "Небесная лагуна",
    "rides",
    1050,
    "🐠",
    "Бирюзовые горки, рыбки в аквариуме, пальмы и тёплые фонарики.",
    [12, 10],
    ["ride"],
  ),
  item(
    "coaster-sakura",
    "Петля цветущих снов",
    "rides",
    880,
    "🌸",
    "Розовый маршрут среди цветущих деревьев и светящихся лепестков.",
    [11, 10],
    ["ride"],
  ),
  item(
    "coaster-moon",
    "Лунный экспресс",
    "rides",
    1150,
    "☾",
    "Золотые арки, грибная станция и сказочный полёт над островом.",
    [13, 11],
    ["ride"],
  ),
  item(
    "coaster-mushroom",
    "Грибной серпантин",
    "rides",
    760,
    "🍄",
    "Уютная деревянная горка среди сказочных грибов и цветочных садов.",
    [10, 9],
    ["ride"],
  ),
  item(
    "coaster-cloud",
    "Облачная корона",
    "rides",
    1750,
    "☁",
    "Легендарный маршрут с белыми облаками, золотыми поручнями и высоким дворцом.",
    [15, 14],
    ["ride"],
  ),
  item(
    "coaster-clockwork",
    "Золотая карусель времени",
    "rides",
    1250,
    "⚙",
    "Медные рельсы, заводная станция и фонари города часовщика.",
    [12, 11],
    ["ride"],
  ),
);
BIOMES.push({
  id: "aquapark",
  name: "Радужная корона",
  subtitle: "Легендарный аквапарк · замок, каскады, полёты и лазурные лагуны",
  icon: "🏰",
  price: 35000,
  center: [88, 36],
  radius: 19,
  ground: 0x89b982,
  edge: 0x425b80,
  foliage: 0x72b578,
  accent: 0xffd26a,
  requiredLevel: 20,
  quest: { harvests: 180, friends: 3, visits: 7 },
});
CATALOG.push(
  item(
    "coaster-rainbow-launch",
    "Радужная катапульта",
    "rides",
    4800,
    "🌈",
    "Цветные рельсы, облачная арка и смешной полёт Чичи над лагуной.",
    [10, 8],
    ["ride"],
  ),
  item(
    "slide-royal-cascade",
    "Королевский каскад",
    "rides",
    5600,
    "🏰",
    "Золотая башня, длинный голубой спуск и искрящийся водный финиш.",
    [10, 9],
    ["ride"],
  ),
  item(
    "slide-vortex-bowl",
    "Чаша водоворота",
    "rides",
    4100,
    "🌀",
    "Обойти радужную чашу по спирали, провалиться в центр и мягко приводниться.",
    [9, 8],
    ["ride"],
  ),
  item(
    "coaster-comet-flight",
    "Комета Чичи",
    "rides",
    7600,
    "☄️",
    "Космическая петля и огромный полёт с растопыренными лапками.",
    [12, 10],
    ["ride"],
  ),
  item(
    "ride-jellyfish",
    "Медузья карусель",
    "rides",
    2900,
    "🪼",
    "Прозрачный купол, светящиеся щупальца и покачивающиеся корзинки.",
    [6, 6],
    ["ride"],
  ),
  item(
    "ride-dragon-cloud",
    "Облачный дракон",
    "rides",
    5200,
    "🐉",
    "Кружить верхом на смешном драконе между цветными облаками.",
    [8, 7],
    ["ride"],
  ),
  item(
    "toy-bubble-garden",
    "Сад мыльных пузырей",
    "toys",
    620,
    "🫧",
    "Пузырьки разных размеров и прыжки за радужными бликами.",
    [3, 3],
    ["play"],
  ),
  item(
    "toy-magic-fish",
    "Летающая рыбка",
    "toys",
    820,
    "🐠",
    "Рыбка летит над цветами, Чичи ловит её лапками и смешно подпрыгивает.",
    [3, 3],
    ["play"],
  ),
  item(
    "cat-barista",
    "Мур-бариста",
    "social",
    1800,
    "☕",
    "Объёмное кафе с котиком-бариста, паром над чашечками и настоящими гостями. Перекусы расходуют еду из общей миски.",
    [5, 4],
    ["eat", "party"],
  ),
  item(
    "swim-lagoon",
    "Лагуна для плавания",
    "decor",
    450,
    "💦",
    "Прозрачная вода, разноцветные рыбки и круги от кошачьих лапок.",
    [4, 4],
    ["swim", "explore"],
  ),
);
CATALOG.push(
  item(
    "adoption-center",
    "Cat Adoption Center",
    "social",
    320,
    "🐾",
    "Постройте уютный дом знакомства: усыновляйте котиков разных пород, размеров и окрасов.",
    [5, 5],
    ["explore"],
  ),
);
CATALOG.push(
  ...BUSINESSES.map((b) => ({
    ...b,
    category: "business",
    footprint: b.footprint || [5, 5],
    actions:
      ["produce", "fish", "toys"].includes(b.goods) ||
      b.id === "business-florist" ||
      b.id === "business-artist"
        ? ["explore", "party"]
        : ["eat", "party"],
  })),
);
CATEGORIES.splice(
  CATEGORIES.findIndex((c) => c.id === "lands"),
  0,
  { id: "business", name: "Кошачий бизнес", icon: "☕" },
  { id: "cats", name: "Породы котиков", icon: "🐱" },
);
CATALOG.push(
  item(
    "ride-butterfly",
    "Бабочка цветущих снов",
    "rides",
    1200,
    "🦋",
    "Настоящие взмахи крыльев, седло и плавный полёт над островом.",
    [4, 4],
    ["ride"],
  ),
  item(
    "ride-lotus",
    "Парусный лотос",
    "rides",
    1500,
    "🪷",
    "Гигантский раскрывающийся цветок несёт Чичи над водой.",
    [4, 4],
    ["ride"],
  ),
  item(
    "ride-dragonfly",
    "Стрекоза кристальной лагуны",
    "rides",
    1100,
    "✨",
    "Четыре переливчатых крыла и длинный голубой хвост несут Чичи над цветами.",
    [4, 4],
    ["ride"],
  ),
  item(
    "ride-dinosaur",
    "Добрый динозавр",
    "rides",
    1800,
    "🦕",
    "Небольшой динозавр шагает с Чичи на спине и кивает друзьям.",
    [4, 4],
    ["ride"],
  ),
);
CATALOG.push(
  item(
    "ride-whale",
    "Небесный синий кит",
    "rides",
    2200,
    "🐋",
    "Живой звёздный кит несёт Чичи над лагуной, машет плавниками и выпускает фонтанчики.",
    [5, 5],
    ["ride"],
  ),
  item(
    "ride-whale-aurora",
    "Кит лилового сияния",
    "rides",
    3200,
    "✨",
    "Перламутровый кит с созвездиями и светящимся хвостом пролетает над островом по своему маршруту.",
    [5, 5],
    ["ride"],
  ),
);
CATALOG.push(
  ...[...CITY_RIDES, ...COTTON_RIDES, ...CAPYBARA_RIDES].map((ride) => ({
    ...ride,
    category: "rides",
    actions: ["ride"],
    fixedPrice: true,
  })),
);
for (const [id, price, minutes] of [
  ["ride-whale", 1200, 45],
  ["ride-whale-aurora", 1650, 60],
]) {
  const whale = CATALOG.find((i) => i.id === id);
  Object.assign(whale, { price, buildMinutes: minutes, fixedPrice: true });
}
const levelOverrides = {
  "ride-whale": 4,
  "ride-whale-aurora": 4,
  "adoption-center": 2,
  "ride-butterfly": 6,
  "ride-lotus": 11,
  "ride-dragonfly": 10,
  "ride-dinosaur": 12,
  yarn: 1,
  mouse: 1,
  feather: 2,
  tunnel: 3,
  scratch: 2,
  trampoline: 3,
  swing: 2,
  carousel: 5,
  coaster: 6,
  waterslide: 5,
  ferris: 7,
  teacup: 4,
  train: 6,
  boat: 3,
  balloon: 5,
  broom: 4,
  scooter: 2,
  party: 3,
  cafe: 4,
  picnic: 2,
  stage: 5,
  fountain: 2,
  mushroom: 3,
  crystal: 3,
  lantern: 1,
  flowers: 1,
  bed: 1,
  pond: 2,
  "farm-field": 2,
  greenhouse: 5,
  barn: 3,
  orchard: 4,
  "cat-barista": 5,
  "swim-lagoon": 3,
  "coaster-rainbow-launch": 12,
  "slide-royal-cascade": 14,
  "slide-vortex-bowl": 11,
  "coaster-comet-flight": 18,
  "ride-jellyfish": 9,
  "ride-dragon-cloud": 15,
  "toy-bubble-garden": 4,
  "toy-magic-fish": 6,
};
const biomeLevels = {
  moon: 1,
  autumn: 3,
  summer: 4,
  beach: 5,
  winter: 4,
  water: 7,
  nature: 7,
  wizard: 8,
  sakura: 9,
  desert: 10,
  bamboo: 10,
  mushrooms: 11,
  candy: 11,
  coral: 12,
  lotus: 12,
  crystal: 13,
  rainbow: 14,
  clouds: 15,
  volcano: 16,
  dusk: 16,
  stars: 17,
  ice: 18,
  clockwork: 18,
  galaxy: 19,
  aquapark: 20,
};
for (const biome of BIOMES) {
  biome.requiredLevel = biomeLevels[biome.id];
  if (biome.id !== "moon" && biome.id !== "aquapark")
    biome.price =
      Math.round((biome.price * (1 + biome.requiredLevel * 0.7)) / 10) * 10;
}
CATALOG.push(...REFERENCE_SLIDES, ...ATOLL_SLIDES,...SHOWCASE_WATER_RIDES,MAGIC_BED,...MAGIC_BED_SEEDS);
CATEGORIES.splice(CATEGORIES.findIndex(c=>c.id==='lands'),0,{id:'seeds',name:'Насіння',icon:'🌰'});
for (const product of CATALOG) {
  product.requiredLevel ||=
    levelOverrides[product.id] ||
    (product.id.includes("mystic")
      ? 19
      : product.id.includes("legendary")
        ? 18
        : product.id.includes("epic")
          ? 11
          : product.id.includes("coaster")
            ? 14
            : product.id.includes("water-")
              ? 12
              : 8);
  if (
    !product.fixedPrice &&
    product.category !== "business" &&
    product.id !== "adoption-center" &&
    ![
      "coaster-rainbow-launch",
      "slide-royal-cascade",
      "slide-vortex-bowl",
      "coaster-comet-flight",
      "ride-jellyfish",
      "ride-dragon-cloud",
      "toy-bubble-garden",
      "toy-magic-fish",
      "cat-barista",
      "swim-lagoon",
    ].includes(product.id) &&
    product.requiredLevel > 1
  )
    product.price =
      Math.round((product.price * (1 + product.requiredLevel * 0.28)) / 5) * 5;
}
const buildOverrides = {
  "adoption-center": 20,
  "coaster-rainbow-launch": 720,
  "slide-royal-cascade": 960,
  "slide-vortex-bowl": 480,
  "coaster-comet-flight": 1440,
  "ride-jellyfish": 360,
  "ride-dragon-cloud": 960,
  "cat-barista": 240,
  "swim-lagoon": 90,
  coaster: 240,
  "coaster-lagoon": 720,
  "coaster-sakura": 480,
  "coaster-moon": 960,
  "coaster-mushroom": 360,
  "coaster-cloud": 1440,
  "coaster-clockwork": 960,
  ferris: 240,
  waterslide: 180,
  "coaster-epic": 480,
  "coaster-legendary": 1440,
  "coaster-mystic": 1440,
  "coaster-dragon": 720,
  "water-extreme": 1440,
  "water-whirlpool": 720,
  "water-river": 240,
  "drop-tower": 480,
  rocket: 480,
  ufo: 360,
  airship: 240,
  festival: 480,
  greenhouse: 240,
  barn: 120,
  orchard: 120,
};
for (const product of CATALOG) {
  product.buildMinutes ||=
    buildOverrides[product.id] ||
    (["rides", "transport"].includes(product.category)
      ? 120
      : product.category === "social"
        ? 90
        : 30);
  product.rarity =
    product.buildMinutes >= 1440
      ? "Легендарное"
      : product.buildMinutes >= 480
        ? "Эпическое"
        : product.buildMinutes >= 240
          ? "Редкое"
          : "Уютное";
}
export const CROPS = [
  {
    id: "wheat",
    name: "Золотая пшеница",
    icon: "🌾",
    minutes: 3,
    seed: 2,
    value: 14,
    biome: "moon",
  },
  {
    id: "mint",
    name: "Лунная мята",
    icon: "🌿",
    minutes: 10,
    seed: 4,
    value: 18,
    biome: "nature",
  },
  {
    id: "pumpkin",
    name: "Медовая тыква",
    icon: "🎃",
    minutes: 30,
    seed: 6,
    value: 36,
    biome: "autumn",
  },
  {
    id: "berry",
    name: "Снежная ягода",
    icon: "🫐",
    minutes: 60,
    seed: 8,
    value: 55,
    biome: "winter",
  },
  {
    id: "lavender",
    name: "Ведьмина лаванда",
    icon: "🪻",
    minutes: 20,
    seed: 5,
    value: 25,
    biome: "wizard",
  },
  {
    id: "strawberry",
    name: "Солнечная клубника",
    icon: "🍓",
    minutes: 15,
    seed: 5,
    value: 28,
    biome: "summer",
  },
  {
    id: "lotus-seed",
    name: "Лунный лотос",
    icon: "🪷",
    minutes: 25,
    seed: 6,
    value: 32,
    biome: "water",
  },
  {
    id: "tea",
    name: "Чай сакуры",
    icon: "🍵",
    minutes: 45,
    seed: 8,
    value: 50,
    biome: "sakura",
  },
  {
    id: "cactus",
    name: "Карамельный кактус",
    icon: "🌵",
    minutes: 10,
    seed: 4,
    value: 18,
    biome: "desert",
  },
  {
    id: "candy-cane",
    name: "Сахарные тростинки",
    icon: "🍭",
    minutes: 120,
    seed: 8,
    value: 80,
    biome: "candy",
  },
  {
    id: "star-melon",
    name: "Звёздная дыня",
    icon: "🍈",
    minutes: 240,
    seed: 10,
    value: 140,
    biome: "stars",
  },
  {
    id: "crystal-fruit",
    name: "Кристальный плод",
    icon: "💎",
    minutes: 180,
    seed: 10,
    value: 130,
    biome: "crystal",
  },
  {
    id: "cloud-cotton",
    name: "Облачный хлопок",
    icon: "☁",
    minutes: 120,
    seed: 8,
    value: 95,
    biome: "clouds",
  },
  {
    id: "ember",
    name: "Драконьи перчики",
    icon: "🌶",
    minutes: 90,
    seed: 9,
    value: 85,
    biome: "volcano",
  },
  {
    id: "bamboo",
    name: "Чайный бамбук",
    icon: "🎋",
    minutes: 45,
    seed: 6,
    value: 45,
    biome: "bamboo",
  },
  {
    id: "glow-mushroom",
    name: "Лунные грибочки",
    icon: "🍄",
    minutes: 40,
    seed: 6,
    value: 42,
    biome: "mushrooms",
  },
  {
    id: "pearl-coconut",
    name: "Жемчужный кокос",
    icon: "🥥",
    minutes: 35,
    seed: 6,
    value: 40,
    biome: "beach",
  },
  {
    id: "prism-beet",
    name: "Радужная свёкла",
    icon: "🌈",
    minutes: 75,
    seed: 8,
    value: 70,
    biome: "rainbow",
  },
  {
    id: "galaxy-grape",
    name: "Галактический виноград",
    icon: "🍇",
    minutes: 360,
    seed: 12,
    value: 190,
    biome: "galaxy",
  },
  {
    id: "coral-pear",
    name: "Коралловая груша",
    icon: "🪸",
    minutes: 80,
    seed: 8,
    value: 75,
    biome: "coral",
  },
  {
    id: "lotus-blossom",
    name: "Серебряный цветок лотоса",
    icon: "🌺",
    minutes: 50,
    seed: 7,
    value: 52,
    biome: "lotus",
  },
  {
    id: "ice-peach",
    name: "Ледяной персик",
    icon: "🍑",
    minutes: 180,
    seed: 10,
    value: 125,
    biome: "ice",
  },
  {
    id: "clock-pumpkin",
    name: "Клубничная тыковка",
    icon: "🍓",
    minutes: 150,
    seed: 10,
    value: 115,
    biome: "clockwork",
  },
  {
    id: "night-flower",
    name: "Полуночный цветок",
    icon: "🌙",
    minutes: 240,
    seed: 11,
    value: 160,
    biome: "dusk",
  },
];
export const JOBS = [
  {
    id: "fishing",
    name: "Рыбалка",
    icon: "🎣",
    biomes: ["beach", "water", "coral", "lotus"],
    minutes: 20,
    resource: "fish",
    value: 25,
  },
  {
    id: "foraging",
    name: "Лесной сбор",
    icon: "🍄",
    biomes: ["nature", "autumn", "bamboo", "mushrooms"],
    minutes: 10,
    resource: "mushrooms",
    value: 15,
  },
  {
    id: "mining",
    name: "Самоцветы",
    icon: "💎",
    biomes: ["wizard", "crystal", "volcano", "galaxy", "ice"],
    minutes: 30,
    resource: "gems",
    value: 35,
  },
  {
    id: "honey",
    name: "Медовая пасека",
    icon: "🍯",
    biomes: ["summer", "sakura", "candy", "rainbow"],
    minutes: 60,
    resource: "honey",
    value: 45,
  },
];
export const buildTimeLabel = (minutes) =>
  minutes >= 1440
    ? "1 день"
    : minutes >= 60
      ? Math.round((minutes / 60) * 10) / 10 + " ч"
      : minutes + " мин";
export const biomeFeature = (b) =>
  b === "magic-zoo" ? "П’ять просторих вольєрів, тварини й прогулянки котиків" :
  (b === "sakura"
    ? "Сім відкритих особняків, 14 місць на спільних лежанках та 7 теплих ванн"
    : b === "water"
      ? "Спільний відпочинок, плавання, тепле джакузі та напої в SPA-барі"
      : b === "summer"
        ? "Чотири їздові капібари, купання в чотирьох лагунах і каскадні водоспади"
        : null) ||
  RENEWED_ISLANDS[b]?.feature ||
  CROPS.find((c) => c.biome === b)?.name ||
  JOBS.find((j) => j.biomes.includes(b))?.name ||
  "Новые друзья и приключения";

CROPS.push({
  id: "rainbow-mango",
  name: "Радужное манго",
  icon: "🥭",
  minutes: 240,
  seed: 16,
  value: 240,
  biome: "aquapark",
});
NEIGHBORS.push(
  {
    id: "boba",
    name: "Боба",
    biome: "aquapark",
    color: 0xc8aa8c,
    personality: "Любит водные горки и мягкие приводнения",
  },
  {
    id: "splash",
    name: "Капелька",
    biome: "aquapark",
    color: 0x91bbcb,
    personality: "Плавает в лагуне и обожает разноцветных рыбок",
  },
);
const residentBreeds = [
  "british",
  "ragdoll",
  "blue",
  "tabby",
  "munchkin",
  "tuxedo",
  "persian",
  "blue",
  "tabby",
  "calico",
  "tabby",
  "cheshire",
];
for (const [index, profile] of NEIGHBORS.entries()) {
  profile.breed = residentBreeds[index % residentBreeds.length];
  profile.eyes = [0xb4ce73, 0x8dbfda, 0xe0bc6b, 0x90c49d][index % 4];
  if (profile.id === "moti") profile.build = "plush";
  if (profile.id === "bagel" || profile.id === "boba") profile.build = "giant";
}
NEIGHBORS.push(...ADOPTION_CATS);
// The little munchkin already visiting the hot-dog stand becomes a real
// resident. A stable identity reuses care, friendship and shared destinations;
// rebuilding or adding a second stand must never duplicate this kitten.
NEIGHBORS.push({
  id: "hotdog-bun",
  name: "Булочка",
  biome: "moon",
  venue: "business-hotdog",
  breed: "munchkin",
  color: 0xe2c19d,
  eyes: 0xa5c569,
  size: 0.36 / 0.63,
  personality: "Маленький помощник повара: любит клубочки, купание и прогулки",
});

// Preserve stable save IDs while replacing island art and activities.
for (const biome of BIOMES)
  if (RENEWED_ISLANDS[biome.id]) {
    const next = RENEWED_ISLANDS[biome.id];
    Object.assign(biome, {
      name: next.name,
      subtitle: next.subtitle,
      icon: next.icon,
      radius: next.radius || 14.8,
      ...(next.arrival ? { arrival: next.arrival } : {}),
      ground: next.ground,
      foliage: next.leaf,
      accent: next.flower,
    });
  }
BIOMES.splice(
  BIOMES.findIndex((b) => b.id === "wizard"),
  1,
);
for (const cat of NEIGHBORS) if (cat.biome === "wizard") cat.biome = "moon";
for (const crop of CROPS) if (crop.biome === "wizard") crop.biome = "moon";
for (const job of JOBS)
  job.biomes = job.biomes.map((id) => (id === "wizard" ? "moon" : id));

const renewalCrops = {
  winter: ["Лунная морская ягода", "🔮"],
  autumn: ["Янтарные яблочки", "🍎"],
  ice: ["Кристальные ягоды", "🫐"],
  galaxy: ["Жемчужный виноград", "🍇"],
  volcano: ["Тропический плод", "🥭"],
};
for (const crop of CROPS)
  if (renewalCrops[crop.biome]) {
    crop.name = renewalCrops[crop.biome][0];
    crop.icon = renewalCrops[crop.biome][1];
  }
JOBS.find((job) => job.id === "fishing").biomes.push("winter");

// Art upgrades changed several radii. Keep their shores apart in both the
// renderer and navigation instead of masking coplanar terrain with depth bias.
separateIslandCenters(BIOMES);

// Enlarge only this island after the established map layout is resolved.
// Its small move leaves every other island (especially stars) exactly in place.
Object.assign(
  BIOMES.find((b) => b.id === "sakura"),
  {
    radius: CHILL_RADIUS,
    center: [-104, 0],
    arrival: [CHILL_GATE.x, CHILL_GATE.z],
  },
);

// Resolve the established layout first; only this replacement moves/enlarges.
Object.assign(
  BIOMES.find((b) => b.id === "autumn"),
  {
    radius: MOSA_RADIUS,
    center: [-150, -42],
    arrival: [MOSA_SHORE_GATE.x, MOSA_SHORE_GATE.z],
    requiredLevel: 8,
  },
);
CATALOG.push({
  id: "ride-mosasaur",
  name: "Марин · морской великан",
  icon: "🦕",
  category: "rides",
  islandOnly: true,
  requiredLevel: 8,
  price: 0,
  buildMinutes: 0,
  footprint: [5, 5],
  actions: ["ride"],
  rarity: "Легендарное",
  description:
    "Друг небесного моря: ныряет глубоко и взлетает над волнами вместе с котиком.",
});

// Add only the new destination after all established centres have settled.
BIOMES.push({
  id: "foodcourt",
  name: "Котячий фуд-корт",
  subtitle: "Бургеры, бабл-ти, котячье печенье и кино под облаками",
  icon: "🍔",
  price: 2800,
  requiredLevel: 6,
  radius: COURT_RADIUS,
  center: [-155, 80],
  arrival: [COURT_GATE.x, COURT_GATE.z],
  ground: 0xa9c48b,
  edge: 0x7e8d92,
  foliage: 0x76aa78,
  accent: 0xf4cc9f,
});
CATALOG.push(
  ...COURT_VENUES.map((o) => ({
    id: o.type,
    name: o.name,
    description: o.description,
    category: "business",
    icon: o.icon,
    price: o.price,
    buildMinutes: o.buildMinutes,
    requiredLevel: 6,
    islandOnly: true,
    rarity: "Островной бизнес",
    footprint: [o.w, o.d],
    actions: [o.kind === "cinema" ? "rest" : "eat", "explore"],
  })),
);
NEIGHBORS.push(...COURT_LOCALS);

CROPS.push({
  id: "court-strawberry",
  name: "Жемчужная клубника",
  icon: "🍓",
  minutes: 18,
  seed: 6,
  value: 38,
  biome: "foodcourt",
});

BIOMES.push({
  id: "bikini",
  name: "Бикини-Боттом",
  subtitle: "Губка Боб, Патрик, крабсбургеры и мыльные пузыри над облаками",
  icon: "🧽",
  price: 2400,
  requiredLevel: 5,
  radius: BIKINI_RADIUS,
  center: [-225, 80],
  arrival: [BIKINI_GATE.x, BIKINI_GATE.z],
  ground: 0xe9d5a3,
  edge: 0x8e939f,
  foliage: 0x91b894,
  accent: 0x62cbd9,
});
CATALOG.push(
  {
    id: BIKINI_RESTAURANT.type,
    name: BIKINI_RESTAURANT.name,
    description: BIKINI_RESTAURANT.description,
    category: "business",
    icon: "🍔",
    price: 0,
    buildMinutes: 0,
    requiredLevel: 5,
    islandOnly: true,
    rarity: "Бикини-Боттом",
    footprint: [12, 10],
    actions: ["eat", "explore"],
  },
  ...BIKINI_FRIENDS.map((f) => ({
    id: f.type,
    name: f.name,
    description: "Живой друг: приветствия, игры и объятия с котиками",
    category: "toys",
    icon: f.kind === "sponge" ? "🧽" : "⭐",
    price: 0,
    buildMinutes: 0,
    requiredLevel: 5,
    islandOnly: true,
    rarity: "Друг Бикини-Боттом",
    footprint: [3, 3],
    actions: ["play"],
  })),
);
NEIGHBORS.push(...BIKINI_LOCALS);

CROPS.push({
  id: "bikini-sea-grape",
  name: "Морской виноград",
  icon: "🟢",
  minutes: 16,
  seed: 5,
  value: 34,
  biome: "bikini",
});

// A genuinely blank plot. Append after resolving the old map, so no existing
// house, island, bridge endpoint or saved coordinate changes.
BIOMES.push({
  id: "homestead",
  name: "Наш остров",
  subtitle: "Огромный цветущий луг — всё остальное построите вы",
  icon: "🌼",
  price: 1800,
  requiredLevel: 3,
  radius: HOMESTEAD_RADIUS,
  center: [...HOMESTEAD_EXPANSION.center],
  arrival: [0, 0],
  ground: 0xabc68c,
  edge: 0x95978e,
  foliage: 0xa1bd84,
  accent: 0xf3d3ba,
});
CROPS.push({
  id: "homestead-strawberry",
  name: "Луговая клубника",
  icon: "🍓",
  minutes: 12,
  seed: 4,
  value: 28,
  biome: "homestead",
});

CATALOG.push(...MEGA_RIDES);

CATALOG.push(DIAMOND_MINE);

BIOMES.push({
  id: "aquarium",
  name: "Котячий океанариум",
  subtitle: "Стеклянный дворец, огромные рыбки-котики и нежные встречи у воды",
  icon: "🐠",
  price: 3200,
  requiredLevel: 14,
  radius: AQUARIUM_RADIUS,
  center: [-335, 95],
  arrival: [AQUARIUM_GATE.x, AQUARIUM_GATE.z],
  ground: 0xcbdca6,
  edge: 0xaaa1b5,
  foliage: 0xa8c986,
  accent: 0xa4dfef,
});
CATALOG.push(
  ...AQUARIUM_TANKS.map((o) => ({
    id: o.type,
    name: o.name,
    description: o.description,
    category: "toys",
    icon: o.icon,
    price: 0,
    buildMinutes: 0,
    requiredLevel: 6,
    islandOnly: true,
    rarity: "Океанариум",
    footprint: [o.w, o.d],
    actions: ["play", "explore"],
  })),
);
NEIGHBORS.push(...AQUARIUM_LOCALS);
for (const product of CATALOG) {
  const water = waterRideSpec(product.id);
  if (water)
    product.waterRide = {
      version: water.version,
      kind: water.kind,
      channels: water.channels,
    };
}
// Run after the established layout: all other island centres remain identical.
for (const [id, spec] of Object.entries(BUILDING_EXPANSIONS)) {
  Object.assign(byBiome(id), {
    radius: expandedBuildingRadius(id),
    center: [...spec.center],
    buildableAreaMultiplier: spec.areaMultiplier,
  });
}

// Independent new destination; existing records and their resolved centres stay byte-for-byte unchanged.
BIOMES.push({
  id: JOB_CITY_ID,
  name: "Cat Job City",
  subtitle: "Місто професій, власних монеток та котячих машин",
  icon: "🏙️",
  price: 6500,
  requiredLevel: 8,
  radius: JOB_CITY_RADIUS,
  center: [...JOB_CITY_CENTER],
  arrival: [0, 59],
  ground: 0xb9c994,
  edge: 0x95978d,
  foliage: 0x82ac6e,
  accent: 0xe9c38a,
});
CATALOG.push(
  ...JOB_BUSINESSES.map((b) => ({
    id: b.id,
    name: b.name,
    description: b.description,
    category: "business",
    icon: b.icon,
    price: 0,
    buildMinutes: 0,
    requiredLevel: 8,
    islandOnly: true,
    rarity: "Cat Job City",
    footprint: [b.w, b.d],
    actions: ["explore"],
  })),
);
NEIGHBORS.push(...JOB_CITY_LOCALS);

// Permanent residential destination. Expansions are sections of this one realm,
// not extra catalogue islands or ordinary (sixty-item-limited) placements.
BIOMES.push({
  id: HOUSING_ID,
  name: "Котячі оселі",
  subtitle: "Власні будиночки котиків · нові квартали з кожною покупкою",
  icon: "🏡",
  price: 0,
  requiredLevel: 8,
  radius: HOUSING_RADIUS,
  center: [...HOUSING_CENTER],
  arrival: [0, 37],
  ground: 0xa7bd8a,
  edge: 0x9e9b92,
  foliage: 0x83a56e,
  accent: 0xe8b5c5,
  housingOnly: true,
});

// Retired models remain source assets, never live islands or hidden colliders.
// Repack the complete active map after all original definitions/expansions.
export const RETIRED_BIOMES = BIOMES.filter(b=>isRetiredBiome(b.id));
for(let i=BIOMES.length-1;i>=0;i--)if(isRetiredBiome(BIOMES[i].id))BIOMES.splice(i,1);
for(const b of BIOMES)b.center=[...WORLD_CENTERS[b.id]];
// An annex beyond the existing waterpark shore; all released island records,
// local building addresses and centres above remain unchanged.
BIOMES.push({...ATOLL_PARK, center:[...ATOLL_PARK.center]});
// Withdrawn at the player's request. Keep historical crop/ownership metadata,
// but never register the four farm islands or their roads in the active world.
RETIRED_BIOMES.push(...MAGIC_FARMS.map(f=>({...f,center:[...f.center]})));
CROPS.push(...MAGIC_FRUITS);
CROPS.push(...MAGIC_BED_CROPS);
for(const n of NEIGHBORS)if(isRetiredBiome(n.biome)){
  n.originBiome=n.biome;n.biome='homestead';
}
for(const crop of CROPS)if(isRetiredBiome(crop.biome))crop.biome='homestead';
for(const job of JOBS)job.biomes=[...new Set(job.biomes.map(id=>isRetiredBiome(id)?'homestead':id))];

// Append without recalculating a single released centre or waterpark record.
BIOMES.push({...ZOO_BIOME,center:[...ZOO_BIOME.center]});
CATALOG.push(...ZOO_EXHIBITS.map(e=>({...e,category:'social',requiredLevel:8,islandOnly:true,rarity:'Чарівний зоопарк',actions:['explore']})));
