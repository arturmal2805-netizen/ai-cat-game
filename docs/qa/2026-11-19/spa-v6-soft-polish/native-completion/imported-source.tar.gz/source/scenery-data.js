import {MOSA_RADIUS} from './mosasaur-data.js';
import { BIOMES, RETIRED_BIOMES, byItem, biomeReservations } from "./game-data.js";
import {magicFarm,magicFarmLayout} from './magic-farms-data.js';

export const SCENERY_TYPES = Object.fromEntries([
  ...[
    ["enchanted", "Лунное дерево", "🌳"],
    ["willow", "Сказочная ива", "🌿"],
    ["maple", "Медовый клён", "🍁"],
    ["apple", "Яблоня с фонариками", "🍎"],
    ["snow", "Снежная ель", "🌲"],
    ["crystal", "Кристальное дерево", "💎"],
    ["palm", "Лагунная пальма", "🌴"],
    ["sakura", "Цветущая сакура", "🌸"],
    ["mushroom", "Грибное дерево", "🍄"],
    ["bamboo", "Бамбуковая рощица", "🎋"],
  ].map(([kind, name, icon]) => [
    "scenery-tree-" + kind,
    { kind, name, icon, category: "tree", footprint: [2.7, 2.7] },
  ]),
  [
    "scenery-cottage",
    {
      name: "Домик волшебника",
      icon: "🏡",
      category: "house",
      footprint: [3.4, 3.8],
    },
  ],
  [
    "scenery-mushroom",
    {
      name: "Грибной домик",
      icon: "🍄",
      category: "house",
      footprint: [3.1, 3.1],
    },
  ],
  [
    "scenery-tea",
    {
      name: "Чайная беседка",
      icon: "🍵",
      category: "house",
      footprint: [3.3, 3.3],
    },
  ],
  [
    "scenery-boulder",
    {
      name: "Мшистый валун",
      icon: "🪨",
      category: "rock",
      footprint: [1.8, 1.6],
    },
  ],
  [
    "scenery-landmark",
    {
      name: "Чудо острова",
      icon: "✨",
      category: "landmark",
      footprint: [4.8, 4.8],
    },
  ],
]);
export const byScenery = (type) => SCENERY_TYPES[type];
export function sceneryFootprint(record, rotation = record.rotation || 0) {
  const spec = byScenery(record.type),
    footprint =
      record.originBiome === "summer" && spec.category === "tree"
        ? [1.9, 1.9]
        : spec.footprint,
    size = footprint.map((v) => v * (record.scale || 1));
  return rotation % 2 ? size.reverse() : size;
}
export function sceneryBounds(record) {
  const [w, d] = sceneryFootprint(record);
  return { ...record, w, d };
}
export function sceneryName(record) {
  return record.type === "scenery-landmark"
    ? "Чудо · " + [...BIOMES,...RETIRED_BIOMES].find((b) => b.id === record.originBiome)?.name
    : byScenery(record.type).name;
}
// Decorative objects keep stable identities separate from purchased attractions.
// This also permits old saves with sixty purchases to retain all their items.
const arrangementCache = new Map();
export function initialScenery(placements = []) {
  const key = JSON.stringify(
    placements.map((p) => [p.item, p.biome, p.x, p.z, p.rotation]),
  );
  if (!arrangementCache.has(key)) {
    const arrangement = buildInitialScenery(placements);
    if (arrangementCache.size >= 4)
      arrangementCache.delete(arrangementCache.keys().next().value);
    arrangementCache.set(key, arrangement);
  }
  // Game actions mutate records, never the reusable authored arrangement.
  return arrangementCache.get(key).map((r) => ({ ...r }));
}
function buildInitialScenery(placements) {
  const result = [];
  for (const biome of BIOMES) {
    if(biome.magicFarm)continue;
    if(biome.waterpark){
      for(const [i,c] of [{type:'scenery-tree-palm',x:-340,z:90,scale:1.1},{type:'scenery-tree-palm',x:335,z:-70,scale:.95},{type:'scenery-boulder',x:-338,z:105,scale:1.2},{type:'scenery-boulder',x:330,z:-85,scale:1.3}].entries())
        result.push({id:'decor-atoll-park-'+i,originBiome:biome.id,biome:biome.id,...c,rotation:0});
      continue;
    }
    if (["homestead", "aquarium", "jobcity", "cat-homes", "atoll-park", "magic-zoo"].includes(biome.id))
      continue;
    const candidates = [
      { type: "scenery-landmark", x: -6, z: -6, scale: 0.88 },
      ...(biome.id === "moon"
        ? [{ type: "scenery-cottage", x: -6, z: -6, scale: 1 }]
        : []),
      ...landscapedTrees(biome.id).map((t) => ({
        type: "scenery-tree-" + t.kind,
        x: t.x,
        z: t.z,
        scale: t.scale,
      })),
      ...[
        [7, -6],
        [-7, 6],
      ].map(([x, z]) => ({
        type: ["sakura", "bamboo", "lotus"].includes(biome.id)
          ? "scenery-tea"
          : "scenery-mushroom",
        x,
        z,
        scale: 0.85,
      })),
      ...[
        [8, 1],
        [1, 8],
        [-8, 0],
        [0, -8],
      ].map(([x, z], i) => ({
        type: "scenery-boulder",
        x,
        z,
        scale: 0.75 + i * 0.08,
      })),
    ];
    if (biome.id === "sakura") {
      candidates.push(
        ...[
          [-7.5, -11],
          [7.5, -11],
          [-7, -2],
          [7, -2],
          [-6.5, 7],
          [6.5, 7],
          [-8, 19],
          [8, 19],
        ].map(([x, z], i) => ({
          type: "scenery-tree-" + (i % 3 === 0 ? "sakura" : "enchanted"),
          x,
          z,
          scale: 0.95 + (i % 3) * 0.12,
        })),
      );
    }
    if (biome.id === "water") {
      // Keep seed IDs/types for old saves; give the larger SPA a planted rim.
      const points = [
        [-9.5, -13],
        [-15, -7],
        [-8.5, -16],
        [0, -17.5],
        [3.4, -17.2],
        [-15, 8.5],
        [-11, 13],
        [4, 13],
        [-8, -9],
        [10, 13],
        [-7, 15],
        [-17, -4],
      ];
      candidates.forEach((c, i) => {
        const p = points[i % points.length];
        c.x = p[0];
        c.z = p[1];
      });
      candidates.push(
        ...[
          [-17, 6],
          [-13, 12],
          [-5, -17],
          [16, -2],
          [16, -8],
          [5, -16],
        ].map(([x, z], i) => ({
          type: "scenery-tree-palm",
          x,
          z,
          scale: 0.9 + (i % 3) * 0.1,
        })),
      );
    }
    if (["autumn", "ice", "galaxy", "volcano", "winter"].includes(biome.id)) {
      const kinds = {
        autumn: ["sakura", "apple"],
        ice: ["sakura", "crystal"],
        galaxy: ["willow", "enchanted"],
        volcano: ["palm", "bamboo"],
        winter: ["palm", "crystal"],
      };
      candidates.push(
        { type: "scenery-tree-" + kinds[biome.id][0], x: 9, z: 7, scale: 1.1 },
        {
          type: "scenery-tree-" + kinds[biome.id][1],
          x: -11,
          z: -1,
          scale: 0.92,
        },
      );
    }
    if (biome.id === "winter") {
      Object.assign(candidates[0], { x: 10, z: -5, scale: 0.86 });
      const houses = candidates.filter((c) => c.type === "scenery-mushroom");
      Object.assign(houses[0], { x: -11, z: 7.5, scale: 0.88 });
      Object.assign(houses[1], { x: 6, z: 10.8, scale: 0.84 });
      Object.assign(candidates.at(-2), { x: 12, z: 6, scale: 0.98 });
      Object.assign(candidates.at(-1), { x: -12, z: 5, scale: 0.92 });
    }
    if (biome.id === "summer") {
      candidates.push(
        ...[
          [-8, -17],
          [-13, -12],
          [-18, -1],
          [-17, 5],
          [-13, 12],
          [11, 12],
          [17, 5],
          [18, -1],
          [13, -12],
          [5, -17],
          [-5, 7],
          [2, -6],
          [-6, -1],
          [4, 8],
        ].map(([x, z], i) => ({
          type: "scenery-tree-palm",
          x,
          z,
          scale: 0.92 + (i % 3) * 0.12,
        })),
      );
    }
    if (biome.id === "clockwork") {
      candidates.push(
        ...[
          [-18, 7],
          [-14, 13],
          [19, 8],
          [15, -12],
          [-8, -19],
          [1, -21],
          [-20, -4],
          [-18, -13],
          [8, 7],
          [4, -7],
          [-4, 3],
        ].map(([x, z], i) => ({
          type: "scenery-tree-sakura",
          x,
          z,
          scale: 0.95 + (i % 3) * 0.12,
        })),
        ...[
          [-10, 7],
          [-5, 8],
          [8, -6],
          [-9, -3],
        ].map(([x, z], i) => ({
          type: "scenery-mushroom",
          x,
          z,
          scale: 0.9 + (i % 2) * 0.12,
        })),
      );
    }
    if (biome.id === "aquapark") {
      candidates.splice(
        0,
        candidates.length,
        ...[
          [-14, 0],
          [-7, 14],
          [5, 15],
          [15, 1],
          [1, -16],
        ].map(([x, z], i) => ({
          type: "scenery-tree-palm",
          x,
          z,
          scale: 1.15 + i * 0.08,
        })),
        ...[
          [-13, 12],
          [3, 15],
          [16, -3],
          [-13, -13],
        ].map(([x, z]) => ({ type: "scenery-boulder", x, z, scale: 1.1 })),
      );
    }
    if (biome.id === "autumn") {
      candidates.splice(
        0,
        candidates.length,
        ...Array.from({ length: 8 }, (_, i) => ({
          type: i % 3 === 0 ? "scenery-boulder" : "scenery-tree-palm",
          x: Math.sin(0.45 + i * 0.78) * (MOSA_RADIUS-4),
          z: Math.cos(0.45 + i * 0.78) * (MOSA_RADIUS-4),
          scale: 0.8 + (i % 3) * 0.14,
        })),
      );
    }
    if (biome.id === "bikini")
      candidates.splice(
        0,
        candidates.length,
        ...[
          [-25, -9],
          [-14, -24],
          [15, -24],
          [26, 7],
          [-22, 21],
        ].map(([x, z]) => ({ type: "scenery-tree-palm", x, z, scale: 1.1 })),
      );
    if (biome.id === "bikini")
      candidates.push(
        { type: "scenery-boulder", x: -27, z: 5, scale: 0.85 },
        { type: "scenery-boulder", x: 17, z: 25, scale: 0.9 },
      );
    if (biome.id === "foodcourt")
      candidates.splice(
        0,
        candidates.length,
        ...Array.from({ length: 16 }, (_, i) => ({
          type: i % 5 === 0 ? "scenery-boulder" : "scenery-tree-palm",
          x: Math.sin(i * 0.39 + 0.15) * 30,
          z: Math.cos(i * 0.39 + 0.15) * 30,
          scale: 0.85 + (i % 3) * 0.13,
        })),
      );
    candidates.forEach((c, index) => {
      const record = {
        id: `decor-${biome.id}-${index}`,
        originBiome: biome.id,
        biome: biome.id,
        ...c,
        rotation: 0,
      };
      const occupied = [
        // Keep a usable building yard beside the starter activities. This is
        // only a planting preference, never a permanent placement restriction.
        ...(biome.id === "moon" ? [{ x: 0, z: -5, w: 6.4, d: 5.4 }] : []),
        ...(biome.id === "summer" ? [{ x: -7, z: -7, w: 5.6, d: 5.6 }] : []),
        ...biomeReservations(biome.id),
        ...placements
          .filter((p) => p.biome === biome.id)
          .map((p) => {
            const size = byItem(p.item).footprint,
              [w, d] = p.rotation % 2 ? [size[1], size[0]] : size;
            return { ...p, w, d };
          }),
        ...result
          .filter((p) => p.biome === biome.id && !p.stored)
          .map(sceneryBounds),
      ];
      const free = (x, z) => {
        const [w, d] = sceneryFootprint(record);
        return (
          Math.hypot(Math.abs(x) + w / 2, Math.abs(z) + d / 2) <=
            (biome.radius ? biome.radius - 0.7 : 10.8) &&
          !occupied.some((p) =>
            ["summer", "autumn"].includes(biome.id) && p.rx && p.rz
              ? (Math.max(0, Math.abs(x - p.x) - w / 2) / p.rx) ** 2 +
                  (Math.max(0, Math.abs(z - p.z) - d / 2) / p.rz) ** 2 <
                1
              : Math.abs(x - p.x) < (w + p.w) / 2 + 0.2 &&
                Math.abs(z - p.z) < (d + p.d) / 2 + 0.2,
          )
        );
      };
      let point = free(c.x, c.z) ? { x: c.x, z: c.z } : null;
      if (!point) {
        const choices = [];
        for (
          let x = -(biome.radius ? 17 : 9);
          x <= (biome.radius ? 17 : 9);
          x++
        )
          for (
            let z = -(biome.radius ? 17 : 9);
            z <= (biome.radius ? 17 : 9);
            z++
          )
            if (free(x, z)) choices.push({ x, z });
        choices.sort(
          (a, b) =>
            Math.hypot(a.x - c.x, a.z - c.z) - Math.hypot(b.x - c.x, b.z - c.z),
        );
        point = choices[0];
      }
      result.push({ ...record, ...point, ...(!point ? { stored: true } : {}) });
    });
  }
  return result;
}

// Authored arrangements rather than a uniform ring of repeated trees.
const layouts = {
  "atoll-park": [[-340,90,"palm",1.1],[335,-70,"palm",.95]],
  aquapark: [
    [-14, 0, "palm", 1.15],
    [-7, 14, "palm", 1.23],
    [5, 15, "palm", 1.31],
    [15, 1, "palm", 1.39],
    [1, -16, "palm", 1.47],
  ],
  moon: [
    [-1, -8, "enchanted", 1],
    [6, -3, "willow", 1.08],
    [-5, 6, "enchanted", 0.82],
  ],
  autumn: [
    [-4, 5, "maple", 1.12],
    [5, -5, "maple", 0.91],
    [7, 3, "apple", 0.76],
  ],
  winter: [
    [-4, 5, "snow", 1.13],
    [5, -4, "crystal", 0.92],
    [7, 4, "snow", 0.72],
  ],
  beach: [
    [-8, 3, "palm", 1.1],
    [6, 5, "palm", 1.04],
  ],
  water: [
    [6, -4, "willow", 1.15],
    [5, 6, "palm", 0.9],
  ],
  wizard: [
    [-3, 6, "mushroom", 1.12],
    [6, -4, "enchanted", 1.03],
    [7, 3, "mushroom", 0.74],
  ],
  summer: [
    [-5, 4, "apple", 1.1],
    [5, -5, "apple", 0.84],
    [7, 2, "willow", 0.9],
  ],
  nature: [
    [-5, 4, "willow", 1.12],
    [5, -5, "apple", 0.94],
    [7, 2, "enchanted", 0.76],
  ],
  sakura: [
    [6, -5, "sakura", 1.12],
    [1, 7, "sakura", 0.95],
    [-7, 3, "willow", 0.8],
  ],
  clouds: [
    [-4, 5, "crystal", 0.96],
    [6.5, -3.5, "enchanted", 0.9],
  ],
  desert: [
    [4, -5, "palm", 1.05],
    [-3, 7, "palm", 0.8],
  ],
  stars: [
    [-5, 4, "enchanted", 1.04],
    [6, -3, "crystal", 0.81],
  ],
  volcano: [
    [-5, 4, "maple", 0.91],
    [5, -3, "mushroom", 0.84],
  ],
  crystal: [
    [-4, 5, "crystal", 1.15],
    [6, -4, "crystal", 0.87],
    [7, 3, "enchanted", 0.72],
  ],
  candy: [
    [-5, 4, "sakura", 0.97],
    [5, -4, "apple", 1.02],
    [7, 3, "mushroom", 0.77],
  ],
  rainbow: [
    [-4, 5, "sakura", 1.08],
    [5, -4, "willow", 0.99],
    [7, 3, "crystal", 0.72],
  ],
  bamboo: [
    [-5, 4, "bamboo", 1.13],
    [5, -5, "bamboo", 0.98],
    [7, 2, "willow", 0.78],
  ],
  mushrooms: [
    [-4, 5, "mushroom", 1.17],
    [6, -4, "mushroom", 0.9],
    [6, 5, "enchanted", 0.76],
  ],
  galaxy: [
    [-5, 4, "crystal", 1.03],
    [6, -3, "mushroom", 0.92],
  ],
  coral: [
    [-7.8, 2.3, "palm", 1.14],
    [5.8, 6.2, "palm", 1.07],
  ],
  lotus: [
    [6, -4, "willow", 1.16],
    [4, 7, "bamboo", 0.91],
  ],
  ice: [
    [-4, 5, "crystal", 1.16],
    [6, -4, "snow", 0.92],
  ],
  clockwork: [
    [-5, 4, "maple", 1.03],
    [5, -4, "apple", 0.91],
    [7, 3, "enchanted", 0.74],
  ],
  dusk: [
    [-4, 5, "willow", 1.12],
    [6, -4, "enchanted", 1],
    [7, 3, "mushroom", 0.74],
  ],
};
layouts.bikini = [
  [-25, -9, "palm", 1.1],
  [15, -24, "palm", 0.95],
  [26, 7, "palm", 1.03],
];
layouts.foodcourt = [
  [-27, -8, "palm", 1.1],
  [24, 22, "palm", 0.95],
  [-4, -28, "apple", 1.02],
];
const artKinds = {
  enchanted: [false, 0, "oak"],
  sakura: [false, 1, "sakura"],
  palm: [false, 2, "palm"],
  snow: [false, 3, "snow"],
  willow: [true, 0, "oak"],
  maple: [true, 1, "maple"],
  bamboo: [true, 2, "bamboo"],
  apple: [true, 3, "fruit"],
  crystal: [true, 4, "snow"],
  mushroom: [true, 5, "oak"],
};
Object.assign(layouts, {
  winter: [
    [-11, -8, "palm", 1.22],
    [9, 9, "palm", 1.08],
    [-4, 12, "crystal", 0.9],
  ],
  autumn: [
    [-9, 4, "sakura", 1.18],
    [6, -5, "apple", 1.02],
    [6, 7, "sakura", 0.94],
  ],
  ice: [
    [-9, 4, "sakura", 1.12],
    [6, -5, "crystal", 1.05],
    [6, 7, "sakura", 0.94],
  ],
  galaxy: [
    [-9, 4, "willow", 1.2],
    [6, -5, "enchanted", 0.96],
    [6, 7, "willow", 0.92],
  ],
  volcano: [
    [-9, 4, "palm", 1.28],
    [6, -5, "palm", 1.04],
    [6, 7, "bamboo", 1.1],
  ],
});
export function landscapedTrees(id) {
  const farm=magicFarm(id);if(farm)return magicFarmLayout(id).plants.filter(p=>p.kind!=='pumpkin').map((p,i)=>({id:'tree-'+id+'-'+p.id,kind:farm.kind==='crystal'?'crystal':farm.kind==='cloud'?'sakura':farm.kind==='moon'?'willow':'enchanted',x:p.x,z:p.z,scale:p.hero?1.65:1,cell:i%6}));
  return (layouts[id] || []).map(([x, z, kind, scale], index) => {
    const [trees, cell, fallback] = artKinds[kind];
    return {
      id: `tree-${id}-${index}`,
      x,
      z,
      kind,
      scale,
      trees,
      cell,
      fallback,
      height: 4.7 * scale,
      width: 4.3 * scale,
    };
  });
}
