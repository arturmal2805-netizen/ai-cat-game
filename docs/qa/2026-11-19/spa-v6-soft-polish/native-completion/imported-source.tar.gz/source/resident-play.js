import * as THREE from "three";
import {groupBoardingFrame} from './group-boarding.js';
import {catNavigationRadius} from './cat-navigation-size.js';
import { yarnPlayFrame, applyYarnFrame, resetYarn } from "./yarn-play.js";
import { swimFrame } from "./swimming.js";
import {
  reserveSlide,
  releaseSlide,
  launchSlide,
  hasSlideRoom,
} from "./slide-riders.js";
import {
  socialFrame,
  socialDuration,
  socialContext,
  chooseSocialRide,
} from "./social-animation.js";
// Uses the same authored ride seats, toy chase and swim frames as Chichi.
// Each normal object has one reservation; communal SPA/Chill seating uses its
// existing multi-place runtime instead. No new cat meshes or saved AI moods.
function riderPhase(v, now) {
  if (!v.rider) return "activity";
  launchSlide(v.object, v.rider, now);
  return "queue";
}
function localQueue(result, g, rider, u) {
  result.position.copy(
    g.localToWorld(
      new THREE.Vector3(...rider.queue).lerp(
        new THREE.Vector3(...rider.entry),
        u * u * (3 - 2 * u),
      ),
    ),
  );
  result.walking = u > 0 && u < 1;
  result.yaw =
    g.rotation.y +
    Math.atan2(
      rider.entry[0] - rider.queue[0],
      rider.entry[2] - rider.queue[2],
    );
}
export function createResidentPlay({
  getCat,
  getObject,
  groundY = () => 0.16,
  disturb = (g, f, time) =>
    g.userData.lagoon?.userData.disturb?.(f.x, f.z, time, 0.4),
  onComplete = () => {},
  random = Math.random,
  concurrentSlides = false,
  onGroupReserved = () => {},
}) {
  const visits = new Map(),
    locks = new Map(),
    point = new THREE.Vector3();
  function cancel(id) {
    const v = visits.get(id);
    if (!v) return;
    if (v.phase !== "approach" &&
        (v.object?.userData.deepRide || v.object?.userData.mega)) {
      const n = getCat(id);
      if (n) {
        n.carrier.position.copy(
          v.object.localToWorld(
            new THREE.Vector3(...v.object.userData.dismount),
          ),
        );
        n.carrier.position.y = 0.16;
        n.carrier.rotation.x = 0;
        n.carrier.rotation.z = 0;
      }
    }
    if (v.friend && v.social) {
      const actor = getCat(id);
      for (const a of [actor, v.friend])
        if (a)
          a.carrier.position.y = groundY(a.carrier.position, a.profile.biome);
    }
    if (v.object) {
      if(v.harvester&&v.phase==='activity'&&v.object.userData.magicBed){const n=getCat(id);if(n)n.carrier.position.copy(v.object.localToWorld(new THREE.Vector3(v.harvester.entry.x,.16,v.harvester.entry.z)));}
      v.object.userData.releaseHarvest?.(id);
      v.object.userData.releasePlay?.(getCat(id)?.carrier);
      resetYarn(v.object);
      v.object.userData.playing = false;
      delete v.object.userData.heroPlayPos;
      releaseSlide(v.object, id);v.object.userData.releaseRide?.(id);
      if (!v.object.userData.slideRiders?.size)
        delete v.object.userData.rideElapsed;
    }
    if (
      locks.get(v.decision.activityId || "friend:" + v.decision.friendId) === id
    )
      locks.delete(v.decision.activityId || "friend:" + v.decision.friendId);
    visits.delete(id);
  }
  function start(id, decision, now = performance.now()) {
    const n = getCat(id),
      object = getObject(decision.activityId),
      friend = getCat(decision.friendId);
    if (
      !n ||
      (!object && !friend) ||
      decision.friendId === id ||
      (locks.has(decision.activityId || "friend:" + decision.friendId) &&
        !(
          concurrentSlides &&
          decision.action === "ride" &&
          hasSlideRoom(object) || decision.action==='farm'&&object?.userData.harvests?.available()
        ))
    )
      return false;
    cancel(id);
    const harvester=decision.action==='farm'&&(object?.userData.magicFarm||object?.userData.magicBed)?object.userData.reserveHarvest(id,catNavigationRadius(n.model),decision.bedCell):null;
    if((object?.userData.magicFarm||object?.userData.magicBed)&&decision.action==='farm'&&!harvester)return false;
    const rider =
      concurrentSlides &&
      decision.action === "ride" &&
      object?.userData.slideWater
        ? reserveSlide(object, id)
        : null;
    if (
      concurrentSlides &&
      decision.action === "ride" &&
      object?.userData.slideWater &&
      !rider
    )
      return false;
    const social = friend
      ? socialContext(n.model, friend.model, { ride: chooseSocialRide(random) })
      : null;
    const bounds = object?.userData.swimBounds || { rx: 1.7, rz: 1.7 };
    const destination = object
      ? object.localToWorld(
          new THREE.Vector3(
            decision.action === "swim" ? bounds.rx + 0.65 : 0,
            0,
            decision.action === "swim" ? 0 : 1.2,
          ),
        )
      : friend.carrier.position
          .clone()
          .add(new THREE.Vector3(social.gap, 0, 0));
    if (object?.userData.approachOffset)
      destination.copy(
        object.localToWorld(
          new THREE.Vector3(...object.userData.approachOffset),
        ),
      );
    if (object?.userData.approachFrame && decision.action === "ride")
      destination.copy(
        object.localToWorld(
          new THREE.Vector3(...object.userData.rideFrame(0, true).position),
        ),
      );
    if (rider)
      destination.copy(object.localToWorld(new THREE.Vector3(...rider.queue)));
    if(harvester)destination.copy(object.localToWorld(new THREE.Vector3(harvester.entry.x,harvester.entry.y,harvester.entry.z)));
    if (!object?.userData.approachFrame)
      destination.y =
        decision.action === "swim"
          ? (object.userData.shoreHeight ?? object.position.y)
          : groundY(
              destination,
              object?.userData.placement?.biome || n.profile.biome,
            );
    if(decision.action==='ride')object?.userData.prepareRide?.(id);
    const v = {
      id,
      rider,
      harvester,
      social,
      socialKind: friend && social.ride ? "piggyback" : "play",
      decision,
      object,
      friend,
      from: n.carrier.position.clone(),
      destination,
      shoreLocal:
        object && decision.action === "swim"
          ? object.worldToLocal(destination.clone())
          : null,
      started: now,
      travel: object?.userData.approachDuration
        ? object.userData.approachDuration(object.worldToLocal(n.carrier.position.clone()).toArray(),object.worldToLocal(destination.clone()).toArray())
        : Math.min(
        6500,
        Math.max(900, n.carrier.position.distanceTo(destination) * 160),
      ),
      phase: "approach",
      elapsed: 0,
      origin: friend?.carrier.position.clone(),
    };
    visits.set(id, v);
    if(rider&&object.userData.groupSeats)onGroupReserved(object);
    locks.set(decision.activityId || "friend:" + decision.friendId, id);
    return true;
  }
  function frame(id, now, time, reduced = false) {
    const v = visits.get(id);
    if (!v) return null;
    const n = getCat(id),
      g = v.object,
      d = v.decision;
    if (
      !n ||
      (g && g !== getObject(d.activityId)) ||
      (v.friend && v.friend !== getCat(d.friendId))
    ) {
      cancel(id);
      return null;
    }
    const result = {
      position: n.carrier.position.clone(),
      yaw: n.carrier.rotation.y,
      walking: false,
      reaction: null,
      mood: d.action === "rest" ? "sleep" : "happy",
      roll: 0,
      pitch: 0,
      quaternion: null,
    };
    if (v.phase === "approach") {
      const t = Math.min(1, (now - v.started) / (reduced ? 50 : v.travel)),
        q = t * t * (3 - 2 * t);
      if (g?.userData.approachFrame) {
        const a = g.worldToLocal(v.from.clone()),
          b = g.worldToLocal(v.destination.clone());
        result.position.copy(
          g.localToWorld(
            new THREE.Vector3(
              ...g.userData.approachFrame(a.toArray(), b.toArray(), t),
            ),
          ),
        );
      } else result.position.lerpVectors(v.from, v.destination, q);
      result.yaw = Math.atan2(
        v.destination.x - v.from.x,
        v.destination.z - v.from.z,
      );
      if(g?.userData.approachYaw)result.yaw=g.rotation.y+g.userData.approachYaw(g.worldToLocal(v.from.clone()).toArray(),g.worldToLocal(v.destination.clone()).toArray(),t);
      result.walking = t < 1;
      result.mood = "happy";
      if (t >= 1) {
        v.phase = riderPhase(v, now);
        v.activityStart = now;
        if (v.social) {
          v.social.heroYaw = result.yaw;
          v.social.friendYaw = v.friend.carrier.rotation.y;
        }
        if (g && d.action === "play") g.userData.playing = true;
      }
      return result;
    }
    if (v.phase === "queue") {
      if(g.userData.groupSeats){
        const f=groupBoardingFrame(g,v.rider,now,reduced);
        result.position.copy(g.localToWorld(new THREE.Vector3(...f.position)));
        result.quaternion=g.quaternion.clone().multiply(new THREE.Quaternion().fromArray(f.quaternion));
        result.walking=f.walking;result.reaction=f.reaction;
        if(f.departed){v.phase='activity';v.activityStart=v.rider.launchAt;}
        return result;
      }
      const launch = v.rider.launchAt,
        u = Math.min(1, Math.max(0, (now - launch) / 1100));
      localQueue(result, g, v.rider, u);
      if (u >= 1) {
        v.phase = "activity";
        v.activityStart = g?.userData.groupSeats ? launch + 1100 : now;
      }
      return result;
    }
    const elapsed = (now - v.activityStart) / 1000 + (v.rider?.routeOffset||0);
    v.elapsed = elapsed;
    let local = point.set(0, 0.16, 0),
      world = false;
    if(d.action==='farm'&&v.harvester){
      const f=v.harvester.frame(elapsed,reduced);local.set(...f.position);result.yaw=g.rotation.y+f.yaw;result.walking=f.walking;result.reaction=f.reaction;g.userData.showHarvest(v.harvester,f);
    }else if (d.action === "ride" && g) {
      if (g.userData.rideFrame) {
        g.userData.rideElapsed = elapsed;
        if (v.rider) v.rider.elapsed = elapsed;
        const f = g.userData.rideFrame(elapsed, reduced, v.rider?.lane || 0);
        result.walking = f.walking ?? false;
        local.set(...f.position);
        result.yaw = (f.yaw || 0) + g.rotation.y;
        result.roll = f.roll || 0;
        result.pitch = f.pitch || 0;
        if (f.quaternion)
          result.quaternion = g.quaternion
            .clone()
            .multiply(new THREE.Quaternion().fromArray(f.quaternion));
        result.reaction = g.userData.rideReaction?.(
          elapsed,
          reduced,
          v.rider?.lane || 0,
        ) || {
          paw: f.paw || 0,
          headPitch: f.headPitch || 0,
          surprise: f.surprise || 0,
        };
        g.userData.update?.(time, reduced);
      } else if (g.userData.curve) {
        local.copy(
          g.userData.curve.getPoint(
            (g.userData.id === "waterslide" ? elapsed / 4 : time * 0.1) % 1,
          ),
        );
        local.y += 0.5;
      } else if (g.userData.id === "carousel") {
        local.set(
          Math.cos(time * 0.65) * 1.05,
          0.95,
          -Math.sin(time * 0.65) * 1.05,
        );
      } else if (g.userData.id === "ferris") {
        local.set(
          -Math.sin(time * 0.4) * 1.5,
          2 + Math.cos(time * 0.4) * 1.5,
          0.18,
        );
      } else if (g.userData.moving) {
        local.copy(
          g.userData.moving.localToWorld(
            new THREE.Vector3(0, g.userData.seatHeight || 0.5, 0),
          ),
        );
        world = true;
      } else local.y += reduced ? 0 : Math.abs(Math.sin(elapsed * 3)) * 1.5;
      if (!g.userData.rideFrame) result.yaw = time * 0.8;
    } else if (d.action === "play" && g?.userData.id === "yarn") {
      const f = yarnPlayFrame(elapsed, reduced);
      applyYarnFrame(g, f);
      local.set(f.cat.x, 0.16 + f.jump, f.cat.z);
      result.yaw = g.rotation.y + f.yaw;
      result.walking = f.running;
      result.reaction = f;
    } else if (d.action === "play" && g?.userData.playFrame) {
      const f = g.userData.playFrame(elapsed, reduced);
      g.userData.heroPlayPos = { x: f.position[0], z: f.position[2] };
      local.set(...f.position);
      result.yaw = g.rotation.y + (f.yaw || 0);
      result.reaction = f.reaction || { paw: f.paw };
      result.walking = f.walking ?? !reduced;
    } else if (d.action === "swim") {
      const bounds = g.userData.swimBounds || { rx: 1.7, rz: 1.7 },
        f = swimFrame(elapsed, bounds, n.index, reduced);
      local.set(f.x, f.y, f.z);
      result.yaw = f.yaw;
      result.reaction = f;
      result.walking = true;
      if (elapsed > 10)
        local.lerp(v.shoreLocal, Math.min(1, (elapsed - 10) / 2));
      if (!reduced) disturb(g, f, time);
    } else if (d.action === "rest") {
      local.y = g.userData.id === "bed" ? 0.3 : 0.16;
      result.reaction = { headPitch: 0.12 };
    } else if (d.action === "eat") {
      local.set(-0.3, 0.16, 0.8);
      result.yaw = g.rotation.y + Math.PI;
      result.reaction = {
        headPitch: 0.25 + (reduced ? 0 : Math.sin(elapsed * 4) * 0.06),
      };
    } else if (d.action === "farm") {
      local.set(Math.sin(elapsed * 1.5), 0.18, Math.cos(elapsed * 1.5) * 0.7);
      result.walking = true;
      result.yaw = elapsed;
      result.reaction = { paw: Math.max(0, Math.sin(elapsed * 3)) * 0.3 };
    } else if (d.action === "meet") {
      const f = socialFrame(elapsed, v.socialKind, reduced, v.social),
        friend = v.friend;
      result.position
        .copy(v.origin)
        .add(new THREE.Vector3(f.hero.x, f.hero.jump, f.hero.z));
      result.yaw = f.hero.yaw;
      result.walking = f.hero.running;
      result.reaction = f.hero;
      if (friend) {
        friend.carrier.position
          .copy(v.origin)
          .add(new THREE.Vector3(f.friend.x, f.friend.jump, f.friend.z));
        friend.carrier.rotation.y = f.friend.yaw;
        v.friendFrame = f.friend;
      }
    } else if (d.action === "party") {
      local.y = 0.35 + (reduced ? 0 : Math.abs(Math.sin(elapsed * 4)) * 0.15);
      result.yaw = Math.sin(elapsed * 2) * 0.35;
    } else if (d.action === "play") {
      local.set(Math.sin(elapsed * 2) * 0.7, 0.16, Math.cos(elapsed * 2) * 0.7);
      if (g.userData.id === "tunnel")
        local.set(Math.sin(elapsed) * 1.35, 0.16, 0);
      result.walking = true;
      result.yaw = -elapsed * 2;
    } else {
      local.z = 0.9;
      result.yaw = g.rotation.y + Math.sin(elapsed * 0.9) * 0.3;
    }
    if (g) result.position.copy(world ? local : g.localToWorld(local));
    if (d.action === "swim" && elapsed < 1) {
      const t = Math.max(0, elapsed),
        q = t * t * (3 - 2 * t);
      result.position.lerpVectors(v.destination, result.position, q);
    }
    const duration = reduced
      ? 0.3
      : d.action === "meet"
        ? socialDuration(v.socialKind)
        : d.action === "swim"
          ? 12
          : g?.userData.duration || 10;
    if (v.harvester?v.harvester.finished:elapsed > duration) {
      if (d.action !== "meet")
        result.position.copy(
          g?.userData.deepRide
            ? g.localToWorld(new THREE.Vector3(...g.userData.dismount))
            : v.destination,
        );
      if (d.action === "meet")
        result.position.y = groundY(result.position, n.profile.biome);
      result.quaternion = null;
      result.pitch = 0;
      result.roll = 0;
      cancel(id);
      if (g?.userData.bikiniFriend && d.characterAction === "carry")
        result.position.copy(n.carrier.position);
      onComplete(id, d, v.harvester?(g?.userData.magicBed?{bedHarvest:v.harvester.receipt}:{magicHarvest:v.harvester.receipt}):{});
      result.completed = true;
    }
    return result;
  }
  return {
    visits,
    start,
    cancel,
    frame,
    get: (id) => visits.get(id),
    reserved: (id) =>
      locks.has(id) && !(concurrentSlides && hasSlideRoom(getObject(id))) && !getObject(id)?.userData.harvests?.available(),
    friendVisit: (id) =>
      [...visits.values()].find((v) => v.decision.friendId === id),
    clear() {
      for (const id of [...visits.keys()]) cancel(id);
    },
  };
}
