// city-ai-pack.mjs
function packCityPayload(payload, columns) {
  const counts = /* @__PURE__ */ new Map();
  const count = (v) => {
    if (typeof v === "string") counts.set(v, (counts.get(v) || 0) + 1);
    else if (Array.isArray(v)) v.forEach(count);
  };
  for (const [table, positions] of Object.entries(columns)) for (const row2 of payload[table] || []) for (const index of positions) count(row2[index]);
  const text2 = [], indices = /* @__PURE__ */ new Map();
  for (const [value, n] of counts) {
    const original = JSON.stringify(value).length, digits = String(text2.length).length;
    if (n > 1 && (original - digits) * n > original + 1) {
      indices.set(value, text2.length);
      text2.push(value);
    }
  }
  if (!text2.length) return payload;
  const encode = (v) => typeof v === "string" ? indices.has(v) ? indices.get(v) : v : Array.isArray(v) ? v.map(encode) : v;
  const packed = { ...payload };
  for (const [table, positions] of Object.entries(columns)) if (payload[table]) packed[table] = payload[table].map((row2) => {
    const next = [...row2];
    for (const i of positions) if (i < next.length) next[i] = encode(next[i]);
    return next;
  });
  packed.text = text2;
  return JSON.stringify(packed).length < JSON.stringify(payload).length ? packed : payload;
}
var CITY_PLAN_TEXT_COLUMNS = Object.freeze({ cats: [2, 14] });
var CITY_LIFE_TEXT_COLUMNS = Object.freeze({ careers: [1], evenings: [1, 6, 7], buyers: [5], singles: [3] });
var CITY_PLAN_PACKING_HINT = " If text exists, numbers in cat personality or wishes are indices into text; strings stay literal. Decode before reasoning. All other numbers retain their column meaning.";
var CITY_LIFE_PACKING_HINT = " If text exists, numbers in personality, wishes or visitedMallStores columns are indices into text; strings stay literal. Decode before reasoning. All other numbers retain their column meaning.";

// public/resort-spa-pool-data.js
var RESORT_POOL = Object.freeze({ depth: 1.8, rise: 0.3, run: 0.75, steps: 6, width: 4, foot: 0.012 });

// public/resort-spa-data.js
var RESORT_SPA = Object.freeze({ id: "chichi-underwater-spa", biome: "autumn", x: 0, z: 225, offsetZ: -20, y: -165, width: 248, depth: 144, rise: 9, levels: 3, gate: { x: 0, z: 153, y: -164.82 }, palette: { water: 53231, deep: 663101, amber: 16757575, gold: 16764016, pink: 16723610, lavender: 12086271, ivory: 16770500, coral: 15945166 } });
var rows = [
  ["thermal", "Grand Thermal Lagoon", "swim", 150, 0, 266, 0, 50, 24, 12],
  ["jacuzzi", "Luxury Jacuzzi Terraces", "jacuzzi", 150, -65, 265, 1, 23, 21, 8],
  ["massage", "Massage Palace", "massage", 300, -88, 219, 0, 25, 24, 6],
  ["aroma", "Aroma Therapy Garden", "aroma", 180, 87, 263, 0, 24, 22, 6],
  ["sauna", "Sauna & Steam Palace", "sauna", 120, 87, 219, 1, 25, 24, 8],
  ["cabana", "Floating Glass Cabanas", "cabana", 200, -82, 177, 1, 28, 18, 6],
  ["beauty", "Beauty & Grooming", "groom", 180, 82, 177, 0, 28, 18, 6],
  ["vip", "Golden Galaxy VIP Suite", "vip", 700, 43, 208, 2, 20, 19, 4],
  ["meditation", "Ocean Meditation Dome", "meditate", 100, 87, 263, 2, 24, 22, 8],
  ["nap", "Cat Nap Galaxy", "sleep", 100, -43, 208, 2, 20, 19, 8],
  ["cafe", "Wellness Caf\xE9", "eat", 100, 0, 203, 1, 30, 24, 8],
  ["waterfall", "Waterfall Relaxation Garden", "garden", 100, 0, 266, 2, 46, 24, 8],
  ["amber", "Amber Star Lounge", "lounge", 100, -88, 219, 2, 25, 24, 8],
  ["midnight", "Midnight Blue Relaxation Room", "sleep", 100, 82, 177, 2, 28, 18, 8]
];
var RESORT_ZONES = Object.freeze(rows.map(([key, name, procedure, price, x, z, level, rx, rz, seats]) => Object.freeze({ id: "resort-" + key, key, name, procedure, price, x, z, level, y: RESORT_SPA.y + level * RESORT_SPA.rise, rx, rz, seats, biome: "autumn", resort: true, kind: procedure === "eat" ? "food" : "spa", action: procedure === "eat" ? "eat" : procedure === "swim" ? "swim" : "rest" })));
var resortZone = (id) => RESORT_ZONES.find((z) => z.id === id);
var RESORT_PROCEDURE_PRICE = Object.freeze({ entry: 100, thermal: 150, massage: 300, aroma: 180, sauna: 120, vip: 700 });
var RESORT_PRODUCTS = Object.freeze(RESORT_ZONES.map((z) => Object.freeze({ id: z.id + "-session", storeId: z.id, name: z.name, brand: "CHICHI CAT SPA", category: "mall", kind: z.kind, use: z.procedure === "eat" ? "eat" : "spa", icon: "\u{1FAB7}", price: z.price, stock: 1e5, unique: false, resort: true })));
function resortOffers(game) {
  return game.unlocked?.includes("autumn") ? RESORT_ZONES.map((z) => ({ id: z.id, type: z.id, biome: "autumn", name: "SPA \xB7 " + z.key, action: z.action })) : [];
}
var RESORT_STAIRS = Object.freeze([0, 1].map((level) => Object.freeze({ level, x: level ? -25 : 25, z: 187, count: 30, rise: 0.3, run: 1.1, width: 5, landingZ: 222 })));

// public/mall-layout.js
var MALL_LAYOUT = Object.freeze({
  version: 2,
  biome: "autumn",
  x: 0,
  z: 65,
  y: -165,
  rise: 8.5,
  radius: 60,
  atriumRadius: 22,
  lift: { x: -43, z: 81, radius: 11.8, landing: 15 },
  gate: { x: -33, y: 0.35, z: 107 },
  capacity: 4,
  speed: 9,
  shoreJoin: { x: 0, y: 0.35, z: 110 },
  wings: [{ x: -86.5, z: 65, w: 80, d: 70, corner: 22 }, { x: 86.5, z: 65, w: 80, d: 70, corner: 22 }],
  pavilions: [{ id: "mall-west-pavilion", x: -150, z: 45, radius: 18, roofRadius: 20, floor: 2, connection: { x: -118, z: 60 } }, { id: "mall-east-pavilion", x: 150, z: 45, radius: 18, roofRadius: 20, floor: 6, connection: { x: 118, z: 60 } }],
  room: { w: 28, d: 24, h: 7.4 },
  arrivalLobby: { x: -43, z: 102, w: 36, d: 34, corner: 5 }
});
function roundedMallRectDistance(x, z, room) {
  const qx = Math.abs(x - room.x) - room.w / 2 + room.corner, qz = Math.abs(z - room.z) - room.d / 2 + room.corner;
  return Math.hypot(Math.max(qx, 0), Math.max(qz, 0)) + Math.min(Math.max(qx, qz), 0) - room.corner;
}
function mallBuildingFootprintDistance(x, z) {
  let d = Math.hypot(x - MALL_LAYOUT.x, z - MALL_LAYOUT.z) - MALL_LAYOUT.radius;
  for (const wing of MALL_LAYOUT.wings) d = Math.min(d, roundedMallRectDistance(x, z, wing));
  d = Math.min(d, roundedMallRectDistance(x, z, MALL_LAYOUT.arrivalLobby));
  return d;
}
function mallConstructionFootprintDistance(x, z) {
  let d = mallBuildingFootprintDistance(x, z);
  for (const p of MALL_LAYOUT.pavilions) d = Math.min(d, Math.hypot(x - p.x, z - p.z) - (p.roofRadius || p.radius));
  d = Math.min(d, Math.hypot(x - MALL_LAYOUT.lift.x, z - MALL_LAYOUT.lift.z) - MALL_LAYOUT.lift.radius - 1.8);
  for (const p of MALL_LAYOUT.pavilions) {
    const a = p.connection, dx = p.x - a.x, dz = p.z - a.z, length = Math.hypot(dx, dz), mx = (p.x + a.x) / 2, mz = (p.z + a.z) / 2;
    const along = ((x - mx) * dx + (z - mz) * dz) / length, across = (-(x - mx) * dz + (z - mz) * dx) / length;
    d = Math.min(d, roundedMallRectDistance(along, across, { x: 0, z: 0, w: length, d: 10, corner: 0 }));
  }
  return d;
}
function mallRoomPlacement(index, count = 7) {
  if (count === 3 && index === 2) return { x: 0, z: MALL_LAYOUT.z - 47.8, yaw: 0, w: 28, d: 20, zone: "atrium" };
  if (index < 4) {
    const x = (count <= 3 ? [-91, 87] : [-106.5, -76.5, 72.5, 102.5])[index];
    return { x, z: 78, yaw: 0, w: 28, d: 24, zone: x < 0 ? "west" : "east" };
  }
  const angles = count === 5 ? [Math.PI * 3 / 2] : count === 6 ? [Math.PI * 4 / 3, Math.PI * 5 / 3] : [Math.PI * 7 / 6, Math.PI * 3 / 2, Math.PI * 11 / 6];
  const angle = angles[index - 4], r = 47.8;
  if (angle === void 0) throw Error("Mall floor requires another authored room");
  return { x: Math.cos(angle) * r, z: MALL_LAYOUT.z + Math.sin(angle) * r, yaw: -angle - Math.PI / 2, w: 28, d: 20, zone: "atrium" };
}
function mallFoundationBedY(x, z, natural) {
  const cove = (Math.hypot(x / 112, (z - 145) / 50) - 1) * 50;
  const d = Math.min(mallConstructionFootprintDistance(x, z), cove);
  if (d >= 14) return natural;
  const t = Math.min(1, Math.max(0, (14 - d) / 12)), f = t * t * (3 - 2 * t);
  return natural + (Math.min(natural, MALL_LAYOUT.y - 4.5) - natural) * f;
}

// public/mall-ice-data.js
var MALL_ICE_FLAVORS = Object.freeze([
  { key: "strawberry-cloud", name: "\u041F\u043E\u043B\u0443\u043D\u0438\u0447\u043D\u0430 \u0445\u043C\u0430\u0440\u0438\u043D\u043A\u0430", icon: "\u{1F353}", price: 45, color: 16740515, accent: 14166880, style: "scoop", reaction: "delight" },
  { key: "blue-lagoon", name: "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0430 \u043B\u0430\u0433\u0443\u043D\u0430", icon: "\u{1FAD0}", price: 48, color: 4708607, accent: 6840553, style: "swirl", reaction: "cool" },
  { key: "pistachio-garden", name: "\u0424\u0456\u0441\u0442\u0430\u0448\u043A\u043E\u0432\u0438\u0439 \u0441\u0430\u0434", icon: "\u{1F33F}", price: 52, color: 12117111, accent: 5536568, style: "scoop", reaction: "savour" },
  { key: "mango-sun", name: "\u041C\u0430\u043D\u0433\u043E\u0432\u0435 \u0441\u043E\u043D\u0435\u0447\u043A\u043E", icon: "\u{1F96D}", price: 50, color: 16762430, accent: 16743990, style: "swirl", reaction: "delight" },
  { key: "vanilla-pearl", name: "\u0412\u0430\u043D\u0456\u043B\u044C\u043D\u0430 \u043F\u0435\u0440\u043B\u0438\u043D\u0430", icon: "\u{1F366}", price: 40, color: 16773075, accent: 13808012, style: "swirl", reaction: "savour" },
  { key: "cosmic-rainbow", name: "\u041A\u043E\u0441\u043C\u0456\u0447\u043D\u0430 \u0432\u0435\u0441\u0435\u043B\u043A\u0430", icon: "\u{1F308}", price: 65, color: 14651135, accent: 6022632, style: "rainbow", reaction: "wow" }
].map(Object.freeze));

// public/mall-data.js
var MALL = MALL_LAYOUT;
var MALL_FLOORS = Object.freeze([
  ["Atrium", "Ocean Grand Atrium", 6677741],
  ["Luxury", "Cat Luxury Avenue", 16764295],
  ["Food", "Cat Food Paradise", 16753287],
  ["Cinema", "Cinema & Entertainment", 13537279],
  ["Lifestyle", "Cat Lifestyle", 8447967],
  ["Leisure", "Ocean Leisure", 16033260],
  ["Observatory", "Sky Ocean Observatory", 8641791]
].map(([short, name, color], i) => Object.freeze({ id: i + 1, short, name, color, y: MALL.y + i * MALL.rise })));
var MALL_BRANDS = Object.freeze({
  vuitton: "Louis Vuitton",
  gucci: "Gucci",
  prada: "Prada",
  chanel: "Chanel",
  nike: "Nike",
  mcd: "McDonald\u2019s",
  star: "Starbucks",
  kfc: "KFC",
  sushi: "Sushi Cat",
  bakery: "Meow Bakery",
  ice: "Ocean Ice Cream",
  ikea: "IKEA Cat Home",
  lego: "LEGO Cat World",
  tech: "Paw Technology",
  toys: "Cat Toy Planet",
  fashion: "Pet Fashion",
  books: "Book & Magic"
});
var MALL_PARODY_BRANDS = Object.freeze({
  vuitton: "Louis Mewton",
  gucci: "Purrcci",
  prada: "Prawda",
  chanel: "Chatnelle",
  nike: "Paw Sprint",
  mcd: "McMeow",
  star: "StarPaws",
  kfc: "Kitten Kitchen",
  ikea: "MIKEA",
  lego: "MEOW Blocks"
});
var floors = [
  [["cafe", "Pearl Caf\xE9", "food", 65], ["map", "Ocean Welcome", "rest", 0]],
  [["vuitton", "Louis Vuitton", "fashion", 850], ["gucci", "Gucci", "fashion", 720], ["prada", "Prada", "fashion", 680], ["chanel", "Chanel", "fashion", 790], ["nike", "Nike", "fashion", 420]],
  [["mcd", "McDonald\u2019s", "food", 48], ["star", "Starbucks", "food", 40], ["kfc", "KFC", "food", 55], ["sushi", "Sushi Cat", "food", 72], ["bakery", "Meow Bakery", "food", 36], ["ice", "Ocean Ice Cream", "food", 45]],
  [["cinema", "CHICHI CINEMA", "cinema", 90], ["cinema-two", "Moon Cinema", "cinema", 90], ["arcade", "Pixel Paw Arcade", "arcade", 25], ["dance", "Neon Dance", "dance", 0], ["bowling", "Ocean Bowling", "bowling", 35], ["vr", "Deep VR", "arcade", 40], ["photo", "Paw Photo", "photo", 20]],
  [["ikea", "IKEA Cat Home", "home", 320], ["lego", "LEGO Cat World", "toy", 180], ["tech", "Paw Technology", "gadget", 480], ["toys", "Cat Toy Planet", "toy", 95], ["fashion", "Pet Fashion", "fashion", 160], ["books", "Book & Magic", "book", 120]],
  [["restaurant", "Blue Horizon", "food", 110], ["spa", "Ocean Spa", "spa", 80], ["jellies", "Jellyfish Garden", "rest", 0], ["playground", "Coral Playground", "arcade", 0], ["tunnel", "Ocean View Tunnel", "rest", 0]],
  [["sky-cafe", "Sky Ocean Caf\xE9", "food", 85], ["date", "Moonlight Seats", "social", 0], ["observatory", "Ocean Hologram", "rest", 0]]
];
var MALL_STORES = Object.freeze(floors.flatMap((rows4, i) => rows4.map(([key, name, kind, price], j) => {
  const placement = mallRoomPlacement(j, rows4.length), angle = -placement.yaw - Math.PI / 2;
  const store = { id: "mall-" + key, key, name, brand: key, floor: i + 1, kind, price, angle, placement, x: placement.x, z: placement.z, y: MALL_FLOORS[i].y };
  return Object.freeze({ ...store, entrance: mallPoint(store, 0, 0.18, placement.d / 2 + 3), counter: mallPoint(store, 0, 0.18, 5.5), seat: mallPoint(store, 8, 0.18, 14.3) });
})));
var mallStore = (id) => MALL_STORES.find((s) => s.id === id) || resortZone(id);
var mallLabel = (s, parody = false) => parody && MALL_PARODY_BRANDS[s.brand] || MALL_BRANDS[s.brand] || s.name;
var goods = {
  fashion: [["collar", "\u041F\u0435\u0440\u043B\u0438\u043D\u043D\u0438\u0439 \u043D\u0430\u0448\u0438\u0439\u043D\u0438\u043A", "\u{1F380}", "wear"], ["bag", "\u0421\u0443\u043C\u043E\u0447\u043A\u0430 \u0437 \u043B\u0430\u043F\u043A\u043E\u044E", "\u{1F45C}", "carry"], ["bow", "\u041E\u043A\u0435\u0430\u043D\u0441\u044C\u043A\u0438\u0439 \u0431\u0430\u043D\u0442\u0438\u043A", "\u{1F380}", "wear"]],
  food: [["meal", "\u041D\u0456\u0436\u043D\u0435 \u043A\u043E\u0442\u044F\u0447\u0435 \u0444\u0456\u043B\u0435", "\u{1F41F}", "eat"], ["treat", "\u0411\u0435\u0437\u043F\u0435\u0447\u043D\u0438\u0439 \u043A\u043E\u0442\u044F\u0447\u0438\u0439 \u0434\u0435\u0441\u0435\u0440\u0442", "\u{1F365}", "eat"], ["drink", "\u0411\u0443\u043B\u044C\u0439\u043E\u043D \u0456\u0437 \u043C\u043E\u0440\u0441\u044C\u043A\u043E\u044E \u0437\u0456\u0440\u043E\u0447\u043A\u043E\u044E", "\u{1F963}", "eat"]],
  cinema: [["ticket", "\u041A\u0432\u0438\u0442\u043E\u043A \xAB\u041F\u0440\u0438\u0433\u043E\u0434\u0438 \u0427\u0438\u0447\u0456\xBB", "\u{1F39F}\uFE0F", "cinema"]],
  arcade: [["pass", "\u0421\u0435\u0430\u043D\u0441 \u0433\u0440\u0438", "\u{1F579}\uFE0F", "arcade"]],
  dance: [],
  bowling: [["pass", "\u0413\u0440\u0430 \u0432 \u0431\u043E\u0443\u043B\u0456\u043D\u0433", "\u{1F3B3}", "bowling"]],
  photo: [["print", "\u041F\u0430\u043C\u2019\u044F\u0442\u043D\u0435 \u0444\u043E\u0442\u043E", "\u{1F4F8}", "photo"]],
  home: [["bed", "\u041F\u0435\u0440\u043B\u0438\u043D\u043D\u0430 \u043B\u0435\u0436\u0430\u043D\u043A\u0430", "\u{1F6CF}\uFE0F", "rest"], ["lamp", "\u041B\u0430\u043C\u043F\u0430-\u043C\u0435\u0434\u0443\u0437\u0430", "\u{1FABC}", "home"], ["cushion", "\u041E\u043A\u0435\u0430\u043D\u0441\u044C\u043A\u0430 \u043F\u043E\u0434\u0443\u0448\u043A\u0430", "\u{1F6CB}\uFE0F", "rest"]],
  toy: [["ball", "\u041A\u043E\u0440\u0430\u043B\u043E\u0432\u0430 \u0456\u0433\u0440\u0430\u0448\u043A\u0430", "\u{1F9F6}", "play"], ["blocks", "\u041D\u0430\u0431\u0456\u0440 \u043A\u043E\u0442\u044F\u0447\u0438\u0445 \u043A\u0443\u0431\u0438\u043A\u0456\u0432", "\u{1F9E9}", "play"]],
  gadget: [["tablet", "\u041A\u043E\u0442\u044F\u0447\u0438\u0439 \u043F\u043B\u0430\u043D\u0448\u0435\u0442", "\u{1F4F1}", "play"], ["headset", "\u041E\u043A\u0435\u0430\u043D\u0441\u044C\u043A\u0456 \u043D\u0430\u0432\u0443\u0448\u043D\u0438\u043A\u0438", "\u{1F3A7}", "wear"]],
  book: [["book", "\u041A\u043D\u0438\u0433\u0430 \u043E\u043A\u0435\u0430\u043D\u0441\u044C\u043A\u0438\u0445 \u0447\u0430\u0440", "\u{1F4D6}", "read"], ["star", "\u041C\u0430\u0433\u0456\u0447\u043D\u0430 \u0437\u043E\u0440\u044F", "\u2728", "play"]],
  spa: [["session", "\u041F\u0435\u0440\u043B\u0438\u043D\u043D\u0438\u0439 \u0434\u043E\u0433\u043B\u044F\u0434", "\u{1FAE7}", "spa"]],
  rest: [],
  social: []
};
var originalProducts = MALL_STORES.flatMap((s) => (s.price > 0 ? goods[s.kind] || [] : []).map(([key, name, icon, use], i) => Object.freeze({
  id: `${s.id}-${key}`,
  storeId: s.id,
  name,
  brand: mallLabel(s),
  category: "mall",
  kind: s.kind,
  use,
  icon,
  price: Math.max(1, Math.round(s.price * [1, 0.6, 0.4][i])),
  stock: ["food", "cinema", "arcade", "spa", "bowling", "photo"].includes(s.kind) ? 1e5 : 60,
  unique: !["food", "cinema", "arcade", "spa", "bowling", "photo"].includes(s.kind),
  ...s.key === "ice" ? { legacy: true } : {}
})));
var MALL_PRODUCTS = Object.freeze([...originalProducts.filter((p) => !p.legacy), ...MALL_ICE_FLAVORS.map((f) => Object.freeze({
  id: "mall-ice-" + f.key,
  storeId: "mall-ice",
  name: f.name,
  brand: MALL_BRANDS.ice,
  category: "mall",
  kind: "food",
  use: "eat",
  icon: f.icon,
  price: f.price,
  stock: 1e5,
  unique: false,
  iceFlavor: f.key
})), ...originalProducts.filter((p) => p.legacy), ...RESORT_PRODUCTS]);
var mallProduct = (id) => MALL_PRODUCTS.find((p) => p.id === id);
var MALL_ACTIONS = Object.freeze(["VisitMall", "EnterElevator", "SelectFloor", "BrowseStore", "InspectProduct", "CompareProducts", "PurchaseItem", "VisitRestaurant", "OrderFood", "EatMeal", "BuyCinemaTicket", "WatchMovie", "PlayArcade", "MeetFriend", "RelaxAtMall", "ReturnHome"]);
function mallOffers(game) {
  return game.unlocked?.includes("autumn") ? [...MALL_STORES.map((s) => ({ id: s.id, type: s.id, biome: "autumn", name: `\u041F\u0456\u0434\u0432\u043E\u0434\u043D\u0438\u0439 \u0422\u0420\u0426 \xB7 F${s.floor} \xB7 ${s.name}`, action: ["food"].includes(s.kind) ? "eat" : ["rest", "spa", "social"].includes(s.kind) ? "rest" : "play" })), ...resortOffers(game)] : [];
}
function mallPoint(store, x = 0, y = 0.18, z = 0) {
  const c = Math.cos(store.angle), s = Math.sin(store.angle);
  return { x: store.x - s * x - c * z, y: store.y + y, z: store.z + c * x - s * z };
}

// public/world-layout.js
var SHORE_MARGIN = 0.65;
var MIN_ISLAND_GAP = 3;
var islandShoreRadius = (biome) => (biome.radius || 11.65) + SHORE_MARGIN;
function separateIslandCenters(biomes) {
  let scale = 1;
  for (let i = 0; i < biomes.length; i++)
    for (let j = i + 1; j < biomes.length; j++) {
      const a = biomes[i], b = biomes[j], distance = Math.hypot(
        a.center[0] - b.center[0],
        a.center[1] - b.center[1]
      );
      if (!distance) throw Error("Island centres must be distinct");
      scale = Math.max(
        scale,
        (islandShoreRadius(a) + islandShoreRadius(b) + MIN_ISLAND_GAP) / distance
      );
    }
  scale = Math.ceil(scale * 27 - 1e-8) / 27;
  const anchor = biomes.find((b) => b.id === "moon")?.center || [0, 0];
  for (const b of biomes)
    b.center = b.center.map(
      (v, axis) => Math.round((anchor[axis] + (v - anchor[axis]) * scale) * 1e6) / 1e6
    );
  return scale;
}
var RETIRED_BIOME_IDS = Object.freeze([
  "lotus",
  "crystal",
  "mushrooms",
  "desert",
  "beach",
  "aquapark",
  "rainbow",
  "nature",
  "bamboo",
  "dusk",
  "stars",
  "coral",
  "clouds",
  "farm-starlight",
  "farm-sugarcloud",
  "farm-crystal",
  "farm-moonpumpkin"
]);
var retired = new Set(RETIRED_BIOME_IDS);
var isRetiredBiome = (id) => retired.has(id);
var WORLD_CENTERS = Object.freeze({
  "moon": [0, 0],
  "homestead": [0, -245],
  "jobcity": [-92, 55],
  "cat-homes": [-210, 55],
  "aquarium": [18.3427, 51.7981],
  "foodcourt": [81.1833, 8.609],
  "bikini": [87.9955, 77.1497],
  // Residential sections extend indefinitely along X at Z=55. Leave the
  // entire housing strip clear, including automatic future home expansions.
  "autumn": [-450, 500],
  "sakura": [46.4777, 122.8444],
  "clouds": [135.8717, -24.2511],
  "candy": [136.9242, 39.6054],
  "clockwork": [-137.2347, -28.3119],
  "water": [-60.0521, 141.3472],
  "summer": [14.5771, 162.7468],
  "winter": [92.9434, 128.5351],
  "volcano": [-26.5033, 162.7201],
  "galaxy": [137.7209, 85.2487],
  "ice": [-163.1679, 5.485],
  "stars": [-28.0476, -1.7155],
  "coral": [29.298, -2.0487]
});
function retiredDistrict(id) {
  const index = RETIRED_BIOME_IDS.indexOf(id);
  if (index < 0) return null;
  if (index >= 13) {
    const angle2 = (index - 13) * Math.PI / 2 + 0.4;
    return { x: Math.round(Math.sin(angle2) * 170 * 1e6) / 1e6, z: Math.round(Math.cos(angle2) * 170 * 1e6) / 1e6 };
  }
  const original = index < 10, angle = original ? index * Math.PI * 2 / 10 : (index - 10) * Math.PI * 2 / 3, radius = original ? 185 : 115;
  return {
    x: Math.round(Math.sin(angle) * radius * 1e6) / 1e6,
    z: Math.round(Math.cos(angle) * radius * 1e6) / 1e6
  };
}

// public/jobcity-data.js
var JOB_CITY_ID = "jobcity";
var JOB_CITY_RADIUS = 67;
var JOB_CITY_CENTER = [...WORLD_CENTERS.jobcity];
var JOB_MINUTE_MS = 1e3;
var JOB_DAY_MINUTES = 1440;
var JOB_CLOCK_ORIGIN = 12 * 60;
var JOB_START = 9 * 60;
var JOB_END = 17 * 60;
var JOB_SHIFT_MINUTES = JOB_END - JOB_START;
var JOB_HOURS = "09:00\u201317:00";
var JOB_CAPACITY = 6;
var JOB_BUSINESSES = [
  [
    "bank",
    "\u041A\u043E\u0442\u044F\u0447\u0438\u0439 \u0431\u0430\u043D\u043A",
    "\u{1F3E6}",
    -32,
    -22,
    15317844,
    90,
    900,
    "\u041A\u0430\u0441\u0438, \u0440\u0430\u0445\u0443\u043D\u043A\u0438 \u0442\u0430 \u0437\u0430\u0442\u0438\u0448\u043D\u0435 \u0441\u0445\u043E\u0432\u0438\u0449\u0435"
  ],
  [
    "crypto",
    "\u041A\u0440\u0438\u043F\u0442\u043E\u043E\u0444\u0456\u0441",
    "\u{1F4C8}",
    0,
    -22,
    5602749,
    110,
    1100,
    "\u041A\u043E\u043C\u043F\u2019\u044E\u0442\u0435\u0440\u0438, \u0433\u0440\u0430\u0444\u0456\u043A\u0438 \u0442\u0430 \u043A\u043E\u043C\u0430\u043D\u0434\u043D\u0456 \u043E\u0431\u0433\u043E\u0432\u043E\u0440\u0435\u043D\u043D\u044F"
  ],
  [
    "factory",
    "\u041A\u043E\u0442\u044F\u0447\u0435 \u0432\u0438\u0440\u043E\u0431\u043D\u0438\u0446\u0442\u0432\u043E",
    "\u2699\uFE0F",
    32,
    -22,
    14249055,
    100,
    1050,
    "\u041A\u043E\u043D\u0432\u0435\u0454\u0440\u0438, \u0440\u043E\u0431\u043E\u0442\u0438\u0437\u043E\u0432\u0430\u043D\u0456 \u043B\u0430\u043F\u043A\u0438 \u0442\u0430 \u043C\u0430\u0439\u0441\u0442\u0435\u0440\u043D\u044F"
  ],
  [
    "furniture",
    "\u041C\u0435\u0431\u043B\u0435\u0432\u0438\u0439 \u0434\u0456\u043C",
    "\u{1F6CB}\uFE0F",
    -32,
    19,
    13595243,
    85,
    800,
    "\u0414\u0438\u0432\u0430\u043D\u0438, \u043B\u0456\u0436\u0435\u0447\u043A\u0430 \u0442\u0430 \u0434\u043E\u043F\u043E\u043C\u043E\u0433\u0430 \u043F\u043E\u043A\u0443\u043F\u0446\u044F\u043C"
  ],
  [
    "estate",
    "\u041A\u043E\u0442\u044F\u0447\u0456 \u0431\u0443\u0434\u0438\u043D\u043E\u0447\u043A\u0438",
    "\u{1F3E1}",
    0,
    23,
    7512428,
    115,
    1e3,
    "\u041C\u0430\u043A\u0435\u0442 \u043C\u0456\u0441\u0442\u0430, \u043F\u043B\u0430\u043D\u0438 \u0439 \u043D\u043E\u0432\u0456 \u043E\u0441\u0435\u043B\u0456"
  ],
  [
    "cars",
    "\u041C\u0443\u0440-\u041C\u043E\u0442\u043E\u0440\u0441",
    "\u{1F697}",
    32,
    19,
    6852295,
    105,
    1200,
    "\u0410\u0432\u0442\u043E\u0441\u0430\u043B\u043E\u043D, \u0442\u0435\u0441\u0442\u043E\u0432\u0456 \u043F\u043E\u0457\u0437\u0434\u043A\u0438 \u0442\u0430 \u043F\u0430\u0440\u043A\u043E\u0432\u043A\u0430"
  ]
].map(([kind, name, icon, x, z, color, wage, rate, description]) => ({
  id: "job-" + kind,
  type: "job-" + kind,
  biome: JOB_CITY_ID,
  kind,
  name,
  icon,
  x,
  z,
  color,
  wage,
  rate,
  description,
  w: 25,
  d: 20,
  h: 15.5,
  capacity: JOB_CAPACITY
}));
var JOB_KINDS = JOB_BUSINESSES.map((b) => b.kind);
var JOB_CARS = [
  {
    id: "car-peach",
    name: "\u041F\u0435\u0440\u0441\u0438\u043A\u043E\u0432\u0438\u0439 \u041C\u0443\u0440\u0447\u0438\u043A",
    icon: "\u{1F697}",
    price: 1200,
    color: 15702956,
    speed: 8
  },
  {
    id: "car-cloud",
    name: "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0430 \u0425\u043C\u0430\u0440\u0438\u043D\u043A\u0430",
    icon: "\u{1F699}",
    price: 1800,
    color: 7126748,
    speed: 9
  },
  {
    id: "car-lime",
    name: "\u0424\u0456\u0441\u0442\u0430\u0448\u043A\u043E\u0432\u0438\u0439 \u0416\u0443\u0447\u043E\u043A",
    icon: "\u{1F698}",
    price: 2400,
    color: 10669695,
    speed: 10
  },
  {
    id: "car-lavender",
    name: "\u041B\u0430\u0432\u0430\u043D\u0434\u043E\u0432\u0438\u0439 \u041A\u0440\u0443\u0457\u0437\u0435\u0440",
    icon: "\u{1F699}",
    price: 3600,
    color: 12164317,
    speed: 9.5
  },
  {
    id: "car-sun",
    name: "\u0417\u043E\u043B\u043E\u0442\u0438\u0439 \u041C\u0443\u0440\u0440 GT",
    icon: "\u{1F3CE}\uFE0F",
    price: 6500,
    color: 15382620,
    speed: 12
  }
];
var jobCar = (id) => JOB_CARS.find((c) => c.id === id);
var JOB_CITY_LOCALS = JOB_BUSINESSES.flatMap(
  (b, i) => [0, 1].map((j) => ({
    id: "jobcat-" + b.kind + "-" + j,
    name: [
      ["\u041A\u0435\u0448", "\u041F\u0435\u043D\u043D\u0456"],
      ["\u0411\u0456\u0442", "\u0413\u0440\u0430\u0444\u0456\u043A"],
      ["\u0413\u0430\u0439\u043A\u0430", "\u041C\u043E\u043B\u043E\u0442\u0438\u043A"],
      ["\u041F\u043B\u044E\u0448\u043A\u0430", "\u0412\u0435\u043B\u044E\u0440"],
      ["\u041A\u043B\u044E\u0447\u0438\u043A", "\u0414\u0430\u0445\u0438\u043A"],
      ["\u0422\u0443\u0440\u0431\u043E", "\u041F\u0456\u043A\u0441\u0435\u043B\u044C"]
    ][i][j],
    biome: JOB_CITY_ID,
    color: [14076334, 10724524, 13539948, 15458768, 9935783, 14727065][(i + j) % 6],
    size: j ? 0.75 : 0.9,
    preferredJob: b.kind,
    jobCityLocal: true,
    hat: false
  }))
);
var JOB_PARKING = Array.from({ length: 12 }, (_, i) => ({
  x: -36 + i * 6.5,
  z: 48,
  y: 0.32
}));
function jobReservations() {
  return [
    ...JOB_BUSINESSES.map((b) => ({ x: b.x, z: b.z, w: b.w + 4, d: b.d + 3 })),
    { x: 0, z: 0, radius: 6 },
    { x: 0, z: 48, w: 92, d: 12 },
    ...[-50, -16, 16, 50].map((x) => ({ x, z: 1, w: 4.7, d: 82 })),
    ...[-38, 40].map((z) => ({ x: 0, z, w: 104, d: 4.7 })),
    { x: -33, z: 0, w: 38, d: 4.7 },
    { x: 33, z: 0, w: 38, d: 4.7 }
  ];
}

// public/chill-data.js
var CHILL_RADIUS = 11.65 * Math.sqrt(5);
var CHILL_GATE = { x: 0, z: 21.8 };
var CHILL_WATER_Y = 1.35;
var CHILL_HOUSES = [
  {
    id: "sage",
    name: "\u0421\u0430\u0434\u043E\u0432\u0430 \u0432\u0456\u043B\u043B\u0430",
    x: -14,
    z: 10.5,
    roof: 7444078,
    cushion: 15250885,
    form: "wave"
  },
  {
    id: "lavender",
    name: "\u041B\u0430\u0432\u0430\u043D\u0434\u043E\u0432\u0438\u0439 \u043E\u0441\u043E\u0431\u043D\u044F\u043A",
    x: 14,
    z: 10.5,
    roof: 9140662,
    cushion: 13809893,
    form: "turret"
  },
  {
    id: "rose",
    name: "\u0422\u0440\u043E\u044F\u043D\u0434\u043E\u0432\u0438\u0439 \u0434\u0456\u043C",
    x: -17,
    z: -1.2,
    roof: 13076884,
    cushion: 15780025,
    form: "asymmetric"
  },
  {
    id: "blue",
    name: "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0430 \u0440\u0435\u0437\u0438\u0434\u0435\u043D\u0446\u0456\u044F",
    x: 17,
    z: -1.2,
    roof: 7773621,
    cushion: 12047583,
    form: "dome"
  },
  {
    id: "honey",
    name: "\u041C\u0435\u0434\u043E\u0432\u0435 \u0448\u0430\u043B\u0435",
    x: -13,
    z: -14,
    roof: 13743208,
    cushion: 15913388,
    form: "chalet"
  },
  {
    id: "berry",
    name: "\u041C\u0430\u043B\u0438\u043D\u043E\u0432\u0438\u0439 \u043E\u0441\u043E\u0431\u043D\u044F\u043A",
    x: 13,
    z: -14,
    roof: 11892629,
    cushion: 14725578,
    form: "bow"
  },
  {
    id: "ivy",
    name: "\u0411\u0443\u0434\u0438\u043D\u043E\u043A \u043F\u043B\u044E\u0449\u0435\u0432\u0438\u0445 \u0441\u043D\u0456\u0432",
    x: 0,
    z: -19,
    roof: 7576461,
    cushion: 12638394,
    form: "garden"
  }
];
var CHILL_OBJECTS = CHILL_HOUSES.flatMap((h) => [
  {
    id: `chill-${h.id}-bed`,
    type: "bed",
    kind: "bed",
    biome: "sakura",
    houseId: h.id,
    name: `${h.name} \xB7 \u043B\u0435\u0436\u0430\u043D\u043A\u0430 \u0434\u043B\u044F \u0434\u0432\u043E\u0445`,
    x: h.x - 2.55,
    z: h.z + 0.65,
    footprint: [6.3, 3.1]
  },
  {
    id: `chill-${h.id}-bath`,
    type: "swim-lagoon",
    kind: "bath",
    biome: "sakura",
    houseId: h.id,
    name: `${h.name} \xB7 \u0442\u0435\u043F\u043B\u0430 \u0432\u0430\u043D\u043D\u0430`,
    x: h.x + 3.05,
    z: h.z + 0.65,
    rx: 1.5,
    rz: 1.45,
    surfaceY: CHILL_WATER_Y,
    footprint: [3.6, 3.5]
  }
]);
var chillReservations = () => [
  ...CHILL_HOUSES.map((h) => ({ x: h.x, z: h.z + 0.5, w: 11.4, d: 9.5 })),
  { x: 0, z: 21.2, w: 8, d: 4.4 }
];

// public/housing-data.js
var HOUSING_ID = "cat-homes";
var HOUSING_CENTER = [...WORLD_CENTERS["cat-homes"]];
var HOUSING_RADIUS = 43;
var HOUSE_TYPES = CHILL_HOUSES.map((h, i) => ({
  ...h,
  id: "home-" + h.id,
  modelId: h.id,
  category: "property",
  icon: "\u{1F3E1}",
  price: [1600, 2600, 2100, 3200, 1800, 2400, 3600][i]
}));
var houseType = (id) => HOUSE_TYPES.find((h) => h.id === id);

// public/showcase-water-data.js
var rows2 = [
  ["barrel-wave", "\u0413\u0456\u0433\u0430\u043D\u0442\u0441\u044C\u043A\u0430 \u0445\u0432\u0438\u043B\u044F", "\u{1F30A}", 64, 21e4, 3329512, 10350317, 1, 3.8, 1, "\u0411\u043E\u0434\u0456\u0431\u043E\u0440\u0434: \u0448\u0432\u0438\u0434\u043A\u0438\u0439 \u0440\u043E\u0437\u0433\u0456\u043D \u043A\u0440\u0456\u0437\u044C \u0432\u0435\u043B\u0438\u043A\u0443 \u0437\u0430\u043A\u0440\u0443\u0447\u0435\u043D\u0443 \u0432\u043E\u0434\u044F\u043D\u0443 \u0445\u0432\u0438\u043B\u044E."],
  ["canyon-rafting", "\u0420\u0430\u0444\u0442\u0438\u043D\u0433 \u0443 \u043A\u0430\u043D\u044C\u0439\u043E\u043D\u0456", "\u{1F3DE}\uFE0F", 43, 16e4, 4249062, 12156769, 4, 6.5, 1, "\u0421\u043F\u0456\u043B\u044C\u043D\u0438\u0439 \u043A\u0440\u0443\u0433\u043B\u0438\u0439 \u0440\u0430\u0444\u0442: \u043F\u043E\u0440\u043E\u0433\u0438, \u043C\u043E\u0441\u0442\u0438, \u0432\u043E\u0434\u043E\u0441\u043F\u0430\u0434\u0438 \u0442\u0430 \u0441\u043C\u0456\u0448\u043D\u0456 \u043E\u0431\u0435\u0440\u0442\u0438."],
  ["glass-drop", "\u0412\u0435\u0436\u0430 \u0432\u0456\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u0430\u0434\u0456\u043D\u043D\u044F", "\u{1F3F0}", 82, 25e4, 5757428, 16768140, 2, 4.8, 1, "\u041F\u0440\u043E\u0437\u043E\u0440\u0438\u0439 \u043F\u0456\u0434\u0439\u043E\u043C, \u043D\u0430\u043F\u0440\u0443\u0436\u0435\u043D\u0430 \u0437\u0443\u043F\u0438\u043D\u043A\u0430 \u0439 \u0432\u0435\u0440\u0442\u0438\u043A\u0430\u043B\u044C\u043D\u0435 \u0432\u043E\u0434\u044F\u043D\u0435 \u043F\u0430\u0434\u0456\u043D\u043D\u044F."],
  ["lagoon-launch", "\u0412\u043E\u0434\u044F\u043D\u0438\u0439 \u0437\u0430\u043F\u0443\u0441\u043A \u0456 \u043F\u043E\u043B\u0456\u0442", "\u{1F680}", 38, 22e4, 4706799, 16503678, 2, 4.8, 3, "\u0412\u043E\u0434\u044F\u043D\u0438\u0439 \u043F\u0440\u0438\u0441\u043A\u043E\u0440\u044E\u0432\u0430\u0447 \u0456 \u0441\u043F\u0440\u0430\u0432\u0436\u043D\u044F \u0434\u0443\u0433\u0430 \u043F\u043E\u043B\u044C\u043E\u0442\u0443 \u0432 \u043E\u043A\u0440\u0435\u043C\u0443 \u043B\u0430\u0433\u0443\u043D\u0443."],
  ["surf-halfpipe", "\u0421\u0435\u0440\u0444\u0456\u043D\u0433 \u043D\u0430 \u0433\u0456\u0433\u0430\u043D\u0442\u0441\u044C\u043A\u0456\u0439 \u0445\u0432\u0438\u043B\u0456", "\u{1F3C4}", 46, 175e3, 3722990, 15841005, 1, 4.2, 2, "\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438\u0439 half-pipe: \u0432\u0438\u0441\u043E\u043A\u0435 \u0431\u0430\u043B\u0430\u043D\u0441\u0443\u0432\u0430\u043D\u043D\u044F, \u0440\u043E\u0437\u0432\u043E\u0440\u043E\u0442\u0438 \u0439 \u0442\u0440\u044E\u043A\u0438 \u043D\u0430 \u0434\u043E\u0448\u0446\u0456."],
  ["lazy-river", "\u041F\u0440\u0438\u0433\u043E\u0434\u0430 \u043D\u0430 \u0434\u0438\u043A\u0456\u0439 \u0440\u0456\u0447\u0446\u0456", "\u{1F6DF}", 26, 11e4, 5824476, 9354359, 1, 4.6, 1, "\u041A\u0456\u043B\u044C\u0446\u0435 \u043A\u0440\u0456\u0437\u044C \u0434\u0436\u0443\u043D\u0433\u043B\u0456: \u0448\u0432\u0438\u0434\u043A\u0456 \u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0456, \u043F\u043E\u0440\u043E\u0433\u0438 \u0439 \u0437\u0430\u043A\u0440\u0443\u0447\u0435\u043D\u0456 \u0432\u0456\u0440\u0430\u0436\u0456."],
  ["fountain-carousel", "\u0412\u043E\u0434\u043D\u0430 \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C", "\u{1F338}", 23, 145e3, 5822953, 15903437, 4, 4, 2, "\u0427\u043E\u0442\u0438\u0440\u0438 \u0440\u0430\u0434\u0456\u0430\u043B\u044C\u043D\u0456 \u0447\u043E\u0432\u043D\u0438\u043A\u0438 \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u043A\u0432\u0456\u0442\u043A\u043E\u0432\u043E\u0433\u043E \u0444\u043E\u043D\u0442\u0430\u043D\u0430 \u0437 \u043F\u043B\u0430\u0432\u043D\u0438\u043C \u0440\u043E\u0437\u0433\u043E\u043D\u043E\u043C."],
  ["pool-pendulum", "\u041C\u0430\u044F\u0442\u043D\u0438\u043A \u043D\u0430\u0434 \u0431\u0430\u0441\u0435\u0439\u043D\u043E\u043C", "\u{1F3A1}", 58, 23e4, 4904429, 14200684, 4, 6.5, 0, "\u041F\u0456\u0434\u0432\u0456\u0441\u043D\u0438\u0439 \u0447\u043E\u0432\u0435\u043D: \u0432\u0438\u0441\u043E\u043A\u0430 \u0434\u0443\u0433\u0430, \u0434\u043E\u0442\u0438\u043A \u0432\u043E\u0434\u0438 \u0439 \u0431\u0440\u0438\u0437\u043A\u0438 \u043D\u0430 \u043A\u043E\u0436\u043D\u043E\u043C\u0443 \u043F\u0440\u043E\u0445\u043E\u0434\u0456."]
];
var SHOWCASE_WATER_RIDES = rows2.map(([kind, name, icon, height, price, color, accent, seats, radius, channels, description], i) => {
  const cell = [0, 3, 4, 5, 6, 7, 8, 9][i];
  return {
    id: "ride-water-" + kind,
    kind,
    name,
    icon,
    height,
    price,
    color,
    accent,
    seats,
    radius,
    channels,
    description,
    showcaseWater: true,
    referenceSlide: true,
    premiumWater: true,
    mega: true,
    fixedPrice: true,
    collection: "\u0412\u043E\u0434\u043D\u0456 \u043F\u0440\u0438\u0433\u043E\u0434\u0438 \xB7 8 \u043C\u0456\u043D\u0456\u0431\u0456\u043E\u043C\u0456\u0432",
    referenceCell: { index: cell + 1, row: Math.floor(cell / 5) + 1, column: cell % 5 + 1 },
    category: "rides",
    actions: ["ride"],
    rarity: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u043E\u0435",
    requiredLevel: 20,
    buildMinutes: 60 + cell * 5,
    footprint: [124, 120],
    pool: ["barrel-wave", "lagoon-launch"].includes(kind) ? [0, 31, 37, 20] : kind === "surf-halfpipe" ? [0, 18, 43, 22] : ["fountain-carousel", "pool-pendulum"].includes(kind) ? [0, 0, 26, 25] : [0, 35, 22, 15],
    surfaceY: 1.45,
    incomePerHour: Math.round(price / 80 / 100) * 100
  };
});

// public/zoo-data.js
var ZOO_LINEAR_SCALE = 2;
var ZOO_ID = "magic-zoo";
var ZOO_RADIUS = 11.65 * Math.sqrt(3) * ZOO_LINEAR_SCALE;
var ZOO_GATE = { x: 0, z: 17.9 * ZOO_LINEAR_SCALE };
var ZOO_BIOME = { id: ZOO_ID, name: "\u0427\u0430\u0440\u0456\u0432\u043D\u0438\u0439 \u0437\u043E\u043E\u043F\u0430\u0440\u043A", subtitle: "\u041F\u2019\u044F\u0442\u044C \u043F\u0440\u043E\u0441\u0442\u043E\u0440\u0438\u0445 \u0432\u043E\u043B\u044C\u0454\u0440\u0456\u0432 \xB7 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0456 \u0434\u0438\u0432\u0430 \u0439 \u0434\u043E\u0431\u0440\u0456 \u0432\u0435\u043B\u0435\u0442\u043D\u0456", icon: "\u{1F418}", price: 3600, requiredLevel: 8, radius: ZOO_RADIUS, center: [207, 136], arrival: [ZOO_GATE.x, ZOO_GATE.z], ground: 10929787, edge: 9608072, foliage: 6661964, accent: 16763356, zoo: true };
var row = [
  ["elephant", "\u0421\u043B\u043E\u043D\u043E\u0432\u0430 \u0434\u043E\u043B\u0438\u043D\u0430", "\u{1F418}", 0, 0, -12.8, 10207088, 16765099, "\u0414\u043E\u0431\u0440\u0456 \u0432\u0435\u043B\u0435\u0442\u043D\u0456, \u0441\u043B\u043E\u043D\u0435\u043D\u044F, \u0445\u043E\u0431\u043E\u0442\u0438-\u0444\u043E\u043D\u0442\u0430\u043D\u0438 \u0442\u0430 \u043A\u0430\u0441\u043A\u0430\u0434."],
  ["axolotl", "\u0420\u0438\u0444 \u0430\u043A\u0441\u043E\u043B\u043E\u0442\u043B\u0456\u0432", "\u{1FAE7}", 6500, -12.1, 6.1, 9234158, 16757718, "\u041A\u0440\u0438\u0445\u0456\u0442\u043D\u0456 \u043F\u0443\u0445\u043A\u0456 \u0430\u043A\u0441\u043E\u043B\u043E\u0442\u043B\u0456 \u0437 \u043F\u0435\u043B\u044E\u0441\u0442\u043A\u043E\u0432\u0438\u043C\u0438 \u0437\u044F\u0431\u0440\u0430\u043C\u0438 \u0443 \u0432\u0435\u043B\u0438\u043A\u043E\u043C\u0443 \u043F\u0440\u043E\u0437\u043E\u0440\u043E\u043C\u0443 \u0430\u043A\u0432\u0430\u0440\u0456\u0443\u043C\u0456."],
  ["otter", "\u041B\u0430\u0433\u0443\u043D\u0430 \u0432\u0438\u0434\u0440", "\u{1F9A6}", 11e3, 0, 11.35, 7653811, 15911811, "\u041F\u0456\u0440\u043D\u0430\u043D\u043D\u044F, \u0432\u0435\u0441\u0435\u043B\u0456 \u043F\u0435\u0440\u0435\u0432\u043E\u0440\u043E\u0442\u0438 \u0439 \u0432\u0456\u0434\u043F\u043E\u0447\u0438\u043D\u043E\u043A \u043D\u0430 \u0442\u0435\u043F\u043B\u0438\u0445 \u043A\u0430\u043C\u0456\u043D\u0446\u044F\u0445."],
  ["polar", "\u041A\u0435\u0434\u0440\u043E\u0432\u0438\u0439 \u0433\u0430\u0439 \u0433\u0440\u0456\u0437\u043B\u0456", "\u{1F43B}", 29e3, 11.5, -6.4, 10599555, 14464391, "\u041F\u0443\u0445\u043A\u0435\u043D\u044C\u043A\u0456 \u0431\u0443\u0440\u0456 \u0433\u0440\u0456\u0437\u043B\u0456, \u043A\u0435\u0434\u0440\u043E\u0432\u0456 \u0434\u0435\u0440\u0435\u0432\u0430, \u0433\u0456\u0440\u0441\u044C\u043A\u0430 \u043B\u0430\u0433\u0443\u043D\u0430 \u0439 \u0456\u0433\u0440\u0438 \u0437 \u0448\u0438\u0448\u043A\u0430\u043C\u0438."],
  ["gorilla", "\u0414\u0436\u0443\u043D\u0433\u043B\u0456 \u0433\u043E\u0440\u0438\u043B", "\u{1F98D}", 44e3, -11.5, -6.4, 5938276, 15847311, "\u041C\u043E\u0433\u0443\u0442\u043D\u0456 \u0434\u043E\u0431\u0440\u0456 \u0433\u043E\u0440\u0438\u043B\u0438, \u043B\u0456\u0430\u043D\u0438, \u0434\u0435\u0440\u0435\u0432\u2019\u044F\u043D\u0456 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0456\u0457 \u0442\u0430 \u0437\u0435\u043B\u0435\u043D\u044C."]
];
var ZOO_EXHIBITS = row.map(([species, name, icon, price, x, z, ground, accent, description], index) => ({ id: "zoo-" + species, type: "zoo-" + species, biome: ZOO_ID, kind: "zoo", zoo: true, species, index, name, icon, price, x: species === "polar" ? 24.5 : species === "otter" ? 8 : x * ZOO_LINEAR_SCALE, z: species === "polar" ? -4 : species === "otter" ? 23.5 : z * ZOO_LINEAR_SCALE, ground, accent, description, radius: ["polar", "otter"].includes(species) ? 11.5 : 9, w: ["polar", "otter"].includes(species) ? 23 : 18, d: ["polar", "otter"].includes(species) ? 23 : 18, h: species === "axolotl" ? 4.4 : 4, buildMinutes: 0, rate: 0, footprint: ["polar", "otter"].includes(species) ? [23, 23] : [18, 18] }));
var zooExhibit = (id) => ZOO_EXHIBITS.find((e) => e.id === id || e.species === id);
var ZOO_ANIMALS = { elephant: { count: 3, scale: [1.15, 1.02, 0.52], height: 3.6 }, axolotl: { count: 8, scale: [0.72, 0.63, 0.6, 0.52, 0.48, 0.58, 0.55, 0.45], height: 0.62 }, otter: { count: 4, scale: [0.8, 0.72, 0.76, 0.6], height: 0.85 }, polar: { count: 3, scale: [0.95, 0.8, 0.52], height: 2.15 }, gorilla: { count: 3, scale: [1, 0.9, 0.6], height: 2.65 } };
var ZOO_RETIRED_EXHIBIT = { id: "zoo-tiger", index: 3, price: 18e3 };

// public/homestead-expansion.js
var HOMESTEAD_EXPANSION = {
  originalRadius: 46.6 * Math.SQRT2,
  areaMultiplier: 12,
  center: [...WORLD_CENTERS.homestead]
};
var HOMESTEAD_RADIUS = HOMESTEAD_EXPANSION.originalRadius * Math.sqrt(HOMESTEAD_EXPANSION.areaMultiplier);

// public/aquarium-data.js
var AQUARIUM_RADIUS = 38.5;
var AQUARIUM_GATE = { x: 0, z: 33 };
var AQUARIUM_BUILDING = { w: 64, d: 54, r: 12, wall: 8.8, dome: 11.4 };
var AQUARIUM_TANKS = [
  {
    id: "aquarium-aurora",
    name: "\u0421\u0435\u0440\u0434\u0446\u0435 \u043E\u043A\u0435\u0430\u043D\u0430\u0440\u0438\u0443\u043C\u0430 \xB7 \u0410\u0432\u0440\u043E\u0440\u0430",
    x: 0,
    z: -5,
    w: 13,
    d: 13,
    h: 13,
    r: 6.5,
    circular: true,
    color: 6937071,
    fish: 10,
    hero: 2.65
  },
  {
    id: "aquarium-pearl",
    name: "\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u044B\u0439 \u0437\u0430\u043B",
    x: -20,
    z: 10,
    w: 21,
    d: 20,
    h: 9.3,
    r: 1.6,
    color: 6412526,
    fish: 11,
    hero: 3
  },
  {
    id: "aquarium-coral",
    name: "\u041A\u043E\u0440\u0430\u043B\u043B\u043E\u0432\u044B\u0439 \u0437\u0430\u043B",
    x: 20,
    z: 10,
    w: 21,
    d: 20,
    h: 9.3,
    r: 1.6,
    color: 7921644,
    fish: 11,
    hero: 3
  },
  {
    id: "aquarium-lilac",
    name: "\u041B\u0430\u0432\u0430\u043D\u0434\u043E\u0432\u0430\u044F \u0433\u043B\u0443\u0431\u0438\u043D\u0430",
    x: -20,
    z: -13,
    w: 21,
    d: 18,
    h: 10.6,
    r: 1.6,
    color: 9096176,
    fish: 9,
    hero: 3
  },
  {
    id: "aquarium-sunrise",
    name: "\u0421\u043E\u043B\u043D\u0435\u0447\u043D\u0430\u044F \u043B\u0430\u0433\u0443\u043D\u0430",
    x: 20,
    z: -13,
    w: 21,
    d: 18,
    h: 10.6,
    r: 1.6,
    color: 7920869,
    fish: 9,
    hero: 3
  }
].map((o, i) => ({
  ...o,
  type: o.id,
  biome: "aquarium",
  kind: "aquarium",
  index: i,
  icon: "\u{1F420}",
  price: 0,
  buildMinutes: 0,
  rate: 0,
  description: "\u0411\u043E\u043B\u044C\u0448\u0438\u0435 \u043B\u0430\u0441\u043A\u043E\u0432\u044B\u0435 \u0440\u044B\u0431\u043A\u0438-\u043A\u043E\u0442\u0438\u043A\u0438, \u043F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u043E\u0435 \u0441\u0442\u0435\u043A\u043B\u043E \u0438 \u0441\u0432\u043E\u0431\u043E\u0434\u043D\u044B\u0435 \u043C\u0435\u0441\u0442\u0430 \u0434\u043B\u044F \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u043D\u044B\u0445 \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u0445 \u043F\u043E\u0441\u0435\u0442\u0438\u0442\u0435\u043B\u0435\u0439."
}));
var AQUARIUM_LOCALS = [
  {
    id: "aquarium-pearl-cat",
    name: "\u041F\u0435\u0440\u043B\u0438\u043D\u043A\u0430",
    breed: "ragdoll",
    color: 15261912,
    eyes: 8764378,
    personality: "\u041B\u044E\u0431\u0443\u0454\u0442\u044C\u0441\u044F \u043D\u0430\u0439\u0431\u0456\u043B\u044C\u0448\u0438\u043C\u0438 \u0440\u0438\u0431\u043A\u0430\u043C\u0438 \u0439 \u0442\u0438\u0445\u0435\u043D\u044C\u043A\u043E \u0442\u043E\u0440\u043A\u0430\u0454\u0442\u044C\u0441\u044F \u0441\u043A\u043B\u0430"
  },
  {
    id: "aquarium-plush-cat",
    name: "\u041F\u043B\u043E\u043C\u0431\u0456\u0440\u0447\u0438\u043A",
    breed: "british",
    build: "plush",
    color: 10987959,
    eyes: 11916670,
    personality: "\u041C\u0438\u043B\u0438\u0439 \u043F\u0443\u0445\u043A\u0435\u043D\u044C\u043A\u0438\u0439 \u0432\u0456\u0434\u0432\u0456\u0434\u0443\u0432\u0430\u0447 \u043E\u043A\u0435\u0430\u043D\u0430\u0440\u0456\u0443\u043C\u0443"
  },
  {
    id: "aquarium-ginger-cat",
    name: "\u041A\u043E\u0440\u0430\u043B\u0438\u043A",
    breed: "calico",
    color: 14069898,
    eyes: 9882547,
    personality: "\u0420\u0430\u0434\u0456\u0441\u043D\u043E \u043C\u0430\u0445\u0430\u0454 \u043B\u0430\u043F\u043A\u043E\u044E \u043A\u043E\u0440\u0430\u043B\u043E\u0432\u0438\u043C \u0440\u0438\u0431\u043A\u0430\u043C"
  },
  {
    id: "aquarium-moon-cat",
    name: "\u041F\u0443\u0445\u0438\u0440\u0447\u0438\u043A",
    breed: "persian",
    build: "plush",
    color: 13944284,
    eyes: 9555680,
    personality: "\u0421\u0456\u0434\u0430\u0454 \u0431\u0456\u043B\u044F \u0441\u043A\u043B\u0430 \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u044C \u0437\u0430 \u043F\u043B\u0430\u0432\u043D\u0438\u043A\u0430\u043C\u0438"
  }
].map((o) => ({ ...o, biome: "aquarium" }));

// public/diamond-data.js
var DIAMOND_MINE = {
  id: "diamond-mine",
  name: "\u0410\u043B\u043C\u0430\u0437\u043D\u0430\u044F \u0448\u0430\u0445\u0442\u0430 \u041C\u0443\u0440-\u043A\u043E\u043F\u0430",
  category: "business",
  icon: "\u{1F48E}",
  price: 2200,
  requiredLevel: 4,
  buildMinutes: 20,
  footprint: [4, 4],
  rate: 2,
  currency: "diamonds",
  rarity: "\u0420\u0435\u0434\u043A\u0430\u044F",
  color: 12231139,
  actions: ["explore"],
  description: "\u041A\u043E\u0442\u0438\u043A-\u043C\u0430\u0439\u043D\u0435\u0440 \u0434\u043E\u0431\u044B\u0432\u0430\u0435\u0442 \u043F\u043E\u043B\u0443\u043F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u044B\u0435 \u0441\u0438\u0440\u0435\u043D\u0435\u0432\u044B\u0435 \u0430\u043B\u043C\u0430\u0437\u044B: 2 \u{1F48E} \u0432 \u0447\u0430\u0441, \u0437\u0430\u043F\u0430\u0441 \u0434\u043E 8 \u0447\u0430\u0441\u043E\u0432. \u0417\u0430 8 \u{1F48E} \u0443\u0441\u043A\u043E\u0440\u044C\u0442\u0435 \u043A\u043E\u0442\u0438\u043A\u043E\u0432-\u0441\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u0435\u0439 \u0432 10 \u0440\u0430\u0437 \u043D\u0430 \u0446\u0435\u043B\u044B\u0439 \u0447\u0430\u0441."
};

// public/atoll-slide-data.js
var ATOLL_PRICE_BASE = 8e4;
var ATOLL_PRICE_MAX = 25e4;
var ATOLL_INCOME_BASE = 24e4 * 8;
var ATOLL_PARK_ID = "atoll-park";
var ATOLL_PARK = {
  id: ATOLL_PARK_ID,
  name: "\u0412\u0435\u043B\u0438\u043A\u0438\u0439 \u0430\u043A\u0432\u0430\u043F\u0430\u0440\u043A",
  icon: "\u{1F30A}",
  price: 0,
  subtitle: "20 \u0432\u0435\u043B\u0435\u0442\u0435\u043D\u0441\u044C\u043A\u0438\u0445 \u0432\u043E\u0434\u043D\u0438\u0445 \u043C\u0456\u043D\u0456\u0431\u0456\u043E\u043C\u0456\u0432 \xB7 \u043F\u0440\u043E\u0441\u0442\u043E\u0440\u0456 \u0430\u043B\u0435\u0457",
  radius: 390,
  center: [0, -925],
  arrival: [0, 375],
  requiredLevel: 20,
  ground: 10079668,
  edge: 8822428,
  foliage: 7650179,
  accent: 6020589,
  waterpark: true
};
var specs = [
  ["giant-wave", "\u0412\u0435\u043B\u0435\u0442\u0435\u043D\u0441\u044C\u043A\u0430 \u0445\u0432\u0438\u043B\u044F", "\u{1F30A}", 70, 1, 1, 3659239, 10155250, 2.4, "\u0412\u0435\u043B\u0438\u0447\u0435\u0437\u043D\u0438\u0439 \u0431\u0456\u0440\u044E\u0437\u043E\u0432\u0438\u0439 \u0437\u0430\u0432\u0438\u0442\u043E\u043A, \u043F\u0440\u043E\u0457\u0437\u0434 \u043A\u0440\u0456\u0437\u044C \u0445\u0432\u0438\u043B\u044E \u0442\u0430 \u043F\u0440\u043E\u0441\u0442\u043E\u0440\u0430 \u043B\u0430\u0433\u0443\u043D\u0430."],
  ["rock-arch", "\u0421\u043A\u0435\u043B\u044F\u0441\u0442\u0430 \u0430\u0440\u043A\u0430", "\u{1F3DE}\uFE0F", 63, 1, 1, 7527670, 15914913, 1.25, "\u0421\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u0432\u0438\u0441\u043E\u043A\u043E\u0457 \u0441\u043A\u0435\u043B\u0456, \u043F\u0440\u0438\u0440\u043E\u0434\u043D\u0430 \u0430\u0440\u043A\u0430 \u0442\u0430 \u0432\u043E\u0434\u043E\u0441\u043F\u0430\u0434\u043D\u0430 \u0437\u0430\u0432\u0456\u0441\u0430."],
  ["rainbow-race", "\u0412\u0435\u0441\u0435\u043B\u043A\u043E\u0432\u0438\u0439 \u0441\u043F\u0443\u0441\u043A", "\u{1F308}", 66, 6, 6, 9101299, 16364509, 1.4, "\u0428\u0456\u0441\u0442\u044C \u0441\u043F\u0440\u0430\u0432\u0436\u043D\u0456\u0445 \u043A\u043E\u043B\u044C\u043E\u0440\u043E\u0432\u0438\u0445 \u0434\u043E\u0440\u0456\u0436\u043E\u043A, \u043E\u0434\u043D\u043E\u0447\u0430\u0441\u043D\u0456 \u0437\u0430\u0457\u0437\u0434\u0438 \u0439 \u0432\u0435\u043B\u0438\u043A\u0430 \u043B\u0430\u0433\u0443\u043D\u0430."],
  ["sky-serpent", "\u041D\u0435\u0431\u0435\u0441\u043D\u0438\u0439 \u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D", "\u{1F300}", 73, 1, 1, 7986421, 12971770, 1.55, "\u041F\u0440\u043E\u0437\u043E\u0440\u0438\u0439 \u0432\u043E\u0434\u043D\u0438\u0439 \u0442\u0443\u043D\u0435\u043B\u044C \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u0448\u043F\u0438\u043B\u044F, \u043A\u0440\u0456\u0437\u044C \u0441\u043A\u0435\u043B\u044C\u043D\u0443 \u0430\u0440\u043A\u0443."],
  ["blue-whirlpool", "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0438\u0439 \u0432\u0438\u0440", "\u{1F4A7}", 61, 1, 3, 3789281, 10473146, 1.3, "\u0412\u0435\u043B\u0438\u043A\u0430 \u043F\u0440\u0438\u0440\u043E\u0434\u043D\u0430 \u0441\u043A\u0435\u043B\u044C\u043D\u0430 \u0447\u0430\u0448\u0430, \u0433\u043B\u0438\u0431\u043E\u043A\u0438\u0439 \u0432\u0438\u0440 \u0456 \u043E\u043A\u0440\u0435\u043C\u0438\u0439 \u0432\u0438\u0445\u0456\u0434 \u0434\u043E \u0431\u0430\u0441\u0435\u0439\u043D\u0443."],
  ["double-serpent", "\u041F\u043E\u0434\u0432\u0456\u0439\u043D\u0438\u0439 \u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D", "\u{1F380}", 69, 2, 2, 16288723, 5823719, 1.65, "\u0414\u0432\u0456 \u043F\u0435\u0440\u0435\u043F\u043B\u0435\u0442\u0435\u043D\u0456 \u0442\u0440\u0430\u0441\u0438 \u2014 \u0440\u043E\u0436\u0435\u0432\u0430 \u0439 \u0431\u0456\u0440\u044E\u0437\u043E\u0432\u0430 \u2014 \u0437 \u043E\u043A\u0440\u0435\u043C\u0438\u043C\u0438 \u0432\u043E\u0434\u043D\u0438\u043C\u0438 \u0444\u0456\u043D\u0456\u0448\u0430\u043C\u0438."],
  ["waterfall-cascade", "\u041A\u0430\u0441\u043A\u0430\u0434 \u0432\u043E\u0434\u043E\u0441\u043F\u0430\u0434\u0456\u0432", "\u{1F3DD}\uFE0F", 66, 1, 4, 8054510, 14997421, 1.6, "\u0427\u043E\u0442\u0438\u0440\u0438 \u0432\u0435\u043B\u0438\u043A\u0456 \u0442\u0435\u0440\u0430\u0441\u0438-\u0431\u0430\u0441\u0435\u0439\u043D\u0438, \u0432\u043E\u0434\u043E\u0441\u043F\u0430\u0434\u0438 \u0439 \u043F\u043E\u0441\u043B\u0456\u0434\u043E\u0432\u043D\u0456 \u0432\u043E\u0434\u043D\u0456 \u0441\u043F\u0443\u0441\u043A\u0438."],
  ["emerald-canyon", "\u0421\u043C\u0430\u0440\u0430\u0433\u0434\u043E\u0432\u0438\u0439 \u043A\u0430\u043D\u044C\u0439\u043E\u043D", "\u{1F33F}", 64, 1, 1, 8056485, 13103770, 1.2, "\u0417\u0435\u043B\u0435\u043D\u0430 \u0441\u0442\u0440\u0456\u0447\u043A\u0430 \u043C\u0456\u0436 \u0432\u0438\u0441\u043E\u043A\u0438\u043C\u0438 \u0441\u043A\u0435\u043B\u044F\u043C\u0438, \u043C\u0456\u0441\u0442\u043A\u0430\u043C\u0438 \u0439 \u043E\u0437\u0435\u0440\u0446\u044F\u043C\u0438."],
  ["crystal-cavern", "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u0430 \u043F\u0435\u0447\u0435\u0440\u0430", "\u{1F48E}", 68, 1, 1, 8835071, 11967476, 1.5, "\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0430 \u043F\u0435\u0447\u0435\u0440\u0430, \u0432\u0438\u0441\u043E\u043A\u0456 \u0441\u044F\u044E\u0447\u0456 \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u0438 \u0442\u0430 \u0431\u043B\u0430\u043A\u0438\u0442\u043D\u0438\u0439 \u0432\u043E\u0434\u043D\u0438\u0439 \u043C\u0430\u0440\u0448\u0440\u0443\u0442."],
  ["root-valley", "\u0414\u043E\u043B\u0438\u043D\u0430 \u043A\u043E\u0440\u0456\u043D\u043D\u044F", "\u{1F333}", 76, 1, 1, 7987184, 11984009, 1.7, "\u0412\u0435\u043B\u0435\u0442\u0435\u043D\u0441\u044C\u043A\u0435 \u0434\u0435\u0440\u0435\u0432\u043E, \u0436\u0438\u0432\u0435 \u043A\u043E\u0440\u0456\u043D\u043D\u044F, \u0437\u0432\u0438\u0432\u0438\u0441\u0442\u0438\u0439 \u0441\u043F\u0443\u0441\u043A \u0456 \u0432\u043E\u0434\u043E\u0441\u043F\u0430\u0434\u0438."],
  ["blue-halfpipe", "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0430 \u043F\u0456\u0432\u0442\u0440\u0443\u0431\u0430", "\u{1FA75}", 67, 1, 1, 6346735, 11660791, 1.35, "\u0412\u0438\u0441\u043E\u043A\u0430 U-\u043F\u043E\u0434\u0456\u0431\u043D\u0430 \u043F\u0456\u0432\u0442\u0440\u0443\u0431\u0430: \u0440\u043E\u0437\u0433\u0456\u043D, \u0437\u043B\u0456\u0442 \u0443\u0433\u043E\u0440\u0443 \u0439 \u0431\u0440\u0438\u0437\u043A\u0438 \u0432\u043D\u0438\u0437\u0443."],
  ["lagoon-loop", "\u041A\u0456\u043B\u044C\u0446\u0435 \u043B\u0430\u0433\u0443\u043D\u0438", "\u2B55", 77, 1, 1, 6670076, 13872122, 1.85, "\u0412\u0435\u043B\u0438\u0447\u0435\u0437\u043D\u0430 \u0432\u0435\u0440\u0442\u0438\u043A\u0430\u043B\u044C\u043D\u0430 \u043F\u0435\u0442\u043B\u044F \u043D\u0430\u0434 \u043B\u0430\u0433\u0443\u043D\u043E\u044E \u0442\u0430 \u0432\u043B\u0430\u0441\u043D\u0438\u0439 \u0432\u043E\u0434\u043D\u0438\u0439 \u0444\u0456\u043D\u0456\u0448."],
  ["coral-arch", "\u041A\u043E\u0440\u0430\u043B\u043E\u0432\u0430 \u0430\u0440\u043A\u0430", "\u{1FAB8}", 65, 1, 1, 7724782, 16038320, 1.45, "\u041F\u0440\u0438\u0440\u043E\u0434\u043D\u0430 \u043A\u0430\u043C\u2019\u044F\u043D\u0430 \u0430\u0440\u043A\u0430, \u043A\u043E\u0440\u0430\u043B\u043E\u0432\u0456 \u0441\u0430\u0434\u0438 \u0442\u0430 \u0448\u0438\u0440\u043E\u043A\u0438\u0439 \u0432\u0438\u0433\u043D\u0443\u0442\u0438\u0439 \u0441\u043F\u0443\u0441\u043A."],
  ["cloud-islets", "\u0425\u043C\u0430\u0440\u043D\u0456 \u043E\u0441\u0442\u0440\u043E\u0432\u0438", "\u2601\uFE0F", 79, 1, 1, 8642289, 14866939, 1.95, "\u041F\u0456\u0434\u0432\u0456\u0441\u043D\u0456 \u0437\u0435\u043B\u0435\u043D\u0456 \u043E\u0441\u0442\u0440\u0456\u0432\u0446\u0456, \u0441\u043A\u0435\u043B\u044C\u043D\u0456 \u0448\u043F\u0438\u043B\u0456 \u0442\u0430 \u043B\u0435\u0433\u043A\u0456 \u0432\u043E\u0434\u043E\u0441\u043F\u0430\u0434\u0438 \u043D\u0430\u0434 \u0445\u043C\u0430\u0440\u0430\u043C\u0438."],
  ["flower-lagoon", "\u041A\u0432\u0456\u0442\u043A\u043E\u0432\u0430 \u043B\u0430\u0433\u0443\u043D\u0430", "\u{1F338}", 70, 1, 1, 12622331, 16360919, 1.6, "\u0424\u0456\u043E\u043B\u0435\u0442\u043E\u0432\u043E-\u0440\u043E\u0436\u0435\u0432\u0438\u0439 \u043C\u0430\u0440\u0448\u0440\u0443\u0442, \u043A\u0432\u0456\u0442\u0443\u0447\u0456 \u0434\u0435\u0440\u0435\u0432\u0430 \u0439 \u0432\u0435\u043B\u0438\u0447\u0435\u0437\u043D\u0430 \u043A\u0432\u0456\u0442\u043A\u0430 \u043D\u0430\u0434 \u043B\u0430\u0433\u0443\u043D\u043E\u044E."],
  ["red-canyon", "\u0427\u0435\u0440\u0432\u043E\u043D\u0438\u0439 \u043A\u0430\u043D\u044C\u0439\u043E\u043D", "\u{1F3DC}\uFE0F", 72, 2, 2, 16755338, 7853567, 1.55, "\u0414\u0432\u0430 \u0441\u0442\u0440\u0456\u043C\u043A\u0456 \u0433\u043E\u043D\u043E\u0447\u043D\u0456 \u0441\u043F\u0443\u0441\u043A\u0438 \u043C\u0456\u0436 \u0442\u0435\u043F\u043B\u0438\u043C\u0438 \u0442\u0435\u0440\u0430\u043A\u043E\u0442\u043E\u0432\u0438\u043C\u0438 \u0441\u043A\u0435\u043B\u044F\u043C\u0438."],
  ["abyss-bridge", "\u041C\u0456\u0441\u0442 \u043D\u0430\u0434 \u0431\u0435\u0437\u043E\u0434\u043D\u0435\u044E", "\u{1F309}", 81, 1, 1, 7593460, 15585170, 1.8, "\u0412\u0438\u0441\u043E\u043A\u0438\u0439 \u043F\u0440\u043E\u0433\u0443\u043B\u044F\u043D\u043A\u043E\u0432\u0438\u0439 \u043C\u0456\u0441\u0442 \u0456 \u043C\u0430\u0439\u0436\u0435 \u0432\u0435\u0440\u0442\u0438\u043A\u0430\u043B\u044C\u043D\u0438\u0439 \u0432\u043E\u0434\u043D\u0438\u0439 \u0441\u043F\u0443\u0441\u043A \u0443 \u0431\u0430\u0441\u0435\u0439\u043D."],
  ["green-valley", "\u0417\u0435\u043B\u0435\u043D\u0430 \u0434\u043E\u043B\u0438\u043D\u0430", "\u{1F334}", 62, 1, 1, 8185307, 11787412, 1.1, "\u0414\u043E\u0432\u0433\u0438\u0439 \u043F\u043B\u0430\u0432\u043D\u0438\u0439 \u0441\u043F\u0443\u0441\u043A \u043C\u0456\u0436 \u0437\u0435\u043B\u0435\u043D\u0438\u043C\u0438 \u043F\u0430\u0433\u043E\u0440\u0431\u0430\u043C\u0438, \u0434\u0435\u0440\u0435\u0432\u0430\u043C\u0438 \u0439 \u043A\u0430\u0441\u043A\u0430\u0434\u0430\u043C\u0438."],
  ["purple-vortex", "\u0424\u0456\u043E\u043B\u0435\u0442\u043E\u0432\u0430 \u0432\u043E\u0440\u043E\u043D\u043A\u0430", "\u{1F49C}", 78, 1, 3, 12163830, 16040331, 1.9, "\u0412\u0438\u0441\u043E\u043A\u0438\u0439 \u0440\u043E\u0437\u0433\u0456\u043D \u0443 \u0432\u0435\u043B\u0438\u0447\u0435\u0437\u043D\u0443 \u0444\u0456\u043E\u043B\u0435\u0442\u043E\u0432\u0443 \u0447\u0430\u0448\u0443, \u043E\u0431\u0435\u0440\u0442\u0430\u043D\u043D\u044F \u0439 \u043E\u043A\u0440\u0435\u043C\u0438\u0439 \u0432\u0438\u0445\u0456\u0434\u043D\u0438\u0439 \u043A\u0430\u043D\u0430\u043B."],
  ["mega-loops", "\u041C\u0435\u0433\u0430-\u043F\u0435\u0442\u043B\u0456", "\u{1F3A2}", 86, 1, 1, 8772346, 16030674, 2.8, "\u0422\u0440\u0438 \u0432\u0435\u043B\u0438\u043A\u0456 \u043A\u043E\u043B\u044C\u043E\u0440\u043E\u0432\u0456 \u043F\u0435\u0442\u043B\u0456, \u0448\u0432\u0438\u0434\u043A\u0456 \u043F\u043E\u0432\u043E\u0440\u043E\u0442\u0438 \u0439 \u043F\u0440\u043E\u0441\u0442\u043E\u0440\u0438\u0439 \u0444\u0456\u043D\u0456\u0448\u043D\u0438\u0439 \u0431\u0430\u0441\u0435\u0439\u043D."]
];
var ATOLL_SLIDES = specs.map(([kind, name, icon, height, lanes, channels, color, accent, multiplier, description], i) => ({
  id: "slide-atoll-" + kind,
  kind,
  name,
  icon,
  height,
  lanes,
  channels,
  color,
  accent,
  description,
  referenceCell: { index: i + 1, row: Math.floor(i / 5) + 1, column: i % 5 + 1 },
  collection: "\u0412\u0435\u043B\u0435\u0442\u0435\u043D\u0441\u044C\u043A\u0456 \u0432\u043E\u0434\u043D\u0456 \u0441\u0432\u0456\u0442\u0438 \xB7 20 \u0433\u0456\u0440\u043E\u043A",
  premiumWater: true,
  referenceSlide: true,
  category: "rides",
  actions: ["ride"],
  rarity: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u043E\u0435",
  mega: true,
  fixedPrice: true,
  price: Math.round((ATOLL_PRICE_BASE + (ATOLL_PRICE_MAX - ATOLL_PRICE_BASE) * i / (specs.length - 1)) / 1e3) * 1e3,
  incomePerHour: Math.round(ATOLL_INCOME_BASE * multiplier / 30 / 100) * 100,
  requiredLevel: 20,
  buildMinutes: 240 + i * 6,
  footprint: [112, 108],
  pool: [0, 33, 19, 12],
  surfaceY: 1.45,
  speedScale: 1.05
}));

// public/reference-slide-data.js
var REFERENCE_SLIDES = [
  [
    "crystal-loops",
    "\u041A\u0440\u0438\u0448\u0442\u0430\u043B\u0435\u0432\u0456 \u0442\u0440\u0438 \u043F\u0435\u0442\u043B\u0456",
    "\u{1F48E}",
    29,
    1,
    7987199,
    13870586,
    "\u0422\u0440\u0438 \u0432\u0435\u043B\u0438\u043A\u0456 \u043F\u0440\u043E\u0437\u043E\u0440\u0456 \u043F\u0435\u0442\u043B\u0456 \u0441\u0435\u0440\u0435\u0434 \u0441\u044F\u044E\u0447\u0438\u0445 \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u0456\u0432 \u0456 \u0437\u043E\u043B\u043E\u0442\u0438\u0445 \u043F\u0430\u0432\u0456\u043B\u044C\u0439\u043E\u043D\u0456\u0432."
  ],
  [
    "pearl-funnel",
    "\u041F\u0435\u0440\u043B\u0438\u043D\u043D\u0430 \u043C\u0443\u0448\u043B\u044F-\u0432\u043E\u0440\u043E\u043D\u043A\u0430",
    "\u{1F41A}",
    25,
    3,
    16232407,
    16766348,
    "\u041F\u0435\u0440\u043B\u0430\u043C\u0443\u0442\u0440\u043E\u0432\u0430 \u043C\u0443\u0448\u043B\u044F, \u0441\u043F\u0456\u0440\u0430\u043B\u044C \u043F\u043E \u0441\u043F\u0440\u0430\u0432\u0436\u043D\u0456\u0439 \u0447\u0430\u0448\u0456 \u0442\u0430 \u0432\u0438\u0445\u0456\u0434 \u043A\u0440\u0456\u0437\u044C \u0457\u0457 \u0433\u043E\u0440\u043B\u043E\u0432\u0438\u043D\u0443."
  ],
  [
    "rainbow-launch",
    "\u0412\u0435\u0441\u0435\u043B\u043A\u043E\u0432\u0438\u0439 \u043F\u043E\u043B\u0456\u0442",
    "\u{1F308}",
    30,
    1,
    16227021,
    16765560,
    "\u0412\u0435\u0441\u0435\u043B\u043A\u043E\u0432\u0438\u0439 \u0440\u043E\u0437\u0433\u0456\u043D, \u0432\u0438\u0441\u043E\u043A\u0435 \u043F\u0456\u0434\u043A\u0438\u0434\u0430\u043D\u043D\u044F \u0442\u0430 \u0441\u043F\u0440\u0430\u0432\u0436\u043D\u0456\u0439 \u043F\u043E\u043B\u0456\u0442 \u0443 \u0432\u0435\u043B\u0438\u043A\u0438\u0439 \u0431\u0430\u0441\u0435\u0439\u043D."
  ],
  [
    "waterfall-arch",
    "\u0411\u0440\u0430\u043C\u0430 \u0431\u043B\u0430\u043A\u0438\u0442\u043D\u043E\u0433\u043E \u0432\u043E\u0434\u043E\u0441\u043F\u0430\u0434\u0443",
    "\u{1F3DB}\uFE0F",
    34,
    1,
    7265522,
    15848869,
    "\u0421\u0442\u0440\u0456\u043C\u043A\u0430 \u0432\u043E\u0434\u044F\u043D\u0430 \u0441\u0442\u0456\u043D\u0430 \u0443 \u0432\u0438\u0441\u043E\u043A\u0456\u0439 \u043A\u0430\u043C\u2019\u044F\u043D\u0456\u0439 \u0431\u0440\u0430\u043C\u0456, \u0437 \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0438\u043C \u043E\u0433\u043B\u044F\u0434\u043E\u043C \u043A\u043E\u0442\u0438\u043A\u0430."
  ],
  [
    "canyon-twins",
    "\u0414\u0432\u0430 \u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D\u0438 \u043A\u0430\u043D\u044C\u0439\u043E\u043D\u0443",
    "\u{1F3DE}\uFE0F",
    28,
    2,
    16491709,
    7256824,
    "\u0414\u0432\u0430 \u043E\u043A\u0440\u0435\u043C\u0456 \u043F\u0435\u0440\u0435\u043F\u043B\u0435\u0442\u0435\u043D\u0456 \u0441\u043A\u043B\u044F\u043D\u0456 \u0441\u043F\u0443\u0441\u043A\u0438 \u043D\u0430\u0434 \u043A\u0430\u043D\u044C\u0439\u043E\u043D\u043E\u043C; \u0437\u0430\u0457\u0437\u0434\u0438 \u0447\u0435\u0440\u0433\u0443\u044E\u0442\u044C \u0434\u043E\u0440\u0456\u0436\u043A\u0438."
  ],
  [
    "ocean-tunnel",
    "\u041E\u043A\u0435\u0430\u043D\u0441\u044C\u043A\u0438\u0439 \u0430\u043A\u0432\u0430\u0442\u0443\u043D\u0435\u043B\u044C",
    "\u{1F420}",
    25,
    1,
    7067118,
    13152755,
    "\u041F\u0430\u043D\u043E\u0440\u0430\u043C\u043D\u0438\u0439 \u0442\u0443\u043D\u0435\u043B\u044C \u0443 \u043F\u0440\u043E\u0437\u043E\u0440\u0456\u0439 \u0442\u043E\u0432\u0449\u0456 \u0432\u043E\u0434\u0438, \u0440\u0438\u0431\u043A\u0438, \u0431\u0443\u043B\u044C\u0431\u0430\u0448\u043A\u0438 \u0442\u0430 \u0432\u0438\u0445\u0456\u0434 \u0444\u043E\u043D\u0442\u0430\u043D\u043E\u043C."
  ],
  [
    "blossom-tree",
    "\u0421\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D \u043A\u0432\u0456\u0442\u0443\u0447\u043E\u0433\u043E \u0434\u0435\u0440\u0435\u0432\u0430",
    "\u{1F338}",
    27,
    1,
    7267280,
    16755157,
    "\u0412\u043E\u0434\u044F\u043D\u0456 \u0432\u0438\u0442\u043A\u0438 \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u0432\u0435\u043B\u0438\u0447\u0435\u0437\u043D\u043E\u0433\u043E \u043A\u0432\u0456\u0442\u0443\u0447\u043E\u0433\u043E \u0434\u0435\u0440\u0435\u0432\u0430 \u0437 \u0431\u0443\u0434\u0438\u043D\u043E\u0447\u043A\u0430\u043C\u0438 \u043D\u0430 \u0433\u0456\u043B\u043A\u0430\u0445."
  ],
  [
    "ice-tunnel",
    "\u041A\u0440\u0438\u0436\u0430\u043D\u0430 \u0431\u0440\u0430\u043C\u0430",
    "\u2744\uFE0F",
    29,
    1,
    10608119,
    14800639,
    "\u0421\u0438\u043D\u0456\u0439 \u043B\u0456\u0434, \u0437\u0430\u0441\u043D\u0456\u0436\u0435\u043D\u0456 \u044F\u043B\u0438\u043D\u0438 \u0439 \u0432\u0435\u043B\u0438\u043A\u0438\u0439 \u043F\u0440\u043E\u0437\u043E\u0440\u0438\u0439 \u0442\u0443\u043D\u0435\u043B\u044C \u0443 \u043A\u0440\u0438\u0436\u0430\u043D\u0456\u0439 \u0441\u043A\u0435\u043B\u0456."
  ],
  [
    "orbital-shell",
    "\u041E\u0440\u0431\u0456\u0442\u0430 \u043C\u0456\u0441\u044F\u0447\u043D\u043E\u0457 \u043C\u0443\u0448\u043B\u0456",
    "\u{1FA90}",
    29,
    3,
    14002161,
    16174041,
    "\u0414\u043E\u0432\u0433\u0438\u0439 \u043E\u0440\u0431\u0456\u0442\u0430\u043B\u044C\u043D\u0438\u0439 \u0437\u0430\u0457\u0437\u0434 \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u043C\u0443\u0448\u043B\u0456, \u0437\u0430\u043A\u0440\u0443\u0447\u0443\u0432\u0430\u043D\u043D\u044F \u0443 \u0432\u0438\u0440 \u0456 \u0432\u043E\u0434\u044F\u043D\u0438\u0439 \u0432\u0438\u0445\u0456\u0434."
  ],
  [
    "terrace-cascades",
    "\u0421\u0430\u0434\u0438 \u0441\u0435\u043C\u0438 \u043A\u0430\u0441\u043A\u0430\u0434\u0456\u0432",
    "\u{1F3DD}\uFE0F",
    29,
    4,
    7134175,
    15912585,
    "\u0427\u043E\u0442\u0438\u0440\u0438 \u043E\u043A\u0440\u0435\u043C\u0456 \u0442\u0435\u0440\u0430\u0441\u0438 \u0442\u0440\u0430\u0441\u0438, \u0437\u2019\u0454\u0434\u043D\u0430\u043D\u0456 \u0441\u043F\u0440\u0430\u0432\u0436\u043D\u0456\u043C\u0438 \u0432\u043E\u0434\u044F\u043D\u0438\u043C\u0438 \u043A\u0430\u0441\u043A\u0430\u0434\u0430\u043C\u0438."
  ],
  [
    "canyon-eight",
    "\u041D\u0435\u0441\u043A\u0456\u043D\u0447\u0435\u043D\u043D\u0456\u0441\u0442\u044C \u0434\u0432\u043E\u0445 \u0441\u043A\u0435\u043B\u044C",
    "\u267E\uFE0F",
    28,
    1,
    15702488,
    8443898,
    "\u041F\u0440\u043E\u0441\u0442\u043E\u0440\u043E\u0432\u0430 \u0432\u0456\u0441\u0456\u043C\u043A\u0430 \u0437 \u0440\u0456\u0437\u043D\u0438\u043C\u0438 \u0432\u0438\u0441\u043E\u0442\u0430\u043C\u0438 \u043F\u0435\u0440\u0435\u0442\u0438\u043D\u0443 \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u0434\u0432\u043E\u0445 \u0441\u043A\u0435\u043B\u044C."
  ],
  [
    "luminous-vortex",
    "\u0421\u043F\u0456\u0440\u0430\u043B\u044C \u0437\u043E\u0440\u044F\u043D\u043E\u0433\u043E \u0432\u0438\u0440\u0443",
    "\u{1F52E}",
    30,
    3,
    9806847,
    6678765,
    "\u041F\u0456\u0434\u0441\u0432\u0456\u0447\u0435\u043D\u0430 \u043A\u0440\u0438\u0448\u0442\u0430\u043B\u0435\u0432\u0430 \u0441\u043F\u0456\u0440\u0430\u043B\u044C \u0443 \u043F\u0435\u0447\u0435\u0440\u0456 \u0442\u0430 \u0433\u043B\u0438\u0431\u043E\u043A\u0430 \u0447\u0430\u0448\u0430 \u0441\u044F\u044E\u0447\u043E\u0433\u043E \u0432\u0438\u0440\u0443."
  ],
  [
    "ring-launch",
    "\u041A\u043E\u043C\u0435\u0442\u0430 \u0437\u043E\u043B\u043E\u0442\u0438\u0445 \u043A\u0456\u043B\u0435\u0446\u044C",
    "\u{1F4AB}",
    33,
    1,
    16166091,
    16765806,
    "\u041A\u0440\u0443\u0442\u0438\u0439 \u0440\u043E\u0437\u0433\u0456\u043D \u0456 \u0431\u0430\u043B\u043B\u0456\u0441\u0442\u0438\u0447\u043D\u0438\u0439 \u043F\u043E\u043B\u0456\u0442 \u0442\u043E\u0447\u043D\u043E \u043A\u0440\u0456\u0437\u044C \u0442\u0440\u0438 \u0437\u043E\u043B\u043E\u0442\u0456 \u043A\u0456\u043B\u044C\u0446\u044F."
  ],
  [
    "ribbon-tower",
    "\u0411\u0430\u0448\u0442\u0430 \u043A\u043E\u043B\u044C\u043E\u0440\u043E\u0432\u0438\u0445 \u0432\u0438\u0442\u043A\u0456\u0432",
    "\u{1F380}",
    32,
    3,
    7785724,
    16765557,
    "\u0422\u0440\u0438 \u0440\u0456\u0437\u043D\u043E\u043A\u043E\u043B\u044C\u043E\u0440\u043E\u0432\u0456 \u043F\u0435\u0440\u0435\u043F\u043B\u0435\u0442\u0435\u043D\u0456 \u0434\u043E\u0440\u0456\u0436\u043A\u0438 \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u0432\u0438\u0441\u043E\u043A\u043E\u0457 \u0431\u0430\u0448\u0442\u0438."
  ],
  [
    "tidal-wave",
    "\u041F\u0440\u0438\u0431\u043E\u0440\u043A\u0443\u0432\u0430\u0447 \u0432\u0435\u043B\u0438\u043A\u043E\u0457 \u0445\u0432\u0438\u043B\u0456",
    "\u{1F30A}",
    26,
    3,
    6542072,
    10808557,
    "\u0412\u0438\u0441\u043E\u043A\u0430 \u0445\u0432\u0438\u043B\u044F, \u0434\u0432\u0430 \u043A\u043E\u0440\u043E\u0442\u043A\u0456 \u0431\u0430\u043B\u043B\u0456\u0441\u0442\u0438\u0447\u043D\u0456 \u043F\u0456\u0434\u0441\u043A\u043E\u043A\u0438 \u0442\u0430 \u043C\u2019\u044F\u043A\u0435 \u043F\u0440\u0438\u0432\u043E\u0434\u043D\u0435\u043D\u043D\u044F."
  ],
  [
    "water-lift",
    "\u041F\u0456\u0434\u0439\u043E\u043C\u043D\u0438\u043A \u043D\u0435\u0431\u0435\u0441\u043D\u043E\u0457 \u0432\u043E\u0434\u0438",
    "\u{1F6D7}",
    35,
    2,
    8248817,
    16768145,
    "\u041F\u0440\u043E\u0437\u043E\u0440\u0430 \u0432\u043E\u0434\u044F\u043D\u0430 \u0448\u0430\u0445\u0442\u0430 \u043F\u0456\u0434\u043D\u0456\u043C\u0430\u0454 \u043A\u043E\u0442\u0438\u043A\u0430 \u043F\u0435\u0440\u0435\u0434 \u0440\u0456\u0437\u043A\u0438\u043C \u0441\u043F\u0443\u0441\u043A\u043E\u043C \u0443\u0437\u0434\u043E\u0432\u0436 \u0431\u0430\u0448\u0442\u0438."
  ],
  [
    "dragon-tail",
    "\u0425\u0432\u0456\u0441\u0442 \u0431\u0456\u0440\u044E\u0437\u043E\u0432\u043E\u0433\u043E \u0434\u0440\u0430\u043A\u043E\u043D\u0430",
    "\u{1F409}",
    32,
    1,
    15962539,
    16765043,
    "\u0414\u043E\u0432\u0433\u0438\u0439 \u0434\u0440\u0430\u043A\u043E\u043D\u044F\u0447\u0438\u0439 \u0445\u0432\u0456\u0441\u0442-\u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D, \u0432\u0435\u043B\u0438\u0447\u0435\u0437\u043D\u0430 \u0434\u0440\u0443\u0436\u043D\u044F \u0433\u043E\u043B\u043E\u0432\u0430 \u0442\u0430 \u0437\u043E\u043B\u043E\u0442\u0456 \u0433\u0440\u0435\u0431\u0456\u043D\u0446\u0456."
  ],
  [
    "four-funnels",
    "\u041A\u043E\u0440\u043E\u043B\u0456\u0432\u0441\u044C\u043A\u0456 \u0447\u043E\u0442\u0438\u0440\u0438 \u0432\u043E\u0440\u043E\u043D\u043A\u0438",
    "\u{1F451}",
    43,
    9,
    15772633,
    7594734,
    "\u0427\u043E\u0442\u0438\u0440\u0438 \u0432\u0435\u043B\u0438\u043A\u0456 \u0447\u0430\u0448\u0456 \u043E\u0434\u043D\u0430 \u043F\u0456\u0434 \u043E\u0434\u043D\u043E\u044E, \u0437\u0456 \u0441\u043F\u0456\u0440\u0430\u043B\u044F\u043C\u0438 \u0439 \u0431\u0435\u0437\u043F\u0435\u0440\u0435\u0440\u0432\u043D\u0438\u043C\u0438 \u0432\u043E\u0434\u044F\u043D\u0438\u043C\u0438 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0430\u043C\u0438."
  ],
  [
    "sky-bridge",
    "\u041C\u0456\u0441\u0442 \u0443 \u0431\u043B\u0430\u043A\u0438\u0442\u043D\u0443 \u0431\u0435\u0437\u043E\u0434\u043D\u044E",
    "\u{1F309}",
    32,
    1,
    9165043,
    16046251,
    "\u0414\u043E\u0432\u0433\u0438\u0439 \u0430\u043A\u0432\u0435\u0434\u0443\u043A \u043D\u0430 \u0430\u0440\u043A\u0430\u0445, \u0448\u0432\u0438\u0434\u043A\u0435 \u043F\u0430\u0434\u0456\u043D\u043D\u044F \u0439 \u0441\u043A\u043B\u044F\u043D\u0438\u0439 \u0442\u0443\u043D\u0435\u043B\u044C \u0431\u0456\u043B\u044F \u0431\u0430\u0441\u0435\u0439\u043D\u0443."
  ],
  [
    "cave-loop",
    "\u041F\u0435\u0442\u043B\u044F \u043A\u0440\u0438\u0448\u0442\u0430\u043B\u0435\u0432\u043E\u0457 \u043F\u0435\u0447\u0435\u0440\u0438",
    "\u{1F30C}",
    28,
    1,
    10198527,
    7859444,
    "\u0412\u0435\u043B\u0438\u043A\u0430 \u0441\u043F\u0440\u0430\u0432\u0436\u043D\u044F \u043F\u0435\u0442\u043B\u044F \u0441\u0435\u0440\u0435\u0434 \u0441\u0442\u0430\u043B\u0430\u043A\u0442\u0438\u0442\u0456\u0432, \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u0456\u0432 \u0456 \u0441\u0432\u0456\u0442\u043D\u043E\u0457 \u0432\u043E\u0434\u0438."
  ],
  [
    "twin-flights",
    "\u0417\u0443\u0441\u0442\u0440\u0456\u0447 \u0434\u0432\u043E\u0445 \u0432\u043E\u0434\u044F\u043D\u0438\u0445 \u043A\u043E\u043C\u0435\u0442",
    "\u2604\uFE0F",
    29,
    2,
    16163017,
    8247543,
    "\u0414\u0432\u0456 \u0440\u043E\u0437\u0433\u0456\u043D\u043D\u0456 \u0442\u0440\u0430\u0441\u0438, \u0449\u043E \u0441\u0445\u043E\u0434\u044F\u0442\u044C\u0441\u044F \u0432 \u043F\u043E\u0432\u0456\u0442\u0440\u0456; \u0440\u0456\u0437\u043D\u0456 \u0434\u043E\u0440\u0456\u0436\u043A\u0438 \u0434\u043B\u044F \u043F\u043E\u0441\u043B\u0456\u0434\u043E\u0432\u043D\u0438\u0445 \u0437\u0430\u0457\u0437\u0434\u0456\u0432."
  ],
  [
    "lighthouse",
    "\u0421\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D \u043F\u0435\u0440\u043B\u0438\u043D\u043D\u043E\u0433\u043E \u043C\u0430\u044F\u043A\u0430",
    "\u{1F5FC}",
    31,
    1,
    7134184,
    16757183,
    "\u0422\u0440\u0438 \u0448\u0438\u0440\u043E\u043A\u0456 \u0432\u043E\u0434\u044F\u043D\u0456 \u0432\u0438\u0442\u043A\u0438 \u043D\u0430\u0432\u043A\u043E\u043B\u043E \u0447\u0435\u0440\u0432\u043E\u043D\u043E-\u0431\u0456\u043B\u043E\u0433\u043E \u043C\u0430\u044F\u043A\u0430 \u0442\u0430 \u043C\u043E\u0440\u0441\u044C\u043A\u0438\u0439 \u0431\u0430\u0441\u0435\u0439\u043D."
  ],
  [
    "twin-shell",
    "\u0414\u0432\u0430 \u0441\u0435\u0440\u0446\u044F \u0432\u0435\u043B\u0438\u043A\u043E\u0457 \u043C\u0443\u0448\u043B\u0456",
    "\u{1F497}",
    30,
    2,
    15970523,
    16767633,
    "\u0414\u0432\u0456 \u043F\u043E\u0441\u043B\u0456\u0434\u043E\u0432\u043D\u0456 \u0445\u0432\u0438\u043B\u0456-\u0441\u043F\u0443\u0441\u043A\u0438 \u0437 \u043F\u0435\u0440\u043B\u0438\u043D\u043D\u043E\u0457 \u043C\u0443\u0448\u043B\u0456 \u0432 \u0441\u043F\u0456\u043B\u044C\u043D\u0443 \u043B\u0430\u0433\u0443\u043D\u0443."
  ],
  [
    "royal-aqueduct",
    "\u0410\u043A\u0432\u0435\u0434\u0443\u043A \u0447\u043E\u0442\u0438\u0440\u044C\u043E\u0445 \u043F\u043E\u0432\u043E\u0440\u043E\u0442\u0456\u0432",
    "\u{1F3F0}",
    34,
    4,
    7789289,
    16111523,
    "\u0427\u043E\u0442\u0438\u0440\u0438 \u0434\u043E\u0432\u0433\u0456 \u043A\u0430\u0441\u043A\u0430\u0434\u043D\u0456 \u043F\u043E\u0432\u043E\u0440\u043E\u0442\u0438 \u043D\u0430\u0434 \u0432\u0438\u0441\u043E\u043A\u0438\u043C\u0438 \u043A\u0430\u043C\u2019\u044F\u043D\u0438\u043C\u0438 \u0430\u0440\u043A\u0430\u043C\u0438."
  ],
  [
    "cloud-star",
    "\u0425\u043C\u0430\u0440\u043D\u0430 \u043A\u043E\u0440\u043E\u043D\u0430 \u0439 \u0437\u043E\u0440\u044F\u043D\u0438\u0439 \u0431\u0430\u0441\u0435\u0439\u043D",
    "\u2B50",
    38,
    1,
    8641009,
    16766063,
    "\u0421\u043F\u0443\u0441\u043A \u0456\u0437 \u0437\u043E\u043B\u043E\u0442\u043E\u0433\u043E \u0445\u043C\u0430\u0440\u043D\u043E\u0433\u043E \u043A\u0456\u043B\u044C\u0446\u044F \u043A\u0440\u0456\u0437\u044C \u0434\u043E\u0432\u0433\u0443 \u0441\u043F\u0456\u0440\u0430\u043B\u044C \u0443 \u0432\u0435\u043B\u0438\u043A\u0438\u0439 \u0431\u0430\u0441\u0435\u0439\u043D-\u0437\u0456\u0440\u043A\u0443."
  ]
].map(([key, name, icon, height, channels, color, accent, description], i) => ({
  id: "slide-dream-" + key,
  kind: key,
  name,
  icon,
  height,
  channels,
  color,
  accent,
  description,
  referenceCell: {
    index: i + 1,
    row: Math.floor(i / 5) + 1,
    column: i % 5 + 1
  },
  collection: "\u0410\u043A\u0432\u0430\u043F\u0430\u0440\u043A \u043C\u0440\u0456\u0457 \xB7 25 \u0433\u0456\u0440\u043E\u043A",
  referenceSlide: true,
  category: "rides",
  actions: ["ride"],
  rarity: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u043E\u0435",
  mega: true,
  fixedPrice: true,
  price: [
    96e3,
    42e3,
    48e3,
    28e3,
    78e3,
    66e3,
    54e3,
    46e3,
    68e3,
    72e3,
    94e3,
    88e3,
    116e3,
    132e3,
    86e3,
    72e3,
    104e3,
    24e4,
    78e3,
    112e3,
    96e3,
    36e3,
    98e3,
    124e3,
    168e3
  ][i],
  incomePerHour: [
    3200,
    1500,
    1700,
    1e3,
    2700,
    2300,
    1900,
    1600,
    2400,
    2500,
    3200,
    3e3,
    3900,
    4400,
    2900,
    2500,
    3500,
    8e3,
    2700,
    3800,
    3200,
    1300,
    3400,
    4200,
    5600
  ][i],
  requiredLevel: 6 + Math.floor(i / 3),
  buildMinutes: 110 + i * 8,
  footprint: key === "four-funnels" ? [54, 52] : [54, 48],
  pool: [3, 12, 7.2, 4.5],
  surfaceY: 1.45
}));

// public/water-ride-data.js
var WATER_RIDE_RULE_VERSION = 1;
var WATER_RIDES = [
  ["waterslide", "flume", 1],
  ["water-river", "channel", 1],
  ["water-whirlpool", "vortex", 1],
  ["water-extreme", "flume", 1],
  ["slide-royal-cascade", "flume", 1],
  ["slide-vortex-bowl", "vortex", 1],
  ["ride-crystal-slide", "flume", 1],
  ["slide-marshmallow", "flume", 3],
  ["slide-glass-corkscrew", "flume", 1],
  ["slide-sky-cannon", "flume", 1],
  ["slide-titan-funnel", "vortex", 3],
  ["slide-jungle-titan", "flume", 1],
  ["slide-rainbow-tsunami", "flume", 6],
  ["slide-abyss-capsule", "flume", 1],
  ["dive-triple-sky", "dive", 0],
  ...REFERENCE_SLIDES.map((s) => [s.id, "flume", s.channels]),
  ...ATOLL_SLIDES.map((s) => [s.id, "flume", s.channels]),
  ...SHOWCASE_WATER_RIDES.map((s) => [s.id, s.channels ? "flume" : "dive", s.channels])
].map(([id, kind, channels]) => ({
  id,
  kind,
  channels,
  version: WATER_RIDE_RULE_VERSION
}));
var waterRideSpec = (id) => WATER_RIDES.find((r) => r.id === id);

// public/magic-farms-data.js
var MAGIC_FARMS = [
  { id: "farm-starlight", kind: "star", name: "\u0417\u043E\u0440\u044F\u043D\u0438\u0439 \u0444\u0440\u0443\u043A\u0442\u043E\u0432\u0438\u0439 \u0441\u0430\u0434", icon: "\u{1F31F}", price: 12e4, requiredLevel: 8, radius: 88, center: [-600, -340], ground: 9226645, edge: 9012400, foliage: 7453585, accent: 16768903, water: 5430489, subtitle: "\u0417\u043E\u0440\u044F\u043D\u0456 \u043A\u0440\u043E\u043D\u0438, \u043C\u0456\u0441\u044F\u0447\u043D\u0456 \u0433\u0440\u0443\u0448\u0456, \u0441\u0432\u0456\u0442\u043B\u044F\u0447\u043A\u0438 \u0442\u0430 \u043E\u0437\u0435\u0440\u043E \u0431\u0430\u0436\u0430\u043D\u044C." },
  { id: "farm-sugarcloud", kind: "cloud", name: "\u0424\u0435\u0440\u043C\u0430 \u0446\u0443\u043A\u0440\u043E\u0432\u0438\u0445 \u0445\u043C\u0430\u0440", icon: "\u2601\uFE0F", price: 155e3, requiredLevel: 10, radius: 96, center: [-650, -60], ground: 13034190, edge: 11642061, foliage: 15313880, accent: 10217215, water: 11724282, subtitle: "\u041F\u0443\u0445\u043D\u0430\u0441\u0442\u0456 \u0434\u0435\u0440\u0435\u0432\u0430, \u0445\u043C\u0430\u0440\u043D\u0456 \u044F\u0433\u043E\u0434\u0438 \u0439 \u0441\u043E\u043B\u043E\u0434\u043A\u0456 \u0440\u043E\u0436\u0435\u0432\u0456 \u043A\u0430\u0441\u043A\u0430\u0434\u0438." },
  { id: "farm-crystal", kind: "crystal", name: "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u0456 \u0434\u0436\u0443\u043D\u0433\u043B\u0456", icon: "\u{1F48E}", price: 195e3, requiredLevel: 12, radius: 104, center: [-630, 220], ground: 8699315, edge: 9143982, foliage: 9554866, accent: 12951807, water: 4836316, subtitle: "\u0421\u044F\u0439\u043B\u0438\u0432\u0456 \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u0438, \u043F\u0440\u043E\u0437\u043E\u0440\u0456 \u0444\u0440\u0443\u043A\u0442\u0438 \u0439 \u0431\u0456\u0440\u044E\u0437\u043E\u0432\u0456 \u0434\u0436\u0435\u0440\u0435\u043B\u0430." },
  { id: "farm-moonpumpkin", kind: "moon", name: "\u041C\u0456\u0441\u044F\u0447\u043D\u0438\u0439 \u0433\u0430\u0440\u0431\u0443\u0437\u043E\u0432\u0438\u0439 \u043A\u0440\u0430\u0439", icon: "\u{1F319}", price: 24e4, requiredLevel: 14, radius: 98, center: [-410, 400], ground: 10269888, edge: 7831196, foliage: 12966368, accent: 16760955, water: 9358833, subtitle: "\u0412\u0435\u043B\u0435\u0442\u0435\u043D\u0441\u044C\u043A\u0456 \u0433\u0430\u0440\u0431\u0443\u0437\u0438, \u0441\u0440\u0456\u0431\u043D\u0438\u0439 \u0433\u0430\u0439 \u0456 \u0442\u0435\u043F\u043B\u0456 \u043D\u0456\u0447\u043D\u0456 \u043B\u0456\u0445\u0442\u0430\u0440\u0438\u043A\u0438." }
].map((f) => ({ ...f, magicFarm: true, arrival: [0, f.radius - 10] }));
var fruitSpecs = [
  ["starberry", "\u0417\u0456\u0440\u0447\u0430\u0441\u0442\u0430 \u044F\u0433\u043E\u0434\u0430", "\u2B50", 16765021, 16774849, 55, "\u0417\u0432\u0438\u0447\u0430\u0439\u043D\u0438\u0439", 90],
  ["moonpear", "\u041C\u0456\u0441\u044F\u0447\u043D\u0430 \u0433\u0440\u0443\u0448\u0430", "\u{1F350}", 11398129, 15335167, 120, "\u0420\u0456\u0434\u043A\u0456\u0441\u043D\u0438\u0439", 180],
  ["sunstar", "\u0421\u043E\u043D\u044F\u0447\u043D\u0430 \u0437\u0456\u0440\u043A\u0430", "\u{1F31F}", 16754110, 16770979, 380, "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u0438\u0439", 420],
  ["cloudberry", "\u042F\u0433\u0456\u0434\u043A\u0430-\u0445\u043C\u0430\u0440\u0438\u043D\u043A\u0430", "\u2601\uFE0F", 16758758, 16773114, 65, "\u0417\u0432\u0438\u0447\u0430\u0439\u043D\u0438\u0439", 100],
  ["sugarpeach", "\u0426\u0443\u043A\u0440\u043E\u0432\u0438\u0439 \u043F\u0435\u0440\u0441\u0438\u043A", "\u{1F351}", 10476795, 15268607, 145, "\u0420\u0456\u0434\u043A\u0456\u0441\u043D\u0438\u0439", 200],
  ["rainbowfloss", "\u0412\u0435\u0441\u0435\u043B\u043A\u043E\u0432\u0430 \u0441\u043E\u043B\u043E\u0434\u043A\u0430 \u0445\u043C\u0430\u0440\u043A\u0430", "\u{1F308}", 15119871, 16770723, 440, "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u0438\u0439", 450],
  ["crystalapple", "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u0435 \u044F\u0431\u043B\u0443\u043A\u043E", "\u{1F48E}", 7726297, 15925241, 90, "\u0417\u0432\u0438\u0447\u0430\u0439\u043D\u0438\u0439", 120],
  ["amethystplum", "\u0410\u043C\u0435\u0442\u0438\u0441\u0442\u043E\u0432\u0430 \u0441\u043B\u0438\u0432\u0430", "\u{1F52E}", 11900927, 16771327, 195, "\u0420\u0456\u0434\u043A\u0456\u0441\u043D\u0438\u0439", 240],
  ["aurorafruit", "\u041F\u043B\u0456\u0434 \u043F\u043E\u043B\u044F\u0440\u043D\u043E\u0433\u043E \u0441\u044F\u0439\u0432\u0430", "\u2728", 16755671, 16777215, 560, "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u0438\u0439", 480],
  ["moonpumpkin", "\u041C\u0456\u0441\u044F\u0447\u043D\u0438\u0439 \u0433\u0430\u0440\u0431\u0443\u0437", "\u{1F383}", 16759928, 16770213, 100, "\u0417\u0432\u0438\u0447\u0430\u0439\u043D\u0438\u0439", 130],
  ["silverpear", "\u0421\u0440\u0456\u0431\u043B\u044F\u0441\u0442\u0430 \u0433\u0440\u0443\u0448\u0430", "\u{1F350}", 12836600, 16121855, 210, "\u0420\u0456\u0434\u043A\u0456\u0441\u043D\u0438\u0439", 260],
  ["lunapumpkin", "\u0413\u0430\u0440\u0431\u0443\u0437 \u043C\u0456\u0441\u044F\u0447\u043D\u043E\u0433\u043E \u0441\u044F\u0439\u0432\u0430", "\u{1F319}", 12890874, 16773033, 620, "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u0438\u0439", 540]
];
var MAGIC_FRUITS = fruitSpecs.map(([id, name, icon, color, core, value, rarity, seconds], i) => ({ id, name, icon, color, core, value, rarity, seconds, minutes: seconds / 60, seed: 0, biome: MAGIC_FARMS[Math.floor(i / 3)].id, magicFruit: true }));
var magicFarm = (id) => MAGIC_FARMS.find((f) => f.id === id);
var farmFruits = (id) => MAGIC_FRUITS.filter((f) => f.biome === id);
var layouts = /* @__PURE__ */ new Map();
function magicFarmLayout(id) {
  if (layouts.has(id)) return layouts.get(id);
  const farm = magicFarm(id);
  if (!farm) return null;
  const fruits = farmFruits(id), plants = [];
  for (let i = 0; i < 18; i++) {
    let x, z;
    if (farm.kind === "star") {
      const a2 = i * Math.PI * 2 / 18;
      x = Math.sin(a2) * 57;
      z = Math.cos(a2) * 43 - 5;
    } else if (farm.kind === "cloud") {
      x = (i % 3 - 1) * 43 + Math.sin(Math.floor(i / 3) * 1.7) * 5;
      z = Math.floor(i / 3) * 22 - 58;
    } else if (farm.kind === "crystal") {
      const side = i % 2 ? 1 : -1;
      x = side * (32 + Math.sin(i * 0.9) * 13);
      z = Math.floor(i / 2) * 14 - 62;
    } else {
      const a2 = i * Math.PI * 2 / 18;
      x = Math.sin(a2) * (i % 2 ? 60 : 43);
      z = Math.cos(a2) * (i % 2 ? 50 : 34) - 4;
    }
    const fruit = fruits[i === 5 || i === 14 ? 2 : i % 3 === 1 ? 1 : 0];
    const kind = farm.kind === "moon" && i % 3 !== 1 ? "pumpkin" : farm.kind === "crystal" ? "crystal" : "tree", hero = i === (farm.kind === "cloud" ? 1 : 9);
    const a = Math.atan2(x, z), reach = kind === "pumpkin" ? hero ? 6 : 3 : hero ? 7.7 : 4.8;
    plants.push({ id: "plant-" + i, x, z, fruit: fruit.id, kind, hero, radius: kind === "pumpkin" ? hero ? 7.3 : 4.4 : hero ? 9.2 : 6.3, height: hero ? 21 : 8 + i % 3 * 1.2, fruitX: x + Math.sin(a) * reach, fruitZ: z + Math.cos(a) * reach, fruitY: kind === "pumpkin" ? 1.25 : 3.3 });
  }
  const pond = farm.kind === "star" ? [0, -7, 18, 15] : farm.kind === "cloud" ? [20, -4, 12, 10] : farm.kind === "crystal" ? [0, -32, 14, 24] : [0, -5, 20, 16];
  const result2 = { plants, pond, storage: { x: 0, z: 67 }, gate: { x: 0, z: farm.radius - 11 }, bounds: farm.radius - 5 };
  layouts.set(id, result2);
  return result2;
}
var MAGIC_FARM_OBJECTS = MAGIC_FARMS.map((f) => ({ id: "orchard-" + f.id, type: "farm-field", biome: f.id, name: f.name, x: 0, z: 0, magicFarm: f.id }));

// public/magic-bed-data.js
var MAGIC_BED_ID = "farm-magic-fruits";
var MAGIC_BED = { id: MAGIC_BED_ID, name: "\u0412\u0435\u043B\u0438\u043A\u0430 \u043C\u0430\u0433\u0456\u0447\u043D\u0430 \u0433\u0440\u044F\u0434\u043A\u0430", icon: "\u{1F331}", category: "farm", price: 6400, footprint: [10, 4.8], actions: ["farm"], requiredLevel: 6, buildMinutes: 4, rarity: "\u0420\u0435\u0434\u043A\u043E\u0435", fixedPrice: true, magicBed: true, description: "\u0428\u0456\u0441\u0442\u044C \u0440\u044F\u0434\u0456\u0432 \u0447\u0430\u0440\u0456\u0432\u043D\u0438\u0445 \u043A\u0443\u043B\u044C\u0442\u0443\u0440: \u043F\u0443\u0445\u043D\u0430\u0441\u0442\u0430 \u0432\u0430\u0442\u0430, \u043B\u0456\u0445\u0442\u0430\u0440\u0438\u043A\u0438, \u0441\u0435\u0440\u0434\u0435\u0447\u043A\u0430, \u0432\u043E\u0434\u044F\u043D\u0456 \u043A\u0440\u0430\u043F\u043B\u0456, \u0441\u043C\u0430\u0440\u0430\u0433\u0434\u0438 \u0439 \u0437\u043E\u043B\u043E\u0442\u0456 \u0437\u0430\u0432\u0438\u0442\u043A\u0438. \u0420\u043E\u0437\u043C\u0456\u0449\u0443\u0454\u0442\u044C\u0441\u044F \u043D\u0430 \u043D\u0430\u044F\u0432\u043D\u043E\u043C\u0443 \u043E\u0441\u0442\u0440\u043E\u0432\u0456." };
var rows3 = [
  ["cotton", "\u0426\u0443\u043A\u0440\u043E\u0432\u0430 \u0445\u043C\u0430\u0440\u0438\u043D\u043A\u0430", "\u041D\u0430\u0441\u0456\u043D\u043D\u044F \u0440\u043E\u0436\u0435\u0432\u043E\u0457 \u0432\u0430\u0442\u0438", "\u2601\uFE0F", 16755165, 16771061, 45, 35, 90, 0.95],
  ["lantern", "\u041F\u043E\u043C\u0430\u0440\u0430\u043D\u0447\u0435\u0432\u0438\u0439 \u043B\u0456\u0445\u0442\u0430\u0440\u0438\u043A", "\u041D\u0430\u0441\u0456\u043D\u043D\u044F \u043F\u043B\u043E\u0434\u0456\u0432-\u043B\u0456\u0445\u0442\u0430\u0440\u0438\u043A\u0456\u0432", "\u{1F3EE}", 16753463, 16770464, 65, 50, 120, 1.2],
  ["heart", "\u041F\u0435\u0440\u0441\u0438\u043A\u043E\u0432\u0435 \u0441\u0435\u0440\u0434\u0435\u0447\u043A\u043E", "\u041D\u0430\u0441\u0456\u043D\u043D\u044F \u043F\u0435\u0440\u0441\u0438\u043A\u043E\u0432\u0438\u0445 \u0441\u0435\u0440\u0434\u0435\u0447\u043E\u043A", "\u{1F351}", 16754344, 16770232, 80, 65, 150, 1.05],
  ["aqua", "\u0412\u043E\u0434\u044F\u043D\u0430 \u043A\u0440\u0430\u043F\u043B\u044F", "\u041D\u0430\u0441\u0456\u043D\u043D\u044F \u0431\u043B\u0430\u043A\u0438\u0442\u043D\u0438\u0445 \u043A\u0440\u0430\u043F\u0435\u043B\u044C", "\u{1F4A7}", 6740479, 15203583, 105, 85, 180, 1.2],
  ["emerald", "\u0421\u043C\u0430\u0440\u0430\u0433\u0434\u043E\u0432\u0438\u0439 \u043F\u043B\u0456\u0434", "\u041D\u0430\u0441\u0456\u043D\u043D\u044F \u0441\u043C\u0430\u0440\u0430\u0433\u0434\u043E\u0432\u0438\u0445 \u0441\u043F\u0456\u0440\u0430\u043B\u0435\u0439", "\u{1F49A}", 4704661, 16768889, 140, 115, 240, 1.15],
  ["golden", "\u0417\u043E\u043B\u043E\u0442\u0438\u0439 \u0437\u0430\u0432\u0438\u0442\u043E\u043A", "\u041D\u0430\u0441\u0456\u043D\u043D\u044F \u0437\u043E\u043B\u043E\u0442\u0438\u0445 \u0437\u0430\u0432\u0438\u0442\u043A\u0456\u0432", "\u2728", 16760655, 16773293, 170, 145, 300, 1.25]
];
var MAGIC_BED_CROPS = rows3.map(([kind, name, seedName, icon, color, core, seedPrice, value, gameMinutes, height], row2) => ({ id: "magic-fruit-" + kind, kind, name, seedName, icon, color, core, seedPrice, value, row: row2, gameMinutes, height, seconds: gameMinutes, minutes: gameMinutes / 60, seed: seedPrice, biome: "moon", magicBedOnly: true, yield: 2 }));
var MAGIC_BED_SEEDS = MAGIC_BED_CROPS.map((c) => ({ id: "magic-seed-" + c.kind, name: c.seedName, icon: c.icon, category: "seeds", price: c.seedPrice, seedCrop: c.id, seedRow: c.row, seed: true, footprint: [0.8, 0.8], actions: [], requiredLevel: 6, buildMinutes: 0, rarity: "\u041E\u0431\u044B\u0447\u043D\u043E\u0435", fixedPrice: true, description: "\u0420\u044F\u0434\u043E\u043A " + (c.row + 1) + " \xB7 " + c.name + " \xB7 \u0440\u0456\u0441\u0442 " + c.gameMinutes + " \u0456\u0433\u0440\u043E\u0432\u0438\u0445 \u0445\u0432\u0438\u043B\u0438\u043D." }));
var magicBedCrop = (id) => MAGIC_BED_CROPS.find((c) => c.id === id);
var MAGIC_BED_SLOTS = MAGIC_BED_CROPS.flatMap((c) => [1, -1].map((side, i) => ({ index: c.row * 2 + i, row: c.row, side, x: -3.65 + c.row * 1.46, z: side * 1.08, fruitZ: side * 1.93, fruitY: c.height + 0.3, crop: c.id })));

// public/building-expansions.js
var BUILDING_EXPANSIONS = {
  candy: { originalRadius: 11.65, areaMultiplier: 5, center: [-88, 130] },
  nature: { originalRadius: 11.65, areaMultiplier: 5, center: [40, 135] },
  rainbow: { originalRadius: 11.65, areaMultiplier: 5, center: [125, 112] },
  clouds: { originalRadius: 11.65, areaMultiplier: 5, center: [132, -8] }
};
var expandedBuildingRadius = (id) => {
  const spec = BUILDING_EXPANSIONS[id];
  return spec ? spec.originalRadius * Math.sqrt(spec.areaMultiplier) : null;
};

// public/bikini-data.js
var BIKINI_RADIUS = 11.65 * Math.sqrt(7);
var BIKINI_GATE = { x: 0, z: 27 };
var BIKINI_HOUSES = [
  { kind: "tube", x: -11, z: -25, w: 3, d: 3 },
  { kind: "tube", x: 15, z: -23, w: 3, d: 3 },
  { kind: "tube", x: -27, z: 0, w: 3, d: 3 },
  { kind: "pineapple", x: -17, z: -12, w: 7, d: 7 },
  { kind: "moai", x: -3, z: -21, w: 6, d: 6 },
  { kind: "rock", x: -21, z: 7, w: 7, d: 6 },
  { kind: "lighthouse", x: 23, z: -16, w: 3, d: 3 },
  { kind: "tube", x: 5, z: -24, w: 3, d: 3 },
  { kind: "tube", x: 23, z: 5, w: 3, d: 3 }
];
var BIKINI_POOLS = [
  {
    id: "lake-bikini",
    type: "swim-lagoon",
    biome: "bikini",
    name: "\u0413\u043E\u043B\u0443\u0431\u0430\u044F \u043B\u0430\u0433\u0443\u043D\u0430 \u0411\u0438\u043A\u0438\u043D\u0438-\u0411\u043E\u0442\u0442\u043E\u043C",
    x: 0,
    z: -6,
    rx: 4.2,
    rz: 5,
    surfaceY: 0.155,
    shoreY: 0.16
  },
  {
    id: "lake-bikini-shells",
    type: "swim-lagoon",
    biome: "bikini",
    name: "\u041B\u0430\u0433\u0443\u043D\u0430 \u0440\u0430\u043A\u0443\u0448\u0435\u043A",
    x: 19,
    z: 16,
    rx: 3.5,
    rz: 3.4,
    surfaceY: 0.155,
    shoreY: 0.16
  }
];
var BIKINI_RESTAURANT = {
  id: "bikini-krusty",
  type: "bikini-krusty",
  biome: "bikini",
  kind: "burger",
  x: 13,
  z: -7,
  w: 12,
  d: 10,
  name: "\u041A\u0440\u0430\u0441\u0442\u0438 \u041A\u0440\u0430\u0431",
  icon: "\u{1F354}",
  color: 13015920,
  roof: 10249029,
  price: 0,
  buildMinutes: 0,
  rate: 760,
  nautical: true,
  description: "\u0413\u0443\u0431\u043A\u0430 \u0411\u043E\u0431 \u0436\u0430\u0440\u0438\u0442 \u043A\u0440\u0430\u0431\u0441\u0431\u0443\u0440\u0433\u0435\u0440\u044B, \u043A\u043E\u0442\u0438\u043A\u0438 \u0437\u0430\u043A\u0430\u0437\u044B\u0432\u0430\u044E\u0442 \u0438 \u0435\u0434\u044F\u0442 \u0437\u0430 \u0441\u0442\u043E\u043B\u0438\u043A\u0430\u043C\u0438. \u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0439 \u0438\u043D\u0442\u0435\u0440\u044C\u0435\u0440, \u043C\u043E\u043D\u0435\u0442\u044B \u0438 XP."
};
var BIKINI_FRIENDS = [
  {
    id: "bikini-sponge",
    type: "bikini-sponge",
    biome: "bikini",
    kind: "sponge",
    name: "\u0413\u0443\u0431\u043A\u0430 \u0411\u043E\u0431",
    x: -7,
    z: 7,
    footprint: [3, 3]
  },
  {
    id: "bikini-patrick",
    type: "bikini-patrick",
    biome: "bikini",
    kind: "patrick",
    name: "\u041F\u0430\u0442\u0440\u0438\u043A",
    x: 8,
    z: 17,
    footprint: [3, 3]
  }
];
var bikiniFriend = (id) => BIKINI_FRIENDS.find((f) => f.id === id);
var BIKINI_ACTIONS = {
  sponge: [
    ["greet", "\u{1F44B} \u041F\u043E\u0437\u0434\u043E\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F"],
    ["five", "\u{1F43E} \u0414\u0430\u0442\u044C \u043F\u044F\u0442\u044C"],
    ["hug", "\u{1F49B} \u041E\u0431\u043D\u044F\u0442\u044C\u0441\u044F"],
    ["pet", "\u{1F408} \u041F\u043E\u0433\u043B\u0430\u0434\u0438\u0442\u044C"],
    ["carry", "\u{1F917} \u041F\u043E\u0433\u0443\u043B\u044F\u0442\u044C \u043D\u0430 \u0440\u0443\u0447\u043A\u0430\u0445"],
    ["play", "\u{1FAE7} \u041F\u043E\u0438\u0433\u0440\u0430\u0442\u044C \u0441 \u043F\u0443\u0437\u044B\u0440\u044F\u043C\u0438"],
    ["dance", "\u{1F3B5} \u041F\u043E\u0442\u0430\u043D\u0446\u0435\u0432\u0430\u0442\u044C"]
  ],
  patrick: [
    ["greet", "\u{1F44B} \u041F\u043E\u0437\u0434\u043E\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F"],
    ["photo", "\u{1F4F8} \u0421\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u043E\u0435 \u0444\u043E\u0442\u043E"],
    ["sit", "\u{1F324}\uFE0F \u041F\u043E\u0441\u0438\u0434\u0435\u0442\u044C \u0440\u044F\u0434\u043E\u043C"]
  ]
};
var BIKINI_LOCALS = [
  {
    id: "bikini-sandy-cat",
    name: "\u041F\u0435\u0441\u0447\u0438\u043D\u043A\u0430",
    biome: "bikini",
    breed: "calico",
    color: 13806210,
    eyes: 9424555,
    personality: "\u041B\u043E\u0432\u0438\u0442 \u043F\u0443\u0437\u044B\u0440\u0438 \u0438 \u0434\u0440\u0443\u0436\u0438\u0442 \u0441 \u0413\u0443\u0431\u043A\u043E\u0439 \u0411\u043E\u0431\u043E\u043C"
  },
  {
    id: "bikini-shell-cat",
    name: "\u0420\u0430\u043A\u0443\u0448\u0435\u0447\u043A\u0430",
    biome: "bikini",
    breed: "british",
    build: "plush",
    color: 12106429,
    eyes: 14074999,
    personality: "\u041B\u044E\u0431\u0438\u0442 \u043A\u0440\u0430\u0431\u0441\u0431\u0443\u0440\u0433\u0435\u0440\u044B \u0438 \u0442\u0438\u0445\u0438\u0435 \u043B\u0430\u0433\u0443\u043D\u044B"
  }
];
function bikiniReservations() {
  return [
    ...BIKINI_HOUSES.map((h) => ({ ...h, w: h.w + 1, d: h.d + 1 })),
    ...BIKINI_POOLS.map((p) => ({ ...p, w: p.rx * 2 + 1, d: p.rz * 2 + 1 })),
    { ...BIKINI_RESTAURANT, w: 13, d: 17, z: -4 },
    { x: -7, z: 10, w: 14, d: 13 },
    { x: 8, z: 20, w: 10, d: 10 },
    { x: 0, z: 27, w: 6, d: 6 }
  ];
}

// public/zoo-guest-data.js
var ZOO_GUEST_MS = JOB_MINUTE_MS * JOB_DAY_MINUTES / 2;
var zooAnimalId = (species, index) => `zoo-${species}-${index}`;
var text = (v) => typeof v === "string" && v.length > 0 && v.length <= 160 && !/[\u0000-\u001f]/.test(v);
var stamp = (v) => Number.isSafeInteger(v) && v > 0 && v < 1e15;
function normalizeZooGuests(raw) {
  const out = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return out;
  for (const e of ZOO_EXHIBITS) for (let i = 0; i < ZOO_ANIMALS[e.species].count; i++) {
    const key = zooAnimalId(e.species, i), v = raw[key];
    if (!v || !text(v.id) || v.animalId !== key || !text(v.houseId) || !stamp(v.startedAt) || v.endsAt !== v.startedAt + ZOO_GUEST_MS || !stamp(v.endsAt) || v.cancelledAt !== void 0 && (!stamp(v.cancelledAt) || v.cancelledAt < v.startedAt)) continue;
    out[key] = { id: v.id, animalId: key, houseId: v.houseId, startedAt: v.startedAt, endsAt: v.endsAt, ...v.cancelledAt ? { cancelledAt: v.cancelledAt } : {} };
  }
  return out;
}
var same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
var immutable = (v) => v && [v.id, v.animalId, v.houseId, v.startedAt, v.endsAt];
function mergeZooGuests(base, current, incoming) {
  const b = normalizeZooGuests(base), c = normalizeZooGuests(current), n = normalizeZooGuests(incoming), out = { ...c };
  for (const [key, change] of Object.entries(n)) {
    const old = b[key], actual = c[key];
    if (same(old, change)) continue;
    if (old?.id === change.id) {
      if (!same(immutable(old), immutable(change)) || old.cancelledAt && !change.cancelledAt) throw Error("\u041D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0437\u043C\u0456\u043D\u044E\u0432\u0430\u0442\u0438 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0438\u0439 \u0433\u043E\u0441\u0442\u044C\u043E\u0432\u0438\u0439 \u0432\u0456\u0437\u0438\u0442.");
      if (actual?.id === change.id) out[key] = { ...actual, ...change.cancelledAt ? { cancelledAt: Math.max(actual.cancelledAt || 0, change.cancelledAt) } : {} };
      continue;
    }
    if (actual?.id === change.id) {
      if (!same(immutable(actual), immutable(change))) throw Error("\u041D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0437\u043C\u0456\u043D\u044E\u0432\u0430\u0442\u0438 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0438\u0439 \u0433\u043E\u0441\u0442\u044C\u043E\u0432\u0438\u0439 \u0432\u0456\u0437\u0438\u0442.");
      out[key] = { ...actual, ...change.cancelledAt ? { cancelledAt: Math.max(actual.cancelledAt || 0, change.cancelledAt) } : {} };
      continue;
    }
    if (actual && actual.id !== old?.id) {
      if (same(actual, change)) continue;
      throw Error("\u0426\u044F \u0442\u0432\u0430\u0440\u0438\u043D\u0430 \u0432\u0436\u0435 \u043C\u0430\u0454 \u0456\u043D\u0448\u0438\u0439 \u0432\u0456\u0437\u0438\u0442. \u041E\u043D\u043E\u0432\u0456\u0442\u044C \u0433\u0440\u0443.");
    }
    if (actual && change.startedAt < actual.endsAt && !actual.cancelledAt) throw Error("\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u0456\u0439 \u0432\u0456\u0437\u0438\u0442 \u0449\u0435 \u0442\u0440\u0438\u0432\u0430\u0454.");
    if (actual && change.startedAt < Math.max(actual.startedAt, actual.cancelledAt || 0)) throw Error("\u0417\u0430\u0441\u0442\u0430\u0440\u0456\u043B\u0438\u0439 \u0433\u043E\u0441\u0442\u044C\u043E\u0432\u0438\u0439 \u0432\u0456\u0437\u0438\u0442.");
    out[key] = { ...change };
  }
  return out;
}

// public/zoo-system.js
var newZoo = () => ({ version: 1, receipts: {} });
function zooSnapshotValid(raw) {
  if (raw === void 0 || raw === null) return true;
  if (raw.version !== 1 || !raw.receipts || typeof raw.receipts !== "object" || Array.isArray(raw.receipts)) return false;
  const entries = Object.entries(raw.receipts);
  if (entries.length > 5) return false;
  for (const [id, p] of entries) {
    const e = zooExhibit(id) || (id === ZOO_RETIRED_EXHIBIT.id ? ZOO_RETIRED_EXHIBIT : null);
    if (!e || !e.index || !p || p.id !== `opened-${id}` || p.price !== e.price || !Number.isSafeInteger(p.openedAt) || p.openedAt <= 0 || p.openedAt >= 1e15) return false;
  }
  if (raw.receipts[ZOO_RETIRED_EXHIBIT.id] && !raw.receipts["zoo-otter"]) return false;
  for (let i = 1; i < ZOO_EXHIBITS.length; i++) if (raw.receipts[ZOO_EXHIBITS[i].id] && i > 1 && !raw.receipts[ZOO_EXHIBITS[i - 1].id]) return false;
  return true;
}
function normalizeZoo(raw) {
  if (!zooSnapshotValid(raw)) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u043E \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043D\u044F \u0437\u043E\u043E\u043F\u0430\u0440\u043A\u0443.");
  return raw ? { version: 1, receipts: Object.fromEntries(Object.entries(raw.receipts).map(([k, v]) => [k, { id: v.id, price: v.price, openedAt: v.openedAt }])), ...raw.guestVisits ? { guestVisits: normalizeZooGuests(raw.guestVisits) } : {} } : newZoo();
}
function mergeZoo(base, current, incoming) {
  const b = normalizeZoo(base), c = normalizeZoo(current);
  if (incoming === void 0 || incoming === null) return c;
  const n = normalizeZoo(incoming), out = normalizeZoo(c);
  for (const e of [...ZOO_EXHIBITS.slice(1), ZOO_RETIRED_EXHIBIT]) {
    const old = b.receipts[e.id], actual = c.receipts[e.id], change = n.receipts[e.id];
    if (old && change && JSON.stringify(old) !== JSON.stringify(change)) throw Error("\u0406\u0441\u0442\u043E\u0440\u0456\u044E \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0442\u044F \u0432\u043E\u043B\u044C\u0454\u0440\u0430 \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0437\u043C\u0456\u043D\u044E\u0432\u0430\u0442\u0438.");
    if (!old && change) {
      if (e.id === ZOO_RETIRED_EXHIBIT.id) throw Error("\u0422\u0438\u0433\u0440\u043E\u0432\u0438\u0439 \u0432\u043E\u043B\u044C\u0454\u0440 \u043F\u0440\u0438\u0431\u0440\u0430\u043D\u043E. \u041E\u043F\u043B\u0430\u0442\u0443 \u0441\u043A\u0430\u0441\u043E\u0432\u0430\u043D\u043E; \u043E\u043D\u043E\u0432\u0456\u0442\u044C \u0433\u0440\u0443.");
      if (actual) throw Error("\u0412\u043E\u043B\u044C\u0454\u0440 \u0443\u0436\u0435 \u0432\u0456\u0434\u043A\u0440\u0438\u043B\u0438 \u043D\u0430 \u0456\u043D\u0448\u043E\u043C\u0443 \u043F\u0440\u0438\u0441\u0442\u0440\u043E\u0457. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0443 \u043E\u043F\u043B\u0430\u0442\u0443 \u0441\u043A\u0430\u0441\u043E\u0432\u0430\u043D\u043E.");
      out.receipts[e.id] = { ...change };
    }
  }
  const guests = mergeZooGuests(base?.guestVisits, current?.guestVisits, incoming?.guestVisits);
  if (Object.keys(guests).length) out.guestVisits = guests;
  if (!zooSnapshotValid(out)) throw Error("\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0430 \u043F\u043E\u0441\u043B\u0456\u0434\u043E\u0432\u043D\u0456\u0441\u0442\u044C \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0442\u044F \u0432\u043E\u043B\u044C\u0454\u0440\u0456\u0432.");
  return out;
}

// public/construction-boost.js
var BUILDER_BOOST_MS = 36e5;
var BUILDER_BOOST_SPEED = 10;
function normalizeBuilderBoosts(raw) {
  const events = /* @__PURE__ */ new Map();
  for (const e of Array.isArray(raw) ? raw : [])
    if (typeof e?.id === "string" && /^[\w-]{8,64}$/.test(e.id) && Number.isSafeInteger(e.startedAt) && e.startedAt > 0 && e.startedAt < 1e15 && e.until === e.startedAt + BUILDER_BOOST_MS)
      events.set(e.id, { id: e.id, startedAt: e.startedAt, until: e.until });
  return [...events.values()].sort((a, b) => a.startedAt - b.startedAt || a.id.localeCompare(b.id)).slice(-64);
}
function constructionDeadline(p, boosts = []) {
  const base = p.boostBaseReadyAt || p.readyAt;
  if (!base || !p.startedAt || base <= p.startedAt) return base || 0;
  let cursor = p.startedAt, work = base - cursor;
  for (const e of normalizeBuilderBoosts(boosts)) {
    if (e.until <= cursor) continue;
    const before = Math.max(0, e.startedAt - cursor);
    if (work <= before) return cursor + work;
    work -= before;
    cursor = Math.max(cursor, e.startedAt);
    const span = Math.max(0, e.until - cursor);
    if (work <= span * BUILDER_BOOST_SPEED)
      return Math.ceil(cursor + work / BUILDER_BOOST_SPEED);
    work -= span * BUILDER_BOOST_SPEED;
    cursor = e.until;
  }
  return Math.ceil(cursor + work);
}
function resolveConstructionBoosts(game) {
  const boosts = normalizeBuilderBoosts(game.builderBoosts);
  if (!boosts.length) return game;
  let accounts = game.business?.accounts, changed2 = false;
  const placements = game.placements.map((p) => {
    const deadline = constructionDeadline(p, boosts);
    if (deadline === (p.readyAt || 0)) return p;
    changed2 = true;
    if (accounts?.[p.id]?.collectedAt === p.readyAt) {
      accounts = {
        ...accounts,
        [p.id]: { ...accounts[p.id], collectedAt: deadline }
      };
    }
    return {
      ...p,
      boostBaseReadyAt: p.boostBaseReadyAt || p.readyAt,
      readyAt: deadline
    };
  });
  return changed2 ? { ...game, placements, business: { ...game.business, accounts } } : game;
}

// public/foodcourt-data.js
var COURT_RADIUS = 11.65 * Math.sqrt(8);
var COURT_GATE = { x: 0, z: 29 };
var COURT_VENUES = [
  {
    id: "court-burger",
    type: "court-burger",
    biome: "foodcourt",
    kind: "burger",
    x: -17,
    z: -10,
    w: 12,
    d: 10,
    name: "\u041A\u043E\u0442\u044F\u0447\u0438\u0439 McDonald\u2019s",
    icon: "\u{1F354}",
    color: 15232085,
    roof: 12799811,
    price: 950,
    buildMinutes: 40,
    rate: 720,
    requiresBuild: true,
    description: "\u041A\u043E\u0442\u0438\u043A\u0438 \u0436\u0430\u0440\u044F\u0442 \u0431\u0443\u0440\u0433\u0435\u0440\u044B, \u043F\u043E\u0434\u0430\u044E\u0442 \u043A\u0430\u0440\u0442\u043E\u0444\u0435\u043B\u044C \u0444\u0440\u0438 \u0438 \u0443\u0433\u043E\u0449\u0430\u044E\u0442 \u0433\u043E\u0441\u0442\u0435\u0439 \u0437\u0430 \u0441\u0442\u043E\u043B\u0438\u043A\u0430\u043C\u0438."
  },
  {
    id: "court-boba",
    type: "court-boba",
    biome: "foodcourt",
    kind: "boba",
    x: 0,
    z: -16,
    w: 11,
    d: 10,
    name: "Boba Cloud \xB7 \u0436\u0435\u043C\u0447\u0443\u0436\u043D\u043E\u0435 \u043A\u0430\u0444\u0435",
    icon: "\u{1F9CB}",
    color: 13279967,
    roof: 12094411,
    price: 1200,
    buildMinutes: 70,
    rate: 640,
    requiresBuild: true,
    description: "\u042F\u0440\u043A\u0438\u0435 \u043D\u0430\u043F\u0438\u0442\u043A\u0438, \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u0435 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0435 \u0436\u0435\u043C\u0447\u0443\u0436\u0438\u043D\u044B \u0438 \u043A\u043E\u0442\u0438\u043A\u0438 \u0441 \u0431\u043E\u043B\u044C\u0448\u0438\u043C\u0438 \u0441\u0442\u0430\u043A\u0430\u043D\u0447\u0438\u043A\u0430\u043C\u0438."
  },
  {
    id: "court-coffee",
    type: "court-coffee",
    biome: "foodcourt",
    kind: "coffee",
    x: 17,
    z: -10,
    w: 12,
    d: 10,
    name: "Murrbucks \xB7 \u043A\u043E\u0442\u044F\u0447\u044C\u044F \u043A\u043E\u0444\u0435\u0439\u043D\u044F",
    icon: "\u2615",
    color: 9092258,
    roof: 3766884,
    price: 0,
    buildMinutes: 0,
    rate: 560,
    description: "\u0423\u0436\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0430: \u0431\u0430\u0440\u0438\u0441\u0442\u0430 \u043C\u0435\u043B\u0435\u0442 \u0437\u0451\u0440\u043D\u0430, \u0432\u0430\u0440\u0438\u0442 \u043A\u043E\u0442\u044F\u0447\u0438\u0439 \u043A\u043E\u0444\u0435 \u0438 \u043F\u043E\u0434\u0430\u0451\u0442 \u0435\u0433\u043E \u0433\u043E\u0441\u0442\u044F\u043C."
  },
  {
    id: "court-bakery",
    type: "court-bakery",
    biome: "foodcourt",
    kind: "cookie",
    x: 18,
    z: 10,
    w: 11,
    d: 10,
    name: "\u041F\u0435\u043A\u0430\u0440\u043D\u044F \u041A\u043E\u0442\u043E-\u041F\u0435\u0447\u0435\u043D\u044C\u043A\u0430",
    icon: "\u{1F36A}",
    color: 15056268,
    roof: 13408108,
    price: 1450,
    buildMinutes: 100,
    rate: 680,
    requiresBuild: true,
    description: "\u041F\u0435\u0447\u0435\u043D\u044C\u0435 \u0441 \u0443\u0448\u043A\u0430\u043C\u0438, \u0442\u0451\u043F\u043B\u0430\u044F \u043F\u0435\u0447\u044C, \u043F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u044B\u0435 \u0432\u0438\u0442\u0440\u0438\u043D\u044B \u0438 \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u0439 \u043F\u0435\u043A\u0430\u0440\u044C."
  },
  {
    id: "court-cinema",
    type: "court-cinema",
    biome: "foodcourt",
    kind: "cinema",
    x: -12,
    z: 15.5,
    w: 18,
    d: 18,
    name: "\u041A\u043E\u0442\u043E\u043A\u0438\u043D\u043E \u043F\u043E\u0434 \u043E\u0431\u043B\u0430\u043A\u0430\u043C\u0438",
    icon: "\u{1F3AC}",
    color: 10851529,
    roof: 9205674,
    price: 0,
    buildMinutes: 0,
    rate: 480,
    description: "\u041D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u0439 \u0432\u0438\u0434\u0435\u043E\u043F\u043B\u0435\u0435\u0440 \u043D\u0430 \u0431\u043E\u043B\u044C\u0448\u043E\u043C \u044D\u043A\u0440\u0430\u043D\u0435 \u0438 \u0448\u0435\u0441\u0442\u044C \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u0445 \u043C\u044F\u0433\u043A\u0438\u0445 \u043F\u0443\u0444\u043E\u0432 \u0434\u043B\u044F \u0434\u0440\u0443\u0437\u0435\u0439."
  }
];
var ALL_COURT_VENUES = [
  ...COURT_VENUES,
  BIKINI_RESTAURANT,
  ...AQUARIUM_TANKS,
  ...ZOO_EXHIBITS
];
var COURT_FOUNTAIN = {
  id: "lake-foodcourt",
  type: "swim-lagoon",
  biome: "foodcourt",
  name: "\u0424\u043E\u043D\u0442\u0430\u043D \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0445 \u0436\u0435\u043B\u0430\u043D\u0438\u0439",
  x: 0,
  z: 3,
  rx: 3,
  rz: 2.6,
  surfaceY: 0.155,
  shoreY: 0.16
};
function courtReservations() {
  return [
    ...COURT_VENUES.map((o) => ({
      id: o.id,
      x: o.x,
      z: o.z,
      w: o.w + 0.8,
      d: o.d + 0.8
    })),
    { x: 0, z: 3, w: 7, d: 6, rx: 3.5, rz: 3.1 },
    { x: 0, z: 27, w: 5, d: 6 }
  ];
}
var COURT_LOCALS = [
  {
    id: "court-caramel",
    name: "\u041A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043A\u0430",
    biome: "foodcourt",
    breed: "calico",
    color: 13346431,
    eyes: 9289690,
    personality: "\u0421 \u0443\u0434\u043E\u0432\u043E\u043B\u044C\u0441\u0442\u0432\u0438\u0435\u043C \u043F\u0440\u043E\u0431\u0443\u0435\u0442 \u043F\u0435\u0447\u0435\u043D\u044C\u0435 \u0438 \u0437\u043E\u0432\u0451\u0442 \u0434\u0440\u0443\u0437\u0435\u0439 \u0432 \u043A\u0438\u043D\u043E"
  },
  {
    id: "court-biscuit",
    name: "\u041F\u0435\u0447\u0435\u043D\u044E\u0448\u043A\u0430",
    biome: "foodcourt",
    breed: "british",
    build: "plush",
    color: 11973551,
    eyes: 14075767,
    personality: "\u0423\u044E\u0442\u043D\u0430\u044F \u043B\u044E\u0431\u0438\u0442\u0435\u043B\u044C\u043D\u0438\u0446\u0430 \u043C\u044F\u0433\u043A\u0438\u0445 \u043F\u0443\u0444\u043E\u0432 \u0438 \u043A\u043E\u0442\u044F\u0447\u044C\u0435\u0433\u043E \u043B\u0430\u0442\u0442\u0435"
  },
  {
    id: "court-pearl",
    name: "\u0416\u0435\u043C\u0447\u0443\u0436\u0438\u043D\u043A\u0430",
    biome: "foodcourt",
    breed: "ragdoll",
    color: 15063237,
    eyes: 9486044,
    personality: "\u041B\u044E\u0431\u0438\u0442 \u0446\u0432\u0435\u0442\u043D\u043E\u0439 \u0431\u0430\u0431\u043B-\u0442\u0438, \u0431\u043E\u043B\u044C\u0448\u0438\u0435 \u043E\u043A\u043D\u0430 \u0438 \u043D\u043E\u0432\u044B\u0445 \u0434\u0440\u0443\u0437\u0435\u0439"
  }
];

// public/mosasaur-forecourt.js
var APPROVED_BAY = Object.freeze({ x: 0, z: 170, rx: 192, rz: 84, shoulder: 36 });
var MOSA_FORECOURT = Object.freeze({ x: 0, z: 184, rx: 192, rz: 98, floor: -190, shoulder: 24 });
var distanceTo = (c, x, z) => (Math.hypot((x - c.x) / c.rx, (z - c.z) / c.rz) - 1) * c.rz;
function excavation(c, x, z) {
  const t = Math.max(0, Math.min(1, (c.shoulder - distanceTo(c, x, z)) / c.shoulder));
  return t * t * t * (t * (t * 6 - 15) + 10);
}
function oceanForecourtBedY(x, z, bed) {
  const a = excavation(APPROVED_BAY, x, z), b = excavation(MOSA_FORECOURT, x, z);
  const weight = a + b - a * b;
  if (weight <= 0) return bed;
  const outside = Math.max(0, Math.min(1, mallConstructionFootprintDistance(x, z) / 6));
  return bed + (Math.min(bed, MOSA_FORECOURT.floor) - bed) * weight * outside * outside * (3 - 2 * outside);
}

// public/water-depths.js
var LAGOON_SURFACE_Y = 0.155;
var LAGOON_BED_Y = -0.63;
var LEGACY_SEA_DEPTH = LAGOON_SURFACE_Y - LAGOON_BED_Y;

// public/mosasaur-data.js
var MOSA_OLD_RADIUS = 11.65 * Math.sqrt(6);
var MOSA_RELEASED_SEA = Object.freeze({ rx: 105 * Math.sqrt(5), rz: 100 * Math.sqrt(5), radius: 11.65 * Math.sqrt(6) * 5 * Math.sqrt(5) });
var MOSA_WATER_AREA_MULTIPLIER = 2;
var MOSA_FEATURE_SCALE = Math.sqrt(5);
var MOSA_AREA_EXPANSION = 5 * MOSA_WATER_AREA_MULTIPLIER;
var MOSA_HORIZONTAL_EXPANSION = Math.sqrt(MOSA_AREA_EXPANSION);
var MOSA_PREVIOUS_RADIUS = MOSA_OLD_RADIUS * 5;
var housingClearance = Math.abs(WORLD_CENTERS.autumn[1] - HOUSING_CENTER[1]) - HOUSING_RADIUS - MIN_ISLAND_GAP - SHORE_MARGIN * 2;
var MOSA_RADIUS = Math.min(MOSA_RELEASED_SEA.radius + 105 * MOSA_HORIZONTAL_EXPANSION - MOSA_RELEASED_SEA.rx, housingClearance);
var MOSA_SHORE_GATE = { x: 0, z: 103 * MOSA_HORIZONTAL_EXPANSION };
var MOSA_DEPTH = 200;
var MOSA_SEA = {
  id: "lake-autumn",
  x: 0,
  z: 0,
  rx: 105 * MOSA_HORIZONTAL_EXPANSION,
  rz: 100 * MOSA_HORIZONTAL_EXPANSION,
  surfaceY: LAGOON_SURFACE_Y,
  bedY: LAGOON_SURFACE_Y - MOSA_DEPTH
};
var MOSA_OBJECTS = [
  {
    id: "island-mosasaur",
    type: "ride-mosasaur",
    biome: "autumn",
    x: 0,
    z: 0,
    name: "\u041C\u0430\u0440\u0438\u043D \xB7 \u043C\u043E\u0440\u0441\u043A\u043E\u0439 \u0432\u0435\u043B\u0438\u043A\u0430\u043D",
    dismount: [0, 0, 23]
  },
  {
    ...MOSA_SEA,
    type: "swim-lagoon",
    biome: "autumn",
    shoreY: 0.16,
    name: "\u0413\u043B\u0443\u0431\u043E\u043A\u043E\u0435 \u043D\u0435\u0431\u0435\u0441\u043D\u043E\u0435 \u043C\u043E\u0440\u0435"
  }
];
function mosaReservations() {
  return [
    { x: 0, z: 0, rx: 111.5 * MOSA_HORIZONTAL_EXPANSION, rz: 106.5 * MOSA_HORIZONTAL_EXPANSION, w: 223 * MOSA_HORIZONTAL_EXPANSION, d: 213 * MOSA_HORIZONTAL_EXPANSION },
    { x: 0, z: (8 + MOSA_SHORE_GATE.z + 3) / 2, w: 3.4, d: MOSA_SHORE_GATE.z + 3 - 8 },
    ...MOSA_HEADLANDS.map((p) => ({ x: p.x, z: p.z, rx: p.radius + 2, rz: p.radius + 2, w: (p.radius + 2) * 2, d: (p.radius + 2) * 2 }))
  ];
}
var mosaCoastFactor = (a) => 1 + 0.035 * Math.sin(a * 3 + 0.5) + 0.018 * Math.cos(a * 7);
function mosaWaterRadius(x, z) {
  const a = Math.atan2(z / MOSA_SEA.rz, x / MOSA_SEA.rx);
  return Math.hypot(x / MOSA_SEA.rx, z / MOSA_SEA.rz) / mosaCoastFactor(a);
}
var MOSA_HEADLANDS = [0.08, 0.45, 0.86, 1.95, 2.4, 2.85, 3.35, 3.9, 4.45, 4.95, 5.55, 6].map((angle, i) => ({ angle, x: Math.cos(angle) * MOSA_SEA.rx * mosaCoastFactor(angle) * 1.04, z: Math.sin(angle) * MOSA_SEA.rz * mosaCoastFactor(angle) * 1.04, radius: (i % 3 ? 11 + i % 3 * 2 : 17) * MOSA_FEATURE_SCALE, height: i % 3 ? 10 + i % 4 * 3 : 24 + i % 2 * 4 }));
var MOSA_CAVE_LAYOUT = [{ id: "violet-grotto", x: -25, z: -18, radius: 8, depth: 20, color: 9925852 }, { id: "amber-cavern", x: 20, z: 15, radius: 7, depth: 17, color: 15382124 }];
var MOSA_REEF_TERRACES = Array.from({ length: 12 }, (_, i) => {
  const angle = 0.24 + i * Math.PI / 6, q = i % 2 ? 0.82 : 0.67, f = mosaCoastFactor(angle);
  return { id: "reef-terrace-" + i, x: Math.cos(angle) * MOSA_SEA.rx * f * q, z: Math.sin(angle) * MOSA_SEA.rz * f * q, radius: (i % 2 ? 14 : 11.5) * MOSA_FEATURE_SCALE, depth: 7 + i % 4 * 4, angle };
});
function mosaNaturalBedY(x, z) {
  const r = Math.min(1, mosaWaterRadius(x, z));
  const shore = Math.min(1, (1 - r) / 0.06), shelf = shore * shore * (3 - 2 * shore), depth = 0.65 + (MOSA_DEPTH - 0.65) * Math.pow(1 - r, 0.88) * shelf;
  const ridge = (Math.sin(x * 0.075 + Math.sin(z * 0.045) * 1.5) * Math.cos(z * 0.053) + Math.sin((x + z) * 0.09) * 0.3) * Math.min(12, depth * 0.15) * (1 - r);
  return MOSA_SEA.surfaceY - Math.min(MOSA_DEPTH, Math.max(0.65, depth - ridge));
}
function mosaBedY(x, z) {
  const natural = mosaNaturalBedY(x, z);
  let y = natural;
  for (const c of MOSA_CAVE_LAYOUT) {
    const edge = Math.min(c.radius + 0.8 - Math.abs(x - c.x), z - (c.z - c.depth), c.z + 2 - z);
    if (edge <= 0) continue;
    const floor = mosaNaturalBedY(c.x, c.z) + 0.4, fade = Math.min(1, edge / 1.2);
    y = Math.min(y, y + (floor - y) * fade);
  }
  return oceanForecourtBedY(x, z, mallFoundationBedY(x, z, y));
}

// public/capybara-data.js
var CAPYBARA_RADIUS = 11.65 * Math.sqrt(3);
var CAPYBARA_POOLS = [
  {
    id: "lake-summer",
    name: "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0430 \u043B\u0430\u0433\u0443\u043D\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440",
    x: 0,
    z: 5.1,
    rx: 10.5,
    rz: 9.4,
    y: 0
  },
  {
    id: "lake-summer-upper",
    name: "\u0421\u043C\u0430\u0440\u0430\u0433\u0434\u043E\u0432\u0438\u0439 \u0432\u0435\u0440\u0445\u043D\u0456\u0439 \u043A\u0430\u0441\u043A\u0430\u0434",
    x: -1,
    z: -14.2,
    rx: 6,
    rz: 2.2,
    y: 4.2
  },
  {
    id: "lake-summer-jungle",
    name: "\u0414\u0436\u0443\u043D\u0433\u043B\u0435\u0432\u0430 \u043A\u0443\u043F\u0430\u043B\u044C\u043D\u044F",
    x: -14.5,
    z: -4.8,
    rx: 2.7,
    rz: 4.4,
    y: 1.8
  },
  {
    id: "lake-summer-coconut",
    name: "\u041A\u043E\u043A\u043E\u0441\u043E\u0432\u0430 \u0437\u0430\u0432\u043E\u0434\u044C",
    x: 14.4,
    z: -5,
    rx: 2.8,
    rz: 4.5,
    y: 1.2
  }
];
var CAPYBARA_RIDES = [
  {
    id: "ride-capybara-mango",
    name: "\u041C\u0430\u043D\u0433\u043E \xB7 \u0432\u0435\u043B\u0438\u043A\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440\u0430",
    color: 12157770,
    scale: 1.16,
    icon: "\u{1F96D}",
    price: 850,
    requiredLevel: 4,
    buildMinutes: 30,
    footprint: [6, 6],
    description: "\u041F\u0443\u0445\u043A\u0435\u043D\u044C\u043A\u0430 \u0434\u043E\u0431\u0440\u043E\u0434\u0443\u0448\u043D\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440\u0430 \u0441\u043C\u0456\u0448\u043D\u043E \u043F\u0435\u0440\u0435\u0432\u0430\u043B\u044E\u0454\u0442\u044C\u0441\u044F \u0439 \u043A\u0430\u0442\u0430\u0454 \u0427\u0438\u0447\u0456 \u0441\u0435\u0440\u0435\u0434 \u0442\u0440\u043E\u043F\u0456\u0447\u043D\u0438\u0445 \u043A\u0432\u0456\u0442\u0456\u0432."
  },
  {
    id: "ride-capybara-boba",
    name: "\u0411\u043E\u0431\u0430 \xB7 \u043A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043D\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440\u0430",
    color: 11103549,
    scale: 1.04,
    icon: "\u{1F9CB}",
    price: 1e3,
    requiredLevel: 4,
    buildMinutes: 45,
    footprint: [6, 6],
    description: "\u041A\u0440\u0443\u0433\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u0434\u043E\u0441\u043B\u0456\u0434\u043D\u0438\u043A \u0434\u0436\u0443\u043D\u0433\u043B\u0456\u0432: \u043A\u043E\u0440\u043E\u0442\u0435\u043D\u044C\u043A\u0456 \u043B\u0430\u043F\u043A\u0438, \u0441\u043E\u043D\u043D\u0430 \u0443\u0441\u043C\u0456\u0448\u043A\u0430 \u0442\u0430 \u043C'\u044F\u043A\u0430 \u043F\u0440\u043E\u0433\u0443\u043B\u044F\u043D\u043A\u0430 \u0432\u0435\u0440\u0445\u0438."
  },
  {
    id: "ride-capybara-coconut",
    name: "\u041A\u043E\u043A\u043E\u0441 \xB7 \u043A\u0440\u0435\u043C\u043E\u0432\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440\u0430",
    color: 14005891,
    scale: 1.08,
    icon: "\u{1F965}",
    price: 1200,
    requiredLevel: 5,
    buildMinutes: 45,
    footprint: [6, 6],
    description: "\u0421\u0432\u0456\u0442\u043B\u0430 \u0442\u043E\u0432\u0441\u0442\u0435\u043D\u044C\u043A\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440\u0430 \u0437 \u043A\u0432\u0456\u0442\u043A\u043E\u044E \u0437\u0430 \u0432\u0443\u0448\u043A\u043E\u043C. \u041B\u044E\u0431\u0438\u0442\u044C \u043F\u043E\u0432\u0456\u043B\u044C\u043D\u0456 \u043F\u0440\u043E\u0433\u0443\u043B\u044F\u043D\u043A\u0438 \u0439 \u043E\u0431\u0456\u0439\u043C\u0438."
  },
  {
    id: "ride-capybara-float",
    name: "\u0411\u0443\u043B\u043E\u0447\u043A\u0430 \xB7 \u043B\u0430\u0433\u0443\u043D\u043D\u0438\u0439 \u0432\u0435\u043B\u0435\u0442\u0435\u043D\u044C",
    color: 12420939,
    scale: 1.3,
    icon: "\u{1F4A6}",
    price: 1450,
    requiredLevel: 5,
    buildMinutes: 60,
    footprint: [7, 5],
    swimming: true,
    description: "\u0412\u0435\u043B\u0438\u043A\u0430 \u043A\u0443\u043C\u0435\u0434\u043D\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440\u0430 \u043F\u043B\u0430\u0432\u0430\u0454 \u0443 \u0432\u043B\u0430\u0441\u043D\u0456\u0439 \u0431\u043B\u0430\u043A\u0438\u0442\u043D\u0456\u0439 \u043A\u0443\u043F\u0430\u043B\u044C\u043D\u0456, \u0430 \u0427\u0438\u0447\u0456 \u0441\u0438\u0434\u0438\u0442\u044C \u043D\u0430 \u0457\u0457 \u0441\u043F\u0438\u043D\u0446\u0456."
  }
];
var CAPYBARA_OBJECTS = [
  { id: "capybara-mango", type: "ride-capybara-mango", x: 12.4, z: 6 },
  { id: "capybara-boba", type: "ride-capybara-boba", x: -13, z: 7 },
  { id: "capybara-coconut", type: "ride-capybara-coconut", x: 8, z: -13.8 },
  {
    id: "capybara-float",
    type: "ride-capybara-float",
    x: 0,
    z: 5.1,
    dismount: [11.7, 0, 0]
  }
].map((o) => ({ ...o, biome: "summer" }));
function capybaraReservations() {
  return [
    { x: 0, z: -11.3, w: 36, d: 0.5 },
    { x: -11.3, z: -4, w: 0.5, d: 14 },
    { x: 11.3, z: -5.7, w: 0.5, d: 11 },
    ...CAPYBARA_OBJECTS.map((o) => {
      const s = CAPYBARA_RIDES.find((s2) => s2.id === o.type);
      return { x: o.x, z: o.z, w: s.footprint[0], d: s.footprint[1] };
    }),
    ...CAPYBARA_POOLS.map((p) => ({
      ...p,
      rx: p.rx + 0.18,
      rz: p.rz + 0.18,
      w: p.rx * 2 + 0.5,
      d: p.rz * 2 + 0.5
    }))
  ];
}

// public/renewal-data.js
var RENEWED_ISLANDS = {
  winter: {
    name: "\u041A\u0438\u0442\u043E\u0432\u0430\u044F \u043B\u0430\u0433\u0443\u043D\u0430 \u0437\u0432\u0451\u0437\u0434",
    subtitle: "\u041D\u0435\u0431\u0435\u0441\u043D\u044B\u0435 \u043A\u0438\u0442\u044B, \u0436\u0435\u043C\u0447\u0443\u0436\u043D\u044B\u0435 \u0440\u0430\u043A\u0443\u0448\u043A\u0438 \u0438 \u0441\u0438\u044F\u044E\u0449\u0438\u0435 \u0432\u043E\u0434\u043E\u043F\u0430\u0434\u044B",
    icon: "\u{1F40B}",
    radius: 16,
    arrival: [0, 13],
    ground: 10202312,
    leaf: 10402525,
    flower: 15709421,
    roof: 11443686,
    kind: "palm",
    hero: "whale",
    water: [0, -0.5, 8.5, 7.1, 58],
    upper: [-5.2, -10.5, 2.5, 1.4],
    feature: "\u041F\u043E\u043B\u0451\u0442\u044B \u043D\u0430 \u0447\u0435\u0442\u044B\u0440\u0451\u0445 \u043D\u0435\u0431\u0435\u0441\u043D\u044B\u0445 \u043A\u0438\u0442\u0430\u0445, \u043A\u0443\u043F\u0430\u043D\u0438\u0435 \u0438 \u0437\u0432\u0451\u0437\u0434\u043D\u0430\u044F \u0440\u044B\u0431\u0430\u043B\u043A\u0430"
  },
  autumn: {
    name: "\u041D\u0435\u0431\u0435\u0441\u043D\u043E\u0435 \u043C\u043E\u0440\u0435 \u043C\u043E\u0437\u0430\u0437\u0430\u0432\u0440\u0430",
    subtitle: "\u0413\u043B\u0443\u0431\u043E\u043A\u0438\u0439 \u043E\u043A\u0435\u0430\u043D, \u043F\u0430\u0440\u044F\u0449\u0438\u0435 \u0441\u043A\u0430\u043B\u044B \u0438 \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0434\u043E\u0431\u0440\u044B\u0439 \u043C\u043E\u0440\u0441\u043A\u043E\u0439 \u0432\u0435\u043B\u0438\u043A\u0430\u043D",
    icon: "\u{1F995}",
    ground: 11061642,
    leaf: 6203770,
    flower: 16761540,
    roof: 9159100,
    kind: "palm",
    hero: "mosasaur",
    water: [0, 0, 21, 20, 48],
    feature: "\u0413\u043B\u0443\u0431\u043E\u043A\u043E\u0435 \u043F\u043E\u0433\u0440\u0443\u0436\u0435\u043D\u0438\u0435 \u0438 \u0432\u044B\u0441\u043E\u043A\u0438\u0439 \u043F\u0440\u044B\u0436\u043E\u043A \u0432\u0435\u0440\u0445\u043E\u043C \u043D\u0430 \u043C\u043E\u0437\u0430\u0437\u0430\u0432\u0440\u0435 \xB7 \u0443\u0440\u043E\u0432\u0435\u043D\u044C 8"
  },
  ice: {
    name: "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u043B\u043E\u0442\u043E\u0441\u044B",
    subtitle: "\u0413\u0438\u0433\u0430\u043D\u0442\u0441\u043A\u0438\u0435 \u0446\u0432\u0435\u0442\u044B, \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u043B\u044B, \u0431\u0438\u0440\u044E\u0437\u043E\u0432\u0430\u044F \u0432\u043E\u0434\u0430 \u0438 \u0441\u0442\u0440\u0435\u043A\u043E\u0437\u044B",
    icon: "\u{1FAB7}",
    ground: 9618857,
    leaf: 9025709,
    flower: 16102619,
    roof: 10191819,
    kind: "sakura",
    hero: "bloom",
    water: [-4, -3, 4.8, 3.3, 34],
    upper: [-4, -8, 2.7, 1.5],
    river: [-3.5, 7, 1.2, 6.6, 18],
    feature: "\u041F\u0430\u0440\u0443\u0441\u043D\u044B\u0439 \u043B\u043E\u0442\u043E\u0441, \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u044F\u0433\u043E\u0434\u044B \u0438 \u043F\u043E\u043B\u0451\u0442 \u0441\u0442\u0440\u0435\u043A\u043E\u0437\u044B"
  },
  galaxy: {
    name: "\u041B\u0443\u043D\u043D\u044B\u0439 \u0437\u0430\u043B\u0438\u0432 \u043C\u0435\u0434\u0443\u0437",
    subtitle: "\u041B\u0430\u0432\u0430\u043D\u0434\u043E\u0432\u0430\u044F \u0438\u0432\u0430, \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u0435\u0441\u044F \u043C\u0435\u0434\u0443\u0437\u044B \u0438 \u043D\u043E\u0447\u043D\u044B\u0435 \u0432\u043E\u0434\u043E\u043F\u0430\u0434\u044B",
    icon: "\u{1FABC}",
    ground: 6389157,
    leaf: 11115471,
    flower: 13739764,
    roof: 9346777,
    kind: "willow",
    hero: "jelly",
    water: [-4, -3, 4.8, 3.3, 32],
    upper: [-4, -8, 2.7, 1.5],
    river: [-3.5, 7, 1.2, 6.6, 18],
    feature: "\u041F\u043E\u043B\u0451\u0442\u044B \u043D\u0430 \u043C\u0435\u0434\u0443\u0437\u0430\u0445, \u043F\u0435\u0440\u043B\u0430\u043C\u0443\u0442\u0440\u043E\u0432\u044B\u0435 \u0436\u0435\u043C\u0447\u0443\u0436\u0438\u043D\u044B \u0438 \u043D\u043E\u0447\u043D\u0430\u044F \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C"
  },
  volcano: {
    name: "\u0414\u043E\u043B\u0438\u043D\u0430 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0445 \u0434\u0438\u043D\u043E\u0437\u0430\u0432\u0440\u043E\u0432",
    subtitle: "\u041F\u044B\u0448\u043D\u044B\u0435 \u043F\u0430\u043F\u043E\u0440\u043E\u0442\u043D\u0438\u043A\u0438, \u0434\u043E\u0431\u0440\u044B\u0435 \u0434\u0438\u043D\u043E\u0437\u0430\u0432\u0440\u044B \u0438 \u0442\u0451\u043F\u043B\u044B\u0435 \u043B\u0430\u0433\u0443\u043D\u044B",
    icon: "\u{1F995}",
    ground: 10273910,
    leaf: 7451499,
    flower: 16038524,
    roof: 14135920,
    kind: "palm",
    hero: "dinosaur",
    water: [-4, -3, 4.8, 3.3, 36],
    upper: [-4, -8, 2.7, 1.5],
    river: [-3.5, 7, 1.2, 6.6, 18],
    feature: "\u041F\u0440\u043E\u0433\u0443\u043B\u043A\u0430 \u043D\u0430 \u0434\u0438\u043D\u043E\u0437\u0430\u0432\u0440\u0435, \u0442\u0440\u043E\u043F\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u043B\u043E\u0434\u044B \u0438 \u043A\u043E\u043B\u0435\u0441\u043E \u0434\u0436\u0443\u043D\u0433\u043B\u0435\u0439"
  }
};
var ISLAND_RIDES = [
  { id: "island-whale-blue", type: "ride-whale", biome: "winter", x: 11, z: 2 },
  {
    id: "island-whale-aurora",
    type: "ride-whale-aurora",
    biome: "winter",
    x: -11,
    z: -2
  },
  {
    id: "island-whale-pearl",
    type: "ride-whale",
    biome: "winter",
    x: 0,
    z: 11,
    scale: 0.56
  },
  {
    id: "island-whale-dream",
    type: "ride-whale-aurora",
    biome: "winter",
    x: 6,
    z: -10,
    scale: 0.5
  },
  { id: "island-lotus", type: "ride-lotus", biome: "ice", x: 0, z: -10.6 },
  { id: "island-dragonfly", type: "ride-dragonfly", biome: "ice", x: 11, z: 0 },
  {
    id: "island-jelly",
    type: "ride-jellyfish",
    biome: "galaxy",
    x: 0,
    z: -10.6
  },
  { id: "island-moon-wheel", type: "carousel", biome: "galaxy", x: 11, z: 0 },
  {
    id: "island-dinosaur",
    type: "ride-dinosaur",
    biome: "volcano",
    x: 0,
    z: -10.6
  },
  { id: "island-jungle-wheel", type: "ferris", biome: "volcano", x: 11, z: 0 }
];

// public/biome-styles.js
var BIOME_STYLES = {
  "magic-zoo": { ground: 10929787, leaf: 6661964, flower: 16760535, roof: 15250549, kind: "oak", hero: "zoo" },
  "atoll-park": { ground: 10079668, leaf: 7650179, flower: 16103381, roof: 15257496, kind: "palm", hero: "waterpark" },
  "cat-homes": {
    ground: 10993034,
    leaf: 8627566,
    flower: 15907791,
    roof: 7444078,
    kind: "oak",
    hero: "housing"
  },
  jobcity: {
    ground: 12175764,
    leaf: 8563822,
    flower: 15907791,
    roof: 14069875,
    kind: "oak",
    hero: "jobcity"
  },
  aquarium: {
    ground: 13360294,
    leaf: 11061638,
    flower: 15908827,
    roof: 12773882,
    kind: "palm",
    hero: "aquarium"
  },
  aquapark: {
    ground: 9618328,
    leaf: 5552259,
    flower: 16760271,
    roof: 7130589,
    kind: "palm",
    hero: "cloudcastle",
    water: [-6, 5, 8, 5, 52]
  },
  moon: {
    ground: 8166263,
    leaf: 8877749,
    flower: 14004717,
    roof: 9990587,
    kind: "oak",
    hero: "moon",
    water: [5, 4, 1.7, 1.25, 10]
  },
  autumn: {
    ground: 12820844,
    leaf: 14653006,
    flower: 16766094,
    roof: 12091726,
    kind: "maple",
    hero: "pumpkin"
  },
  winter: {
    ground: 15199730,
    leaf: 7710389,
    flower: 12118514,
    roof: 7905205,
    kind: "snow",
    hero: "snow"
  },
  beach: {
    ground: 15784354,
    leaf: 8238175,
    flower: 16302236,
    roof: 5748159,
    kind: "palm",
    hero: "beach",
    water: [-3.8, -3, 5, 3.4, 36]
  },
  water: {
    ground: 10209715,
    leaf: 7388324,
    flower: 16105433,
    roof: 7642801,
    kind: "palm",
    hero: "spa"
  },
  wizard: {
    ground: 8879262,
    leaf: 7892393,
    flower: 12293597,
    roof: 8544688,
    kind: "pine",
    hero: "wizard"
  },
  summer: {
    ground: 9288531,
    leaf: 6666294,
    flower: 16747640,
    roof: 13279583,
    kind: "palm",
    hero: "capybara"
  },
  nature: {
    ground: 7313779,
    leaf: 6458207,
    flower: 14146992,
    roof: 7769200,
    kind: "oak",
    hero: "treehouse"
  },
  sakura: {
    ground: 10993034,
    leaf: 8166237,
    flower: 16109530,
    roof: 7444078,
    kind: "enchanted",
    hero: "chill"
  },
  clouds: {
    ground: 14736617,
    leaf: 12628184,
    flower: 16768954,
    roof: 11903184,
    kind: "oak",
    hero: "cloudcastle"
  },
  desert: {
    ground: 14925704,
    leaf: 10073217,
    flower: 16109726,
    roof: 12224872,
    kind: "palm",
    hero: "oasis",
    water: [-6, -5, 2.2, 1.35, 12]
  },
  stars: {
    ground: 9406640,
    leaf: 10852297,
    flower: 16046240,
    roof: 9205682,
    kind: "oak",
    hero: "observatory"
  },
  volcano: {
    ground: 9729911,
    leaf: 10843266,
    flower: 16760190,
    roof: 10118524,
    kind: "maple",
    hero: "volcano"
  },
  crystal: {
    ground: 11126475,
    leaf: 10339280,
    flower: 14732278,
    roof: 10138836,
    kind: "pine",
    hero: "crystal"
  },
  candy: {
    ground: 14858445,
    leaf: 15247564,
    flower: 16769962,
    roof: 14783163,
    kind: "fruit",
    hero: "candy"
  },
  rainbow: {
    ground: 12113084,
    leaf: 11583953,
    flower: 16760789,
    roof: 12823767,
    kind: "oak",
    hero: "rainbow"
  },
  bamboo: {
    ground: 10203787,
    leaf: 9284712,
    flower: 15785910,
    roof: 8692368,
    kind: "bamboo",
    hero: "bamboo"
  },
  mushrooms: {
    ground: 10588843,
    leaf: 12425409,
    flower: 16040412,
    roof: 11960757,
    kind: "oak",
    hero: "mushrooms"
  },
  galaxy: {
    ground: 10064060,
    leaf: 11378903,
    flower: 15188980,
    roof: 9206201,
    kind: "oak",
    hero: "planet"
  },
  coral: {
    ground: 13160085,
    leaf: 11254979,
    flower: 16101053,
    roof: 13277879,
    kind: "palm",
    hero: "coral",
    water: [-5, -4, 3.8, 2.6, 30]
  },
  lotus: {
    ground: 11061937,
    leaf: 8960160,
    flower: 16503523,
    roof: 10325679,
    kind: "bamboo",
    hero: "tea",
    water: [-5, -4, 3.4, 2.3, 20]
  },
  ice: {
    ground: 14609906,
    leaf: 11654111,
    flower: 12185835,
    roof: 9944529,
    kind: "snow",
    hero: "ice"
  },
  clockwork: {
    ground: 16767688,
    leaf: 16032461,
    flower: 16759516,
    roof: 16358855,
    kind: "sakura",
    hero: "cotton"
  },
  dusk: {
    ground: 10391978,
    leaf: 11179191,
    flower: 14993378,
    roof: 9269405,
    kind: "oak",
    hero: "library"
  }
};
for (const [id, style] of Object.entries(RENEWED_ISLANDS))
  BIOME_STYLES[id] = { ...style };
delete BIOME_STYLES.wizard;
BIOME_STYLES.foodcourt = {
  ground: 11125899,
  leaf: 7515515,
  flower: 16104147,
  roof: 12884653,
  kind: "palm",
  hero: "foodcourt",
  water: [0, 3, 3, 2.6, 12]
};
BIOME_STYLES.bikini = {
  ground: 15324579,
  leaf: 9549972,
  flower: 15378634,
  roof: 10249029,
  kind: "palm",
  hero: "bikini"
};
BIOME_STYLES.homestead = {
  ground: 11257484,
  leaf: 10599812,
  flower: 15909589,
  roof: 12099784,
  kind: "oak",
  hero: "meadow"
};
for (const f of MAGIC_FARMS) BIOME_STYLES[f.id] = { ground: f.ground, leaf: f.foliage, flower: f.accent, roof: f.edge, kind: f.kind === "crystal" ? "crystal" : "oak", hero: "magic-farm", water: magicFarmLayout(f.id).pond };

// public/cat-expansion.js
var TINY_CAT_SIZE = 0.36 / 0.63;
var EXTRA_BREEDS = {
  chartreux: {
    name: "\u0428\u0430\u0440\u0442\u0440\u0435\u0437",
    build: "plush",
    pattern: "solid",
    ears: 0.85,
    fur: "plush"
  },
  manx: {
    name: "\u041C\u044D\u043D\u043A\u0441",
    build: "plush",
    pattern: "tabby",
    ears: 0.93,
    fur: "plush",
    tailLength: 0.12
  },
  toyger: {
    name: "\u0422\u043E\u0439\u0433\u0435\u0440",
    build: "large",
    pattern: "tabby",
    ears: 0.89,
    fur: "sleek",
    squareMuzzle: 0.08
  },
  balinese: {
    name: "\u0411\u0430\u043B\u0438\u043D\u0435\u0437\u0438\u0439\u0441\u043A\u0430\u044F",
    build: "slender",
    pattern: "point",
    ears: 1.13,
    fur: "long",
    tailPlume: 1.4
  },
  oriental: {
    name: "\u041E\u0440\u0438\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u0430\u044F",
    build: "slender",
    pattern: "solid",
    ears: 1.5,
    fur: "sleek",
    faceWidth: 0.88
  },
  laperm: {
    name: "\u041B\u0430\u043F\u0435\u0440\u043C",
    build: "plush",
    pattern: "solid",
    ears: 1.08,
    fur: "curly",
    neckRuff: 1.16
  },
  nebelung: {
    name: "\u041D\u0438\u0431\u0435\u043B\u0443\u043D\u0433",
    build: "large",
    pattern: "solid",
    ears: 1.07,
    fur: "long",
    tailPlume: 1.45,
    neckRuff: 1.18
  },
  himalayan: {
    name: "\u0413\u0438\u043C\u0430\u043B\u0430\u0439\u0441\u043A\u0430\u044F",
    build: "giant",
    pattern: "point",
    ears: 0.72,
    fur: "long",
    neckRuff: 1.3
  },
  burmilla: {
    name: "\u0411\u0443\u0440\u043C\u0438\u043B\u043B\u0430",
    build: "plush",
    pattern: "ticked",
    ears: 0.9,
    fur: "velvet"
  },
  singapura: {
    name: "\u0421\u0438\u043D\u0433\u0430\u043F\u0443\u0440\u0441\u043A\u0430\u044F",
    build: "short",
    pattern: "ticked",
    ears: 1.22,
    fur: "sleek"
  },
  bambino: {
    name: "\u0411\u0430\u043C\u0431\u0438\u043D\u043E",
    build: "short",
    pattern: "solid",
    ears: 1.4,
    fur: "bare"
  },
  napoleon: {
    name: "\u041C\u0435\u043D\u0443\u044D\u0442",
    build: "giant",
    pattern: "solid",
    ears: 0.73,
    fur: "long",
    tailPlume: 1.3
  },
  mau: {
    name: "\u0415\u0433\u0438\u043F\u0435\u0442\u0441\u043A\u0430\u044F \u043C\u0430\u0443",
    build: "balanced",
    pattern: "rosettes",
    ears: 1.14,
    fur: "velvet"
  },
  ocicat: {
    name: "\u041E\u0446\u0438\u043A\u0435\u0442",
    build: "large",
    pattern: "rosettes",
    ears: 1.04,
    fur: "sleek"
  },
  havana: {
    name: "\u0413\u0430\u0432\u0430\u043D\u0430",
    build: "balanced",
    pattern: "solid",
    ears: 1.14,
    fur: "sleek"
  },
  toybob: {
    name: "\u0422\u043E\u0439-\u0431\u043E\u0431",
    build: "short",
    pattern: "point",
    ears: 0.92,
    fur: "plush",
    tailLength: 0.22
  }
};
var tiny = (id, name, breed, color, eyes, price, level, text2, extra = {}) => ({
  id: "adopt-" + id,
  name,
  breed,
  color,
  eyes,
  price,
  requiredLevel: level,
  personality: text2,
  biome: "moon",
  adoption: true,
  size: TINY_CAT_SIZE,
  collection: "tiny",
  ...extra
});
var NEW_TINY_CATS = [
  tiny(
    "crumb",
    "\u041A\u0440\u043E\u0448\u0438\u043A",
    "munchkin",
    13213812,
    12109175,
    320,
    2,
    "\u0422\u043E\u0442 \u0441\u0430\u043C\u044B\u0439 \u043A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0439 \u043C\u0430\u043D\u0447\u043A\u0438\u043D, \u043A\u0430\u043A \u0443 \u0445\u043E\u0442-\u0434\u043E\u0433\u043E\u0432: \u0448\u0443\u0441\u0442\u0440\u044B\u0435 \u043B\u0430\u043F\u043A\u0438 \u0438 \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u043D\u044B\u0439 \u043D\u043E\u0441\u0438\u043A"
  ),
  tiny(
    "truffle",
    "\u0422\u0440\u044E\u0444\u0435\u043B\u044C\u043A\u0430",
    "british",
    10127226,
    14268014,
    460,
    2,
    "\u041A\u0440\u043E\u0445\u043E\u0442\u043D\u0430\u044F \u0442\u043E\u043B\u0441\u0442\u0430\u044F \u0448\u043E\u043A\u043E\u043B\u0430\u0434\u043D\u0430\u044F \u0431\u0443\u043B\u043E\u0447\u043A\u0430",
    { build: "giant" }
  ),
  tiny(
    "dumpling",
    "\u041F\u0435\u043B\u044C\u043C\u0435\u0448\u0435\u043A",
    "exotic",
    15062463,
    9419434,
    620,
    3,
    "\u041A\u0440\u0443\u0433\u043B\u0435\u0435 \u043F\u043E\u0434\u0443\u0448\u043A\u0438, \u0430 \u0440\u043E\u0441\u0442\u043E\u043C \u0441 \u043A\u043E\u0442\u0451\u043D\u043A\u0430: \u0432\u0430\u0436\u043D\u043E \u043F\u0435\u0440\u0435\u0432\u0430\u043B\u0438\u0432\u0430\u0435\u0442\u0441\u044F",
    { build: "colossal" }
  ),
  tiny(
    "jellybean",
    "\u041C\u0430\u0440\u043C\u0435\u043B\u0430\u0434\u043A\u0430",
    "scottish",
    14002849,
    10864765,
    520,
    3,
    "\u0412\u0438\u0441\u043B\u043E\u0443\u0445\u0430\u044F \u043A\u0440\u043E\u0448\u043A\u0430 \u0441 \u043F\u0443\u0445\u043B\u044B\u043C\u0438 \u0449\u0451\u0447\u043A\u0430\u043C\u0438",
    { build: "giant" }
  ),
  tiny(
    "waffle",
    "\u0412\u0430\u0444\u0435\u043B\u044C\u043A\u0430",
    "selkirk",
    13743246,
    13227662,
    700,
    3,
    "\u041A\u0443\u0434\u0440\u044F\u0432\u044B\u0439 \u043A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0439 \u043F\u043E\u043D\u0447\u0438\u043A \u043D\u0430 \u043A\u043E\u0440\u043E\u0442\u043A\u0438\u0445 \u043B\u0430\u043F\u043A\u0430\u0445",
    { build: "colossal" }
  ),
  tiny(
    "creampuff",
    "\u041F\u0440\u043E\u0444\u0438\u0442\u0440\u043E\u043B\u044C",
    "ragamuffin",
    15918541,
    8699610,
    840,
    4,
    "\u041E\u0447\u0435\u043D\u044C \u0442\u043E\u043B\u0441\u0442\u043E\u0435 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u043E\u0431\u043B\u0430\u0447\u043A\u043E \u0441 \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u043C \u0445\u0432\u043E\u0441\u0442\u043E\u043C",
    { build: "colossal" }
  ),
  tiny(
    "peachbun",
    "\u041F\u0435\u0440\u0441\u0438\u043A\u043E\u0432\u0430\u044F \u0411\u0443\u043B\u043E\u0447\u043A\u0430",
    "napoleon",
    14987926,
    11128206,
    920,
    4,
    "\u041F\u0443\u0437\u0430\u0442\u044B\u0439 \u043C\u0435\u043D\u0443\u044D\u0442, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0441\u043C\u0435\u0448\u043D\u043E \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u0441\u044F \u0437\u0430 \u0434\u0440\u0443\u0437\u044C\u044F\u043C\u0438",
    { build: "giant" }
  ),
  tiny(
    "silverbean",
    "\u0421\u0435\u0440\u0435\u0431\u0440\u044F\u043D\u0430\u044F \u0424\u0430\u0441\u043E\u043B\u044C\u043A\u0430",
    "chartreux",
    9543853,
    15185501,
    680,
    3,
    "\u0421\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u044B\u0439 \u043F\u0443\u0445\u043B\u044F\u0448 \u0441 \u0437\u043E\u043B\u043E\u0442\u044B\u043C\u0438 \u0433\u043B\u0430\u0437\u0430\u043C\u0438",
    { build: "giant" }
  ),
  tiny(
    "pebble",
    "\u0413\u043E\u043B\u044B\u0448\u0435\u043A",
    "sphynx",
    13808821,
    9095096,
    980,
    4,
    "\u041A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0439 \u043B\u044B\u0441\u044B\u0439 \u0441\u0444\u0438\u043D\u043A\u0441: \u0431\u043E\u043B\u044C\u0448\u0438\u0435 \u0443\u0448\u043A\u0438 \u0438 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u0435 \u0441\u043A\u043B\u0430\u0434\u043E\u0447\u043A\u0438 \u043A\u043E\u0436\u0438"
  ),
  tiny(
    "pinkie",
    "\u041F\u0443\u043F\u0441\u0438\u043A",
    "bambino",
    14925502,
    10144662,
    1180,
    5,
    "\u041B\u044B\u0441\u044B\u0439 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u043B\u0430\u043F\u044B\u0439 \u043C\u0430\u043B\u044B\u0448 \u0441 \u0442\u0451\u043F\u043B\u044B\u043C\u0438 \u0440\u043E\u0437\u043E\u0432\u044B\u043C\u0438 \u0441\u043A\u043B\u0430\u0434\u043E\u0447\u043A\u0430\u043C\u0438",
    { build: "plush" }
  ),
  tiny(
    "lynxlet",
    "\u0420\u044B\u0441\u0451\u043D\u043E\u043A",
    "maine",
    10330004,
    12045699,
    1060,
    4,
    "\u041C\u0438\u043D\u0438-\u043C\u0435\u0439\u043D-\u043A\u0443\u043D: \u043A\u0438\u0441\u0442\u043E\u0447\u043A\u0438 \u043D\u0430 \u0443\u0448\u043A\u0430\u0445 \u0438 \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u0439 \u0434\u043B\u044F \u043C\u0430\u043B\u044B\u0448\u0430 \u0432\u043E\u0440\u043E\u0442\u043D\u0438\u0447\u043E\u043A"
  ),
  tiny(
    "pipsqueak",
    "\u041F\u0438\u0441\u043A\u043B\u044F",
    "oriental",
    11971232,
    9487007,
    780,
    3,
    "\u0423\u0448\u043A\u0438 \u043F\u043E\u0447\u0442\u0438 \u0441 \u0441\u0430\u043C\u043E\u0433\u043E \u043A\u043E\u0442\u0451\u043D\u043A\u0430, \u0442\u043E\u043D\u043A\u0438\u0439 \u0445\u0432\u043E\u0441\u0442 \u0438 \u043E\u0437\u043E\u0440\u043D\u043E\u0439 \u0432\u0437\u0433\u043B\u044F\u0434"
  ),
  tiny(
    "pompette",
    "\u041F\u043E\u043C\u043F\u043E\u0448\u043A\u0430",
    "manx",
    12232078,
    13351801,
    860,
    4,
    "\u041E\u0447\u0435\u043D\u044C \u043A\u0440\u0443\u0433\u043B\u044B\u0439 \u043C\u0430\u043B\u044B\u0448 \u043F\u043E\u0447\u0442\u0438 \u0431\u0435\u0437 \u0445\u0432\u043E\u0441\u0442\u0438\u043A\u0430",
    { build: "giant" }
  ),
  tiny(
    "tigerpea",
    "\u0422\u0438\u0433\u0440\u0451\u043D\u043E\u043A",
    "toyger",
    13866081,
    10996363,
    1120,
    5,
    "\u041C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u043F\u043E\u043B\u043E\u0441\u0430\u0442\u044B\u0439 \u0442\u0438\u0433\u0440 \u0441 \u043A\u043E\u0448\u0430\u0447\u044C\u0438\u043C\u0438 \u0449\u0451\u0447\u043A\u0430\u043C\u0438"
  ),
  tiny(
    "snowflakelet",
    "\u0421\u043D\u0435\u0436\u0438\u043D\u043A\u0430",
    "balinese",
    15656150,
    9095661,
    1220,
    5,
    "\u041C\u0438\u043D\u0438\u0430\u0442\u044E\u0440\u043D\u0430\u044F \u043C\u0430\u0441\u043A\u0430 \u0438 \u0448\u0451\u043B\u043A\u043E\u0432\u044B\u0439 \u0445\u0432\u043E\u0441\u0442-\u043F\u0451\u0440\u044B\u0448\u043A\u043E"
  ),
  tiny(
    "poppyseed",
    "\u041C\u0430\u043A\u043E\u0432\u043A\u0430",
    "toybob",
    13417385,
    8895453,
    760,
    3,
    "\u041A\u043E\u0440\u043E\u0442\u043A\u0438\u0439 \u0445\u0432\u043E\u0441\u0442\u0438\u043A, \u043A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0435 \u043B\u0430\u043F\u043A\u0438 \u0438 \u0433\u043E\u043B\u0443\u0431\u044B\u0435 \u0433\u043B\u0430\u0437\u043A\u0438"
  ),
  tiny(
    "cinnamonroll",
    "\u0423\u043B\u0438\u0442\u043E\u0447\u043A\u0430",
    "laperm",
    12819328,
    11457938,
    1240,
    5,
    "\u041F\u0443\u0445\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u043A\u043B\u0443\u0431\u043E\u0447\u0435\u043A \u0437\u0430\u0432\u0438\u0442\u0443\u0448\u0435\u043A",
    { build: "giant" }
  ),
  tiny(
    "cookiechip",
    "\u0428\u043E\u043A\u043E\u043B\u0430\u0434\u043D\u0430\u044F \u041A\u0440\u043E\u0448\u043A\u0430",
    "havana",
    8413778,
    9226136,
    880,
    4,
    "\u0428\u043E\u043A\u043E\u043B\u0430\u0434\u043D\u044B\u0439 \u0431\u0430\u0440\u0445\u0430\u0442 \u0438 \u044F\u0440\u043A\u0438\u0435 \u0437\u0435\u043B\u0451\u043D\u044B\u0435 \u0433\u043B\u0430\u0437\u043A\u0438"
  ),
  tiny(
    "polkadot",
    "\u0413\u043E\u0440\u043E\u0448\u0438\u043D\u043A\u0430",
    "mau",
    11977414,
    11196062,
    1360,
    6,
    "\u0421\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u0430\u044F \u043A\u0440\u0430\u043F\u0447\u0430\u0442\u0430\u044F \u043C\u0430\u043B\u044B\u0448\u043A\u0430, \u0432\u0441\u0435\u0433\u0434\u0430 \u0433\u043E\u0442\u043E\u0432\u0430 \u0438\u0433\u0440\u0430\u0442\u044C"
  ),
  tiny(
    "lilacbun",
    "\u0421\u0438\u0440\u0435\u043D\u0435\u0432\u0430\u044F \u041F\u044B\u0448\u043A\u0430",
    "persian",
    12235204,
    11786175,
    1440,
    6,
    "\u0421\u043C\u0435\u0448\u043D\u043E\u0439 \u043A\u0440\u0443\u0433\u043B\u044B\u0439 \u043F\u0435\u0440\u0441\u0438\u0434\u0441\u043A\u0438\u0439 \u043C\u0430\u043B\u044B\u0448 \u0441 \u043A\u0440\u043E\u0445\u043E\u0442\u043D\u044B\u043C\u0438 \u0443\u0448\u043A\u0430\u043C\u0438",
    { build: "colossal" }
  )
];
var adultSpecs = [
  [
    "sherbet",
    "\u0429\u0435\u0440\u0431\u0435\u0442",
    "chartreux",
    9280682,
    14988383,
    "\u041F\u043B\u043E\u0442\u043D\u0430\u044F \u0441\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u0430\u044F \u0448\u0443\u0431\u043A\u0430 \u0438 \u043C\u0435\u0434\u043E\u0432\u044B\u0439 \u0432\u0437\u0433\u043B\u044F\u0434",
    { build: "giant", size: 1.15 }
  ],
  [
    "roundel",
    "\u041A\u0440\u0443\u0433\u043B\u044F\u0448",
    "manx",
    11047806,
    13030036,
    "\u0411\u043E\u043B\u044C\u0448\u043E\u0439 \u043A\u0440\u0443\u0433\u043B\u044B\u0439 \u0434\u043E\u0431\u0440\u044F\u043A \u0441 \u0445\u0432\u043E\u0441\u0442\u043E\u043C-\u043F\u0443\u0433\u043E\u0432\u043A\u043E\u0439",
    { build: "colossal", size: 1.3 }
  ],
  [
    "tigerking",
    "\u0422\u0438\u0433\u0440\u0443\u0448\u0430",
    "toyger",
    13998949,
    10864757,
    "\u041F\u043E\u043B\u043E\u0441\u0430\u0442\u044B\u0439 \u0432\u0435\u043B\u0438\u043A\u0430\u043D \u0441 \u043C\u043E\u0449\u043D\u044B\u043C\u0438 \u043B\u0430\u043F\u0430\u043C\u0438 \u0438 \u0434\u043E\u0431\u0440\u043E\u0439 \u043C\u043E\u0440\u0434\u043E\u0447\u043A\u043E\u0439",
    { size: 1.35 }
  ],
  [
    "silversail",
    "\u0428\u0451\u043B\u043A\u043E\u0432\u044B\u0439 \u041F\u0430\u0440\u0443\u0441",
    "balinese",
    15063234,
    8636387,
    "\u0421\u0442\u0440\u043E\u0439\u043D\u0430\u044F \u043A\u043E\u0448\u0435\u0447\u043A\u0430 \u0441 \u0442\u0451\u043C\u043D\u043E\u0439 \u043C\u0430\u0441\u043A\u043E\u0439 \u0438 \u0445\u0432\u043E\u0441\u0442\u043E\u043C \u043A\u0430\u043A \u043E\u0431\u043B\u0430\u0447\u043A\u043E",
    {}
  ],
  [
    "radar",
    "\u041B\u043E\u043A\u0430\u0442\u043E\u0440",
    "oriental",
    11183009,
    11196829,
    "\u041E\u0433\u0440\u043E\u043C\u043D\u044B\u0435 \u0441\u043C\u0435\u0448\u043D\u044B\u0435 \u0443\u0448\u0438 \u0438 \u0438\u0437\u044F\u0449\u043D\u0430\u044F \u043F\u043E\u0445\u043E\u0434\u043A\u0430",
    {}
  ],
  [
    "meringue",
    "\u0411\u0435\u0437\u0435\u0448\u043A\u0430",
    "laperm",
    15326405,
    11652254,
    "\u0411\u043E\u043B\u044C\u0448\u0430\u044F \u043A\u0443\u0434\u0440\u044F\u0432\u0430\u044F \u043F\u043B\u044E\u0448\u043A\u0430 \u0441 \u043C\u044F\u0433\u043A\u0438\u043C\u0438 \u0449\u0451\u0447\u043A\u0430\u043C\u0438",
    { build: "colossal", size: 1.45 }
  ],
  [
    "silverforest",
    "\u0421\u0435\u0440\u0435\u0431\u0440\u044F\u043D\u044B\u0439 \u041B\u0435\u0441",
    "nebelung",
    9610165,
    11063182,
    "\u0414\u043B\u0438\u043D\u043D\u0430\u044F \u0441\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u0430\u044F \u0448\u0435\u0440\u0441\u0442\u044C, \u0432\u043E\u0440\u043E\u0442\u043D\u0438\u043A \u0438 \u0445\u0432\u043E\u0441\u0442-\u043F\u0435\u0440\u043E",
    { size: 1.28 }
  ],
  [
    "mountainbun",
    "\u0413\u043E\u0440\u0430 \u0411\u0443\u043B\u043E\u0447\u0435\u043A",
    "himalayan",
    15259331,
    8961516,
    "\u041E\u0433\u0440\u043E\u043C\u043D\u0430\u044F \u043F\u0443\u0445\u043B\u0430\u044F \u0433\u0438\u043C\u0430\u043B\u0430\u0439\u0441\u043A\u0430\u044F \u043A\u043E\u0448\u043A\u0430 \u0441 \u0433\u043E\u043B\u0443\u0431\u044B\u043C\u0438 \u0433\u043B\u0430\u0437\u0430\u043C\u0438",
    { build: "colossal", size: 1.75 }
  ],
  [
    "silvercream",
    "\u0421\u043B\u0438\u0432\u043E\u0447\u043D\u043E\u0435 \u0421\u0435\u0440\u0435\u0431\u0440\u043E",
    "burmilla",
    13751243,
    11062180,
    "\u0421\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u0430\u044F \u043A\u0440\u0430\u043F\u0447\u0430\u0442\u0430\u044F \u0448\u0443\u0431\u043A\u0430 \u0438 \u043D\u0435\u0436\u043D\u044B\u0435 \u0433\u043B\u0430\u0437\u043A\u0438",
    {}
  ],
  [
    "tinyroyal",
    "\u041F\u0440\u0438\u043D\u0446\u0435\u0441\u0441\u0430 \u041F\u0435\u0441\u043A\u0430",
    "singapura",
    13152912,
    11849357,
    "\u0411\u043E\u043B\u044C\u0448\u0438\u0435 \u0433\u043B\u0430\u0437\u0430, \u0431\u043E\u043B\u044C\u0448\u0438\u0435 \u0443\u0448\u043A\u0438, \u043A\u043E\u0440\u043E\u0442\u043A\u0438\u0435 \u043F\u0440\u0443\u0436\u0438\u043D\u0438\u0441\u0442\u044B\u0435 \u043B\u0430\u043F\u043A\u0438",
    {}
  ],
  [
    "wrinkle",
    "\u0421\u043A\u043B\u0430\u0434\u043E\u0447\u043A\u0430",
    "bambino",
    13349805,
    10342578,
    "\u0423\u043F\u0438\u0442\u0430\u043D\u043D\u044B\u0439 \u043B\u044B\u0441\u044B\u0439 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u043B\u0430\u043F\u0438\u043A \u0441 \u043C\u044F\u0433\u043A\u0438\u043C\u0438 \u043C\u043E\u0440\u0449\u0438\u043D\u043A\u0430\u043C\u0438",
    { build: "giant" }
  ],
  [
    "kingdumpling",
    "\u0426\u0430\u0440\u044C \u041F\u0435\u043B\u044C\u043C\u0435\u043D\u044C",
    "napoleon",
    14137505,
    12960142,
    "\u041E\u0447\u0435\u043D\u044C \u0448\u0438\u0440\u043E\u043A\u0430\u044F \u043F\u0443\u0448\u0438\u0441\u0442\u0430\u044F \u0431\u0443\u043B\u043E\u0447\u043A\u0430, \u043A\u043E\u0442\u043E\u0440\u0430\u044F \u0441\u043C\u0435\u0448\u043D\u043E \u0442\u043E\u043F\u0430\u0435\u0442",
    { build: "colossal", size: 1.85 }
  ],
  [
    "moonspots",
    "\u041B\u0443\u043D\u043D\u044B\u0435 \u041F\u044F\u0442\u043D\u044B\u0448\u043A\u0438",
    "mau",
    11056056,
    10932629,
    "\u0421\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u044B\u0435 \u043F\u044F\u0442\u043D\u044B\u0448\u043A\u0438 \u0438 \u0433\u0440\u0430\u0446\u0438\u043E\u0437\u043D\u0430\u044F \u043F\u043E\u0445\u043E\u0434\u043A\u0430",
    { size: 1.1 }
  ],
  [
    "caramelspots",
    "\u041A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043D\u044B\u0439 \u041B\u0435\u043E\u043F\u0430\u0440\u0434",
    "ocicat",
    12952960,
    10734495,
    "\u0412\u044B\u0441\u043E\u043A\u0438\u0439 \u043F\u044F\u0442\u043D\u0438\u0441\u0442\u044B\u0439 \u043A\u0440\u0430\u0441\u0430\u0432\u0435\u0446 \u0441 \u0434\u043E\u0431\u0440\u044B\u043C\u0438 \u0431\u043E\u043B\u044C\u0448\u0438\u043C\u0438 \u0433\u043B\u0430\u0437\u0430\u043C\u0438",
    { size: 1.3 }
  ],
  [
    "cocoa",
    "\u041A\u0430\u043A\u0430\u043E",
    "havana",
    7954257,
    9228962,
    "\u0422\u0451\u043F\u043B\u044B\u0439 \u0448\u043E\u043A\u043E\u043B\u0430\u0434, \u0434\u043B\u0438\u043D\u043D\u044B\u0435 \u043B\u0430\u043F\u043A\u0438 \u0438 \u0431\u0430\u0440\u0445\u0430\u0442\u043D\u0430\u044F \u0448\u0443\u0431\u043A\u0430",
    {}
  ],
  [
    "shortcake",
    "\u041A\u043E\u0440\u0436\u0438\u043A",
    "toybob",
    14338486,
    9225959,
    "\u041A\u0440\u0443\u0433\u043B\u044B\u0439 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0445\u0432\u043E\u0441\u0442\u044B\u0439 \u043A\u043E\u0442\u0438\u043A \u0441 \u0442\u0451\u043C\u043D\u044B\u043C\u0438 \u043D\u043E\u0441\u043E\u0447\u043A\u0430\u043C\u0438",
    { build: "giant", size: 1.15 }
  ]
];
var NEW_ADULT_CATS = adultSpecs.map(
  ([id, name, breed, color, eyes, personality, extra], i) => ({
    id: "adopt-" + id,
    name,
    breed,
    color,
    eyes,
    personality,
    ...extra,
    price: 1200 + i * 220,
    requiredLevel: 4 + Math.floor(i / 3),
    biome: "moon",
    adoption: true,
    collection: "new-breeds"
  })
);
var MAGIC_FAMILIES = [
  {
    id: "moon",
    name: "\u041B\u0443\u043D\u043D\u0430\u044F \u043F\u043B\u044E\u0448\u0435\u0432\u0430\u044F",
    build: "plush",
    pattern: "solid",
    fur: "long",
    ears: 0.83,
    tailPlume: 1.35,
    color: 12961251,
    glow: 16770993,
    eyes: 10999017,
    names: ["\u041B\u0443\u043D\u043D\u0430\u044F \u041F\u043B\u044E\u0448\u043A\u0430", "\u041B\u0443\u043D\u043D\u0430\u044F \u041A\u0440\u043E\u0448\u043A\u0430"],
    text: "\u0417\u043E\u043B\u043E\u0442\u043E\u0439 \u043F\u043E\u043B\u0443\u043C\u0435\u0441\u044F\u0446 \u0438 \u0437\u0432\u0451\u0437\u0434\u043E\u0447\u043A\u0438 \u043D\u0430\u0434 \u043C\u044F\u0433\u043A\u043E\u0439 \u043B\u0443\u043D\u043D\u043E\u0439 \u0448\u0443\u0431\u043A\u043E\u0439"
  },
  {
    id: "fairy",
    name: "\u0426\u0432\u0435\u0442\u043E\u0447\u043D\u0430\u044F \u0444\u0435\u044F",
    build: "plush",
    pattern: "solid",
    fur: "plush",
    ears: 0.86,
    color: 15187918,
    glow: 16768939,
    eyes: 10410932,
    names: ["\u0424\u0435\u044F \u041F\u0438\u043E\u043D\u043E\u0432", "\u0424\u0435\u0435\u0447\u043A\u0430"],
    text: "\u041D\u0435\u0436\u043D\u044B\u0435 \u043B\u0435\u043F\u0435\u0441\u0442\u043A\u043E\u0432\u044B\u0435 \u043A\u0440\u044B\u043B\u044B\u0448\u043A\u0438 \u0438 \u0432\u0435\u043D\u043E\u0447\u0435\u043A \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u0445\u0441\u044F \u0446\u0432\u0435\u0442\u043E\u0432"
  },
  {
    id: "dragon",
    name: "\u0414\u0440\u0430\u043A\u043E\u043D\u0438\u0439 \u043A\u043E\u0442\u0438\u043A",
    build: "giant",
    pattern: "solid",
    fur: "velvet",
    ears: 0.9,
    color: 11587283,
    glow: 12514007,
    eyes: 14530017,
    names: ["\u0414\u0440\u0430\u043A\u043E\u043D\u0447\u0438\u043A \u041F\u043B\u044E\u0445", "\u0414\u0440\u0430\u043A\u043E\u0448\u0438\u043A"],
    text: "\u041F\u0443\u0445\u043B\u044B\u0439 \u0434\u043E\u0431\u0440\u044B\u0439 \u0434\u0440\u0430\u043A\u043E\u043D\u0447\u0438\u043A: \u043A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0435 \u0440\u043E\u0436\u043A\u0438 \u0438 \u043C\u044F\u0433\u043A\u0438\u0435 \u043F\u0435\u0440\u0435\u043F\u043E\u043D\u0447\u0430\u0442\u044B\u0435 \u043A\u0440\u044B\u043B\u044C\u044F"
  },
  {
    id: "aurora",
    name: "\u041A\u043E\u0442\u0438\u043A \u0441\u0435\u0432\u0435\u0440\u043D\u043E\u0433\u043E \u0441\u0438\u044F\u043D\u0438\u044F",
    build: "large",
    pattern: "cheshire",
    fur: "long",
    ears: 1.1,
    neckRuff: 1.2,
    color: 12169436,
    glow: 10479839,
    eyes: 9953737,
    names: ["\u041F\u043E\u043B\u044F\u0440\u043D\u043E\u0435 \u0421\u0438\u044F\u043D\u0438\u0435", "\u0410\u0432\u0440\u043E\u0440\u0438\u043A"],
    text: "\u041C\u044F\u0442\u043D\u043E-\u0441\u0438\u0440\u0435\u043D\u0435\u0432\u043E\u0435 \u0441\u0438\u044F\u043D\u0438\u0435, \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u0440\u043E\u043D\u0430 \u0438 \u0434\u043B\u0438\u043D\u043D\u044B\u0439 \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u0439 \u0445\u0432\u043E\u0441\u0442"
  },
  {
    id: "cloud",
    name: "\u041E\u0431\u043B\u0430\u0447\u043D\u044B\u0439 \u043F\u0443\u0445\u043B\u044F\u0448",
    build: "colossal",
    pattern: "solid",
    fur: "long",
    ears: 0.72,
    color: 15655915,
    glow: 14084351,
    eyes: 10733805,
    names: ["\u041E\u0431\u043B\u0430\u043A\u043E \u041E\u0431\u043D\u0438\u043C\u0430\u0448\u0435\u043A", "\u041F\u0443\u0445-\u041E\u0431\u043B\u0430\u0447\u043A\u043E"],
    text: "\u041F\u0443\u0437\u0430\u0442\u043E\u0435 \u043C\u044F\u0433\u043A\u043E\u0435 \u043E\u0431\u043B\u0430\u043A\u043E \u0441 \u043F\u0435\u0440\u043B\u0430\u043C\u0443\u0442\u0440\u043E\u0432\u044B\u043C\u0438 \u043A\u0440\u044B\u043B\u044B\u0448\u043A\u0430\u043C\u0438"
  },
  {
    id: "lotus",
    name: "\u041B\u043E\u0442\u043E\u0441\u043E\u0432\u044B\u0439 \u043A\u043E\u0442\u0438\u043A",
    build: "plush",
    pattern: "point",
    fur: "velvet",
    ears: 0.9,
    color: 15390687,
    glow: 16764133,
    eyes: 11001797,
    names: ["\u041A\u043E\u0440\u043E\u043B\u0435\u0432\u0430 \u041B\u043E\u0442\u043E\u0441\u043E\u0432", "\u0411\u0443\u0442\u043E\u043D\u0447\u0438\u043A"],
    text: "\u0411\u043E\u043B\u044C\u0448\u043E\u0439 \u0440\u043E\u0437\u043E\u0432\u044B\u0439 \u043B\u043E\u0442\u043E\u0441 \u043D\u0430 \u043C\u0430\u043A\u0443\u0448\u043A\u0435 \u0438 \u0446\u0432\u0435\u0442\u043E\u0447\u043D\u044B\u0439 \u0432\u043E\u0440\u043E\u0442\u043D\u0438\u0447\u043E\u043A"
  },
  {
    id: "coral",
    name: "\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u044B\u0439 \u043C\u043E\u0440\u0441\u043A\u043E\u0439 \u043A\u043E\u0442\u0438\u043A",
    build: "plush",
    pattern: "solid",
    fur: "sleek",
    ears: 1.05,
    color: 12639457,
    glow: 15783664,
    eyes: 9685483,
    names: ["\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u0430\u044F \u0412\u043E\u043B\u043D\u0430", "\u0420\u0430\u043A\u0443\u0448\u0435\u0447\u043A\u0430"],
    text: "\u0420\u0430\u043A\u0443\u0448\u043A\u0430-\u043A\u043E\u0440\u043E\u043D\u0430, \u0436\u0435\u043C\u0447\u0443\u0436\u0438\u043D\u043A\u0438 \u0438 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0435 \u043F\u043B\u0430\u0432\u043D\u0438\u0447\u043A\u0438 \u0437\u0430 \u0441\u043F\u0438\u043D\u043E\u0439"
  },
  {
    id: "comet",
    name: "\u0417\u0432\u0451\u0437\u0434\u043D\u044B\u0439 \u043A\u043E\u0442\u0438\u043A",
    build: "slender",
    pattern: "cheshire",
    fur: "velvet",
    ears: 1.08,
    color: 12035538,
    glow: 16768933,
    eyes: 13232049,
    names: ["\u041C\u0443\u0440-\u041A\u043E\u043C\u0435\u0442\u0430", "\u0418\u0441\u043A\u043E\u0440\u043A\u0430"],
    text: "\u0417\u0432\u0451\u0437\u0434\u043D\u0430\u044F \u043A\u043E\u0440\u043E\u043D\u0430 \u0438 \u0441\u043E\u0437\u0432\u0435\u0437\u0434\u0438\u0435, \u043A\u043E\u0442\u043E\u0440\u043E\u0435 \u043A\u0430\u0447\u0430\u0435\u0442\u0441\u044F \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u0445\u0432\u043E\u0441\u0442\u0438\u043A\u043E\u043C"
  },
  {
    id: "frost",
    name: "\u0421\u043D\u0435\u0436\u043D\u044B\u0439 \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u0442\u0438\u043A",
    build: "large",
    pattern: "solid",
    fur: "long",
    ears: 1.08,
    earTufts: 0.1,
    neckRuff: 1.15,
    color: 14018798,
    glow: 12905983,
    eyes: 10864626,
    names: ["\u041B\u0435\u0434\u044F\u043D\u043E\u0435 \u0421\u0443\u0444\u043B\u0435", "\u0418\u043D\u0435\u0439\u0447\u0438\u043A"],
    text: "\u041F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u043E-\u0433\u043E\u043B\u0443\u0431\u0430\u044F \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u0440\u043E\u043D\u0430 \u0438 \u0441\u043D\u0435\u0436\u0438\u043D\u043A\u0430 \u043D\u0430 \u0441\u043F\u0438\u043D\u043A\u0435"
  },
  {
    id: "honey",
    name: "\u041C\u0435\u0434\u043E\u0432\u0430\u044F \u0444\u0435\u044F",
    build: "giant",
    pattern: "tabby",
    fur: "plush",
    ears: 0.8,
    color: 14925959,
    glow: 16770715,
    eyes: 12704406,
    names: ["\u041C\u0435\u0434\u043E\u0432\u044B\u0439 \u041F\u043E\u043D\u0447\u0438\u043A", "\u041C\u0435\u0434\u043E\u0432\u0430\u044F \u041A\u0430\u043F\u0435\u043B\u044C\u043A\u0430"],
    text: "\u041F\u0443\u0445\u043B\u044B\u0439 \u043F\u043E\u043B\u043E\u0441\u0430\u0442\u044B\u0439 \u043C\u0430\u043B\u044B\u0448-\u043F\u0447\u0451\u043B\u043A\u0430 \u0441 \u044F\u043D\u0442\u0430\u0440\u043D\u044B\u043C\u0438 \u043A\u0440\u044B\u043B\u044B\u0448\u043A\u0430\u043C\u0438 \u0438 \u0443\u0441\u0438\u043A\u0430\u043C\u0438"
  },
  {
    id: "mushroom",
    name: "\u0413\u0440\u0438\u0431\u043D\u043E\u0439 \u043B\u0435\u0441\u043D\u043E\u0439 \u0434\u0443\u0445",
    build: "plush",
    pattern: "ticked",
    fur: "curly",
    ears: 0.88,
    color: 12890536,
    glow: 15909845,
    eyes: 11654811,
    names: ["\u0411\u043E\u0440\u043E\u0432\u0438\u0447\u043E\u043A", "\u0413\u0440\u0438\u0431\u043D\u0430\u044F \u041A\u043D\u043E\u043F\u043E\u0447\u043A\u0430"],
    text: "\u041C\u0438\u043B\u044B\u0439 \u043B\u0435\u0441\u043D\u043E\u0439 \u0434\u0443\u0445 \u0441 \u0433\u0440\u0438\u0431\u043D\u043E\u0439 \u0448\u0430\u043F\u043E\u0447\u043A\u043E\u0439 \u0438 \u0440\u043E\u0437\u043E\u0432\u044B\u043C\u0438 \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u043C\u0438\u0441\u044F \u0442\u043E\u0447\u0435\u0447\u043A\u0430\u043C\u0438"
  },
  {
    id: "dream",
    name: "\u0421\u043A\u0430\u0437\u043E\u0447\u043D\u044B\u0439 \u0435\u0434\u0438\u043D\u043E\u043A\u043E\u0442",
    build: "colossal",
    pattern: "solid",
    fur: "long",
    ears: 0.85,
    tailPlume: 1.4,
    color: 15063533,
    glow: 16175334,
    eyes: 11589864,
    names: ["\u0415\u0434\u0438\u043D\u043E\u043A\u043E\u0442 \u041C\u0430\u0440\u043C\u0435\u043B\u0430\u0434", "\u0415\u0434\u0438\u043D\u043E\u043A\u0440\u043E\u0448\u043A\u0430"],
    text: "\u041E\u0434\u0438\u043D \u043F\u0435\u0440\u043B\u0430\u043C\u0443\u0442\u0440\u043E\u0432\u044B\u0439 \u0440\u043E\u0436\u043E\u043A, \u043F\u0430\u0441\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043A\u0440\u044B\u043B\u044B\u0448\u043A\u0438 \u0438 \u043C\u044F\u0433\u043A\u0430\u044F \u0440\u0430\u0434\u0443\u0436\u043D\u0430\u044F \u0433\u0440\u0438\u0432\u0430"
  }
];
var MAGIC_BREEDS = Object.fromEntries(
  MAGIC_FAMILIES.map((f) => ["magic-" + f.id, { ...f, name: f.name }])
);
var NEW_MAGIC_CATS = MAGIC_FAMILIES.flatMap(
  (f, i) => [false, true].map((small) => ({
    id: `adopt-magic-${f.id}${small ? "-tiny" : ""}`,
    name: f.names[small ? 1 : 0],
    breed: "magic-" + f.id,
    color: f.color,
    eyes: f.eyes,
    magic: f.id,
    magicColor: f.glow,
    personality: (small ? "\u041A\u0440\u043E\u0448\u0435\u0447\u043D\u043E\u0435 \u0432\u043E\u043B\u0448\u0435\u0431\u0441\u0442\u0432\u043E: " : "") + f.text,
    price: (small ? 5200 : 7800) + i * (small ? 900 : 1500),
    requiredLevel: 6 + Math.floor(i / 2) + (small ? 0 : 1),
    rarity: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0439",
    collection: "magic",
    tiny: small,
    size: small ? TINY_CAT_SIZE : [1.3, 1.15, 1.55, 1.35, 1.6, 1.2, 1.2, 1.15, 1.4, 1.45, 1.2, 1.55][i],
    biome: "moon",
    adoption: true
  }))
);
var EXTRA_CATS = [
  ...NEW_TINY_CATS.map((c) => ({ ...c, tiny: true })),
  ...NEW_ADULT_CATS,
  ...NEW_MAGIC_CATS
];

// public/cat-breeds.js
var BREEDS = {
  blue: {
    name: "\u0420\u0443\u0441\u0441\u043A\u0430\u044F \u0433\u043E\u043B\u0443\u0431\u0430\u044F",
    build: "slender",
    pattern: "solid",
    ears: 1.08,
    fur: "velvet"
  },
  british: {
    name: "\u0411\u0440\u0438\u0442\u0430\u043D\u0441\u043A\u0430\u044F",
    build: "plush",
    pattern: "solid",
    ears: 0.82,
    fur: "plush"
  },
  tabby: {
    name: "\u0414\u043E\u043C\u0430\u0448\u043D\u044F\u044F \u043F\u043E\u043B\u043E\u0441\u0430\u0442\u0430\u044F",
    build: "balanced",
    pattern: "tabby",
    ears: 1,
    fur: "velvet"
  },
  ragdoll: {
    name: "\u0420\u044D\u0433\u0434\u043E\u043B\u043B",
    build: "plush",
    pattern: "point",
    ears: 0.93,
    fur: "long"
  },
  siamese: {
    name: "\u0421\u0438\u0430\u043C\u0441\u043A\u0430\u044F",
    build: "slender",
    pattern: "point",
    ears: 1.18,
    fur: "velvet"
  },
  maine: {
    name: "\u041C\u0435\u0439\u043D-\u043A\u0443\u043D",
    build: "large",
    pattern: "tabby",
    ears: 1.2,
    fur: "long",
    neckRuff: 1.22,
    earTufts: 0.13,
    squareMuzzle: 0.1,
    tailPlume: 1.32
  },
  persian: {
    name: "\u041F\u0435\u0440\u0441\u0438\u0434\u0441\u043A\u0430\u044F",
    build: "plush",
    pattern: "solid",
    ears: 0.72,
    fur: "long"
  },
  calico: {
    name: "\u0422\u0440\u0451\u0445\u0446\u0432\u0435\u0442\u043D\u0430\u044F",
    build: "balanced",
    pattern: "calico",
    ears: 1,
    fur: "velvet"
  },
  tuxedo: {
    name: "\u041A\u043E\u0442\u0438\u043A \u0432 \u0441\u043C\u043E\u043A\u0438\u043D\u0433\u0435",
    build: "balanced",
    pattern: "tuxedo",
    ears: 1,
    fur: "velvet"
  },
  munchkin: {
    name: "\u041C\u0430\u043D\u0447\u043A\u0438\u043D",
    build: "short",
    pattern: "tabby",
    ears: 0.92,
    fur: "plush"
  },
  cheshire: {
    name: "\u0427\u0435\u0448\u0438\u0440\u0441\u043A\u0438\u0439",
    build: "plush",
    pattern: "cheshire",
    ears: 1,
    fur: "plush"
  },
  scottish: {
    name: "\u0428\u043E\u0442\u043B\u0430\u043D\u0434\u0441\u043A\u0430\u044F \u0432\u0438\u0441\u043B\u043E\u0443\u0445\u0430\u044F",
    build: "plush",
    pattern: "solid",
    ears: 0.78,
    earFold: 0.95,
    fur: "plush"
  },
  bengal: {
    name: "\u0411\u0435\u043D\u0433\u0430\u043B\u044C\u0441\u043A\u0430\u044F",
    build: "slender",
    pattern: "rosettes",
    ears: 0.95,
    fur: "velvet"
  },
  abyssinian: {
    name: "\u0410\u0431\u0438\u0441\u0441\u0438\u043D\u0441\u043A\u0430\u044F",
    build: "slender",
    pattern: "ticked",
    ears: 1.18,
    fur: "velvet"
  },
  norwegian: {
    name: "\u041D\u043E\u0440\u0432\u0435\u0436\u0441\u043A\u0430\u044F \u043B\u0435\u0441\u043D\u0430\u044F",
    build: "large",
    pattern: "tabby",
    ears: 1.14,
    fur: "long",
    neckRuff: 1.2
  },
  siberian: {
    name: "\u0421\u0438\u0431\u0438\u0440\u0441\u043A\u0430\u044F",
    build: "plush",
    pattern: "tabby",
    ears: 0.97,
    fur: "long",
    neckRuff: 1.3
  },
  birman: {
    name: "\u0421\u0432\u044F\u0449\u0435\u043D\u043D\u0430\u044F \u0431\u0438\u0440\u043C\u0430",
    build: "plush",
    pattern: "point",
    ears: 0.93,
    fur: "long",
    whitePaws: true
  },
  angora: {
    name: "\u0422\u0443\u0440\u0435\u0446\u043A\u0430\u044F \u0430\u043D\u0433\u043E\u0440\u0430",
    build: "slender",
    pattern: "solid",
    ears: 1.12,
    fur: "long",
    tailPlume: 1.35
  },
  somali: {
    name: "\u0421\u043E\u043C\u0430\u043B\u0438\u0439\u0441\u043A\u0430\u044F",
    build: "slender",
    pattern: "ticked",
    ears: 1.1,
    fur: "long",
    tailPlume: 1.4
  },
  devon: {
    name: "\u0414\u0435\u0432\u043E\u043D-\u0440\u0435\u043A\u0441",
    build: "short",
    pattern: "solid",
    ears: 1.38,
    fur: "curly",
    faceWidth: 0.9
  },
  bombay: {
    name: "\u0411\u043E\u043C\u0431\u0435\u0439\u0441\u043A\u0430\u044F",
    build: "balanced",
    pattern: "solid",
    ears: 0.96,
    fur: "sleek"
  },
  snowshoe: {
    name: "\u0421\u043D\u043E\u0443-\u0448\u0443",
    build: "balanced",
    pattern: "point",
    ears: 1.03,
    fur: "velvet",
    whitePaws: true
  },
  bobtail: {
    name: "\u041A\u0443\u0440\u0438\u043B\u044C\u0441\u043A\u0438\u0439 \u0431\u043E\u0431\u0442\u0435\u0439\u043B",
    build: "balanced",
    pattern: "tabby",
    ears: 1.05,
    fur: "plush",
    tailLength: 0.28
  },
  sphynx: {
    name: "\u0421\u0444\u0438\u043D\u043A\u0441",
    build: "slender",
    pattern: "solid",
    ears: 1.4,
    fur: "bare"
  },
  curl: {
    name: "\u0410\u043C\u0435\u0440\u0438\u043A\u0430\u043D\u0441\u043A\u0438\u0439 \u043A\u0451\u0440\u043B",
    build: "balanced",
    pattern: "solid",
    ears: 1.12,
    earCurl: 1,
    fur: "long",
    neckRuff: 1.05,
    tailPlume: 1.2
  },
  van: {
    name: "\u0422\u0443\u0440\u0435\u0446\u043A\u0438\u0439 \u0432\u0430\u043D",
    build: "balanced",
    pattern: "van",
    ears: 1.02,
    fur: "long",
    tailPlume: 1.3,
    patchColor: 12942404
  },
  exotic: {
    name: "\u042D\u043A\u0437\u043E\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0448\u0451\u0440\u0441\u0442\u043D\u0430\u044F",
    build: "colossal",
    pattern: "solid",
    ears: 0.7,
    fur: "plush",
    faceWidth: 1.04
  },
  selkirk: {
    name: "\u0421\u0435\u043B\u043A\u0438\u0440\u043A-\u0440\u0435\u043A\u0441",
    build: "colossal",
    pattern: "solid",
    ears: 0.84,
    fur: "curly"
  },
  ragamuffin: {
    name: "\u0420\u0430\u0433\u0430\u043C\u0430\u0444\u0444\u0438\u043D",
    build: "colossal",
    pattern: "solid",
    ears: 0.89,
    fur: "long",
    neckRuff: 1.18,
    tailPlume: 1.4
  }
};
Object.assign(BREEDS, EXTRA_BREEDS, MAGIC_BREEDS);
var cat = (id, name, breed, color, eyes, price, requiredLevel, personality, extra = {}) => ({
  id: "adopt-" + id,
  name,
  breed,
  color,
  eyes,
  price,
  requiredLevel,
  personality,
  biome: "moon",
  adoption: true,
  ...extra
});
var ADOPTION_CATS = [
  cat(
    "biscuit",
    "\u0411\u0438\u0441\u043A\u0432\u0438\u0442",
    "tabby",
    13996370,
    7714951,
    240,
    3,
    "\u041C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u0440\u044B\u0436\u0438\u0439 \u043E\u0445\u043E\u0442\u043D\u0438\u043A \u0437\u0430 \u043A\u043B\u0443\u0431\u043E\u0447\u043A\u0430\u043C\u0438",
    { build: "short", size: 0.86 }
  ),
  cat(
    "mist",
    "\u0422\u0443\u043C\u0430\u043D",
    "blue",
    7833493,
    10867820,
    360,
    3,
    "\u0421\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u044B\u0439 \u0442\u0438\u0445\u043E\u043D\u044F: \u043F\u0435\u0440\u0432\u044B\u043C \u0437\u043D\u0430\u043A\u043E\u043C\u0438\u0442\u0441\u044F \u0441 \u0427\u0438\u0447\u0438"
  ),
  cat(
    "pudding",
    "\u041F\u0443\u0434\u0438\u043D\u0433",
    "british",
    14996408,
    14333015,
    520,
    4,
    "\u041A\u0440\u0443\u0433\u043B\u044B\u0439 \u043B\u044E\u0431\u0438\u0442\u0435\u043B\u044C \u043C\u044F\u0433\u043A\u0438\u0445 \u043F\u043E\u0434\u0443\u0448\u0435\u043A",
    { build: "giant", size: 1.18 }
  ),
  cat(
    "mittens",
    "\u0412\u0430\u0440\u0435\u0436\u043A\u0430",
    "tuxedo",
    3753040,
    10340977,
    620,
    4,
    "\u0411\u0435\u043B\u044B\u0435 \u043D\u043E\u0441\u043E\u0447\u043A\u0438, \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u043D\u043E\u0441\u0438\u043A \u0438 \u043B\u044E\u0431\u043E\u0432\u044C \u043A \u0432\u043E\u0434\u0435"
  ),
  cat(
    "patch",
    "\u041F\u044F\u0442\u043D\u044B\u0448\u043A\u043E",
    "calico",
    15196370,
    10075523,
    780,
    5,
    "\u041B\u044E\u0431\u043E\u043F\u044B\u0442\u043D\u0430\u044F \u0442\u0440\u0451\u0445\u0446\u0432\u0435\u0442\u043D\u0430\u044F \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u0438\u0446\u0430"
  ),
  cat(
    "milo",
    "\u041C\u0438\u043B\u043E",
    "munchkin",
    12367010,
    11061358,
    900,
    5,
    "\u041A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0435 \u043B\u0430\u043F\u043A\u0438, \u0431\u044B\u0441\u0442\u0440\u044B\u0435 \u0441\u043C\u0435\u0448\u043D\u044B\u0435 \u0448\u0430\u0436\u043A\u0438",
    { size: 0.87 }
  ),
  cat(
    "sugar",
    "\u0421\u0430\u0445\u0430\u0440\u043E\u043A",
    "persian",
    15788509,
    9488095,
    1150,
    6,
    "\u041F\u0443\u0448\u0438\u0441\u0442\u043E\u0435 \u043E\u0431\u043B\u0430\u0447\u043A\u043E \u0441 \u0441\u043E\u043D\u043D\u043E\u0439 \u0443\u043B\u044B\u0431\u043A\u043E\u0439"
  ),
  cat(
    "mocha",
    "\u041C\u043E\u043A\u043A\u043E",
    "siamese",
    14339509,
    7715295,
    1350,
    7,
    "\u0421\u0442\u0440\u043E\u0439\u043D\u0430\u044F \u0431\u043E\u043B\u0442\u0443\u0448\u043A\u0430 \u0441 \u0433\u043E\u043B\u0443\u0431\u044B\u043C\u0438 \u0433\u043B\u0430\u0437\u0430\u043C\u0438"
  ),
  cat(
    "toffee",
    "\u0418\u0440\u0438\u0441\u043A\u0430",
    "ragdoll",
    15064528,
    8305882,
    1550,
    8,
    "\u041D\u0435\u0436\u043D\u0430\u044F \u043F\u043E\u0434\u0440\u0443\u0433\u0430: \u043B\u044E\u0431\u0438\u0442 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044E \u0438 \u043E\u0431\u044A\u044F\u0442\u0438\u044F"
  ),
  cat(
    "juniper",
    "\u041C\u043E\u0436\u0436\u0435\u0432\u0435\u043B\u044C\u043D\u0438\u043A",
    "maine",
    9082512,
    12506230,
    1950,
    9,
    "\u0411\u043E\u043B\u044C\u0448\u043E\u0439 \u043B\u0435\u0441\u043D\u043E\u0439 \u043A\u043E\u0442 \u0441 \u043A\u0438\u0441\u0442\u043E\u0447\u043A\u0430\u043C\u0438 \u043D\u0430 \u0443\u0448\u043A\u0430\u0445",
    { size: 1.16 }
  ),
  cat(
    "cloudberry",
    "\u041C\u043E\u0440\u043E\u0448\u043A\u0430",
    "british",
    14332301,
    13413733,
    2400,
    10,
    "\u041E\u0433\u0440\u043E\u043C\u043D\u0430\u044F \u043F\u043B\u044E\u0448\u0435\u0432\u0430\u044F \u0431\u0443\u043B\u043E\u0447\u043A\u0430: \u043A\u0440\u0443\u0433\u043B\u044B\u0439 \u0436\u0438\u0432\u043E\u0442\u0438\u043A \u0438 \u0441\u043C\u0435\u0448\u043D\u044B\u0435 \u043F\u0435\u0440\u0435\u0432\u0430\u043B\u0438\u0432\u0430\u044E\u0449\u0438\u0435\u0441\u044F \u0448\u0430\u0436\u043A\u0438",
    { build: "giant", size: 1.48 }
  ),
  cat(
    "pearl",
    "\u0416\u0435\u043C\u0447\u0443\u0436\u0438\u043D\u043A\u0430",
    "ragdoll",
    15788508,
    9553880,
    2800,
    11,
    "\u041C\u044F\u0433\u043A\u0438\u0439 \u0445\u0432\u043E\u0441\u0442, \u0431\u0435\u043B\u044B\u0435 \u043B\u0430\u043F\u043A\u0438 \u0438 \u043B\u0451\u0433\u043A\u0430\u044F \u043F\u043E\u0445\u043E\u0434\u043A\u0430"
  ),
  cat(
    "ember",
    "\u0423\u0433\u043E\u043B\u0451\u043A",
    "tabby",
    5001818,
    15188581,
    3200,
    12,
    "\u0422\u0451\u043C\u043D\u044B\u0439 \u043F\u043E\u043B\u043E\u0441\u0430\u0442\u044B\u0439 \u043B\u044E\u0431\u0438\u0442\u0435\u043B\u044C \u0430\u0442\u0442\u0440\u0430\u043A\u0446\u0438\u043E\u043D\u043E\u0432"
  ),
  cat(
    "starlight",
    "\u0417\u0432\u0451\u0437\u0434\u043E\u0447\u043A\u0430",
    "cheshire",
    10064327,
    8643277,
    4100,
    13,
    "\u041F\u043E\u043B\u043E\u0441\u0430\u0442\u0430\u044F \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u0438\u0446\u0430 \u0441 \u0448\u0438\u0440\u043E\u043A\u043E\u0439 \u043A\u043E\u0448\u0430\u0447\u044C\u0435\u0439 \u0443\u043B\u044B\u0431\u043A\u043E\u0439"
  ),
  cat(
    "nimbus",
    "\u041D\u0438\u043C\u0431\u0443\u0441",
    "maine",
    13949920,
    8699104,
    4800,
    14,
    "\u0412\u0435\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u0439 \u0432\u0435\u043B\u0438\u043A\u0430\u043D",
    { size: 1.25 }
  ),
  cat(
    "fig",
    "\u0418\u043D\u0436\u0438\u0440",
    "sphynx",
    12952736,
    10210449,
    5600,
    15,
    "\u0420\u0435\u0434\u043A\u0438\u0439 \u0441\u0444\u0438\u043D\u043A\u0441 \u0441 \u0431\u043E\u043B\u044C\u0448\u0438\u043C\u0438 \u0443\u0448\u043A\u0430\u043C\u0438 \u0438 \u0442\u0451\u043F\u043B\u043E\u0439 \u043A\u043E\u0436\u0435\u0439"
  ),
  cat(
    "mooncake",
    "\u041B\u0443\u043D\u043D\u044B\u0439 \u041F\u0438\u0440\u043E\u0433",
    "cheshire",
    6911402,
    14995840,
    6800,
    17,
    "\u0413\u0440\u043E\u043C\u0430\u0434\u043D\u044B\u0439 \u0434\u043E\u0431\u0440\u044F\u043A: \u043C\u0435\u0434\u043B\u0435\u043D\u043D\u043E \u0442\u043E\u043F\u0430\u0435\u0442 \u0438 \u0441\u043C\u0435\u0448\u043D\u043E \u043A\u0430\u0447\u0430\u0435\u0442\u0441\u044F",
    { build: "giant", size: 2.1 }
  ),
  cat(
    "snowdrop",
    "\u041F\u043E\u0434\u0441\u043D\u0435\u0436\u043D\u0438\u043A",
    "persian",
    15397101,
    10271453,
    8200,
    19,
    "\u0420\u0435\u0434\u043A\u0438\u0439 \u0441\u043D\u0435\u0436\u043D\u044B\u0439 \u043A\u043E\u0442 \u0441 \u0433\u043B\u0430\u0437\u0430\u043C\u0438 \u0440\u0430\u0437\u043D\u044B\u0445 \u0446\u0432\u0435\u0442\u043E\u0432",
    { otherEye: 12113526 }
  ),
  cat(
    "button",
    "\u041F\u0443\u0433\u043E\u0432\u043A\u0430",
    "scottish",
    10463923,
    14924392,
    280,
    2,
    "\u0421\u043B\u043E\u0436\u0435\u043D\u043D\u044B\u0435 \u0443\u0448\u043A\u0438 \u0438 \u043C\u044F\u0433\u043A\u0438\u0439 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440: \u043B\u044E\u0431\u0438\u0442 \u043A\u0430\u0442\u0430\u0442\u044C\u0441\u044F \u0441 \u0427\u0438\u0447\u0438"
  ),
  cat(
    "onyx",
    "\u041E\u043D\u0438\u043A\u0441",
    "bombay",
    3159101,
    15710550,
    360,
    2,
    "\u0427\u0451\u0440\u043D\u044B\u0439 \u0431\u0430\u0440\u0445\u0430\u0442, \u0437\u043E\u043B\u043E\u0442\u044B\u0435 \u0433\u043B\u0430\u0437\u0430 \u0438 \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u043D\u044B\u0439 \u043D\u043E\u0441\u0438\u043A"
  ),
  cat(
    "apricot",
    "\u0410\u0431\u0440\u0438\u043A\u043E\u0441",
    "abyssinian",
    13210981,
    10931320,
    580,
    3,
    "\u0414\u043B\u0438\u043D\u043D\u044B\u0435 \u043B\u0430\u043F\u043A\u0438, \u0431\u043E\u043B\u044C\u0448\u0438\u0435 \u0443\u0448\u043A\u0438 \u0438 \u0441\u043E\u043B\u043D\u0435\u0447\u043D\u0430\u044F \u043A\u0440\u0430\u043F\u0447\u0430\u0442\u0430\u044F \u0448\u0435\u0440\u0441\u0442\u044C"
  ),
  cat(
    "spots",
    "\u0412\u0435\u0441\u043D\u0443\u0448\u043A\u0430",
    "bengal",
    13476974,
    8964230,
    850,
    4,
    "\u041C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u043B\u0435\u043E\u043F\u0430\u0440\u0434 \u0441 \u0440\u043E\u0437\u0435\u0442\u043A\u0430\u043C\u0438: \u043E\u0431\u043E\u0436\u0430\u0435\u0442 \u0431\u0435\u0433\u0430\u0442\u044C \u0437\u0430 \u0438\u0433\u0440\u0443\u0448\u043A\u0430\u043C\u0438"
  ),
  cat(
    "socks",
    "\u041D\u043E\u0441\u043E\u0447\u0435\u043A",
    "snowshoe",
    13878964,
    7847138,
    980,
    4,
    "\u0411\u0435\u043B\u044B\u0435 \u043D\u043E\u0441\u043E\u0447\u043A\u0438, \u0442\u0451\u043C\u043D\u0430\u044F \u043C\u0430\u0441\u043A\u0430 \u0438 \u0433\u043E\u043B\u0443\u0431\u043E\u0439 \u0432\u0437\u0433\u043B\u044F\u0434"
  ),
  cat(
    "pompon",
    "\u041F\u043E\u043C\u043F\u043E\u043D",
    "bobtail",
    10068629,
    13094524,
    1200,
    5,
    "\u041A\u043E\u0440\u043E\u0442\u043A\u0438\u0439 \u0445\u0432\u043E\u0441\u0442-\u043F\u043E\u043C\u043F\u043E\u043D \u0438 \u0441\u043C\u0435\u0448\u043D\u0430\u044F \u043F\u043E\u0434\u043F\u0440\u044B\u0433\u0438\u0432\u0430\u044E\u0449\u0430\u044F \u043F\u043E\u0445\u043E\u0434\u043A\u0430"
  ),
  cat(
    "cloud",
    "\u041E\u0431\u043B\u0430\u0447\u043A\u043E",
    "angora",
    15528174,
    8763873,
    1450,
    5,
    "\u0411\u0435\u043B\u043E\u0441\u043D\u0435\u0436\u043D\u044B\u0439 \u0448\u0451\u043B\u043A \u0438 \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u0439 \u0445\u0432\u043E\u0441\u0442; \u043E\u0434\u0438\u043D \u0433\u043B\u0430\u0437 \u0437\u043E\u043B\u043E\u0442\u043E\u0439",
    { otherEye: 14531176 }
  ),
  cat(
    "curls",
    "\u041A\u0443\u0434\u0440\u044F\u0448",
    "devon",
    10922664,
    11193205,
    1750,
    6,
    "\u041A\u0443\u0434\u0440\u044F\u0432\u0430\u044F \u0448\u0443\u0431\u043A\u0430, \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u0435 \u0443\u0448\u043A\u0438 \u0438 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0435 \u043F\u0440\u0443\u0436\u0438\u043D\u0438\u0441\u0442\u044B\u0435 \u043B\u0430\u043F\u043A\u0438",
    { size: 0.85 }
  ),
  cat(
    "moss",
    "\u041C\u043E\u0445",
    "norwegian",
    9083796,
    11850877,
    2100,
    7,
    "\u041B\u0435\u0441\u043D\u043E\u0439 \u0432\u0435\u043B\u0438\u043A\u0430\u043D \u0441 \u0432\u043E\u0440\u043E\u0442\u043D\u0438\u043A\u043E\u043C \u0438 \u043A\u0438\u0441\u0442\u043E\u0447\u043A\u0430\u043C\u0438",
    { size: 1.2 }
  ),
  cat(
    "cedar",
    "\u041A\u0435\u0434\u0440",
    "siberian",
    10591377,
    13811058,
    2400,
    8,
    "\u041F\u043B\u043E\u0442\u043D\u0430\u044F \u043F\u0443\u0448\u0438\u0441\u0442\u0430\u044F \u0448\u0443\u0431\u0430: \u043D\u0435\u0441\u043F\u0435\u0448\u043D\u044B\u0439 \u0434\u0440\u0443\u0433 \u0434\u043B\u044F \u043F\u0440\u043E\u0433\u0443\u043B\u043E\u043A",
    { size: 1.13 }
  ),
  cat(
    "saffron",
    "\u0428\u0430\u0444\u0440\u0430\u043D",
    "somali",
    12883047,
    10144386,
    2900,
    9,
    "\u0420\u044B\u0436\u0438\u0439 \u0445\u0432\u043E\u0441\u0442 \u043A\u0430\u043A \u0443 \u043B\u0438\u0441\u0438\u0447\u043A\u0438, \u043D\u043E \u043C\u043E\u0440\u0434\u043E\u0447\u043A\u0430 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u0433\u043E \u043A\u043E\u0442\u0438\u043A\u0430"
  ),
  cat(
    "silk",
    "\u0428\u0451\u043B\u043A",
    "birman",
    14866632,
    8502496,
    3300,
    10,
    "\u041D\u0435\u0436\u043D\u044B\u0435 \u0431\u0435\u043B\u044B\u0435 \u043B\u0430\u043F\u043A\u0438 \u0438 \u043F\u0443\u0448\u0438\u0441\u0442\u0430\u044F \u0442\u0451\u043C\u043D\u0430\u044F \u043C\u0430\u0441\u043A\u0430"
  ),
  cat(
    "pretzel",
    "\u041A\u0440\u0435\u043D\u0434\u0435\u043B\u0451\u043A",
    "curl",
    12036507,
    11128194,
    1650,
    6,
    "\u0423\u0448\u043A\u0438 \u0437\u0430\u0432\u0438\u0442\u044B \u043D\u0430\u0437\u0430\u0434, \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u0439 \u0432\u043E\u0440\u043E\u0442\u043D\u0438\u0447\u043E\u043A \u0438 \u0445\u0432\u043E\u0441\u0442-\u043F\u0451\u0440\u044B\u0448\u043A\u043E"
  ),
  cat(
    "marzipan",
    "\u041C\u0430\u0440\u0446\u0438\u043F\u0430\u043D",
    "van",
    15788766,
    8830943,
    1850,
    7,
    "\u0411\u0435\u043B\u0430\u044F \u0448\u0443\u0431\u043A\u0430, \u0440\u044B\u0436\u0430\u044F \u0448\u0430\u043F\u043E\u0447\u043A\u0430 \u0438 \u043F\u043E\u043B\u043E\u0441\u0430\u0442\u044B\u0439 \u0445\u0432\u043E\u0441\u0442: \u043E\u0431\u043E\u0436\u0430\u0435\u0442 \u043B\u0430\u0433\u0443\u043D\u044B",
    { otherEye: 14399581 }
  ),
  cat(
    "plushkin",
    "\u041F\u043B\u044E\u0448\u043A\u0438\u043D",
    "exotic",
    14072480,
    13346142,
    3600,
    11,
    "\u0413\u0438\u0433\u0430\u043D\u0442\u0441\u043A\u0430\u044F \u043F\u043B\u044E\u0448\u0435\u0432\u0430\u044F \u043F\u043E\u0434\u0443\u0448\u043A\u0430: \u043A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0435 \u0443\u0448\u043A\u0438, \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u0439 \u0436\u0438\u0432\u043E\u0442\u0438\u043A \u0438 \u0432\u0430\u0436\u043D\u044B\u0435 \u0441\u043C\u0435\u0448\u043D\u044B\u0435 \u0448\u0430\u0436\u043A\u0438",
    { size: 2.05 }
  ),
  cat(
    "doughnut",
    "\u041F\u043E\u043D\u0447\u0438\u043A",
    "selkirk",
    12041670,
    11587964,
    4600,
    13,
    "\u041A\u0443\u0434\u0440\u044F\u0432\u044B\u0439 \u0432\u0435\u043B\u0438\u043A\u0430\u043D: \u0432\u0434\u0432\u043E\u0435 \u0448\u0438\u0440\u0435 \u041C\u043E\u0440\u043E\u0448\u043A\u0438, \u043E\u0431\u043E\u0436\u0430\u0435\u0442 \u043E\u0431\u043D\u0438\u043C\u0430\u0442\u044C\u0441\u044F \u0438 \u0441\u043C\u0435\u0448\u043D\u043E \u043F\u0435\u0440\u0435\u0432\u0430\u043B\u0438\u0432\u0430\u0435\u0442\u0441\u044F",
    { size: 2.15 }
  ),
  cat(
    "marshmallow",
    "\u0417\u0435\u0444\u0438\u0440",
    "ragamuffin",
    15261652,
    9092569,
    6300,
    15,
    "\u041E\u0433\u0440\u043E\u043C\u043D\u043E\u0435 \u043F\u0443\u0448\u0438\u0441\u0442\u043E\u0435 \u043E\u0431\u043B\u0430\u043A\u043E \u0441 \u0432\u043E\u0440\u043E\u0442\u043D\u0438\u043A\u043E\u043C, \u0445\u0432\u043E\u0441\u0442\u043E\u043C-\u043F\u0451\u0440\u044B\u0448\u043A\u043E\u043C \u0438 \u0441\u0430\u043C\u044B\u043C \u043C\u044F\u0433\u043A\u0438\u043C \u0436\u0438\u0432\u043E\u0442\u0438\u043A\u043E\u043C",
    { size: 2.25, otherEye: 14135918 }
  )
];
ADOPTION_CATS.push(...EXTRA_CATS);

// public/business-data.js
var BUSINESSES = [
  {
    id: "business-coffee",
    footprint: [4, 4],
    name: "\u041C\u0443\u0440-\u043A\u043E\u0444\u0435\u0439\u043D\u044F",
    icon: "\u2615",
    price: 460,
    requiredLevel: 2,
    buildMinutes: 20,
    rate: 260,
    color: 9225914,
    description: "\u041A\u043E\u0442-\u0431\u0430\u0440\u0438\u0441\u0442\u0430 \u0432\u0430\u0440\u0438\u0442 \u043A\u043E\u0444\u0435, \u0433\u043E\u0441\u0442\u0438 \u043E\u0442\u0434\u044B\u0445\u0430\u044E\u0442 \u0437\u0430 \u0441\u0442\u043E\u043B\u0438\u043A\u0430\u043C\u0438. \u0427\u0438\u0441\u0442\u0430\u044F \u043F\u0440\u0438\u0431\u044B\u043B\u044C 260 \u2726/\u0447."
  },
  {
    id: "business-hotdog",
    name: "\u0425\u043E\u0442-\u0434\u043E\u0433\u0438 \u0443 \u0411\u0443\u0431\u043B\u0438\u043A\u0430",
    icon: "\u{1F32D}",
    price: 720,
    requiredLevel: 3,
    buildMinutes: 30,
    rate: 360,
    color: 15510138,
    description: "\u041A\u043E\u0442-\u043F\u043E\u0432\u0430\u0440 \u0436\u0430\u0440\u0438\u0442 \u0445\u043E\u0442-\u0434\u043E\u0433\u0438 \u043D\u0430 \u0433\u0440\u0438\u043B\u0435. \u0427\u0438\u0441\u0442\u0430\u044F \u043F\u0440\u0438\u0431\u044B\u043B\u044C 360 \u2726/\u0447."
  },
  {
    id: "business-bakery",
    name: "\u041F\u0435\u043A\u0430\u0440\u043D\u044F \u043C\u044F\u0433\u043A\u0438\u0445 \u0431\u0443\u043B\u043E\u0447\u0435\u043A",
    icon: "\u{1F950}",
    price: 1200,
    requiredLevel: 4,
    buildMinutes: 60,
    rate: 480,
    color: 15054798,
    description: "\u0421\u0432\u0435\u0436\u0438\u0435 \u0431\u0443\u043B\u043E\u0447\u043A\u0438, \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0430\u044F \u043F\u0435\u0447\u044C \u0438 \u043F\u0443\u0448\u0438\u0441\u0442\u044B\u0439 \u043F\u0435\u043A\u0430\u0440\u044C. \u0427\u0438\u0441\u0442\u0430\u044F \u043F\u0440\u0438\u0431\u044B\u043B\u044C 480 \u2726/\u0447."
  },
  {
    id: "business-gelato",
    name: "\u041B\u0443\u043D\u043D\u043E\u0435 \u043C\u043E\u0440\u043E\u0436\u0435\u043D\u043E\u0435",
    icon: "\u{1F366}",
    price: 1850,
    requiredLevel: 5,
    buildMinutes: 90,
    rate: 620,
    color: 12038364,
    description: "\u0426\u0432\u0435\u0442\u043D\u044B\u0435 \u0440\u043E\u0436\u043A\u0438 \u0438 \u043F\u0440\u043E\u0445\u043B\u0430\u0434\u043D\u044B\u0435 \u0434\u0435\u0441\u0435\u0440\u0442\u044B. \u0427\u0438\u0441\u0442\u0430\u044F \u043F\u0440\u0438\u0431\u044B\u043B\u044C 620 \u2726/\u0447."
  },
  {
    id: "business-florist",
    name: "\u0426\u0432\u0435\u0442\u043E\u0447\u043D\u0430\u044F \u043B\u0430\u0432\u043A\u0430 \u0424\u043B\u043E\u0440\u044B",
    icon: "\u{1F490}",
    price: 2450,
    requiredLevel: 6,
    buildMinutes: 120,
    rate: 760,
    color: 11061122,
    description: "\u041A\u043E\u0442-\u0444\u043B\u043E\u0440\u0438\u0441\u0442 \u0441\u043E\u0431\u0438\u0440\u0430\u0435\u0442 \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u044B\u0435 \u0431\u0443\u043A\u0435\u0442\u044B. \u0427\u0438\u0441\u0442\u0430\u044F \u043F\u0440\u0438\u0431\u044B\u043B\u044C 760 \u2726/\u0447."
  },
  {
    id: "business-artist",
    name: "\u0410\u0442\u0435\u043B\u044C\u0435 \u043A\u043E\u0442\u0430-\u0445\u0443\u0434\u043E\u0436\u043D\u0438\u043A\u0430",
    icon: "\u{1F3A8}",
    price: 3300,
    requiredLevel: 8,
    buildMinutes: 180,
    rate: 940,
    color: 8633296,
    description: "\u041A\u043E\u0442-\u0445\u0443\u0434\u043E\u0436\u043D\u0438\u043A \u043F\u0438\u0448\u0435\u0442 \u043C\u0438\u043D\u0438\u0430\u0442\u044E\u0440\u044B \u0438 \u043F\u0440\u043E\u0434\u0430\u0451\u0442 \u0438\u0445 \u0433\u043E\u0441\u0442\u044F\u043C. \u0427\u0438\u0441\u0442\u0430\u044F \u043F\u0440\u0438\u0431\u044B\u043B\u044C 940 \u2726/\u0447."
  },
  {
    id: "business-farmstand",
    footprint: [3, 3],
    name: "\u0423\u0440\u043E\u0436\u0430\u0439\u043D\u0430\u044F \u043B\u0430\u0432\u043E\u0447\u043A\u0430",
    icon: "\u{1F955}",
    price: 180,
    requiredLevel: 1,
    buildMinutes: 5,
    rate: 160,
    color: 9554053,
    style: "stall",
    goods: "produce",
    description: "\u041F\u0435\u0440\u0432\u043E\u0435 \u0434\u0435\u043B\u043E \u0441 \u0443\u0440\u043E\u0432\u043D\u044F 1: \u043A\u043E\u0440\u0437\u0438\u043D\u043A\u0438 \u043E\u0432\u043E\u0449\u0435\u0439, \u043A\u043E\u0442-\u043F\u0440\u043E\u0434\u0430\u0432\u0435\u0446 \u0438 160 \u2726/\u0447 \u0447\u0438\u0441\u0442\u043E\u0433\u043E \u0434\u043E\u0445\u043E\u0434\u0430."
  },
  {
    id: "business-lemonade",
    footprint: [3, 3],
    name: "\u041B\u0438\u043C\u043E\u043D\u0430\u0434 \u0443 \u041B\u0438\u043C\u043E\u043D\u0447\u0438\u043A\u0430",
    icon: "\u{1F34B}",
    price: 260,
    requiredLevel: 2,
    buildMinutes: 10,
    rate: 210,
    color: 15979629,
    style: "stall",
    goods: "lemonade",
    description: "\u0421\u0432\u0435\u0436\u0438\u0439 \u043B\u0438\u043C\u043E\u043D\u0430\u0434, \u0441\u0442\u0435\u043A\u043B\u044F\u043D\u043D\u044B\u0435 \u043A\u0443\u0432\u0448\u0438\u043D\u044B \u0438 \u044F\u0440\u043A\u0438\u0439 \u043F\u043E\u043B\u043E\u0441\u0430\u0442\u044B\u0439 \u043D\u0430\u0432\u0435\u0441. \u0414\u043E\u0445\u043E\u0434 210 \u2726/\u0447."
  },
  {
    id: "business-fishmarket",
    footprint: [4, 4],
    name: "\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u0430\u044F \u0440\u044B\u0431\u043D\u0430\u044F \u043B\u0430\u0432\u043A\u0430",
    icon: "\u{1F41F}",
    price: 430,
    requiredLevel: 3,
    buildMinutes: 20,
    rate: 290,
    color: 7915740,
    style: "stall",
    goods: "fish",
    description: "\u041C\u043E\u0440\u0441\u043A\u0438\u0435 \u0444\u043E\u043D\u0430\u0440\u0438\u043A\u0438, \u0432\u0438\u0442\u0440\u0438\u043D\u0430 \u0441 \u0440\u044B\u0431\u043A\u0430\u043C\u0438 \u0438 \u043A\u043E\u0442-\u0442\u043E\u0440\u0433\u043E\u0432\u0435\u0446. \u0414\u043E\u0445\u043E\u0434 290 \u2726/\u0447."
  },
  {
    id: "business-pizza",
    name: "\u041F\u0438\u0446\u0446\u0435\u0440\u0438\u044F \u041C\u0443\u0440-\u041D\u0435\u0430\u043F\u043E\u043B\u044C",
    icon: "\u{1F355}",
    price: 900,
    requiredLevel: 4,
    buildMinutes: 45,
    rate: 420,
    color: 15306870,
    goods: "pizza",
    description: "\u0414\u0440\u043E\u0432\u044F\u043D\u0430\u044F \u043F\u0435\u0447\u044C, \u0431\u0430\u0437\u0438\u043B\u0438\u043A \u0438 \u043A\u043E\u0442-\u043F\u0438\u0446\u0446\u0430\u0439\u043E\u043B\u043E. \u0414\u043E\u0445\u043E\u0434 420 \u2726/\u0447."
  },
  {
    id: "business-boba",
    name: "\u041E\u0431\u043B\u0430\u0447\u043D\u044B\u0439 \u0431\u0430\u0431\u043B-\u0442\u0438",
    icon: "\u{1F9CB}",
    price: 1300,
    requiredLevel: 5,
    buildMinutes: 60,
    rate: 520,
    color: 12229598,
    goods: "boba",
    description: "\u0421\u0442\u0430\u043A\u0430\u043D\u0447\u0438\u043A\u0438 \u0441 \u0436\u0435\u043C\u0447\u0443\u0436\u0438\u043D\u0430\u043C\u0438, \u0446\u0432\u0435\u0442\u043D\u044B\u0435 \u0442\u0440\u0443\u0431\u043E\u0447\u043A\u0438 \u0438 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u044B\u0435 \u0433\u043E\u0441\u0442\u0438. \u0414\u043E\u0445\u043E\u0434 520 \u2726/\u0447."
  },
  {
    id: "business-honeytea",
    name: "\u041C\u0435\u0434\u043E\u0432\u0430\u044F \u0447\u0430\u0439\u043D\u0430\u044F",
    icon: "\u{1F36F}",
    price: 1850,
    requiredLevel: 6,
    buildMinutes: 90,
    rate: 650,
    color: 14137457,
    goods: "honey",
    description: "\u0421\u0430\u043C\u043E\u0432\u0430\u0440, \u0431\u0430\u043D\u043E\u0447\u043A\u0438 \u043C\u0451\u0434\u0430 \u0438 \u0442\u0451\u043F\u043B\u044B\u0439 \u0441\u0432\u0435\u0442 \u0432 \u043E\u043A\u043E\u0448\u043A\u0430\u0445. \u0414\u043E\u0445\u043E\u0434 650 \u2726/\u0447."
  },
  {
    id: "business-candy",
    name: "\u041A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u043D\u0434\u0438\u0442\u0435\u0440\u0441\u043A\u0430\u044F",
    icon: "\u{1F36C}",
    price: 2800,
    requiredLevel: 8,
    buildMinutes: 120,
    rate: 860,
    color: 15308739,
    goods: "candy",
    description: "\u041B\u0435\u0434\u0435\u043D\u0446\u044B, \u043A\u043E\u043D\u0444\u0435\u0442\u044B \u0438 \u0441\u043B\u0430\u0434\u043A\u0430\u044F \u0432\u0438\u0442\u0440\u0438\u043D\u0430 \u0441\u043E \u0441\u0432\u043E\u0438\u043C \u043A\u043E\u0442\u0438\u043A\u043E\u043C. \u0414\u043E\u0445\u043E\u0434 860 \u2726/\u0447."
  },
  {
    id: "business-toymaker",
    name: "\u041C\u0430\u0441\u0442\u0435\u0440\u0441\u043A\u0430\u044F \u0441\u043C\u0435\u0448\u043D\u044B\u0445 \u0438\u0433\u0440\u0443\u0448\u0435\u043A",
    icon: "\u{1F9F8}",
    price: 4e3,
    requiredLevel: 10,
    buildMinutes: 180,
    rate: 1050,
    color: 8437701,
    goods: "toys",
    description: "\u041A\u043E\u0442-\u043C\u0430\u0441\u0442\u0435\u0440 \u0448\u044C\u0451\u0442 \u043C\u044B\u0448\u0435\u043A \u0438 \u043C\u043E\u0442\u0430\u0435\u0442 \u043A\u043B\u0443\u0431\u043A\u0438. \u0414\u043E\u0445\u043E\u0434 1050 \u2726/\u0447."
  }
];

// public/city-ride-data.js
var CITY_RIDES = [
  {
    id: "ride-dream-balloon",
    name: "\u0412\u043E\u0437\u0434\u0443\u0448\u043D\u044B\u0439 \u0448\u0430\u0440 \u0433\u043E\u0440\u043E\u0434\u0430 \u0441\u043D\u043E\u0432",
    icon: "\u{1F388}",
    price: 340,
    requiredLevel: 2,
    buildMinutes: 15,
    footprint: [5, 5],
    color: 15311821,
    accent: 9820129,
    description: "\u041F\u043E\u043B\u043E\u0441\u0430\u0442\u044B\u0439 \u0448\u0430\u0440, \u043C\u044F\u0433\u043A\u0430\u044F \u043A\u043E\u0440\u0437\u0438\u043D\u043A\u0430 \u0438 \u043F\u043B\u0430\u0432\u043D\u044B\u0439 \u043F\u043E\u043B\u0451\u0442 \u043D\u0430\u0434 \u0446\u0432\u0435\u0442\u0430\u043C\u0438."
  },
  {
    id: "ride-paris-wheel",
    name: "\u041F\u0430\u0440\u0438\u0436\u0441\u043A\u043E\u0435 \u043A\u043E\u043B\u0435\u0441\u043E \u043C\u0443\u0440\u0447\u0430\u043D\u0438\u044F",
    icon: "\u{1F3A1}",
    price: 680,
    requiredLevel: 3,
    buildMinutes: 30,
    footprint: [7, 5],
    color: 13083368,
    accent: 16764536,
    description: "\u0417\u043E\u043B\u043E\u0442\u044B\u0435 \u0441\u043F\u0438\u0446\u044B, \u0446\u0432\u0435\u0442\u043D\u044B\u0435 \u043A\u0430\u0431\u0438\u043D\u043A\u0438 \u0438 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0430\u044F \u0431\u0430\u0448\u043D\u044F \u0441 \u043E\u0433\u043E\u043D\u044C\u043A\u0430\u043C\u0438."
  },
  {
    id: "ride-venice-gondola",
    name: "\u0412\u0435\u043D\u0435\u0446\u0438\u0430\u043D\u0441\u043A\u0430\u044F \u0433\u043E\u043D\u0434\u043E\u043B\u0430",
    icon: "\u{1F6F6}",
    price: 1100,
    requiredLevel: 4,
    buildMinutes: 45,
    footprint: [7, 7],
    color: 7391699,
    accent: 15840140,
    description: "\u0411\u0438\u0440\u044E\u0437\u043E\u0432\u044B\u0439 \u043A\u0430\u043D\u0430\u043B \u0441 \u0440\u044B\u0431\u043A\u0430\u043C\u0438, \u0430\u0440\u043E\u0447\u043D\u044B\u0439 \u043C\u043E\u0441\u0442 \u0438 \u0443\u044E\u0442\u043D\u0430\u044F \u0433\u043E\u043D\u0434\u043E\u043B\u0430."
  },
  {
    id: "ride-tokyo-train",
    name: "\u0421\u0430\u043A\u0443\u0440\u0430-\u044D\u043A\u0441\u043F\u0440\u0435\u0441\u0441",
    icon: "\u{1F682}",
    price: 1550,
    requiredLevel: 5,
    buildMinutes: 60,
    footprint: [8, 7],
    color: 14915517,
    accent: 8899775,
    description: "\u041A\u043E\u0442\u043E\u043F\u043E\u0435\u0437\u0434 \u0432 \u0433\u043E\u0440\u043E\u0434\u0435 \u0441\u0430\u043A\u0443\u0440\u044B: \u043F\u0430\u0433\u043E\u0434\u0430, \u043B\u0435\u043F\u0435\u0441\u0442\u043A\u0438 \u0438 \u0438\u0437\u0432\u0438\u043B\u0438\u0441\u0442\u044B\u0439 \u043F\u0443\u0442\u044C."
  },
  {
    id: "ride-cloud-tram",
    name: "\u0422\u0440\u0430\u043C\u0432\u0430\u0439 \u043E\u0431\u043B\u0430\u0447\u043D\u043E\u0433\u043E \u0433\u043E\u0440\u043E\u0434\u0430",
    icon: "\u{1F68B}",
    price: 2100,
    requiredLevel: 6,
    buildMinutes: 90,
    footprint: [8, 7],
    color: 9029350,
    accent: 14135280,
    description: "\u041B\u0435\u0442\u0430\u044E\u0449\u0438\u0439 \u0442\u0440\u0430\u043C\u0432\u0430\u0439 \u0441 \u0444\u043E\u043D\u0430\u0440\u0438\u043A\u0430\u043C\u0438, \u043D\u0435\u0431\u0435\u0441\u043D\u044B\u043C\u0438 \u0432\u043E\u0440\u043E\u0442\u0430\u043C\u0438 \u0438 \u043C\u044F\u0433\u043A\u0438\u043C\u0438 \u043E\u0431\u043B\u0430\u043A\u0430\u043C\u0438."
  },
  {
    id: "ride-star-carousel",
    name: "\u041A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0433\u043E\u0440\u043E\u0434\u0430 \u0441\u043E\u0437\u0432\u0435\u0437\u0434\u0438\u0439",
    icon: "\u{1F31F}",
    price: 2750,
    requiredLevel: 7,
    buildMinutes: 120,
    footprint: [7, 7],
    color: 8887527,
    accent: 16043901,
    description: "\u041F\u043E\u043B\u0443\u043C\u0435\u0441\u044F\u0446\u044B \u0432\u043C\u0435\u0441\u0442\u043E \u043A\u0440\u0435\u0441\u0435\u043B, \u0437\u043E\u043B\u043E\u0442\u044B\u0435 \u0446\u0435\u043F\u043E\u0447\u043A\u0438 \u0438 \u0432\u0440\u0430\u0449\u0430\u044E\u0449\u0438\u0439\u0441\u044F \u0437\u0432\u0451\u0437\u0434\u043D\u044B\u0439 \u043A\u0443\u043F\u043E\u043B."
  },
  {
    id: "coaster-candy-city",
    name: "\u041A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043D\u044B\u0439 \u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D",
    icon: "\u{1F36D}",
    price: 3500,
    requiredLevel: 8,
    buildMinutes: 180,
    footprint: [9, 8],
    color: 15701176,
    accent: 8574662,
    description: "\u0413\u043E\u0440\u043A\u0430 \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u044F\u043D\u0438\u0447\u043D\u044B\u0439 \u0433\u043E\u0440\u043E\u0434: \u0440\u0430\u0437\u043D\u043E\u0446\u0432\u0435\u0442\u043D\u044B\u0435 \u0440\u0435\u043B\u044C\u0441\u044B, \u043B\u0435\u0434\u0435\u043D\u0446\u043E\u0432\u044B\u0435 \u0430\u0440\u043A\u0438 \u0438 \u0432\u0435\u0441\u0451\u043B\u044B\u0435 \u0432\u0438\u0440\u0430\u0436\u0438."
  },
  {
    id: "ride-crystal-slide",
    name: "\u0422\u044E\u0431\u0438\u043D\u0433 \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0433\u043E\u0440\u043E\u0434\u0430",
    icon: "\u{1F48E}",
    price: 4400,
    requiredLevel: 9,
    buildMinutes: 240,
    footprint: [8, 8],
    color: 9162217,
    accent: 12952044,
    description: "\u0421\u0438\u044F\u044E\u0449\u0430\u044F \u0431\u0430\u0448\u043D\u044F, \u043F\u043E\u0434\u044A\u0451\u043C\u043D\u0438\u043A \u0438 \u0441\u043F\u0438\u0440\u0430\u043B\u044C\u043D\u044B\u0439 \u0432\u043E\u0434\u043D\u044B\u0439 \u0441\u043F\u0443\u0441\u043A \u043D\u0430 \u043C\u044F\u0433\u043A\u043E\u043C \u043A\u0440\u0443\u0433\u0435."
  }
];

// public/mega-ride-data.js
var MEGA_RIDES = [
  {
    id: "slide-glass-corkscrew",
    kind: "glass",
    name: "\u0425\u0440\u0443\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u0448\u0442\u043E\u0440\u043C",
    icon: "\u{1F300}",
    price: 6800,
    requiredLevel: 6,
    buildMinutes: 150,
    footprint: [22, 24],
    height: 16,
    color: 6934499,
    accent: 13148395,
    pool: [3, 7, 4.6, 3.7],
    tower: [-6, -7],
    description: "\u041E\u0433\u0440\u043E\u043C\u043D\u0430\u044F \u043F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u0430\u044F \u0442\u0440\u0443\u0431\u0430: \u0434\u0432\u0430 \u0441\u0442\u0440\u0435\u043C\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u0432\u0438\u0442\u043A\u0430, \u0432\u0438\u0434\u0438\u043C\u0430\u044F \u0432\u043E\u0434\u0430, \u043C\u044F\u0433\u043A\u0438\u0439 \u043A\u0440\u0443\u0433 \u0438 \u0431\u0438\u0440\u044E\u0437\u043E\u0432\u044B\u0439 \u0431\u0430\u0441\u0441\u0435\u0439\u043D."
  },
  {
    id: "slide-sky-cannon",
    kind: "launch",
    name: "\u041D\u0435\u0431\u0435\u0441\u043D\u0430\u044F \u0432\u043E\u0434\u043D\u0430\u044F \u043F\u0443\u0448\u043A\u0430",
    icon: "\u{1F680}",
    price: 9200,
    requiredLevel: 7,
    buildMinutes: 180,
    footprint: [26, 30],
    height: 21,
    color: 15897028,
    accent: 8313817,
    pool: [3, 8, 6, 5],
    tower: [-8, -9],
    description: "\u0420\u0430\u0437\u0433\u043E\u043D \u0441 21-\u043C\u0435\u0442\u0440\u043E\u0432\u043E\u0439 \u0431\u0430\u0448\u043D\u0438, \u043F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u044B\u0439 \u0432\u0438\u0440\u0430\u0436 \u0438 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u0439 \u0431\u0430\u043B\u043B\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0432\u044B\u043B\u0435\u0442 \u043D\u0430\u0434 \u0431\u0430\u0441\u0441\u0435\u0439\u043D\u043E\u043C \u0441 \u0431\u043E\u043B\u044C\u0448\u0438\u043C \u0432\u0441\u043F\u043B\u0435\u0441\u043A\u043E\u043C."
  },
  {
    id: "slide-titan-funnel",
    kind: "funnel",
    name: "\u0422\u0438\u0442\u0430\u043D\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0432\u043E\u0440\u043E\u043D\u043A\u0430",
    icon: "\u{1F32A}\uFE0F",
    price: 11500,
    requiredLevel: 8,
    buildMinutes: 210,
    footprint: [26, 28],
    height: 19,
    color: 11837673,
    accent: 16766592,
    pool: [0, 9, 5.7, 3.6],
    tower: [-9, -8],
    description: "\u0422\u0430 \u0441\u0430\u043C\u0430\u044F \u0433\u0438\u0433\u0430\u043D\u0442\u0441\u043A\u0430\u044F \u0447\u0430\u0448\u0430-\u0432\u043E\u0440\u043E\u043D\u043A\u0430: \u0431\u044B\u0441\u0442\u0440\u044B\u0435 \u043A\u0440\u0443\u0433\u0438 \u043F\u043E \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u043C\u0443 \u0441\u043A\u043B\u043E\u043D\u0443, \u0437\u0430\u043A\u0440\u0443\u0447\u0438\u0432\u0430\u043D\u0438\u0435 \u0432 \u0433\u043E\u0440\u043B\u043E\u0432\u0438\u043D\u0443 \u0438 \u0432\u044B\u0445\u043E\u0434 \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u044B\u0439 \u0442\u043E\u043D\u043D\u0435\u043B\u044C."
  },
  {
    id: "slide-jungle-titan",
    kind: "jungle",
    name: "\u0418\u0437\u0443\u043C\u0440\u0443\u0434\u043D\u044B\u0439 \u0432\u043E\u0434\u043E\u043F\u0430\u0434 \u0442\u0438\u0442\u0430\u043D\u043E\u0432",
    icon: "\u{1F3DD}\uFE0F",
    price: 13800,
    requiredLevel: 9,
    buildMinutes: 240,
    footprint: [28, 28],
    height: 19,
    color: 6867374,
    accent: 15978126,
    pool: [3, 8, 7, 4.5],
    tower: [-8, -8],
    description: "\u0426\u0435\u043B\u044B\u0439 \u0442\u0440\u043E\u043F\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0441: \u0441\u043A\u0430\u043B\u0430, \u043F\u0430\u043B\u044C\u043C\u044B, \u043A\u0430\u0441\u043A\u0430\u0434\u043D\u044B\u0439 \u0432\u043E\u0434\u043E\u043F\u0430\u0434, \u0438\u0437\u0443\u043C\u0440\u0443\u0434\u043D\u044B\u0439 \u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D \u0438 \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u043F\u0440\u0443\u0434 \u0432\u043D\u0438\u0437\u0443."
  },
  {
    id: "slide-rainbow-tsunami",
    kind: "racer",
    name: "\u0420\u0430\u0434\u0443\u0436\u043D\u043E\u0435 \u0446\u0443\u043D\u0430\u043C\u0438",
    icon: "\u{1F308}",
    price: 15200,
    requiredLevel: 10,
    buildMinutes: 270,
    footprint: [26, 32],
    height: 22,
    color: 15835598,
    accent: 9560016,
    pool: [1, 10, 8, 4],
    tower: [-7, -11],
    description: "\u0428\u0435\u0441\u0442\u044C \u044F\u0440\u043A\u0438\u0445 \u0432\u043E\u043B\u043D\u0438\u0441\u0442\u044B\u0445 \u0434\u043E\u0440\u043E\u0436\u0435\u043A \u0441 \u0432\u0435\u0440\u0448\u0438\u043D\u044B \u043E\u0433\u0440\u043E\u043C\u043D\u043E\u0439 \u0431\u0430\u0448\u043D\u0438, \u0440\u0435\u0437\u043A\u0438\u0435 \u0443\u0441\u043A\u043E\u0440\u0435\u043D\u0438\u044F \u0438 \u0432\u0435\u0441\u0451\u043B\u044B\u0439 \u043F\u0440\u044B\u0436\u043E\u043A \u043D\u0430 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0439 \u0432\u043E\u043B\u043D\u0435."
  },
  {
    id: "slide-abyss-capsule",
    kind: "drop",
    name: "\u041F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u0430\u044F \u0431\u0435\u0437\u0434\u043D\u0430",
    icon: "\u{1F48E}",
    price: 17800,
    requiredLevel: 11,
    buildMinutes: 300,
    footprint: [24, 28],
    height: 28,
    color: 9619180,
    accent: 15971796,
    pool: [3, 8, 6.5, 4.4],
    tower: [-7, -8],
    description: "\u041F\u0430\u043D\u043E\u0440\u0430\u043C\u043D\u0430\u044F \u0441\u0442\u0430\u0440\u0442\u043E\u0432\u0430\u044F \u043A\u0430\u043F\u0441\u0443\u043B\u0430 \u043D\u0430 \u0432\u044B\u0441\u043E\u0442\u0435 28 \u043C\u0435\u0442\u0440\u043E\u0432, \u043F\u043E\u0447\u0442\u0438 \u0432\u0435\u0440\u0442\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u043F\u0430\u0434\u0435\u043D\u0438\u0435 \u0438 \u0441\u043A\u043E\u0440\u043E\u0441\u0442\u043D\u043E\u0439 \u0441\u0442\u0435\u043A\u043B\u044F\u043D\u043D\u044B\u0439 \u0432\u0438\u0440\u0430\u0436."
  },
  {
    id: "dive-triple-sky",
    kind: "dive",
    name: "\u0412\u044B\u0448\u043A\u0430 \u0442\u0440\u0451\u0445 \u043D\u0435\u0431\u0435\u0441 \xB7 10 / 20 / 30 \u043C",
    icon: "\u{1FA82}",
    price: 12400,
    requiredLevel: 8,
    buildMinutes: 210,
    footprint: [26, 28],
    height: 30,
    color: 9353957,
    accent: 16766346,
    pool: [3, 7, 6.8, 5.7],
    tower: [-7, -7],
    description: "\u041E\u0434\u043D\u0430 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0430\u044F 30-\u043C\u0435\u0442\u0440\u043E\u0432\u0430\u044F \u0432\u044B\u0448\u043A\u0430 \u0441 \u0442\u0440\u0435\u043C\u044F \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0430\u043C\u0438: \u043A\u043E\u0442\u0438\u043A \u043F\u043E\u0434\u043D\u0438\u043C\u0430\u0435\u0442\u0441\u044F \u0438 \u043F\u043E \u043E\u0447\u0435\u0440\u0435\u0434\u0438 \u043F\u0440\u044B\u0433\u0430\u0435\u0442 \u0441 10, 20 \u0438 30 \u043C\u0435\u0442\u0440\u043E\u0432. \u0411\u0440\u044B\u0437\u0433\u0438, \u0443\u0434\u0438\u0432\u043B\u0451\u043D\u043D\u044B\u0435 \u0433\u043B\u0430\u0437\u043A\u0438 \u0438 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0432\u044B\u0445\u043E\u0434."
  },
  {
    id: "coaster-thunder-loop",
    kind: "loop",
    name: "\u0413\u0440\u043E\u043C\u043E\u0432\u0430\u044F \u043F\u0435\u0442\u043B\u044F",
    icon: "\u{1F3A2}",
    price: 16500,
    requiredLevel: 10,
    buildMinutes: 270,
    footprint: [30, 28],
    height: 25,
    color: 6473950,
    accent: 16764793,
    description: "\u0412\u044B\u0441\u043E\u043A\u0438\u0439 \u0446\u0435\u043F\u043D\u043E\u0439 \u043F\u043E\u0434\u044A\u0451\u043C, \u043E\u0442\u0432\u0435\u0441\u043D\u044B\u0439 \u0440\u0430\u0437\u0433\u043E\u043D \u0438 \u0431\u043E\u043B\u044C\u0448\u0430\u044F \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0430\u044F \u043C\u0451\u0440\u0442\u0432\u0430\u044F \u043F\u0435\u0442\u043B\u044F. \u041A\u043E\u0442\u0438\u043A \u0438 \u0432\u0430\u0433\u043E\u043D\u0447\u0438\u043A \u0432\u043C\u0435\u0441\u0442\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0440\u0430\u0447\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u043D\u0430 \u0440\u0435\u043B\u044C\u0441\u0430\u0445."
  },
  {
    id: "coaster-aurora-rift",
    kind: "corkscrew",
    name: "\u0420\u0430\u0437\u043B\u043E\u043C \u0441\u0435\u0432\u0435\u0440\u043D\u043E\u0433\u043E \u0441\u0438\u044F\u043D\u0438\u044F",
    icon: "\u{1F30C}",
    price: 20500,
    requiredLevel: 12,
    buildMinutes: 330,
    footprint: [32, 28],
    height: 27,
    color: 10201580,
    accent: 9363915,
    description: "\u0421\u0438\u044F\u044E\u0449\u0438\u0435 \u0434\u0432\u043E\u0439\u043D\u044B\u0435 \u0440\u0435\u043B\u044C\u0441\u044B, \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u0430\u0440\u043A\u0438, \u0431\u044B\u0441\u0442\u0440\u044B\u0435 \u0432\u0438\u0440\u0430\u0436\u0438 \u0438 \u0434\u0432\u043E\u0439\u043D\u043E\u0439 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0448\u0442\u043E\u043F\u043E\u0440 \u0441 \u0442\u043E\u0447\u043D\u043E\u0439 \u043F\u043E\u0441\u0430\u0434\u043A\u043E\u0439 \u0432 \u0432\u0430\u0433\u043E\u043D\u0447\u0438\u043A\u0435."
  },
  {
    id: "coaster-dragon-titan",
    kind: "dragon",
    name: "\u0414\u0440\u0430\u043A\u043E\u043D\u0438\u0439 \u0442\u0438\u0442\u0430\u043D",
    icon: "\u{1F409}",
    price: 24800,
    requiredLevel: 14,
    buildMinutes: 360,
    footprint: [34, 30],
    height: 30,
    color: 15180217,
    accent: 16764558,
    description: "\u0422\u0440\u0438\u0434\u0446\u0430\u0442\u0438\u043C\u0435\u0442\u0440\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0448\u0438\u043D\u0430, \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u0439 \u0437\u043E\u043B\u043E\u0442\u043E\u0439 \u0434\u0440\u0430\u043A\u043E\u043D, \u043F\u0438\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u043F\u0430\u0441\u0442\u044C \u0441\u043A\u0430\u043B\u044B \u0438 \u0441\u043A\u043E\u0440\u043E\u0441\u0442\u043D\u0430\u044F \u0432\u043E\u0437\u0434\u0443\u0448\u043D\u0430\u044F \u043F\u0435\u0442\u043B\u044F \u0432 \u0434\u0440\u0430\u043A\u043E\u043D\u044C\u0435\u043C \u0432\u0430\u0433\u043E\u043D\u0447\u0438\u043A\u0435."
  }
].map((spec) => ({
  ...spec,
  category: "rides",
  actions: ["ride"],
  rarity: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u043E\u0435",
  fixedPrice: true,
  mega: true
}));

// public/cotton-data.js
var COTTON_RIDES = [
  {
    id: "ride-cupcake-wheel",
    name: "\u041A\u043E\u043B\u0435\u0441\u043E \u0441\u0430\u0445\u0430\u0440\u043D\u044B\u0445 \u043A\u0435\u043A\u0441\u043E\u0432",
    icon: "\u{1F3A1}",
    footprint: [10, 6],
    price: 2600,
    requiredLevel: 8,
    buildMinutes: 180,
    description: "\u0417\u043E\u043B\u043E\u0442\u0430\u044F \u0437\u0432\u0435\u0437\u0434\u0430, \u0434\u0435\u0441\u044F\u0442\u044C \u043A\u0435\u043A\u0441\u043E\u0432-\u043A\u0430\u0431\u0438\u043D\u043E\u043A \u0438 \u0440\u043E\u0437\u043E\u0432\u044B\u0435 \u043E\u0433\u043E\u043D\u044C\u043A\u0438 \u043D\u0430\u0434 \u0441\u043B\u0430\u0434\u043A\u0438\u043C \u043E\u0441\u0442\u0440\u043E\u0432\u043E\u043C."
  },
  {
    id: "coaster-piglet-express",
    name: "\u0425\u0440\u044E-\u044D\u043A\u0441\u043F\u0440\u0435\u0441\u0441 \u0441\u043B\u0430\u0434\u043A\u043E\u0439 \u0432\u0430\u0442\u044B",
    icon: "\u{1F3A2}",
    footprint: [16, 9],
    price: 4800,
    requiredLevel: 12,
    buildMinutes: 360,
    description: "\u041F\u043E\u0435\u0437\u0434-\u0445\u0440\u044E\u0448\u043A\u0430 \u043C\u0447\u0438\u0442\u0441\u044F \u043F\u043E \u0442\u0440\u0451\u043C \u0431\u043E\u043B\u044C\u0448\u0438\u043C \u0432\u043E\u043B\u043D\u0430\u043C \u043A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043D\u044B\u0445 \u0440\u0435\u043B\u044C\u0441\u043E\u0432."
  },
  {
    id: "ride-sugar-teacups",
    name: "\u0427\u0430\u0439\u043D\u044B\u0435 \u0447\u0430\u0448\u0435\u0447\u043A\u0438 \u0441\u0435\u0440\u0434\u0435\u0447\u0435\u043A",
    icon: "\u2615",
    footprint: [7, 7],
    price: 1800,
    requiredLevel: 6,
    buildMinutes: 90,
    description: "\u041F\u0430\u0441\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0447\u0430\u0448\u0435\u0447\u043A\u0438 \u043A\u0440\u0443\u0436\u0430\u0442\u0441\u044F \u043D\u0430 \u0441\u0430\u0445\u0430\u0440\u043D\u043E\u043C \u0431\u043B\u044E\u0434\u0446\u0435 \u2014 \u043A\u0430\u0436\u0434\u0430\u044F \u0441\u043E \u0441\u0432\u043E\u0435\u0439 \u0443\u043B\u044B\u0431\u0447\u0438\u0432\u043E\u0439 \u0445\u0440\u044E\u0448\u043A\u043E\u0439."
  },
  {
    id: "slide-marshmallow",
    name: "\u0417\u0435\u0444\u0438\u0440\u043D\u044B\u0439 \u0432\u043E\u0434\u043D\u044B\u0439 \u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D",
    icon: "\u{1F308}",
    footprint: [8, 10],
    price: 3200,
    requiredLevel: 9,
    buildMinutes: 240,
    description: "\u0422\u0440\u0438 \u0436\u0435\u043C\u0447\u0443\u0436\u043D\u044B\u0435 \u0434\u043E\u0440\u043E\u0436\u043A\u0438, \u0431\u0440\u044B\u0437\u0433\u0438 \u0440\u043E\u0437\u043E\u0432\u043E\u0439 \u0432\u043E\u0434\u044B \u0438 \u043C\u044F\u0433\u043A\u0438\u0439 \u043F\u0440\u044B\u0436\u043E\u043A \u0432\u043D\u0438\u0437\u0443."
  },
  ...[
    ["ride-pig-rose", "\u0420\u043E\u0437\u043E\u0447\u043A\u0430 \xB7 \u0441\u0430\u0445\u0430\u0440\u043D\u0430\u044F \u0445\u0440\u044E\u0448\u043A\u0430", "\u{1F437}"],
    ["ride-pig-peach", "\u041F\u0435\u0440\u0441\u0438\u043A \xB7 \u043F\u044F\u0442\u043D\u0438\u0441\u0442\u0430\u044F \u0445\u0440\u044E\u0448\u043A\u0430", "\u{1F43D}"],
    ["ride-pig-lilac", "\u0417\u0435\u0444\u0438\u0440\u043A\u0430 \xB7 \u043B\u0438\u043B\u043E\u0432\u0430\u044F \u0445\u0440\u044E\u0448\u043A\u0430", "\u{1F49C}"]
  ].map(([id, name, icon]) => ({
    id,
    name,
    icon,
    footprint: [5, 5],
    price: 1100,
    requiredLevel: 5,
    buildMinutes: 60,
    description: "\u0416\u0438\u0432\u0430\u044F \u0434\u043E\u0431\u0440\u0430\u044F \u0445\u0440\u044E\u0448\u043A\u0430: \u0442\u043E\u043F\u0430\u0435\u0442 \u043A\u043E\u043F\u044B\u0442\u0446\u0430\u043C\u0438, \u0448\u0435\u0432\u0435\u043B\u0438\u0442 \u0443\u0448\u043A\u0430\u043C\u0438 \u0438 \u043A\u0430\u0442\u0430\u0435\u0442 \u0427\u0438\u0447\u0438 \u043D\u0430 \u0441\u0432\u043E\u0435\u0439 \u0441\u043F\u0438\u043D\u043A\u0435."
  }))
];
var COTTON_OBJECTS = [
  { id: "cotton-wheel", type: "ride-cupcake-wheel", x: -15, z: -6 },
  { id: "cotton-express", type: "coaster-piglet-express", x: 5, z: -16 },
  { id: "cotton-teacups", type: "ride-sugar-teacups", x: 16, z: 0 },
  { id: "cotton-slide", type: "slide-marshmallow", x: 13, z: 11 },
  { id: "cotton-pig-rose", type: "ride-pig-rose", x: -17, z: 10 },
  { id: "cotton-pig-peach", type: "ride-pig-peach", x: -12, z: 16 },
  { id: "cotton-pig-lilac", type: "ride-pig-lilac", x: 17, z: -8 }
].map((o) => ({ ...o, biome: "clockwork" }));
var COTTON_POOLS = [
  {
    id: "lake-clockwork",
    x: -0.5,
    z: 16,
    rx: 8,
    rz: 4.2,
    y: 0,
    name: "\u0420\u043E\u0437\u043E\u0432\u0430\u044F \u0437\u0435\u0444\u0438\u0440\u043D\u0430\u044F \u043B\u0430\u0433\u0443\u043D\u0430"
  },
  {
    id: "lake-clockwork-upper",
    x: -5,
    z: -14,
    rx: 4,
    rz: 2,
    y: 2.4,
    name: "\u0412\u0435\u0440\u0445\u043D\u0438\u0439 \u043A\u043B\u0443\u0431\u043D\u0438\u0447\u043D\u044B\u0439 \u043A\u0430\u0441\u043A\u0430\u0434"
  },
  {
    id: "lake-clockwork-cascade",
    x: -16,
    z: 0,
    rx: 3,
    rz: 2,
    y: 1.2,
    name: "\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u0430\u044F \u0440\u043E\u0437\u043E\u0432\u0430\u044F \u0437\u0430\u0432\u043E\u0434\u044C"
  }
];
function cottonReservations() {
  return [
    // Prevent new buildings from straddling the stepped cake terraces.
    { x: 0, z: -11, w: 40, d: 0.4 },
    { x: -11, z: -4, w: 0.4, d: 14 },
    ...COTTON_OBJECTS.map((o) => {
      const s = COTTON_RIDES.find((r) => r.id === o.type);
      return { x: o.x, z: o.z, w: s.footprint[0], d: s.footprint[1] };
    }),
    ...COTTON_POOLS.map((p) => ({
      ...p,
      w: p.rx * 2 + 0.4,
      d: p.rz * 2 + 0.4,
      rx: p.rx + 0.2,
      rz: p.rz + 0.2
    }))
  ];
}

// public/spa-data.js
var SPA_RADIUS = 11.65 * Math.sqrt(3);
var SPA_POOL = {
  id: "lake-water",
  x: 0,
  z: 1,
  rx: 6.5,
  rz: 6.2,
  y: 0
};
var SPA_JACUZZI = {
  id: "spa-jacuzzi",
  x: 14.1,
  z: 4.5,
  rx: 3.2,
  rz: 3.2,
  y: 0.3
};
var SPA_OBJECTS = [
  {
    ...SPA_POOL,
    type: "swim-lagoon",
    surfaceY: 0.155,
    name: "Cat SPA \xB7 \u0432\u0435\u043B\u0438\u043A\u0438\u0439 \u0431\u0430\u0441\u0435\u0439\u043D",
    actions: ["swim"]
  },
  {
    id: "spa-lounge",
    type: "bed",
    x: -14.2,
    z: 0,
    name: "\u0421\u043F\u0456\u043B\u044C\u043D\u0438\u0439 \u043C\u2019\u044F\u043A\u0438\u0439 \u043B\u0435\u0436\u0430\u043A",
    footprint: [7.2, 6.4]
  },
  { ...SPA_JACUZZI, type: "bed", name: "\u0422\u0435\u043F\u043B\u0435 \u0434\u0436\u0430\u043A\u0443\u0437\u0456", footprint: [6.8, 6.8] },
  {
    id: "spa-bar",
    type: "cat-barista",
    x: 9.2,
    z: -13,
    name: "Cat SPA \xB7 \u0431\u0430\u0440 \u0431\u0456\u043B\u044F \u0431\u0430\u0441\u0435\u0439\u043D\u0443",
    actions: ["eat"],
    footprint: [8, 4]
  }
].map((o) => ({ ...o, biome: "water" }));
function spaReservations() {
  return [
    { ...SPA_POOL, rx: 7, rz: 6.7, w: 14, d: 13.4 },
    { x: 0, z: 8.8, w: 3.8, d: 3.6 },
    { x: 0, z: 15.4, w: 7, d: 2.5 },
    ...SPA_OBJECTS.filter((o) => o.id !== "lake-water").map((o) => ({
      x: o.x,
      z: o.z,
      w: o.footprint[0] + 0.6,
      d: o.footprint[1] + 0.6
    }))
  ];
}
var SPA_SEATS = {
  "spa-lounge": [-2.2, 0, 2.2].flatMap(
    (x, column) => [-1.15, 1.15].map((z, row2) => ({
      x: -14.2 + x,
      z,
      y: 0.91,
      yaw: 0.35 + column * 0.2,
      column,
      row: row2
    }))
  ),
  "lake-water": [-2.6, 2.6].flatMap(
    (x) => [-2.2, 2.2].map((z) => ({ x, z: z + 1, y: -0.28, yaw: 0 }))
  ),
  "spa-jacuzzi": Array.from({ length: 4 }, (_, i) => {
    const a = Math.PI / 4 + i * Math.PI / 2;
    return {
      x: 14.1 + Math.sin(a) * 1.8,
      z: 4.5 + Math.cos(a) * 1.8,
      y: 0.02,
      yaw: a
    };
  }),
  "spa-bar": [5.9, 8.1, 10.3, 12.5].map((x) => ({
    x,
    z: -8.2,
    y: 0.76,
    yaw: Math.PI
  }))
};

// public/game-data.js
var BIOMES = [
  {
    id: "moon",
    name: "\u041B\u0443\u043D\u043D\u044B\u0439 \u0441\u0430\u0434",
    subtitle: "\u0414\u043E\u043C \u0427\u0438\u0447\u0438 \xB7 \u0437\u0432\u0451\u0437\u0434\u044B \u0438 \u043C\u044F\u0433\u043A\u0438\u0439 \u043C\u043E\u0445",
    icon: "\u263E",
    price: 0,
    center: [0, 0],
    ground: 5401448,
    edge: 3161428,
    foliage: 8428945,
    accent: 15255441
  },
  {
    id: "autumn",
    name: "\u041C\u0435\u0434\u043E\u0432\u0430\u044F \u043E\u0441\u0435\u043D\u044C",
    subtitle: "\u0417\u043E\u043B\u043E\u0442\u044B\u0435 \u043B\u0438\u0441\u0442\u044C\u044F \u0438 \u0433\u0440\u0438\u0431\u043D\u044B\u0435 \u0434\u043E\u043C\u0438\u043A\u0438",
    icon: "\u{1F341}",
    price: 240,
    center: [-27, 0],
    ground: 9469025,
    edge: 5325656,
    foliage: 14194527,
    accent: 16043401
  },
  {
    id: "winter",
    name: "\u0421\u043D\u0435\u0436\u043D\u0430\u044F \u0441\u043A\u0430\u0437\u043A\u0430",
    subtitle: "\u0422\u0438\u0445\u0438\u0439 \u0441\u043D\u0435\u0433 \u0438 \u0441\u0438\u044F\u043D\u0438\u0435 \u0441\u0435\u0432\u0435\u0440\u043D\u044B\u0445 \u043E\u0433\u043D\u0435\u0439",
    icon: "\u2744",
    price: 380,
    center: [27, 0],
    ground: 13162716,
    edge: 5399675,
    foliage: 10207169,
    accent: 12446707
  },
  {
    id: "beach",
    name: "\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u044B\u0439 \u043F\u043B\u044F\u0436",
    subtitle: "\u0420\u0430\u043A\u0443\u0448\u043A\u0438, \u043F\u0430\u043B\u044C\u043C\u044B \u0438 \u0442\u0451\u043F\u043B\u044B\u0439 \u043F\u0440\u0438\u0431\u043E\u0439",
    icon: "\u{1F41A}",
    price: 300,
    center: [0, 27],
    ground: 13810578,
    edge: 7760512,
    foliage: 8629135,
    accent: 16113082
  },
  {
    id: "water",
    name: "Cat SPA",
    subtitle: "\u0411\u0430\u0441\u0435\u0439\u043D, \u0442\u0435\u043F\u043B\u0435 \u0434\u0436\u0430\u043A\u0443\u0437\u0456, \u0441\u043F\u0456\u043B\u044C\u043D\u0438\u0439 \u043B\u0435\u0436\u0430\u043A \u0456 \u043A\u043E\u0442\u044F\u0447\u0438\u0439 \u0431\u0430\u0440",
    radius: SPA_RADIUS,
    arrival: [0, 15.6],
    icon: "\u{1FAB7}",
    price: 420,
    center: [0, -27],
    ground: 7382947,
    edge: 3955054,
    foliage: 10206128,
    accent: 10479317
  },
  {
    id: "wizard",
    name: "\u0412\u0435\u0434\u044C\u043C\u0438\u043D \u043B\u0435\u0441",
    subtitle: "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u043B\u044B, \u0437\u0430\u043A\u043B\u0438\u043D\u0430\u043D\u0438\u044F \u0438 \u043B\u0443\u043D\u043D\u044B\u0435 \u0433\u0440\u0438\u0431\u044B",
    icon: "\u{1F52E}",
    price: 550,
    center: [-27, -27],
    ground: 6707060,
    edge: 3944789,
    foliage: 10257075,
    accent: 13085937
  },
  {
    id: "summer",
    name: "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0430 \u043B\u0430\u0433\u0443\u043D\u0430 \u043A\u0430\u043F\u0456\u0431\u0430\u0440",
    subtitle: "\u0411\u043B\u0430\u043A\u0438\u0442\u043D\u0456 \u043A\u0430\u0441\u043A\u0430\u0434\u0438, \u0441\u043E\u043A\u043E\u0432\u0438\u0442\u0456 \u0434\u0436\u0443\u043D\u0433\u043B\u0456 \u0439 \u043F\u0443\u0445\u043A\u0435\u043D\u044C\u043A\u0456 \u043A\u0430\u043F\u0456\u0431\u0430\u0440\u0438",
    radius: CAPYBARA_RADIUS,
    arrival: [-11, 10],
    icon: "\u{1F334}",
    price: 340,
    center: [-27, 27],
    ground: 8436045,
    edge: 5463893,
    foliage: 6928953,
    accent: 15979676
  },
  {
    id: "nature",
    name: "\u0418\u0437\u0443\u043C\u0440\u0443\u0434\u043D\u0430\u044F \u0440\u043E\u0449\u0430",
    subtitle: "\u041F\u0430\u043F\u043E\u0440\u043E\u0442\u043D\u0438\u043A\u0438, \u043B\u0435\u0441\u043D\u044B\u0435 \u043C\u043E\u0441\u0442\u044B \u0438 \u0434\u0440\u0443\u0437\u044C\u044F",
    icon: "\u{1F33F}",
    price: 460,
    center: [27, 27],
    ground: 5732710,
    edge: 3165005,
    foliage: 8233351,
    accent: 12113323
  },
  {
    id: "sakura",
    name: "Chill Land",
    subtitle: "\u0417\u0430\u0442\u0438\u0448\u043D\u0456 \u043E\u0441\u043E\u0431\u043D\u044F\u043A\u0438, \u0441\u043F\u0456\u043B\u044C\u043D\u0456 \u0441\u043D\u0438 \u0442\u0430 \u0442\u0435\u043F\u043B\u0456 \u0432\u0430\u043D\u043D\u0438 \u0441\u0435\u0440\u0435\u0434 \u043A\u0432\u0456\u0442\u0456\u0432",
    icon: "\u{1F3E1}",
    price: 580,
    center: [-54, 0],
    ground: 10993034,
    edge: 8749963,
    foliage: 8166237,
    accent: 16767406
  },
  {
    id: "clouds",
    name: "\u041E\u0431\u043B\u0430\u0447\u043D\u043E\u0435 \u043A\u043E\u0440\u043E\u043B\u0435\u0432\u0441\u0442\u0432\u043E",
    subtitle: "\u0411\u0435\u043B\u044B\u0435 \u043E\u0431\u043B\u0430\u043A\u0430 \u0438 \u0437\u043E\u043B\u043E\u0442\u044B\u0435 \u0432\u043E\u0437\u0434\u0443\u0448\u043D\u044B\u0435 \u0434\u0432\u043E\u0440\u0446\u044B",
    icon: "\u2601",
    price: 720,
    center: [54, 0],
    ground: 13421275,
    edge: 7894422,
    foliage: 13814505,
    accent: 16772546
  },
  {
    id: "desert",
    name: "\u041A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043D\u044B\u0435 \u0434\u044E\u043D\u044B",
    subtitle: "\u0417\u0432\u0451\u0437\u0434\u043D\u044B\u0439 \u043E\u0430\u0437\u0438\u0441 \u0438 \u0441\u043A\u0430\u0437\u043A\u0438 \u0442\u0451\u043F\u043B\u044B\u0445 \u043F\u0435\u0441\u043A\u043E\u0432",
    icon: "\u{1F3DC}",
    price: 520,
    center: [0, 54],
    ground: 13146483,
    edge: 8082278,
    foliage: 11182720,
    accent: 16111010
  },
  {
    id: "stars",
    name: "\u0417\u0432\u0451\u0437\u0434\u043D\u0430\u044F \u0434\u043E\u043B\u0438\u043D\u0430",
    subtitle: "\u041D\u043E\u0447\u043D\u0430\u044F \u043C\u0430\u0433\u0438\u044F \u0438 \u043F\u0440\u0430\u0437\u0434\u043D\u0438\u043A \u0441\u0440\u0435\u0434\u0438 \u043E\u0431\u043B\u0430\u043A\u043E\u0432",
    icon: "\u2726",
    price: 650,
    center: [27, -27],
    ground: 6513791,
    edge: 3421522,
    foliage: 9476285,
    accent: 15191290
  }
];
var item = (id, name, category, price, icon, description, footprint2, actions) => ({ id, name, category, price, icon, description, footprint: footprint2, actions });
var CATALOG = [
  item(
    "yarn",
    "\u041A\u043B\u0443\u0431\u043E\u0447\u0435\u043A \u043B\u0443\u043D\u044B",
    "toys",
    35,
    "\u{1F9F6}",
    "\u0427\u0438\u0447\u0438 \u0433\u043E\u043D\u044F\u0435\u0442\u0441\u044F \u0437\u0430 \u043C\u044F\u0433\u043A\u0438\u043C \u0441\u0438\u044F\u044E\u0449\u0438\u043C \u043A\u043B\u0443\u0431\u043A\u043E\u043C.",
    [2, 2],
    ["play"]
  ),
  item(
    "mouse",
    "\u041C\u044B\u0448\u043A\u0430 \u0441 \u0441\u0435\u043A\u0440\u0435\u0442\u043E\u043C",
    "toys",
    45,
    "\u{1F42D}",
    "\u041C\u0430\u043B\u0435\u043D\u044C\u043A\u0430\u044F \u0437\u0430\u0432\u043E\u0434\u043D\u0430\u044F \u043C\u044B\u0448\u044C \u0434\u043B\u044F \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u043E\u0445\u043E\u0442\u044B.",
    [2, 2],
    ["play"]
  ),
  item(
    "feather",
    "\u041F\u0435\u0440\u043E \u0444\u0435\u043D\u0438\u043A\u0441\u0430",
    "toys",
    55,
    "\u{1FAB6}",
    "\u041F\u0440\u044B\u0433\u043D\u0443\u0442\u044C, \u043F\u043E\u0439\u043C\u0430\u0442\u044C, \u043E\u0442\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0438 \u0441\u043D\u043E\u0432\u0430 \u043F\u043E\u0439\u043C\u0430\u0442\u044C.",
    [2, 2],
    ["play"]
  ),
  item(
    "tunnel",
    "\u0422\u0443\u043D\u043D\u0435\u043B\u044C \u043F\u0440\u0438\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0439",
    "toys",
    75,
    "\u{1F300}",
    "\u041D\u044B\u0440\u043D\u0443\u0442\u044C \u0432 \u043E\u0434\u0438\u043D \u043A\u043E\u043D\u0435\u0446 \u0438 \u0432\u044B\u0441\u043A\u043E\u0447\u0438\u0442\u044C \u0441 \u0434\u0440\u0443\u0433\u043E\u0433\u043E.",
    [3, 2],
    ["play"]
  ),
  item(
    "scratch",
    "\u0411\u0430\u0448\u043D\u044F \u043A\u043E\u0433\u043E\u0442\u043A\u043E\u0432",
    "toys",
    65,
    "\u{1F43E}",
    "\u0423\u044E\u0442\u043D\u0430\u044F \u0431\u0430\u0448\u0435\u043D\u043A\u0430: \u0437\u0430\u0431\u0440\u0430\u0442\u044C\u0441\u044F \u0438 \u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0432\u043B\u0430\u0434\u0435\u043D\u0438\u044F.",
    [2, 2],
    ["play"]
  ),
  item(
    "trampoline",
    "\u041E\u0431\u043B\u0430\u0447\u043D\u044B\u0439 \u0431\u0430\u0442\u0443\u0442",
    "rides",
    115,
    "\u2601",
    "\u041C\u044F\u0433\u043A\u0438\u0435 \u043F\u0440\u044B\u0436\u043A\u0438 \u043F\u043E\u0447\u0442\u0438 \u0434\u043E \u0437\u0432\u0451\u0437\u0434.",
    [3, 3],
    ["ride"]
  ),
  item(
    "swing",
    "\u041B\u0443\u043D\u043D\u044B\u0435 \u043A\u0430\u0447\u0435\u043B\u0438",
    "rides",
    100,
    "\u263E",
    "\u041F\u043B\u0430\u0432\u043D\u043E \u043A\u0430\u0447\u0430\u0442\u044C\u0441\u044F \u043D\u0430 \u0430\u0440\u043A\u0435 \u0438\u0437 \u043B\u0443\u043D\u043D\u043E\u0433\u043E \u0434\u0435\u0440\u0435\u0432\u0430.",
    [3, 3],
    ["ride"]
  ),
  item(
    "carousel",
    "\u041A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0441\u043E\u0437\u0432\u0435\u0437\u0434\u0438\u0439",
    "rides",
    180,
    "\u{1F3A0}",
    "\u041A\u0440\u0443\u0442\u0438\u0442\u044C\u0441\u044F \u0441\u0440\u0435\u0434\u0438 \u0437\u043E\u043B\u043E\u0442\u044B\u0445 \u0437\u0432\u0451\u0437\u0434 \u0438 \u0434\u0440\u0443\u0437\u0435\u0439.",
    [4, 4],
    ["ride"]
  ),
  item(
    "coaster",
    "\u0410\u043C\u0435\u0440\u0438\u043A\u0430\u043D\u0441\u043A\u0438\u0435 \u0433\u043E\u0440\u043A\u0438",
    "rides",
    260,
    "\u{1F3A2}",
    "\u041D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u0439 \u0438\u0437\u0432\u0438\u043B\u0438\u0441\u0442\u044B\u0439 \u043F\u0443\u0442\u044C \u0441 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0439 \u0432\u0430\u0433\u043E\u043D\u0435\u0442\u043A\u043E\u0439.",
    [6, 5],
    ["ride"]
  ),
  item(
    "waterslide",
    "\u0413\u043E\u0440\u043A\u0430 \u0440\u0443\u0441\u0430\u043B\u043E\u0447\u043A\u0438",
    "rides",
    220,
    "\u{1F6DD}",
    "\u0412\u0437\u043E\u0431\u0440\u0430\u0442\u044C\u0441\u044F \u043D\u0430 \u0431\u0430\u0448\u043D\u044E \u0438 \u0441\u043A\u043E\u043B\u044C\u0437\u043D\u0443\u0442\u044C \u0432 \u043C\u044F\u0433\u043A\u0438\u0439 \u0431\u0430\u0441\u0441\u0435\u0439\u043D.",
    [5, 5],
    ["ride"]
  ),
  item(
    "ferris",
    "\u041A\u043E\u043B\u0435\u0441\u043E \u0436\u0435\u043B\u0430\u043D\u0438\u0439",
    "rides",
    240,
    "\u{1F3A1}",
    "\u041F\u043E\u0434\u043D\u044F\u0442\u044C\u0441\u044F \u0432 \u043A\u0430\u0431\u0438\u043D\u043A\u0435 \u0438 \u043F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u043D\u0430 \u0432\u0435\u0441\u044C \u043C\u0438\u0440.",
    [4, 4],
    ["ride"]
  ),
  item(
    "teacup",
    "\u0427\u0430\u0439\u043D\u0430\u044F \u0447\u0430\u0448\u0435\u0447\u043A\u0430",
    "rides",
    135,
    "\u{1FAD6}",
    "\u041A\u0440\u0443\u0436\u0438\u0442\u044C\u0441\u044F \u0432 \u043E\u0433\u0440\u043E\u043C\u043D\u043E\u0439 \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u043E\u0439 \u0447\u0430\u0448\u043A\u0435.",
    [3, 3],
    ["ride"]
  ),
  item(
    "train",
    "\u041A\u043E\u0442\u043E\u043F\u043E\u0435\u0437\u0434",
    "transport",
    210,
    "\u{1F682}",
    "\u0415\u0445\u0430\u0442\u044C \u043F\u043E \u043A\u0440\u0443\u0433\u043E\u0432\u043E\u0439 \u0436\u0435\u043B\u0435\u0437\u043D\u043E\u0439 \u0434\u043E\u0440\u043E\u0433\u0435.",
    [5, 5],
    ["ride"]
  ),
  item(
    "boat",
    "\u041B\u043E\u0434\u043E\u0447\u043A\u0430-\u043B\u0438\u0441\u0442\u0438\u043A",
    "transport",
    120,
    "\u{1F343}",
    "\u041F\u043B\u0430\u0432\u0430\u0442\u044C \u0432 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u043C \u043F\u0440\u0443\u0434\u0438\u043A\u0435 \u043F\u043E\u0434 \u0441\u0432\u0435\u0442\u043B\u044F\u0447\u043A\u0430\u043C\u0438.",
    [4, 3],
    ["ride"]
  ),
  item(
    "balloon",
    "\u0412\u043E\u0437\u0434\u0443\u0448\u043D\u044B\u0439 \u0448\u0430\u0440",
    "transport",
    200,
    "\u{1F388}",
    "\u041F\u043E\u0434\u043D\u044F\u0442\u044C\u0441\u044F \u043D\u0430\u0434 \u043E\u0441\u0442\u0440\u043E\u0432\u043E\u043C \u0432 \u0443\u044E\u0442\u043D\u043E\u0439 \u043A\u043E\u0440\u0437\u0438\u043D\u0435.",
    [3, 3],
    ["ride"]
  ),
  item(
    "broom",
    "\u041C\u0435\u0442\u043B\u0430 \u043A\u043E\u0442\u043E\u0432\u0435\u0434\u044C\u043C\u044B",
    "transport",
    150,
    "\u{1F9F9}",
    "\u041F\u043E\u043B\u0451\u0442 \u043F\u043E \u043A\u0440\u0443\u0433\u0443: \u0427\u0438\u0447\u0438 \u0442\u0435\u043F\u0435\u0440\u044C \u043D\u0435\u043C\u043D\u043E\u0433\u043E \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u0438\u0446\u0430.",
    [4, 4],
    ["ride"]
  ),
  item(
    "scooter",
    "\u041C\u0443\u0440-\u0441\u043A\u0443\u0442\u0435\u0440",
    "transport",
    90,
    "\u{1F6F4}",
    "\u041A\u0430\u0442\u0430\u0442\u044C\u0441\u044F \u043F\u043E \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0439 \u0434\u043E\u0440\u043E\u0436\u043A\u0435 \u0432\u043E\u043A\u0440\u0443\u0433 \u0444\u043B\u0430\u0436\u043A\u0430.",
    [3, 3],
    ["ride"]
  ),
  item(
    "party",
    "\u041F\u043B\u043E\u0449\u0430\u0434\u043A\u0430 \u0432\u0435\u0447\u0435\u0440\u0438\u043D\u043E\u043A",
    "social",
    160,
    "\u{1FAA9}",
    "\u0422\u0430\u043D\u0446\u044B, \u0433\u0438\u0440\u043B\u044F\u043D\u0434\u0430 \u0438 \u0446\u0435\u043B\u0430\u044F \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044F \u043A\u043E\u0442\u0438\u043A\u043E\u0432.",
    [4, 4],
    ["party"]
  ),
  item(
    "cafe",
    "\u041A\u043E\u0442\u043E\u043A\u0430\u0444\u0435",
    "social",
    150,
    "\u2615",
    "\u041F\u043E\u0441\u0438\u0434\u0435\u0442\u044C \u0441 \u0434\u0440\u0443\u0437\u044C\u044F\u043C\u0438 \u0437\u0430 \u0447\u0430\u0448\u0435\u0447\u043A\u043E\u0439 \u0442\u0451\u043F\u043B\u043E\u0433\u043E \u043C\u043E\u043B\u043E\u043A\u0430.",
    [4, 3],
    ["party", "eat"]
  ),
  item(
    "picnic",
    "\u041F\u0438\u043A\u043D\u0438\u043A \u0434\u0440\u0443\u0437\u0435\u0439",
    "social",
    95,
    "\u{1F9FA}",
    "\u0412\u043A\u0443\u0441\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u043A\u0443\u0441 \u0438 \u0442\u0438\u0445\u0438\u0435 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u044B \u043D\u0430 \u043F\u043B\u0435\u0434\u0435.",
    [3, 3],
    ["party", "eat"]
  ),
  item(
    "stage",
    "\u0421\u0446\u0435\u043D\u0430 \u043C\u0443\u0440-\u043A\u043E\u043D\u0446\u0435\u0440\u0442\u043E\u0432",
    "social",
    190,
    "\u{1F3B6}",
    "\u041A\u043E\u0448\u0430\u0447\u0438\u0439 \u043A\u043E\u043D\u0446\u0435\u0440\u0442 \u043F\u043E\u0434 \u043B\u0443\u043D\u043E\u0439.",
    [4, 3],
    ["party"]
  ),
  item(
    "fountain",
    "\u0424\u043E\u043D\u0442\u0430\u043D \u0436\u0435\u043B\u0430\u043D\u0438\u0439",
    "decor",
    80,
    "\u26F2",
    "\u0416\u0443\u0440\u0447\u0430\u043D\u0438\u0435 \u0432\u043E\u0434\u044B \u0438 \u0441\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u044B\u0435 \u0438\u0441\u043A\u0440\u044B.",
    [3, 3],
    ["explore"]
  ),
  item(
    "mushroom",
    "\u0413\u0440\u0438\u0431\u043D\u043E\u0439 \u0434\u043E\u043C\u0438\u043A",
    "decor",
    85,
    "\u{1F344}",
    "\u041A\u0440\u043E\u0448\u0435\u0447\u043D\u044B\u0439 \u0434\u043E\u043C \u0441 \u0442\u0451\u043F\u043B\u044B\u043C\u0438 \u043E\u043A\u043E\u0448\u043A\u0430\u043C\u0438.",
    [3, 3],
    ["rest"]
  ),
  item(
    "crystal",
    "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u0441\u0430\u0434",
    "decor",
    70,
    "\u{1F48E}",
    "\u0421\u0438\u044F\u044E\u0449\u0438\u0435 \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u043B\u044B \u0438 \u043C\u0435\u0441\u0442\u043E \u0434\u043B\u044F \u043C\u0435\u0447\u0442\u0430\u043D\u0438\u0439.",
    [2, 2],
    ["explore"]
  ),
  item(
    "lantern",
    "\u0424\u043E\u043D\u0430\u0440\u0438\u043A\u0438 \u0441\u0432\u0435\u0442\u043B\u044F\u0447\u043A\u043E\u0432",
    "decor",
    40,
    "\u{1F3EE}",
    "\u041C\u044F\u0433\u043A\u0438\u0439 \u0441\u0432\u0435\u0442 \u0438 \u043D\u0435\u043C\u043D\u043E\u0433\u043E \u0432\u043E\u043B\u0448\u0435\u0431\u0441\u0442\u0432\u0430.",
    [2, 2],
    ["explore"]
  ),
  item(
    "flowers",
    "\u041B\u0443\u043D\u043D\u0430\u044F \u043A\u043B\u0443\u043C\u0431\u0430",
    "decor",
    50,
    "\u{1F338}",
    "\u0426\u0432\u0435\u0442\u044B, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0440\u0430\u0441\u043A\u0440\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F \u043A\u043E\u0442\u0438\u043A\u043E\u0432.",
    [2, 2],
    ["explore"]
  ),
  item(
    "bed",
    "\u041B\u043E\u0436\u0435 \u043E\u0431\u043B\u0430\u043A\u043E\u0432",
    "decor",
    60,
    "\u{1F6CF}",
    "\u041A\u0440\u0443\u0433\u043B\u0430\u044F \u043F\u043E\u0434\u0443\u0448\u043A\u0430 \u0434\u043B\u044F \u0441\u0430\u043C\u044B\u0445 \u0441\u043B\u0430\u0434\u043A\u0438\u0445 \u0441\u043D\u043E\u0432.",
    [2, 2],
    ["rest"]
  ),
  item(
    "pond",
    "\u041F\u0440\u0443\u0434 \u0441 \u043B\u0438\u043B\u0438\u044F\u043C\u0438",
    "decor",
    90,
    "\u{1FAB7}",
    "\u041D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u044C \u0437\u0430 \u0440\u044B\u0431\u043A\u0430\u043C\u0438 \u0438 \u0441\u043B\u0443\u0448\u0430\u0442\u044C \u0442\u0438\u0445\u0438\u0439 \u043F\u043B\u0435\u0441\u043A.",
    [3, 3],
    ["explore"]
  )
];
var CATEGORIES = [
  { id: "all", name: "\u0412\u0441\u0451", icon: "\u2726" },
  { id: "toys", name: "\u0418\u0433\u0440\u0443\u0448\u043A\u0438", icon: "\u{1F9F6}" },
  { id: "rides", name: "\u0410\u0442\u0442\u0440\u0430\u043A\u0446\u0438\u043E\u043D\u044B", icon: "\u{1F3A1}" },
  { id: "transport", name: "\u0422\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442", icon: "\u{1F388}" },
  { id: "social", name: "\u041A\u043E\u043C\u043F\u0430\u043D\u0438\u044F", icon: "\u{1F408}" },
  { id: "decor", name: "\u0423\u044E\u0442", icon: "\u{1F338}" },
  { id: "lands", name: "\u0411\u0438\u043E\u043C\u044B", icon: "\u{1F30D}" },
  { id: "bag", name: "\u041C\u043E\u044F \u0441\u0443\u043C\u043A\u0430", icon: "\u25A3" }
];
var NEIGHBORS = [
  {
    id: "luna",
    name: "\u041B\u0443\u043D\u0430",
    biome: "moon",
    color: 11184059,
    personality: "\u041C\u0435\u0447\u0442\u0430\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u043B\u044E\u0431\u0438\u0442\u0435\u043B\u044C\u043D\u0438\u0446\u0430 \u0437\u0432\u0451\u0437\u0434",
    hat: true
  },
  {
    id: "moti",
    name: "\u041C\u043E\u0442\u0438",
    biome: "moon",
    color: 16049355,
    personality: "\u041E\u0431\u043E\u0436\u0430\u0435\u0442 \u0432\u0435\u0447\u0435\u0440\u0438\u043D\u043A\u0438 \u0438 \u043E\u0431\u044A\u044F\u0442\u0438\u044F"
  },
  {
    id: "pixel",
    name: "\u041F\u0438\u043A\u0441\u0435\u043B\u044C",
    biome: "moon",
    color: 7437448,
    personality: "\u0418\u0433\u0440\u0438\u0432\u044B\u0439 \u0438\u0437\u043E\u0431\u0440\u0435\u0442\u0430\u0442\u0435\u043B\u044C \u043F\u0440\u0438\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0439"
  },
  {
    id: "peach",
    name: "\u041F\u0435\u0440\u0441\u0438\u043A",
    biome: "moon",
    color: 15114627,
    personality: "\u0414\u043E\u0431\u0440\u044B\u0439 \u0441\u043E\u0441\u0435\u0434 \u0438 \u043C\u0430\u0441\u0442\u0435\u0440 \u043F\u0438\u043A\u043D\u0438\u043A\u043E\u0432"
  },
  {
    id: "bagel",
    name: "\u0411\u0443\u0431\u043B\u0438\u043A",
    biome: "moon",
    color: 12823436,
    personality: "\u041B\u044E\u0431\u0438\u0442\u0435\u043B\u044C \u043C\u0443\u0437\u044B\u043A\u0438 \u0438 \u043A\u0430\u0447\u0435\u043B\u0435\u0439"
  },
  {
    id: "salem",
    name: "\u0421\u0430\u043B\u0435\u043C",
    biome: "wizard",
    color: 5525604,
    personality: "\u041A\u043E\u0442\u043E\u0432\u043E\u043B\u0448\u0435\u0431\u043D\u0438\u043A \u0441 \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u043C \u0441\u0435\u0440\u0434\u0446\u0435\u043C",
    hat: true
  },
  {
    id: "snow",
    name: "\u0421\u043D\u0435\u0436\u043A\u0430",
    biome: "winter",
    color: 15264749,
    personality: "\u041B\u043E\u0432\u0438\u0442 \u0441\u043D\u0435\u0436\u0438\u043D\u043A\u0438 \u0438 \u0434\u0430\u0440\u0438\u0442 \u0442\u0451\u043F\u043B\u044B\u0435 \u0443\u043B\u044B\u0431\u043A\u0438"
  },
  {
    id: "nori",
    name: "\u041D\u043E\u0440\u0438",
    biome: "beach",
    color: 9544349,
    personality: "\u041C\u043E\u0440\u044F\u043A, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0437\u043D\u0430\u0435\u0442 \u0432\u0441\u0435 \u0440\u0430\u043A\u0443\u0448\u043A\u0438"
  },
  {
    id: "honey",
    name: "\u041C\u0451\u0434",
    biome: "autumn",
    color: 12817238,
    personality: "\u0423\u0433\u043E\u0449\u0430\u0435\u0442 \u0434\u0440\u0443\u0437\u0435\u0439 \u0438 \u0441\u043E\u0431\u0438\u0440\u0430\u0435\u0442 \u043B\u0438\u0441\u0442\u044C\u044F"
  },
  {
    id: "flora",
    name: "\u0424\u043B\u043E\u0440\u0430",
    biome: "nature",
    color: 11318925,
    personality: "\u041F\u043E\u0434\u0440\u0443\u0433\u0430 \u0431\u0430\u0431\u043E\u0447\u0435\u043A \u0438 \u043B\u0435\u0441\u043D\u044B\u0445 \u043A\u043E\u0442\u0438\u043A\u043E\u0432"
  },
  {
    id: "sunny",
    name: "\u041B\u0443\u0447\u0438\u043A",
    biome: "summer",
    color: 15586716,
    personality: "\u0411\u0435\u0433\u0430\u0435\u0442 \u043F\u043E \u043B\u0443\u0433\u0443 \u0438 \u043B\u044E\u0431\u0438\u0442 \u0432\u043E\u0437\u0434\u0443\u0448\u043D\u044B\u0435 \u0448\u0430\u0440\u044B"
  },
  {
    id: "astra",
    name: "\u0410\u0441\u0442\u0440\u0430",
    biome: "stars",
    color: 11838667,
    personality: "\u0423\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u0435\u0442 \u043B\u0443\u0447\u0448\u0438\u0435 \u043D\u043E\u0447\u043D\u044B\u0435 \u043F\u0440\u0430\u0437\u0434\u043D\u0438\u043A\u0438",
    hat: true
  },
  {
    id: "sakura",
    name: "\u0421\u0430\u043A\u0443\u0440\u0430",
    biome: "sakura",
    color: 15121098,
    personality: "\u0421\u043E\u0431\u0438\u0440\u0430\u0435\u0442 \u043B\u0435\u043F\u0435\u0441\u0442\u043A\u0438 \u0438 \u043C\u0435\u0447\u0442\u0430\u0435\u0442 \u043E \u0434\u0440\u0443\u0436\u0431\u0435"
  },
  {
    id: "cloud",
    name: "\u041E\u0431\u043B\u0430\u0447\u043A\u043E",
    biome: "clouds",
    color: 15723510,
    personality: "\u041C\u044F\u0433\u043A\u0438\u0439 \u043A\u043E\u0442\u0438\u043A \u0438\u0437 \u0432\u043E\u0437\u0434\u0443\u0448\u043D\u043E\u0433\u043E \u043A\u043E\u0440\u043E\u043B\u0435\u0432\u0441\u0442\u0432\u0430"
  },
  {
    id: "cinnamon",
    name: "\u041A\u043E\u0440\u0438\u0446\u0430",
    biome: "desert",
    color: 12619876,
    personality: "\u0414\u043E\u0431\u0440\u0430\u044F \u043F\u0443\u0442\u0435\u0448\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u0446\u0430 \u043F\u043E \u0434\u044E\u043D\u0430\u043C"
  },
  {
    id: "lily",
    name: "\u041B\u0438\u043B\u0438",
    biome: "water",
    color: 10669771,
    personality: "\u041F\u043B\u0430\u0432\u0430\u0435\u0442 \u043D\u0430 \u043B\u0438\u0441\u0442\u0438\u043A\u0430\u0445 \u0438 \u0442\u0430\u043D\u0446\u0443\u0435\u0442 \u0443 \u0432\u043E\u0434\u044B"
  }
];
var byItem = (id) => CATALOG.find((x) => x.id === id);
var byBiome = (id) => BIOMES.find((x) => x.id === id);
var ACTIONS = [
  "explore",
  "play",
  "ride",
  "meet",
  "party",
  "rest",
  "eat",
  "swim"
];
function biomeReservations(id) {
  if (id === ZOO_BIOME.id) return [{ x: 0, z: 0, w: ZOO_RADIUS * 2, d: ZOO_RADIUS * 2 }];
  if (isRetiredBiome(id)) return [];
  const farm = magicFarmLayout(id);
  if (farm) {
    const [x, z, rx, rz] = farm.pond;
    return [...farm.plants.map((p) => ({ x: p.x, z: p.z, w: p.radius * 2 + 1.5, d: p.radius * 2 + 1.5 })), { x, z, w: rx * 2 + 4, d: rz * 2 + 4 }, { x: 0, z: 71, w: 78, d: 14 }];
  }
  if (id === JOB_CITY_ID) return jobReservations();
  if (id === "aquarium")
    return [
      { x: 0, z: 0, w: AQUARIUM_BUILDING.w + 1, d: AQUARIUM_BUILDING.d + 1 }
    ];
  if (id === "bikini") return bikiniReservations();
  if (id === "foodcourt") return courtReservations();
  if (id === "autumn") return mosaReservations();
  if (id === "sakura") return chillReservations();
  if (id === "water") return spaReservations();
  if (id === "clockwork") return cottonReservations();
  if (id === "summer") return capybaraReservations();
  const fixed = id === "moon" ? [
    { x: -6, z: -4, w: 1.8, d: 1.8 },
    { x: -2, z: 5, w: 2.5, d: 2.5 }
  ] : [];
  if (id === "aquapark")
    fixed.push(
      { x: -3, z: -8, w: 11, d: 10 },
      { x: 8, z: 6, w: 10, d: 8 },
      { x: 9, z: -7, w: 10, d: 9 },
      { x: -10, z: -8, w: 9, d: 8 }
    );
  if (RENEWED_ISLANDS[id]) {
    const upper = RENEWED_ISLANDS[id].upper;
    fixed.push({
      x: upper[0],
      z: upper[1],
      w: upper[2] * 2 + 0.7,
      d: upper[3] * 2 + 0.7,
      rx: upper[2] + 0.12,
      rz: upper[3] + 0.12
    });
    for (const ride of ISLAND_RIDES.filter((r) => r.biome === id)) {
      const item2 = byItem(ride.type);
      fixed.push({
        x: ride.x,
        z: ride.z,
        w: item2.footprint[0],
        d: item2.footprint[1]
      });
    }
  }
  const river = BIOME_STYLES[id]?.river;
  if (river)
    fixed.push({
      x: river[0],
      z: river[1],
      w: river[2] * 2,
      d: river[3] * 2,
      rx: river[2] + 0.12,
      rz: river[3] + 0.12
    });
  const water = BIOME_STYLES[id]?.water;
  if (water)
    fixed.push({
      x: water[0],
      z: water[1],
      w: water[2] * 2 + 0.4,
      d: water[3] * 2 + 0.4,
      rx: water[2] + 0.12,
      rz: water[3] + 0.12
    });
  return fixed;
}
BIOMES.push(
  {
    id: "volcano",
    name: "\u041E\u0441\u0442\u0440\u043E\u0432 \u0434\u0440\u0430\u043A\u043E\u043D\u044C\u0438\u0445 \u0438\u0441\u043A\u0440",
    subtitle: "\u041E\u0431\u0441\u0438\u0434\u0438\u0430\u043D, \u0442\u0451\u043F\u043B\u044B\u0435 \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u0435\u0441\u044F \u0442\u0440\u0435\u0449\u0438\u043D\u044B \u0438 \u0434\u0440\u0430\u043A\u043E\u043D\u044B",
    icon: "\u{1F30B}",
    price: 900,
    center: [-54, -27],
    ground: 6837094,
    edge: 3878988,
    foliage: 12156045,
    accent: 16757118,
    quest: { harvests: 6 }
  },
  {
    id: "crystal",
    name: "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u043E\u0435 \u043A\u043E\u0440\u043E\u043B\u0435\u0432\u0441\u0442\u0432\u043E",
    subtitle: "\u0420\u0430\u0434\u0443\u0436\u043D\u044B\u0435 \u0448\u043F\u0438\u043B\u0438 \u0438 \u0441\u0430\u043C\u043E\u0446\u0432\u0435\u0442\u043D\u044B\u0435 \u043F\u0435\u0449\u0435\u0440\u044B",
    icon: "\u{1F48E}",
    price: 820,
    center: [54, -27],
    ground: 9283258,
    edge: 5399166,
    foliage: 11061215,
    accent: 14284543
  },
  {
    id: "candy",
    name: "\u0421\u043B\u0430\u0434\u043A\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0430",
    subtitle: "\u041C\u0430\u0440\u043C\u0435\u043B\u0430\u0434\u043D\u044B\u0435 \u0434\u0435\u0440\u0435\u0432\u044C\u044F \u0438 \u0441\u0430\u0445\u0430\u0440\u043D\u044B\u0435 \u043E\u0431\u043B\u0430\u043A\u0430",
    icon: "\u{1F36D}",
    price: 640,
    center: [-54, 27],
    ground: 12886712,
    edge: 9528452,
    foliage: 15515097,
    accent: 16769200
  },
  {
    id: "rainbow",
    name: "\u0414\u043E\u043B\u0438\u043D\u0430 \u0440\u0430\u0434\u0443\u0433",
    subtitle: "\u0421\u0435\u043C\u044C \u0446\u0432\u0435\u0442\u043E\u0432, \u0432\u043E\u0437\u0434\u0443\u0448\u043D\u044B\u0435 \u043C\u043E\u0441\u0442\u044B \u0438 \u0442\u0438\u0445\u0438\u0439 \u0434\u043E\u0436\u0434\u044C",
    icon: "\u{1F308}",
    price: 760,
    center: [54, 27],
    ground: 10664122,
    edge: 7501718,
    foliage: 12693723,
    accent: 16765669
  },
  {
    id: "bamboo",
    name: "\u0411\u0430\u043C\u0431\u0443\u043A\u043E\u0432\u044B\u0439 \u0448\u0451\u043F\u043E\u0442",
    subtitle: "\u0417\u0435\u043B\u0451\u043D\u044B\u0435 \u0440\u043E\u0449\u0438, \u0444\u043E\u043D\u0430\u0440\u0438\u043A\u0438 \u0438 \u0447\u0430\u0439\u043D\u044B\u0435 \u0431\u0435\u0441\u0435\u0434\u043A\u0438",
    icon: "\u{1F38B}",
    price: 590,
    center: [-27, 54],
    ground: 7509379,
    edge: 3892061,
    foliage: 10732939,
    accent: 15003573
  },
  {
    id: "mushrooms",
    name: "\u0413\u0440\u0438\u0431\u043D\u043E\u0435 \u043A\u043E\u0440\u043E\u043B\u0435\u0432\u0441\u0442\u0432\u043E",
    subtitle: "\u0413\u0438\u0433\u0430\u043D\u0442\u0441\u043A\u0438\u0435 \u0433\u0440\u0438\u0431\u044B \u0438 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0435 \u043B\u0435\u0441\u043D\u044B\u0435 \u0447\u0443\u0434\u0435\u0441\u0430",
    icon: "\u{1F344}",
    price: 620,
    center: [27, 54],
    ground: 9009821,
    edge: 5588077,
    foliage: 12230341,
    accent: 15841491
  },
  {
    id: "galaxy",
    name: "\u041A\u043E\u0441\u043C\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0433\u0430\u0432\u0430\u043D\u044C",
    subtitle: "\u041F\u043B\u0430\u043D\u0435\u0442\u044B, \u043A\u043E\u043C\u0435\u0442\u044B \u0438 \u043A\u043E\u0448\u0430\u0447\u044C\u0438 \u043A\u043E\u0441\u043C\u043E\u043B\u0451\u0442\u044B",
    icon: "\u{1FA90}",
    price: 1200,
    center: [0, -54],
    ground: 7367578,
    edge: 3486297,
    foliage: 11576021,
    accent: 14862079,
    quest: { friends: 1 }
  },
  {
    id: "coral",
    name: "\u041A\u043E\u0440\u0430\u043B\u043B\u043E\u0432\u0430\u044F \u0441\u043A\u0430\u0437\u043A\u0430",
    subtitle: "\u041F\u0435\u0440\u043B\u0430\u043C\u0443\u0442\u0440\u043E\u0432\u0430\u044F \u0432\u043E\u0434\u0430 \u0438 \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u044B\u0435 \u043A\u043E\u0440\u0430\u043B\u043B\u044B",
    icon: "\u{1FAB8}",
    price: 700,
    center: [-27, -54],
    ground: 8960445,
    edge: 4945803,
    foliage: 13084108,
    accent: 16762055
  },
  {
    id: "lotus",
    name: "\u041B\u043E\u0442\u043E\u0441\u043E\u0432\u044B\u0439 \u0445\u0440\u0430\u043C",
    subtitle: "\u0426\u0432\u0435\u0442\u0443\u0449\u0438\u0435 \u043B\u043E\u0442\u043E\u0441\u044B \u0438 \u0437\u0435\u0440\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0433\u043B\u0430\u0434\u044C",
    icon: "\u{1FAB7}",
    price: 680,
    center: [27, -54],
    ground: 8435116,
    edge: 4684663,
    foliage: 11258556,
    accent: 16111338
  },
  {
    id: "ice",
    name: "\u0414\u0432\u043E\u0440\u0435\u0446 \u0441\u0435\u0432\u0435\u0440\u043D\u043E\u0433\u043E \u0441\u0438\u044F\u043D\u0438\u044F",
    subtitle: "\u041B\u0435\u0434\u044F\u043D\u044B\u0435 \u0431\u0430\u0448\u043D\u0438 \u0438 \u043F\u0435\u0440\u0435\u043B\u0438\u0432\u044B \u043F\u043E\u043B\u044F\u0440\u043D\u043E\u0439 \u043D\u043E\u0447\u0438",
    icon: "\u{1F3D4}",
    price: 1e3,
    center: [-54, -54],
    ground: 11916513,
    edge: 6519978,
    foliage: 11983844,
    accent: 12711149,
    quest: { harvests: 10 }
  },
  {
    id: "clockwork",
    name: "\u041E\u0441\u0442\u0440\u043E\u0432 \u0441\u043B\u0430\u0434\u043A\u043E\u0439 \u0432\u0430\u0442\u044B",
    subtitle: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0439 \u043F\u0430\u0440\u043A \u0445\u0440\u044E\u0448\u0435\u043A \xB7 \u0440\u043E\u0437\u043E\u0432\u044B\u0435 \u0432\u043E\u0434\u043E\u043F\u0430\u0434\u044B \u0438 \u0441\u0430\u0445\u0430\u0440\u043D\u044B\u0435 \u0433\u043E\u0440\u043A\u0438",
    icon: "\u{1F36D}",
    radius: 23,
    legendary: true,
    arrival: [0, 9],
    price: 1100,
    center: [68, -68],
    ground: 16767688,
    edge: 12938135,
    foliage: 16099539,
    accent: 16769186,
    quest: { friends: 2 }
  },
  {
    id: "dusk",
    name: "\u0421\u0443\u043C\u0435\u0440\u0435\u0447\u043D\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430",
    subtitle: "\u0417\u0430\u0447\u0430\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043A\u043D\u0438\u0433\u0438 \u0438 \u043E\u0441\u0442\u0440\u043E\u0432\u0430 \u0432\u0435\u0447\u043D\u043E\u0433\u043E \u0432\u0435\u0447\u0435\u0440\u0430",
    icon: "\u{1F4DA}",
    price: 860,
    center: [-54, 54],
    ground: 8747157,
    edge: 4930917,
    foliage: 10853051,
    accent: 15258026,
    quest: { harvests: 3 }
  }
);
CATALOG.push(
  item(
    "farm-field",
    "\u0424\u0435\u0440\u043C\u0435\u0440\u0441\u043A\u0438\u0435 \u0433\u0440\u044F\u0434\u043A\u0438",
    "farm",
    80,
    "\u{1F331}",
    "\u041F\u043E\u0441\u0430\u0434\u0438\u0442\u044C, \u0434\u043E\u0436\u0434\u0430\u0442\u044C\u0441\u044F \u0443\u0440\u043E\u0436\u0430\u044F \u0438 \u043F\u0440\u043E\u0434\u0430\u0442\u044C \u0435\u0433\u043E \u0437\u0430 \u043A\u043E\u0442\u043E\u043C\u043E\u043D\u0435\u0442\u044B.",
    [4, 3],
    ["farm"]
  ),
  item(
    "greenhouse",
    "\u0417\u0432\u0451\u0437\u0434\u043D\u0430\u044F \u0442\u0435\u043F\u043B\u0438\u0446\u0430",
    "farm",
    260,
    "\u{1F3E1}",
    "\u0412\u044B\u0440\u0430\u0449\u0438\u0432\u0430\u0442\u044C \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u044B\u0435 \u043A\u0443\u043B\u044C\u0442\u0443\u0440\u044B \u043F\u043E\u0434 \u0441\u0442\u0435\u043A\u043B\u044F\u043D\u043D\u043E\u0439 \u043A\u0440\u044B\u0448\u0435\u0439.",
    [5, 4],
    ["farm"]
  ),
  item(
    "barn",
    "\u0410\u043C\u0431\u0430\u0440 \u0443\u0440\u043E\u0436\u0430\u044F",
    "farm",
    160,
    "\u{1F33E}",
    "\u0422\u0451\u043F\u043B\u043E\u0435 \u0444\u0435\u0440\u043C\u0435\u0440\u0441\u043A\u043E\u0435 \u043C\u0435\u0441\u0442\u0435\u0447\u043A\u043E \u0434\u043B\u044F \u0440\u0430\u0431\u043E\u0442\u044B \u0427\u0438\u0447\u0438.",
    [4, 3],
    ["farm"]
  ),
  item(
    "orchard",
    "\u0421\u0430\u0434 \u043B\u0443\u043D\u043D\u044B\u0445 \u044F\u0431\u043B\u043E\u043A",
    "farm",
    180,
    "\u{1F34E}",
    "\u041C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u0444\u0440\u0443\u043A\u0442\u043E\u0432\u044B\u0439 \u0441\u0430\u0434 \u0441 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C\u0438 \u0433\u0440\u044F\u0434\u043A\u0430\u043C\u0438.",
    [4, 4],
    ["farm"]
  ),
  item(
    "coaster-epic",
    "\u042D\u043F\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043D\u0435\u0431\u0435\u0441\u043D\u044B\u0435 \u0433\u043E\u0440\u043A\u0438",
    "rides",
    580,
    "\u{1F3A2}",
    "\u0412\u044B\u0441\u043E\u043A\u0438\u0435 \u043F\u043E\u0434\u044A\u0451\u043C\u044B, \u0441\u043F\u0438\u0440\u0430\u043B\u0438 \u0438 \u044D\u0444\u0444\u0435\u043A\u0442\u043D\u044B\u0439 \u043F\u043E\u043B\u0451\u0442.",
    [9, 8],
    ["ride"]
  ),
  item(
    "coaster-legendary",
    "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0435 \u0434\u0440\u0430\u043A\u043E\u043D\u044C\u0438 \u0433\u043E\u0440\u043A\u0438",
    "rides",
    1600,
    "\u{1F409}",
    "\u041E\u0433\u0440\u043E\u043C\u043D\u044B\u0439 \u043C\u0430\u0440\u0448\u0440\u0443\u0442 \u043D\u0430\u0434 \u0432\u0441\u0435\u043C \u043E\u0441\u0442\u0440\u043E\u0432\u043E\u043C. \u0421\u0442\u0440\u043E\u0439\u043A\u0430 \u2014 \u0441\u0443\u0442\u043A\u0438.",
    [15, 14],
    ["ride"]
  ),
  item(
    "coaster-mystic",
    "\u041C\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043F\u043E\u043B\u0451\u0442",
    "rides",
    1200,
    "\u{1F52E}",
    "\u041F\u043E\u043B\u0451\u0442 \u043D\u0430\u0434 \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u043C\u0438\u0441\u044F \u043F\u043E\u0440\u0442\u0430\u043B\u0430\u043C\u0438 \u0438 \u0433\u043E\u043B\u043E\u0432\u043E\u043A\u0440\u0443\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u0430\u0434\u0435\u043D\u0438\u0435.",
    [14, 13],
    ["ride"]
  ),
  item(
    "coaster-dragon",
    "\u041E\u0433\u043D\u0435\u043D\u043D\u0430\u044F \u0441\u043F\u0438\u0440\u0430\u043B\u044C",
    "rides",
    950,
    "\u{1F525}",
    "\u0421\u0432\u0435\u0440\u043A\u0430\u044E\u0449\u0430\u044F \u0441\u043F\u0438\u0440\u0430\u043B\u044C \u0432\u043E\u043A\u0440\u0443\u0433 \u0434\u0440\u0430\u043A\u043E\u043D\u044C\u0435\u0439 \u0431\u0430\u0448\u043D\u0438.",
    [12, 10],
    ["ride"]
  ),
  item(
    "water-river",
    "\u041B\u0435\u043D\u0438\u0432\u0430\u044F \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u0430\u044F \u0440\u0435\u043A\u0430",
    "rides",
    420,
    "\u{1F30A}",
    "\u041F\u043B\u044B\u0442\u044C \u043F\u043E \u0438\u0437\u0432\u0438\u043B\u0438\u0441\u0442\u043E\u043C\u0443 \u043A\u0430\u043D\u0430\u043B\u0443 \u0432 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0439 \u043B\u043E\u0434\u043A\u0435.",
    [8, 7],
    ["ride"]
  ),
  item(
    "water-whirlpool",
    "\u0420\u0430\u0434\u0443\u0436\u043D\u044B\u0439 \u0432\u043E\u0434\u043E\u0432\u043E\u0440\u043E\u0442",
    "rides",
    750,
    "\u{1F300}",
    "\u0412\u043E\u0434\u0430 \u0437\u0430\u043A\u0440\u0443\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u0432 \u043E\u0433\u0440\u043E\u043C\u043D\u0443\u044E \u043C\u044F\u0433\u043A\u0443\u044E \u0432\u043E\u0440\u043E\u043D\u043A\u0443.",
    [10, 9],
    ["ride"]
  ),
  item(
    "water-extreme",
    "\u0412\u043E\u0434\u043D\u0430\u044F \u0433\u043E\u0440\u043A\u0430 \u0442\u0438\u0442\u0430\u043D\u043E\u0432",
    "rides",
    1100,
    "\u{1F4A6}",
    "\u0412\u0437\u043E\u0431\u0440\u0430\u0442\u044C\u0441\u044F \u043D\u0430 \u0432\u044B\u0441\u043E\u0447\u0435\u043D\u043D\u0443\u044E \u0431\u0430\u0448\u043D\u044E \u0438 \u043F\u0440\u043E\u043B\u0435\u0442\u0435\u0442\u044C \u043A \u0431\u0430\u0441\u0441\u0435\u0439\u043D\u0443.",
    [12, 10],
    ["ride"]
  ),
  item(
    "zipline",
    "\u0417\u0432\u0451\u0437\u0434\u043D\u044B\u0439 \u0437\u0438\u043F\u043B\u0430\u0439\u043D",
    "rides",
    340,
    "\u{1F320}",
    "\u041F\u0440\u043E\u043C\u0447\u0430\u0442\u044C\u0441\u044F \u043F\u043E \u0432\u043E\u0437\u0434\u0443\u0448\u043D\u043E\u043C\u0443 \u043A\u0430\u043D\u0430\u0442\u0443 \u043C\u0435\u0436\u0434\u0443 \u0434\u0432\u0443\u043C\u044F \u0431\u0430\u0448\u043D\u044F\u043C\u0438.",
    [7, 4],
    ["ride"]
  ),
  item(
    "drop-tower",
    "\u0411\u0430\u0448\u043D\u044F \u043A\u043E\u043C\u0435\u0442",
    "rides",
    700,
    "\u2604",
    "\u041F\u043E\u0434\u043D\u044F\u0442\u044C\u0441\u044F \u0432 \u043D\u0435\u0431\u043E \u0438 \u043C\u044F\u0433\u043A\u043E \u0443\u043F\u0430\u0441\u0442\u044C \u043D\u0430 \u043E\u0431\u043B\u0430\u0447\u043D\u0443\u044E \u043F\u043E\u0434\u0443\u0448\u043A\u0443.",
    [4, 4],
    ["ride"]
  ),
  item(
    "bumpercars",
    "\u041C\u0443\u0440-\u0430\u0432\u0442\u043E\u0434\u0440\u043E\u043C",
    "rides",
    320,
    "\u{1F697}",
    "\u0412\u0435\u0441\u0451\u043B\u044B\u0435 \u043C\u0430\u0448\u0438\u043D\u043A\u0438 \u043A\u0440\u0443\u0436\u0430\u0442\u0441\u044F \u043D\u0430 \u043E\u0441\u0432\u0435\u0449\u0451\u043D\u043D\u043E\u0439 \u043F\u043B\u043E\u0449\u0430\u0434\u043A\u0435.",
    [6, 5],
    ["ride"]
  ),
  item(
    "rocket",
    "\u041B\u0443\u043D\u043D\u0430\u044F \u0440\u0430\u043A\u0435\u0442\u0430",
    "transport",
    650,
    "\u{1F680}",
    "\u041E\u0431\u043B\u0435\u0442\u0435\u0442\u044C \u043E\u0441\u0442\u0440\u043E\u0432 \u043D\u0430 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0439 \u043F\u0443\u0448\u0438\u0441\u0442\u043E\u0439 \u0440\u0430\u043A\u0435\u0442\u0435.",
    [5, 5],
    ["ride"]
  ),
  item(
    "ufo",
    "\u041B\u0435\u0442\u0430\u044E\u0449\u0430\u044F \u043C\u0443\u0440-\u0442\u0430\u0440\u0435\u043B\u043A\u0430",
    "transport",
    520,
    "\u{1F6F8}",
    "\u041F\u0430\u0440\u0438\u0442\u044C \u0441\u0440\u0435\u0434\u0438 \u0437\u0432\u0451\u0437\u0434 \u0432 \u0441\u0438\u044F\u044E\u0449\u0435\u043C \u043A\u043E\u0440\u0430\u0431\u043B\u0438\u043A\u0435.",
    [5, 5],
    ["ride"]
  ),
  item(
    "airship",
    "\u041D\u0435\u0431\u0435\u0441\u043D\u044B\u0439 \u043A\u043E\u0442\u043E\u0434\u0438\u0440\u0438\u0436\u0430\u0431\u043B\u044C",
    "transport",
    480,
    "\u{1F388}",
    "\u041F\u043B\u0430\u0432\u043D\u044B\u0439 \u043F\u043E\u043B\u0451\u0442 \u043D\u0430\u0434 \u0441\u0430\u0434\u0430\u043C\u0438 \u0438 \u0438\u0433\u0440\u0443\u0448\u043A\u0430\u043C\u0438.",
    [6, 5],
    ["ride"]
  ),
  item(
    "skate",
    "\u0420\u0430\u0434\u0443\u0436\u043D\u044B\u0439 \u0441\u043A\u0435\u0439\u0442",
    "transport",
    160,
    "\u{1F6F9}",
    "\u041A\u0430\u0442\u0430\u0442\u044C\u0441\u044F \u0438 \u0441\u043E\u0432\u0435\u0440\u0448\u0430\u0442\u044C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0435 \u043F\u0440\u044B\u0436\u043A\u0438.",
    [4, 4],
    ["ride"]
  ),
  item(
    "catbus",
    "\u0421\u043A\u0430\u0437\u043E\u0447\u043D\u044B\u0439 \u043A\u043E\u0442\u043E\u0431\u0443\u0441",
    "transport",
    420,
    "\u{1F68C}",
    "\u041F\u0443\u0442\u0435\u0448\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u043F\u043E \u043A\u043E\u043B\u044C\u0446\u0435\u0432\u043E\u0439 \u0434\u043E\u0440\u043E\u0433\u0435.",
    [6, 5],
    ["ride"]
  ),
  item(
    "maze",
    "\u041B\u0430\u0431\u0438\u0440\u0438\u043D\u0442 \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u0441\u0442\u0432\u0430",
    "toys",
    240,
    "\u{1F333}",
    "\u0418\u0441\u043A\u0430\u0442\u044C \u0434\u043E\u0440\u043E\u0433\u0443 \u0441\u0440\u0435\u0434\u0438 \u043C\u044F\u0433\u043A\u0438\u0445 \u0437\u0435\u043B\u0451\u043D\u044B\u0445 \u0441\u0442\u0435\u043D.",
    [5, 5],
    ["play"]
  ),
  item(
    "laser",
    "\u0417\u0432\u0451\u0437\u0434\u043D\u044B\u0439 \u043E\u0433\u043E\u043D\u0451\u043A",
    "toys",
    110,
    "\u2726",
    "\u041F\u043E\u0439\u043C\u0430\u0442\u044C \u0443\u0431\u0435\u0433\u0430\u044E\u0449\u0443\u044E \u0438\u0441\u043A\u043E\u0440\u043A\u0443.",
    [3, 3],
    ["play"]
  ),
  item(
    "fireflies",
    "\u0411\u0430\u043D\u043E\u0447\u043A\u0430 \u0441\u0432\u0435\u0442\u043B\u044F\u0447\u043A\u043E\u0432",
    "toys",
    95,
    "\u{1FAD9}",
    "\u0421\u043B\u0435\u0434\u0438\u0442\u044C \u0437\u0430 \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u044B\u043C\u0438 \u043E\u0433\u043E\u043D\u044C\u043A\u0430\u043C\u0438 \u0438 \u0438\u0433\u0440\u0430\u0442\u044C \u0441 \u043D\u0438\u043C\u0438.",
    [2, 2],
    ["play"]
  ),
  item(
    "toy-fish",
    "\u0420\u044B\u0431\u043A\u0430-\u043F\u043E\u043F\u0440\u044B\u0433\u0443\u043D\u044C\u044F",
    "toys",
    90,
    "\u{1F41F}",
    "\u041B\u043E\u0432\u0438\u0442\u044C \u043F\u043E\u0434\u043F\u0440\u044B\u0433\u0438\u0432\u0430\u044E\u0449\u0443\u044E \u043C\u044F\u0433\u043A\u0443\u044E \u0440\u044B\u0431\u043A\u0443.",
    [2, 2],
    ["play"]
  ),
  item(
    "library",
    "\u0414\u043E\u043C \u0441\u043A\u0430\u0437\u043E\u043A",
    "social",
    240,
    "\u{1F4D6}",
    "\u0412\u0441\u0442\u0440\u0435\u0447\u0438 \u0434\u0440\u0443\u0437\u0435\u0439 \u0438 \u0447\u0442\u0435\u043D\u0438\u0435 \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u044B\u0445 \u0438\u0441\u0442\u043E\u0440\u0438\u0439.",
    [4, 4],
    ["party", "rest"]
  ),
  item(
    "observatory",
    "\u041E\u0431\u0441\u0435\u0440\u0432\u0430\u0442\u043E\u0440\u0438\u044F \u0436\u0435\u043B\u0430\u043D\u0438\u0439",
    "social",
    380,
    "\u{1F52D}",
    "\u041D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u044C \u0437\u0430 \u0437\u0432\u0451\u0437\u0434\u0430\u043C\u0438 \u0432 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438 \u043A\u043E\u0442\u0438\u043A\u043E\u0432.",
    [5, 4],
    ["party", "explore"]
  ),
  item(
    "spa",
    "\u041B\u0443\u043D\u043D\u044B\u0435 \u0442\u0435\u0440\u043C\u044B",
    "social",
    290,
    "\u{1FAE7}",
    "\u041E\u0442\u0434\u043E\u0445\u043D\u0443\u0442\u044C \u0432 \u0442\u0451\u043F\u043B\u043E\u043C \u0431\u0430\u0441\u0441\u0435\u0439\u043D\u0435 \u0441\u0440\u0435\u0434\u0438 \u0446\u0432\u0435\u0442\u043E\u0432.",
    [4, 4],
    ["rest"]
  ),
  item(
    "festival",
    "\u0424\u0435\u0441\u0442\u0438\u0432\u0430\u043B\u044C \u0441\u043E\u0437\u0432\u0435\u0437\u0434\u0438\u0439",
    "social",
    600,
    "\u{1F386}",
    "\u041C\u0443\u0437\u044B\u043A\u0430, \u0441\u0438\u044F\u044E\u0449\u0438\u0435 \u0433\u0438\u0440\u043B\u044F\u043D\u0434\u044B \u0438 \u0431\u043E\u043B\u044C\u0448\u0430\u044F \u0432\u0435\u0447\u0435\u0440\u0438\u043D\u043A\u0430.",
    [6, 5],
    ["party"]
  ),
  item(
    "portal",
    "\u041F\u043E\u0440\u0442\u0430\u043B \u0447\u0443\u0434\u0435\u0441",
    "decor",
    330,
    "\u{1FA84}",
    "\u0421\u0432\u0435\u0440\u043A\u0430\u044E\u0449\u0438\u0439 \u043A\u0440\u0443\u0433 \u0434\u043B\u044F \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0433\u043E \u043C\u0430\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u0438\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F.",
    [4, 3],
    ["play"]
  )
);
CATEGORIES.splice(
  CATEGORIES.findIndex((c) => c.id === "lands"),
  0,
  { id: "farm", name: "\u0424\u0435\u0440\u043C\u0430", icon: "\u{1F331}" }
);
var extraCats = [
  "\u0418\u0441\u043A\u0440\u0430",
  "\u041E\u043F\u0430\u043B",
  "\u0417\u0435\u0444\u0438\u0440",
  "\u0418\u0440\u0438\u0441",
  "\u041F\u0430\u043D\u0434\u0430",
  "\u0422\u0440\u044E\u0444\u0435\u043B\u044C",
  "\u041A\u043E\u0441\u043C\u043E",
  "\u041A\u043E\u0440\u0430",
  "\u041B\u043E\u0442\u0442\u0438",
  "\u0410\u0439\u0441",
  "\u0422\u0438\u043A",
  "\u0421\u0443\u043C\u0440\u0430\u043A"
];
for (let i = 12; i < BIOMES.length; i++) {
  const b = BIOMES[i];
  NEIGHBORS.push({
    id: "neighbor-" + b.id,
    name: extraCats[i - 12],
    biome: b.id,
    color: b.foliage,
    personality: "\u0425\u0440\u0430\u043D\u0438\u0442\u0435\u043B\u044C " + b.name.toLowerCase(),
    hat: i % 3 === 0
  });
}
ACTIONS.push("farm");
CATALOG.push(
  item(
    "coaster-lagoon",
    "\u041D\u0435\u0431\u0435\u0441\u043D\u0430\u044F \u043B\u0430\u0433\u0443\u043D\u0430",
    "rides",
    1050,
    "\u{1F420}",
    "\u0411\u0438\u0440\u044E\u0437\u043E\u0432\u044B\u0435 \u0433\u043E\u0440\u043A\u0438, \u0440\u044B\u0431\u043A\u0438 \u0432 \u0430\u043A\u0432\u0430\u0440\u0438\u0443\u043C\u0435, \u043F\u0430\u043B\u044C\u043C\u044B \u0438 \u0442\u0451\u043F\u043B\u044B\u0435 \u0444\u043E\u043D\u0430\u0440\u0438\u043A\u0438.",
    [12, 10],
    ["ride"]
  ),
  item(
    "coaster-sakura",
    "\u041F\u0435\u0442\u043B\u044F \u0446\u0432\u0435\u0442\u0443\u0449\u0438\u0445 \u0441\u043D\u043E\u0432",
    "rides",
    880,
    "\u{1F338}",
    "\u0420\u043E\u0437\u043E\u0432\u044B\u0439 \u043C\u0430\u0440\u0448\u0440\u0443\u0442 \u0441\u0440\u0435\u0434\u0438 \u0446\u0432\u0435\u0442\u0443\u0449\u0438\u0445 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0438 \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u0445\u0441\u044F \u043B\u0435\u043F\u0435\u0441\u0442\u043A\u043E\u0432.",
    [11, 10],
    ["ride"]
  ),
  item(
    "coaster-moon",
    "\u041B\u0443\u043D\u043D\u044B\u0439 \u044D\u043A\u0441\u043F\u0440\u0435\u0441\u0441",
    "rides",
    1150,
    "\u263E",
    "\u0417\u043E\u043B\u043E\u0442\u044B\u0435 \u0430\u0440\u043A\u0438, \u0433\u0440\u0438\u0431\u043D\u0430\u044F \u0441\u0442\u0430\u043D\u0446\u0438\u044F \u0438 \u0441\u043A\u0430\u0437\u043E\u0447\u043D\u044B\u0439 \u043F\u043E\u043B\u0451\u0442 \u043D\u0430\u0434 \u043E\u0441\u0442\u0440\u043E\u0432\u043E\u043C.",
    [13, 11],
    ["ride"]
  ),
  item(
    "coaster-mushroom",
    "\u0413\u0440\u0438\u0431\u043D\u043E\u0439 \u0441\u0435\u0440\u043F\u0430\u043D\u0442\u0438\u043D",
    "rides",
    760,
    "\u{1F344}",
    "\u0423\u044E\u0442\u043D\u0430\u044F \u0434\u0435\u0440\u0435\u0432\u044F\u043D\u043D\u0430\u044F \u0433\u043E\u0440\u043A\u0430 \u0441\u0440\u0435\u0434\u0438 \u0441\u043A\u0430\u0437\u043E\u0447\u043D\u044B\u0445 \u0433\u0440\u0438\u0431\u043E\u0432 \u0438 \u0446\u0432\u0435\u0442\u043E\u0447\u043D\u044B\u0445 \u0441\u0430\u0434\u043E\u0432.",
    [10, 9],
    ["ride"]
  ),
  item(
    "coaster-cloud",
    "\u041E\u0431\u043B\u0430\u0447\u043D\u0430\u044F \u043A\u043E\u0440\u043E\u043D\u0430",
    "rides",
    1750,
    "\u2601",
    "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0439 \u043C\u0430\u0440\u0448\u0440\u0443\u0442 \u0441 \u0431\u0435\u043B\u044B\u043C\u0438 \u043E\u0431\u043B\u0430\u043A\u0430\u043C\u0438, \u0437\u043E\u043B\u043E\u0442\u044B\u043C\u0438 \u043F\u043E\u0440\u0443\u0447\u043D\u044F\u043C\u0438 \u0438 \u0432\u044B\u0441\u043E\u043A\u0438\u043C \u0434\u0432\u043E\u0440\u0446\u043E\u043C.",
    [15, 14],
    ["ride"]
  ),
  item(
    "coaster-clockwork",
    "\u0417\u043E\u043B\u043E\u0442\u0430\u044F \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0432\u0440\u0435\u043C\u0435\u043D\u0438",
    "rides",
    1250,
    "\u2699",
    "\u041C\u0435\u0434\u043D\u044B\u0435 \u0440\u0435\u043B\u044C\u0441\u044B, \u0437\u0430\u0432\u043E\u0434\u043D\u0430\u044F \u0441\u0442\u0430\u043D\u0446\u0438\u044F \u0438 \u0444\u043E\u043D\u0430\u0440\u0438 \u0433\u043E\u0440\u043E\u0434\u0430 \u0447\u0430\u0441\u043E\u0432\u0449\u0438\u043A\u0430.",
    [12, 11],
    ["ride"]
  )
);
BIOMES.push({
  id: "aquapark",
  name: "\u0420\u0430\u0434\u0443\u0436\u043D\u0430\u044F \u043A\u043E\u0440\u043E\u043D\u0430",
  subtitle: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0439 \u0430\u043A\u0432\u0430\u043F\u0430\u0440\u043A \xB7 \u0437\u0430\u043C\u043E\u043A, \u043A\u0430\u0441\u043A\u0430\u0434\u044B, \u043F\u043E\u043B\u0451\u0442\u044B \u0438 \u043B\u0430\u0437\u0443\u0440\u043D\u044B\u0435 \u043B\u0430\u0433\u0443\u043D\u044B",
  icon: "\u{1F3F0}",
  price: 35e3,
  center: [88, 36],
  radius: 19,
  ground: 9025922,
  edge: 4348800,
  foliage: 7517560,
  accent: 16765546,
  requiredLevel: 20,
  quest: { harvests: 180, friends: 3, visits: 7 }
});
CATALOG.push(
  item(
    "coaster-rainbow-launch",
    "\u0420\u0430\u0434\u0443\u0436\u043D\u0430\u044F \u043A\u0430\u0442\u0430\u043F\u0443\u043B\u044C\u0442\u0430",
    "rides",
    4800,
    "\u{1F308}",
    "\u0426\u0432\u0435\u0442\u043D\u044B\u0435 \u0440\u0435\u043B\u044C\u0441\u044B, \u043E\u0431\u043B\u0430\u0447\u043D\u0430\u044F \u0430\u0440\u043A\u0430 \u0438 \u0441\u043C\u0435\u0448\u043D\u043E\u0439 \u043F\u043E\u043B\u0451\u0442 \u0427\u0438\u0447\u0438 \u043D\u0430\u0434 \u043B\u0430\u0433\u0443\u043D\u043E\u0439.",
    [10, 8],
    ["ride"]
  ),
  item(
    "slide-royal-cascade",
    "\u041A\u043E\u0440\u043E\u043B\u0435\u0432\u0441\u043A\u0438\u0439 \u043A\u0430\u0441\u043A\u0430\u0434",
    "rides",
    5600,
    "\u{1F3F0}",
    "\u0417\u043E\u043B\u043E\u0442\u0430\u044F \u0431\u0430\u0448\u043D\u044F, \u0434\u043B\u0438\u043D\u043D\u044B\u0439 \u0433\u043E\u043B\u0443\u0431\u043E\u0439 \u0441\u043F\u0443\u0441\u043A \u0438 \u0438\u0441\u043A\u0440\u044F\u0449\u0438\u0439\u0441\u044F \u0432\u043E\u0434\u043D\u044B\u0439 \u0444\u0438\u043D\u0438\u0448.",
    [10, 9],
    ["ride"]
  ),
  item(
    "slide-vortex-bowl",
    "\u0427\u0430\u0448\u0430 \u0432\u043E\u0434\u043E\u0432\u043E\u0440\u043E\u0442\u0430",
    "rides",
    4100,
    "\u{1F300}",
    "\u041E\u0431\u043E\u0439\u0442\u0438 \u0440\u0430\u0434\u0443\u0436\u043D\u0443\u044E \u0447\u0430\u0448\u0443 \u043F\u043E \u0441\u043F\u0438\u0440\u0430\u043B\u0438, \u043F\u0440\u043E\u0432\u0430\u043B\u0438\u0442\u044C\u0441\u044F \u0432 \u0446\u0435\u043D\u0442\u0440 \u0438 \u043C\u044F\u0433\u043A\u043E \u043F\u0440\u0438\u0432\u043E\u0434\u043D\u0438\u0442\u044C\u0441\u044F.",
    [9, 8],
    ["ride"]
  ),
  item(
    "coaster-comet-flight",
    "\u041A\u043E\u043C\u0435\u0442\u0430 \u0427\u0438\u0447\u0438",
    "rides",
    7600,
    "\u2604\uFE0F",
    "\u041A\u043E\u0441\u043C\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043F\u0435\u0442\u043B\u044F \u0438 \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u0439 \u043F\u043E\u043B\u0451\u0442 \u0441 \u0440\u0430\u0441\u0442\u043E\u043F\u044B\u0440\u0435\u043D\u043D\u044B\u043C\u0438 \u043B\u0430\u043F\u043A\u0430\u043C\u0438.",
    [12, 10],
    ["ride"]
  ),
  item(
    "ride-jellyfish",
    "\u041C\u0435\u0434\u0443\u0437\u044C\u044F \u043A\u0430\u0440\u0443\u0441\u0435\u043B\u044C",
    "rides",
    2900,
    "\u{1FABC}",
    "\u041F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u044B\u0439 \u043A\u0443\u043F\u043E\u043B, \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u0435\u0441\u044F \u0449\u0443\u043F\u0430\u043B\u044C\u0446\u0430 \u0438 \u043F\u043E\u043A\u0430\u0447\u0438\u0432\u0430\u044E\u0449\u0438\u0435\u0441\u044F \u043A\u043E\u0440\u0437\u0438\u043D\u043A\u0438.",
    [6, 6],
    ["ride"]
  ),
  item(
    "ride-dragon-cloud",
    "\u041E\u0431\u043B\u0430\u0447\u043D\u044B\u0439 \u0434\u0440\u0430\u043A\u043E\u043D",
    "rides",
    5200,
    "\u{1F409}",
    "\u041A\u0440\u0443\u0436\u0438\u0442\u044C \u0432\u0435\u0440\u0445\u043E\u043C \u043D\u0430 \u0441\u043C\u0435\u0448\u043D\u043E\u043C \u0434\u0440\u0430\u043A\u043E\u043D\u0435 \u043C\u0435\u0436\u0434\u0443 \u0446\u0432\u0435\u0442\u043D\u044B\u043C\u0438 \u043E\u0431\u043B\u0430\u043A\u0430\u043C\u0438.",
    [8, 7],
    ["ride"]
  ),
  item(
    "toy-bubble-garden",
    "\u0421\u0430\u0434 \u043C\u044B\u043B\u044C\u043D\u044B\u0445 \u043F\u0443\u0437\u044B\u0440\u0435\u0439",
    "toys",
    620,
    "\u{1FAE7}",
    "\u041F\u0443\u0437\u044B\u0440\u044C\u043A\u0438 \u0440\u0430\u0437\u043D\u044B\u0445 \u0440\u0430\u0437\u043C\u0435\u0440\u043E\u0432 \u0438 \u043F\u0440\u044B\u0436\u043A\u0438 \u0437\u0430 \u0440\u0430\u0434\u0443\u0436\u043D\u044B\u043C\u0438 \u0431\u043B\u0438\u043A\u0430\u043C\u0438.",
    [3, 3],
    ["play"]
  ),
  item(
    "toy-magic-fish",
    "\u041B\u0435\u0442\u0430\u044E\u0449\u0430\u044F \u0440\u044B\u0431\u043A\u0430",
    "toys",
    820,
    "\u{1F420}",
    "\u0420\u044B\u0431\u043A\u0430 \u043B\u0435\u0442\u0438\u0442 \u043D\u0430\u0434 \u0446\u0432\u0435\u0442\u0430\u043C\u0438, \u0427\u0438\u0447\u0438 \u043B\u043E\u0432\u0438\u0442 \u0435\u0451 \u043B\u0430\u043F\u043A\u0430\u043C\u0438 \u0438 \u0441\u043C\u0435\u0448\u043D\u043E \u043F\u043E\u0434\u043F\u0440\u044B\u0433\u0438\u0432\u0430\u0435\u0442.",
    [3, 3],
    ["play"]
  ),
  item(
    "cat-barista",
    "\u041C\u0443\u0440-\u0431\u0430\u0440\u0438\u0441\u0442\u0430",
    "social",
    1800,
    "\u2615",
    "\u041E\u0431\u044A\u0451\u043C\u043D\u043E\u0435 \u043A\u0430\u0444\u0435 \u0441 \u043A\u043E\u0442\u0438\u043A\u043E\u043C-\u0431\u0430\u0440\u0438\u0441\u0442\u0430, \u043F\u0430\u0440\u043E\u043C \u043D\u0430\u0434 \u0447\u0430\u0448\u0435\u0447\u043A\u0430\u043C\u0438 \u0438 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u043C\u0438 \u0433\u043E\u0441\u0442\u044F\u043C\u0438. \u041F\u0435\u0440\u0435\u043A\u0443\u0441\u044B \u0440\u0430\u0441\u0445\u043E\u0434\u0443\u044E\u0442 \u0435\u0434\u0443 \u0438\u0437 \u043E\u0431\u0449\u0435\u0439 \u043C\u0438\u0441\u043A\u0438.",
    [5, 4],
    ["eat", "party"]
  ),
  item(
    "swim-lagoon",
    "\u041B\u0430\u0433\u0443\u043D\u0430 \u0434\u043B\u044F \u043F\u043B\u0430\u0432\u0430\u043D\u0438\u044F",
    "decor",
    450,
    "\u{1F4A6}",
    "\u041F\u0440\u043E\u0437\u0440\u0430\u0447\u043D\u0430\u044F \u0432\u043E\u0434\u0430, \u0440\u0430\u0437\u043D\u043E\u0446\u0432\u0435\u0442\u043D\u044B\u0435 \u0440\u044B\u0431\u043A\u0438 \u0438 \u043A\u0440\u0443\u0433\u0438 \u043E\u0442 \u043A\u043E\u0448\u0430\u0447\u044C\u0438\u0445 \u043B\u0430\u043F\u043E\u043A.",
    [4, 4],
    ["swim", "explore"]
  )
);
CATALOG.push(
  item(
    "adoption-center",
    "Cat Adoption Center",
    "social",
    320,
    "\u{1F43E}",
    "\u041F\u043E\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u0443\u044E\u0442\u043D\u044B\u0439 \u0434\u043E\u043C \u0437\u043D\u0430\u043A\u043E\u043C\u0441\u0442\u0432\u0430: \u0443\u0441\u044B\u043D\u043E\u0432\u043B\u044F\u0439\u0442\u0435 \u043A\u043E\u0442\u0438\u043A\u043E\u0432 \u0440\u0430\u0437\u043D\u044B\u0445 \u043F\u043E\u0440\u043E\u0434, \u0440\u0430\u0437\u043C\u0435\u0440\u043E\u0432 \u0438 \u043E\u043A\u0440\u0430\u0441\u043E\u0432.",
    [5, 5],
    ["explore"]
  )
);
CATALOG.push(
  ...BUSINESSES.map((b) => ({
    ...b,
    category: "business",
    footprint: b.footprint || [5, 5],
    actions: ["produce", "fish", "toys"].includes(b.goods) || b.id === "business-florist" || b.id === "business-artist" ? ["explore", "party"] : ["eat", "party"]
  }))
);
CATEGORIES.splice(
  CATEGORIES.findIndex((c) => c.id === "lands"),
  0,
  { id: "business", name: "\u041A\u043E\u0448\u0430\u0447\u0438\u0439 \u0431\u0438\u0437\u043D\u0435\u0441", icon: "\u2615" },
  { id: "cats", name: "\u041F\u043E\u0440\u043E\u0434\u044B \u043A\u043E\u0442\u0438\u043A\u043E\u0432", icon: "\u{1F431}" }
);
CATALOG.push(
  item(
    "ride-butterfly",
    "\u0411\u0430\u0431\u043E\u0447\u043A\u0430 \u0446\u0432\u0435\u0442\u0443\u0449\u0438\u0445 \u0441\u043D\u043E\u0432",
    "rides",
    1200,
    "\u{1F98B}",
    "\u041D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u0435 \u0432\u0437\u043C\u0430\u0445\u0438 \u043A\u0440\u044B\u043B\u044C\u0435\u0432, \u0441\u0435\u0434\u043B\u043E \u0438 \u043F\u043B\u0430\u0432\u043D\u044B\u0439 \u043F\u043E\u043B\u0451\u0442 \u043D\u0430\u0434 \u043E\u0441\u0442\u0440\u043E\u0432\u043E\u043C.",
    [4, 4],
    ["ride"]
  ),
  item(
    "ride-lotus",
    "\u041F\u0430\u0440\u0443\u0441\u043D\u044B\u0439 \u043B\u043E\u0442\u043E\u0441",
    "rides",
    1500,
    "\u{1FAB7}",
    "\u0413\u0438\u0433\u0430\u043D\u0442\u0441\u043A\u0438\u0439 \u0440\u0430\u0441\u043A\u0440\u044B\u0432\u0430\u044E\u0449\u0438\u0439\u0441\u044F \u0446\u0432\u0435\u0442\u043E\u043A \u043D\u0435\u0441\u0451\u0442 \u0427\u0438\u0447\u0438 \u043D\u0430\u0434 \u0432\u043E\u0434\u043E\u0439.",
    [4, 4],
    ["ride"]
  ),
  item(
    "ride-dragonfly",
    "\u0421\u0442\u0440\u0435\u043A\u043E\u0437\u0430 \u043A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u043E\u0439 \u043B\u0430\u0433\u0443\u043D\u044B",
    "rides",
    1100,
    "\u2728",
    "\u0427\u0435\u0442\u044B\u0440\u0435 \u043F\u0435\u0440\u0435\u043B\u0438\u0432\u0447\u0430\u0442\u044B\u0445 \u043A\u0440\u044B\u043B\u0430 \u0438 \u0434\u043B\u0438\u043D\u043D\u044B\u0439 \u0433\u043E\u043B\u0443\u0431\u043E\u0439 \u0445\u0432\u043E\u0441\u0442 \u043D\u0435\u0441\u0443\u0442 \u0427\u0438\u0447\u0438 \u043D\u0430\u0434 \u0446\u0432\u0435\u0442\u0430\u043C\u0438.",
    [4, 4],
    ["ride"]
  ),
  item(
    "ride-dinosaur",
    "\u0414\u043E\u0431\u0440\u044B\u0439 \u0434\u0438\u043D\u043E\u0437\u0430\u0432\u0440",
    "rides",
    1800,
    "\u{1F995}",
    "\u041D\u0435\u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0434\u0438\u043D\u043E\u0437\u0430\u0432\u0440 \u0448\u0430\u0433\u0430\u0435\u0442 \u0441 \u0427\u0438\u0447\u0438 \u043D\u0430 \u0441\u043F\u0438\u043D\u0435 \u0438 \u043A\u0438\u0432\u0430\u0435\u0442 \u0434\u0440\u0443\u0437\u044C\u044F\u043C.",
    [4, 4],
    ["ride"]
  )
);
CATALOG.push(
  item(
    "ride-whale",
    "\u041D\u0435\u0431\u0435\u0441\u043D\u044B\u0439 \u0441\u0438\u043D\u0438\u0439 \u043A\u0438\u0442",
    "rides",
    2200,
    "\u{1F40B}",
    "\u0416\u0438\u0432\u043E\u0439 \u0437\u0432\u0451\u0437\u0434\u043D\u044B\u0439 \u043A\u0438\u0442 \u043D\u0435\u0441\u0451\u0442 \u0427\u0438\u0447\u0438 \u043D\u0430\u0434 \u043B\u0430\u0433\u0443\u043D\u043E\u0439, \u043C\u0430\u0448\u0435\u0442 \u043F\u043B\u0430\u0432\u043D\u0438\u043A\u0430\u043C\u0438 \u0438 \u0432\u044B\u043F\u0443\u0441\u043A\u0430\u0435\u0442 \u0444\u043E\u043D\u0442\u0430\u043D\u0447\u0438\u043A\u0438.",
    [5, 5],
    ["ride"]
  ),
  item(
    "ride-whale-aurora",
    "\u041A\u0438\u0442 \u043B\u0438\u043B\u043E\u0432\u043E\u0433\u043E \u0441\u0438\u044F\u043D\u0438\u044F",
    "rides",
    3200,
    "\u2728",
    "\u041F\u0435\u0440\u043B\u0430\u043C\u0443\u0442\u0440\u043E\u0432\u044B\u0439 \u043A\u0438\u0442 \u0441 \u0441\u043E\u0437\u0432\u0435\u0437\u0434\u0438\u044F\u043C\u0438 \u0438 \u0441\u0432\u0435\u0442\u044F\u0449\u0438\u043C\u0441\u044F \u0445\u0432\u043E\u0441\u0442\u043E\u043C \u043F\u0440\u043E\u043B\u0435\u0442\u0430\u0435\u0442 \u043D\u0430\u0434 \u043E\u0441\u0442\u0440\u043E\u0432\u043E\u043C \u043F\u043E \u0441\u0432\u043E\u0435\u043C\u0443 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0443.",
    [5, 5],
    ["ride"]
  )
);
CATALOG.push(
  ...[...CITY_RIDES, ...COTTON_RIDES, ...CAPYBARA_RIDES].map((ride) => ({
    ...ride,
    category: "rides",
    actions: ["ride"],
    fixedPrice: true
  }))
);
for (const [id, price, minutes] of [
  ["ride-whale", 1200, 45],
  ["ride-whale-aurora", 1650, 60]
]) {
  const whale = CATALOG.find((i) => i.id === id);
  Object.assign(whale, { price, buildMinutes: minutes, fixedPrice: true });
}
var levelOverrides = {
  "ride-whale": 4,
  "ride-whale-aurora": 4,
  "adoption-center": 2,
  "ride-butterfly": 6,
  "ride-lotus": 11,
  "ride-dragonfly": 10,
  "ride-dinosaur": 12,
  yarn: 1,
  mouse: 1,
  feather: 2,
  tunnel: 3,
  scratch: 2,
  trampoline: 3,
  swing: 2,
  carousel: 5,
  coaster: 6,
  waterslide: 5,
  ferris: 7,
  teacup: 4,
  train: 6,
  boat: 3,
  balloon: 5,
  broom: 4,
  scooter: 2,
  party: 3,
  cafe: 4,
  picnic: 2,
  stage: 5,
  fountain: 2,
  mushroom: 3,
  crystal: 3,
  lantern: 1,
  flowers: 1,
  bed: 1,
  pond: 2,
  "farm-field": 2,
  greenhouse: 5,
  barn: 3,
  orchard: 4,
  "cat-barista": 5,
  "swim-lagoon": 3,
  "coaster-rainbow-launch": 12,
  "slide-royal-cascade": 14,
  "slide-vortex-bowl": 11,
  "coaster-comet-flight": 18,
  "ride-jellyfish": 9,
  "ride-dragon-cloud": 15,
  "toy-bubble-garden": 4,
  "toy-magic-fish": 6
};
var biomeLevels = {
  moon: 1,
  autumn: 3,
  summer: 4,
  beach: 5,
  winter: 4,
  water: 7,
  nature: 7,
  wizard: 8,
  sakura: 9,
  desert: 10,
  bamboo: 10,
  mushrooms: 11,
  candy: 11,
  coral: 12,
  lotus: 12,
  crystal: 13,
  rainbow: 14,
  clouds: 15,
  volcano: 16,
  dusk: 16,
  stars: 17,
  ice: 18,
  clockwork: 18,
  galaxy: 19,
  aquapark: 20
};
for (const biome of BIOMES) {
  biome.requiredLevel = biomeLevels[biome.id];
  if (biome.id !== "moon" && biome.id !== "aquapark")
    biome.price = Math.round(biome.price * (1 + biome.requiredLevel * 0.7) / 10) * 10;
}
CATALOG.push(...REFERENCE_SLIDES, ...ATOLL_SLIDES, ...SHOWCASE_WATER_RIDES, MAGIC_BED, ...MAGIC_BED_SEEDS);
CATEGORIES.splice(CATEGORIES.findIndex((c) => c.id === "lands"), 0, { id: "seeds", name: "\u041D\u0430\u0441\u0456\u043D\u043D\u044F", icon: "\u{1F330}" });
for (const product of CATALOG) {
  product.requiredLevel ||= levelOverrides[product.id] || (product.id.includes("mystic") ? 19 : product.id.includes("legendary") ? 18 : product.id.includes("epic") ? 11 : product.id.includes("coaster") ? 14 : product.id.includes("water-") ? 12 : 8);
  if (!product.fixedPrice && product.category !== "business" && product.id !== "adoption-center" && ![
    "coaster-rainbow-launch",
    "slide-royal-cascade",
    "slide-vortex-bowl",
    "coaster-comet-flight",
    "ride-jellyfish",
    "ride-dragon-cloud",
    "toy-bubble-garden",
    "toy-magic-fish",
    "cat-barista",
    "swim-lagoon"
  ].includes(product.id) && product.requiredLevel > 1)
    product.price = Math.round(product.price * (1 + product.requiredLevel * 0.28) / 5) * 5;
}
var buildOverrides = {
  "adoption-center": 20,
  "coaster-rainbow-launch": 720,
  "slide-royal-cascade": 960,
  "slide-vortex-bowl": 480,
  "coaster-comet-flight": 1440,
  "ride-jellyfish": 360,
  "ride-dragon-cloud": 960,
  "cat-barista": 240,
  "swim-lagoon": 90,
  coaster: 240,
  "coaster-lagoon": 720,
  "coaster-sakura": 480,
  "coaster-moon": 960,
  "coaster-mushroom": 360,
  "coaster-cloud": 1440,
  "coaster-clockwork": 960,
  ferris: 240,
  waterslide: 180,
  "coaster-epic": 480,
  "coaster-legendary": 1440,
  "coaster-mystic": 1440,
  "coaster-dragon": 720,
  "water-extreme": 1440,
  "water-whirlpool": 720,
  "water-river": 240,
  "drop-tower": 480,
  rocket: 480,
  ufo: 360,
  airship: 240,
  festival: 480,
  greenhouse: 240,
  barn: 120,
  orchard: 120
};
for (const product of CATALOG) {
  product.buildMinutes ||= buildOverrides[product.id] || (["rides", "transport"].includes(product.category) ? 120 : product.category === "social" ? 90 : 30);
  product.rarity = product.buildMinutes >= 1440 ? "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u043E\u0435" : product.buildMinutes >= 480 ? "\u042D\u043F\u0438\u0447\u0435\u0441\u043A\u043E\u0435" : product.buildMinutes >= 240 ? "\u0420\u0435\u0434\u043A\u043E\u0435" : "\u0423\u044E\u0442\u043D\u043E\u0435";
}
var CROPS = [
  {
    id: "wheat",
    name: "\u0417\u043E\u043B\u043E\u0442\u0430\u044F \u043F\u0448\u0435\u043D\u0438\u0446\u0430",
    icon: "\u{1F33E}",
    minutes: 3,
    seed: 2,
    value: 14,
    biome: "moon"
  },
  {
    id: "mint",
    name: "\u041B\u0443\u043D\u043D\u0430\u044F \u043C\u044F\u0442\u0430",
    icon: "\u{1F33F}",
    minutes: 10,
    seed: 4,
    value: 18,
    biome: "nature"
  },
  {
    id: "pumpkin",
    name: "\u041C\u0435\u0434\u043E\u0432\u0430\u044F \u0442\u044B\u043A\u0432\u0430",
    icon: "\u{1F383}",
    minutes: 30,
    seed: 6,
    value: 36,
    biome: "autumn"
  },
  {
    id: "berry",
    name: "\u0421\u043D\u0435\u0436\u043D\u0430\u044F \u044F\u0433\u043E\u0434\u0430",
    icon: "\u{1FAD0}",
    minutes: 60,
    seed: 8,
    value: 55,
    biome: "winter"
  },
  {
    id: "lavender",
    name: "\u0412\u0435\u0434\u044C\u043C\u0438\u043D\u0430 \u043B\u0430\u0432\u0430\u043D\u0434\u0430",
    icon: "\u{1FABB}",
    minutes: 20,
    seed: 5,
    value: 25,
    biome: "wizard"
  },
  {
    id: "strawberry",
    name: "\u0421\u043E\u043B\u043D\u0435\u0447\u043D\u0430\u044F \u043A\u043B\u0443\u0431\u043D\u0438\u043A\u0430",
    icon: "\u{1F353}",
    minutes: 15,
    seed: 5,
    value: 28,
    biome: "summer"
  },
  {
    id: "lotus-seed",
    name: "\u041B\u0443\u043D\u043D\u044B\u0439 \u043B\u043E\u0442\u043E\u0441",
    icon: "\u{1FAB7}",
    minutes: 25,
    seed: 6,
    value: 32,
    biome: "water"
  },
  {
    id: "tea",
    name: "\u0427\u0430\u0439 \u0441\u0430\u043A\u0443\u0440\u044B",
    icon: "\u{1F375}",
    minutes: 45,
    seed: 8,
    value: 50,
    biome: "sakura"
  },
  {
    id: "cactus",
    name: "\u041A\u0430\u0440\u0430\u043C\u0435\u043B\u044C\u043D\u044B\u0439 \u043A\u0430\u043A\u0442\u0443\u0441",
    icon: "\u{1F335}",
    minutes: 10,
    seed: 4,
    value: 18,
    biome: "desert"
  },
  {
    id: "candy-cane",
    name: "\u0421\u0430\u0445\u0430\u0440\u043D\u044B\u0435 \u0442\u0440\u043E\u0441\u0442\u0438\u043D\u043A\u0438",
    icon: "\u{1F36D}",
    minutes: 120,
    seed: 8,
    value: 80,
    biome: "candy"
  },
  {
    id: "star-melon",
    name: "\u0417\u0432\u0451\u0437\u0434\u043D\u0430\u044F \u0434\u044B\u043D\u044F",
    icon: "\u{1F348}",
    minutes: 240,
    seed: 10,
    value: 140,
    biome: "stars"
  },
  {
    id: "crystal-fruit",
    name: "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u043B\u043E\u0434",
    icon: "\u{1F48E}",
    minutes: 180,
    seed: 10,
    value: 130,
    biome: "crystal"
  },
  {
    id: "cloud-cotton",
    name: "\u041E\u0431\u043B\u0430\u0447\u043D\u044B\u0439 \u0445\u043B\u043E\u043F\u043E\u043A",
    icon: "\u2601",
    minutes: 120,
    seed: 8,
    value: 95,
    biome: "clouds"
  },
  {
    id: "ember",
    name: "\u0414\u0440\u0430\u043A\u043E\u043D\u044C\u0438 \u043F\u0435\u0440\u0447\u0438\u043A\u0438",
    icon: "\u{1F336}",
    minutes: 90,
    seed: 9,
    value: 85,
    biome: "volcano"
  },
  {
    id: "bamboo",
    name: "\u0427\u0430\u0439\u043D\u044B\u0439 \u0431\u0430\u043C\u0431\u0443\u043A",
    icon: "\u{1F38B}",
    minutes: 45,
    seed: 6,
    value: 45,
    biome: "bamboo"
  },
  {
    id: "glow-mushroom",
    name: "\u041B\u0443\u043D\u043D\u044B\u0435 \u0433\u0440\u0438\u0431\u043E\u0447\u043A\u0438",
    icon: "\u{1F344}",
    minutes: 40,
    seed: 6,
    value: 42,
    biome: "mushrooms"
  },
  {
    id: "pearl-coconut",
    name: "\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u044B\u0439 \u043A\u043E\u043A\u043E\u0441",
    icon: "\u{1F965}",
    minutes: 35,
    seed: 6,
    value: 40,
    biome: "beach"
  },
  {
    id: "prism-beet",
    name: "\u0420\u0430\u0434\u0443\u0436\u043D\u0430\u044F \u0441\u0432\u0451\u043A\u043B\u0430",
    icon: "\u{1F308}",
    minutes: 75,
    seed: 8,
    value: 70,
    biome: "rainbow"
  },
  {
    id: "galaxy-grape",
    name: "\u0413\u0430\u043B\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0432\u0438\u043D\u043E\u0433\u0440\u0430\u0434",
    icon: "\u{1F347}",
    minutes: 360,
    seed: 12,
    value: 190,
    biome: "galaxy"
  },
  {
    id: "coral-pear",
    name: "\u041A\u043E\u0440\u0430\u043B\u043B\u043E\u0432\u0430\u044F \u0433\u0440\u0443\u0448\u0430",
    icon: "\u{1FAB8}",
    minutes: 80,
    seed: 8,
    value: 75,
    biome: "coral"
  },
  {
    id: "lotus-blossom",
    name: "\u0421\u0435\u0440\u0435\u0431\u0440\u044F\u043D\u044B\u0439 \u0446\u0432\u0435\u0442\u043E\u043A \u043B\u043E\u0442\u043E\u0441\u0430",
    icon: "\u{1F33A}",
    minutes: 50,
    seed: 7,
    value: 52,
    biome: "lotus"
  },
  {
    id: "ice-peach",
    name: "\u041B\u0435\u0434\u044F\u043D\u043E\u0439 \u043F\u0435\u0440\u0441\u0438\u043A",
    icon: "\u{1F351}",
    minutes: 180,
    seed: 10,
    value: 125,
    biome: "ice"
  },
  {
    id: "clock-pumpkin",
    name: "\u041A\u043B\u0443\u0431\u043D\u0438\u0447\u043D\u0430\u044F \u0442\u044B\u043A\u043E\u0432\u043A\u0430",
    icon: "\u{1F353}",
    minutes: 150,
    seed: 10,
    value: 115,
    biome: "clockwork"
  },
  {
    id: "night-flower",
    name: "\u041F\u043E\u043B\u0443\u043D\u043E\u0447\u043D\u044B\u0439 \u0446\u0432\u0435\u0442\u043E\u043A",
    icon: "\u{1F319}",
    minutes: 240,
    seed: 11,
    value: 160,
    biome: "dusk"
  }
];
var JOBS = [
  {
    id: "fishing",
    name: "\u0420\u044B\u0431\u0430\u043B\u043A\u0430",
    icon: "\u{1F3A3}",
    biomes: ["beach", "water", "coral", "lotus"],
    minutes: 20,
    resource: "fish",
    value: 25
  },
  {
    id: "foraging",
    name: "\u041B\u0435\u0441\u043D\u043E\u0439 \u0441\u0431\u043E\u0440",
    icon: "\u{1F344}",
    biomes: ["nature", "autumn", "bamboo", "mushrooms"],
    minutes: 10,
    resource: "mushrooms",
    value: 15
  },
  {
    id: "mining",
    name: "\u0421\u0430\u043C\u043E\u0446\u0432\u0435\u0442\u044B",
    icon: "\u{1F48E}",
    biomes: ["wizard", "crystal", "volcano", "galaxy", "ice"],
    minutes: 30,
    resource: "gems",
    value: 35
  },
  {
    id: "honey",
    name: "\u041C\u0435\u0434\u043E\u0432\u0430\u044F \u043F\u0430\u0441\u0435\u043A\u0430",
    icon: "\u{1F36F}",
    biomes: ["summer", "sakura", "candy", "rainbow"],
    minutes: 60,
    resource: "honey",
    value: 45
  }
];
CROPS.push({
  id: "rainbow-mango",
  name: "\u0420\u0430\u0434\u0443\u0436\u043D\u043E\u0435 \u043C\u0430\u043D\u0433\u043E",
  icon: "\u{1F96D}",
  minutes: 240,
  seed: 16,
  value: 240,
  biome: "aquapark"
});
NEIGHBORS.push(
  {
    id: "boba",
    name: "\u0411\u043E\u0431\u0430",
    biome: "aquapark",
    color: 13150860,
    personality: "\u041B\u044E\u0431\u0438\u0442 \u0432\u043E\u0434\u043D\u044B\u0435 \u0433\u043E\u0440\u043A\u0438 \u0438 \u043C\u044F\u0433\u043A\u0438\u0435 \u043F\u0440\u0438\u0432\u043E\u0434\u043D\u0435\u043D\u0438\u044F"
  },
  {
    id: "splash",
    name: "\u041A\u0430\u043F\u0435\u043B\u044C\u043A\u0430",
    biome: "aquapark",
    color: 9550795,
    personality: "\u041F\u043B\u0430\u0432\u0430\u0435\u0442 \u0432 \u043B\u0430\u0433\u0443\u043D\u0435 \u0438 \u043E\u0431\u043E\u0436\u0430\u0435\u0442 \u0440\u0430\u0437\u043D\u043E\u0446\u0432\u0435\u0442\u043D\u044B\u0445 \u0440\u044B\u0431\u043E\u043A"
  }
);
var residentBreeds = [
  "british",
  "ragdoll",
  "blue",
  "tabby",
  "munchkin",
  "tuxedo",
  "persian",
  "blue",
  "tabby",
  "calico",
  "tabby",
  "cheshire"
];
for (const [index, profile] of NEIGHBORS.entries()) {
  profile.breed = residentBreeds[index % residentBreeds.length];
  profile.eyes = [11849331, 9289690, 14728299, 9487517][index % 4];
  if (profile.id === "moti") profile.build = "plush";
  if (profile.id === "bagel" || profile.id === "boba") profile.build = "giant";
}
NEIGHBORS.push(...ADOPTION_CATS);
NEIGHBORS.push({
  id: "hotdog-bun",
  name: "\u0411\u0443\u043B\u043E\u0447\u043A\u0430",
  biome: "moon",
  venue: "business-hotdog",
  breed: "munchkin",
  color: 14860701,
  eyes: 10863977,
  size: 0.36 / 0.63,
  personality: "\u041C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u043F\u043E\u043C\u043E\u0449\u043D\u0438\u043A \u043F\u043E\u0432\u0430\u0440\u0430: \u043B\u044E\u0431\u0438\u0442 \u043A\u043B\u0443\u0431\u043E\u0447\u043A\u0438, \u043A\u0443\u043F\u0430\u043D\u0438\u0435 \u0438 \u043F\u0440\u043E\u0433\u0443\u043B\u043A\u0438"
});
for (const biome of BIOMES)
  if (RENEWED_ISLANDS[biome.id]) {
    const next = RENEWED_ISLANDS[biome.id];
    Object.assign(biome, {
      name: next.name,
      subtitle: next.subtitle,
      icon: next.icon,
      radius: next.radius || 14.8,
      ...next.arrival ? { arrival: next.arrival } : {},
      ground: next.ground,
      foliage: next.leaf,
      accent: next.flower
    });
  }
BIOMES.splice(
  BIOMES.findIndex((b) => b.id === "wizard"),
  1
);
for (const cat2 of NEIGHBORS) if (cat2.biome === "wizard") cat2.biome = "moon";
for (const crop of CROPS) if (crop.biome === "wizard") crop.biome = "moon";
for (const job of JOBS)
  job.biomes = job.biomes.map((id) => id === "wizard" ? "moon" : id);
var renewalCrops = {
  winter: ["\u041B\u0443\u043D\u043D\u0430\u044F \u043C\u043E\u0440\u0441\u043A\u0430\u044F \u044F\u0433\u043E\u0434\u0430", "\u{1F52E}"],
  autumn: ["\u042F\u043D\u0442\u0430\u0440\u043D\u044B\u0435 \u044F\u0431\u043B\u043E\u0447\u043A\u0438", "\u{1F34E}"],
  ice: ["\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u044F\u0433\u043E\u0434\u044B", "\u{1FAD0}"],
  galaxy: ["\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u044B\u0439 \u0432\u0438\u043D\u043E\u0433\u0440\u0430\u0434", "\u{1F347}"],
  volcano: ["\u0422\u0440\u043E\u043F\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043F\u043B\u043E\u0434", "\u{1F96D}"]
};
for (const crop of CROPS)
  if (renewalCrops[crop.biome]) {
    crop.name = renewalCrops[crop.biome][0];
    crop.icon = renewalCrops[crop.biome][1];
  }
JOBS.find((job) => job.id === "fishing").biomes.push("winter");
separateIslandCenters(BIOMES);
Object.assign(
  BIOMES.find((b) => b.id === "sakura"),
  {
    radius: CHILL_RADIUS,
    center: [-104, 0],
    arrival: [CHILL_GATE.x, CHILL_GATE.z]
  }
);
Object.assign(
  BIOMES.find((b) => b.id === "autumn"),
  {
    radius: MOSA_RADIUS,
    center: [-150, -42],
    arrival: [MOSA_SHORE_GATE.x, MOSA_SHORE_GATE.z],
    requiredLevel: 8
  }
);
CATALOG.push({
  id: "ride-mosasaur",
  name: "\u041C\u0430\u0440\u0438\u043D \xB7 \u043C\u043E\u0440\u0441\u043A\u043E\u0439 \u0432\u0435\u043B\u0438\u043A\u0430\u043D",
  icon: "\u{1F995}",
  category: "rides",
  islandOnly: true,
  requiredLevel: 8,
  price: 0,
  buildMinutes: 0,
  footprint: [5, 5],
  actions: ["ride"],
  rarity: "\u041B\u0435\u0433\u0435\u043D\u0434\u0430\u0440\u043D\u043E\u0435",
  description: "\u0414\u0440\u0443\u0433 \u043D\u0435\u0431\u0435\u0441\u043D\u043E\u0433\u043E \u043C\u043E\u0440\u044F: \u043D\u044B\u0440\u044F\u0435\u0442 \u0433\u043B\u0443\u0431\u043E\u043A\u043E \u0438 \u0432\u0437\u043B\u0435\u0442\u0430\u0435\u0442 \u043D\u0430\u0434 \u0432\u043E\u043B\u043D\u0430\u043C\u0438 \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u043A\u043E\u0442\u0438\u043A\u043E\u043C."
});
BIOMES.push({
  id: "foodcourt",
  name: "\u041A\u043E\u0442\u044F\u0447\u0438\u0439 \u0444\u0443\u0434-\u043A\u043E\u0440\u0442",
  subtitle: "\u0411\u0443\u0440\u0433\u0435\u0440\u044B, \u0431\u0430\u0431\u043B-\u0442\u0438, \u043A\u043E\u0442\u044F\u0447\u044C\u0435 \u043F\u0435\u0447\u0435\u043D\u044C\u0435 \u0438 \u043A\u0438\u043D\u043E \u043F\u043E\u0434 \u043E\u0431\u043B\u0430\u043A\u0430\u043C\u0438",
  icon: "\u{1F354}",
  price: 2800,
  requiredLevel: 6,
  radius: COURT_RADIUS,
  center: [-155, 80],
  arrival: [COURT_GATE.x, COURT_GATE.z],
  ground: 11125899,
  edge: 8293778,
  foliage: 7776888,
  accent: 16043167
});
CATALOG.push(
  ...COURT_VENUES.map((o) => ({
    id: o.type,
    name: o.name,
    description: o.description,
    category: "business",
    icon: o.icon,
    price: o.price,
    buildMinutes: o.buildMinutes,
    requiredLevel: 6,
    islandOnly: true,
    rarity: "\u041E\u0441\u0442\u0440\u043E\u0432\u043D\u043E\u0439 \u0431\u0438\u0437\u043D\u0435\u0441",
    footprint: [o.w, o.d],
    actions: [o.kind === "cinema" ? "rest" : "eat", "explore"]
  }))
);
NEIGHBORS.push(...COURT_LOCALS);
CROPS.push({
  id: "court-strawberry",
  name: "\u0416\u0435\u043C\u0447\u0443\u0436\u043D\u0430\u044F \u043A\u043B\u0443\u0431\u043D\u0438\u043A\u0430",
  icon: "\u{1F353}",
  minutes: 18,
  seed: 6,
  value: 38,
  biome: "foodcourt"
});
BIOMES.push({
  id: "bikini",
  name: "\u0411\u0438\u043A\u0438\u043D\u0438-\u0411\u043E\u0442\u0442\u043E\u043C",
  subtitle: "\u0413\u0443\u0431\u043A\u0430 \u0411\u043E\u0431, \u041F\u0430\u0442\u0440\u0438\u043A, \u043A\u0440\u0430\u0431\u0441\u0431\u0443\u0440\u0433\u0435\u0440\u044B \u0438 \u043C\u044B\u043B\u044C\u043D\u044B\u0435 \u043F\u0443\u0437\u044B\u0440\u0438 \u043D\u0430\u0434 \u043E\u0431\u043B\u0430\u043A\u0430\u043C\u0438",
  icon: "\u{1F9FD}",
  price: 2400,
  requiredLevel: 5,
  radius: BIKINI_RADIUS,
  center: [-225, 80],
  arrival: [BIKINI_GATE.x, BIKINI_GATE.z],
  ground: 15324579,
  edge: 9343903,
  foliage: 9549972,
  accent: 6474713
});
CATALOG.push(
  {
    id: BIKINI_RESTAURANT.type,
    name: BIKINI_RESTAURANT.name,
    description: BIKINI_RESTAURANT.description,
    category: "business",
    icon: "\u{1F354}",
    price: 0,
    buildMinutes: 0,
    requiredLevel: 5,
    islandOnly: true,
    rarity: "\u0411\u0438\u043A\u0438\u043D\u0438-\u0411\u043E\u0442\u0442\u043E\u043C",
    footprint: [12, 10],
    actions: ["eat", "explore"]
  },
  ...BIKINI_FRIENDS.map((f) => ({
    id: f.type,
    name: f.name,
    description: "\u0416\u0438\u0432\u043E\u0439 \u0434\u0440\u0443\u0433: \u043F\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F, \u0438\u0433\u0440\u044B \u0438 \u043E\u0431\u044A\u044F\u0442\u0438\u044F \u0441 \u043A\u043E\u0442\u0438\u043A\u0430\u043C\u0438",
    category: "toys",
    icon: f.kind === "sponge" ? "\u{1F9FD}" : "\u2B50",
    price: 0,
    buildMinutes: 0,
    requiredLevel: 5,
    islandOnly: true,
    rarity: "\u0414\u0440\u0443\u0433 \u0411\u0438\u043A\u0438\u043D\u0438-\u0411\u043E\u0442\u0442\u043E\u043C",
    footprint: [3, 3],
    actions: ["play"]
  }))
);
NEIGHBORS.push(...BIKINI_LOCALS);
CROPS.push({
  id: "bikini-sea-grape",
  name: "\u041C\u043E\u0440\u0441\u043A\u043E\u0439 \u0432\u0438\u043D\u043E\u0433\u0440\u0430\u0434",
  icon: "\u{1F7E2}",
  minutes: 16,
  seed: 5,
  value: 34,
  biome: "bikini"
});
BIOMES.push({
  id: "homestead",
  name: "\u041D\u0430\u0448 \u043E\u0441\u0442\u0440\u043E\u0432",
  subtitle: "\u041E\u0433\u0440\u043E\u043C\u043D\u044B\u0439 \u0446\u0432\u0435\u0442\u0443\u0449\u0438\u0439 \u043B\u0443\u0433 \u2014 \u0432\u0441\u0451 \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u043E\u0435 \u043F\u043E\u0441\u0442\u0440\u043E\u0438\u0442\u0435 \u0432\u044B",
  icon: "\u{1F33C}",
  price: 1800,
  requiredLevel: 3,
  radius: HOMESTEAD_RADIUS,
  center: [...HOMESTEAD_EXPANSION.center],
  arrival: [0, 0],
  ground: 11257484,
  edge: 9803662,
  foliage: 10599812,
  accent: 15979450
});
CROPS.push({
  id: "homestead-strawberry",
  name: "\u041B\u0443\u0433\u043E\u0432\u0430\u044F \u043A\u043B\u0443\u0431\u043D\u0438\u043A\u0430",
  icon: "\u{1F353}",
  minutes: 12,
  seed: 4,
  value: 28,
  biome: "homestead"
});
CATALOG.push(...MEGA_RIDES);
CATALOG.push(DIAMOND_MINE);
BIOMES.push({
  id: "aquarium",
  name: "\u041A\u043E\u0442\u044F\u0447\u0438\u0439 \u043E\u043A\u0435\u0430\u043D\u0430\u0440\u0438\u0443\u043C",
  subtitle: "\u0421\u0442\u0435\u043A\u043B\u044F\u043D\u043D\u044B\u0439 \u0434\u0432\u043E\u0440\u0435\u0446, \u043E\u0433\u0440\u043E\u043C\u043D\u044B\u0435 \u0440\u044B\u0431\u043A\u0438-\u043A\u043E\u0442\u0438\u043A\u0438 \u0438 \u043D\u0435\u0436\u043D\u044B\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0438 \u0443 \u0432\u043E\u0434\u044B",
  icon: "\u{1F420}",
  price: 3200,
  requiredLevel: 14,
  radius: AQUARIUM_RADIUS,
  center: [-335, 95],
  arrival: [AQUARIUM_GATE.x, AQUARIUM_GATE.z],
  ground: 13360294,
  edge: 11182517,
  foliage: 11061638,
  accent: 10805231
});
CATALOG.push(
  ...AQUARIUM_TANKS.map((o) => ({
    id: o.type,
    name: o.name,
    description: o.description,
    category: "toys",
    icon: o.icon,
    price: 0,
    buildMinutes: 0,
    requiredLevel: 6,
    islandOnly: true,
    rarity: "\u041E\u043A\u0435\u0430\u043D\u0430\u0440\u0438\u0443\u043C",
    footprint: [o.w, o.d],
    actions: ["play", "explore"]
  }))
);
NEIGHBORS.push(...AQUARIUM_LOCALS);
for (const product of CATALOG) {
  const water = waterRideSpec(product.id);
  if (water)
    product.waterRide = {
      version: water.version,
      kind: water.kind,
      channels: water.channels
    };
}
for (const [id, spec] of Object.entries(BUILDING_EXPANSIONS)) {
  Object.assign(byBiome(id), {
    radius: expandedBuildingRadius(id),
    center: [...spec.center],
    buildableAreaMultiplier: spec.areaMultiplier
  });
}
BIOMES.push({
  id: JOB_CITY_ID,
  name: "Cat Job City",
  subtitle: "\u041C\u0456\u0441\u0442\u043E \u043F\u0440\u043E\u0444\u0435\u0441\u0456\u0439, \u0432\u043B\u0430\u0441\u043D\u0438\u0445 \u043C\u043E\u043D\u0435\u0442\u043E\u043A \u0442\u0430 \u043A\u043E\u0442\u044F\u0447\u0438\u0445 \u043C\u0430\u0448\u0438\u043D",
  icon: "\u{1F3D9}\uFE0F",
  price: 6500,
  requiredLevel: 8,
  radius: JOB_CITY_RADIUS,
  center: [...JOB_CITY_CENTER],
  arrival: [0, 59],
  ground: 12175764,
  edge: 9803661,
  foliage: 8563822,
  accent: 15319946
});
CATALOG.push(
  ...JOB_BUSINESSES.map((b) => ({
    id: b.id,
    name: b.name,
    description: b.description,
    category: "business",
    icon: b.icon,
    price: 0,
    buildMinutes: 0,
    requiredLevel: 8,
    islandOnly: true,
    rarity: "Cat Job City",
    footprint: [b.w, b.d],
    actions: ["explore"]
  }))
);
NEIGHBORS.push(...JOB_CITY_LOCALS);
BIOMES.push({
  id: HOUSING_ID,
  name: "\u041A\u043E\u0442\u044F\u0447\u0456 \u043E\u0441\u0435\u043B\u0456",
  subtitle: "\u0412\u043B\u0430\u0441\u043D\u0456 \u0431\u0443\u0434\u0438\u043D\u043E\u0447\u043A\u0438 \u043A\u043E\u0442\u0438\u043A\u0456\u0432 \xB7 \u043D\u043E\u0432\u0456 \u043A\u0432\u0430\u0440\u0442\u0430\u043B\u0438 \u0437 \u043A\u043E\u0436\u043D\u043E\u044E \u043F\u043E\u043A\u0443\u043F\u043A\u043E\u044E",
  icon: "\u{1F3E1}",
  price: 0,
  requiredLevel: 8,
  radius: HOUSING_RADIUS,
  center: [...HOUSING_CENTER],
  arrival: [0, 37],
  ground: 10993034,
  edge: 10394514,
  foliage: 8627566,
  accent: 15250885,
  housingOnly: true
});
var RETIRED_BIOMES = BIOMES.filter((b) => isRetiredBiome(b.id));
for (let i = BIOMES.length - 1; i >= 0; i--) if (isRetiredBiome(BIOMES[i].id)) BIOMES.splice(i, 1);
for (const b of BIOMES) b.center = [...WORLD_CENTERS[b.id]];
BIOMES.push({ ...ATOLL_PARK, center: [...ATOLL_PARK.center] });
RETIRED_BIOMES.push(...MAGIC_FARMS.map((f) => ({ ...f, center: [...f.center] })));
CROPS.push(...MAGIC_FRUITS);
CROPS.push(...MAGIC_BED_CROPS);
for (const n of NEIGHBORS) if (isRetiredBiome(n.biome)) {
  n.originBiome = n.biome;
  n.biome = "homestead";
}
for (const crop of CROPS) if (isRetiredBiome(crop.biome)) crop.biome = "homestead";
for (const job of JOBS) job.biomes = [...new Set(job.biomes.map((id) => isRetiredBiome(id) ? "homestead" : id))];
BIOMES.push({ ...ZOO_BIOME, center: [...ZOO_BIOME.center] });
CATALOG.push(...ZOO_EXHIBITS.map((e) => ({ ...e, category: "social", requiredLevel: 8, islandOnly: true, rarity: "\u0427\u0430\u0440\u0456\u0432\u043D\u0438\u0439 \u0437\u043E\u043E\u043F\u0430\u0440\u043A", actions: ["explore"] })));

// public/cat-sex.js
var known = {
  chichi: "female",
  nimbus: "male",
  "adopt-nimbus": "male",
  "adopt-marshmallow": "male",
  "adopt-doughnut": "male",
  "adopt-cloudberry": "female"
};
function catSex(cat2) {
  const id = typeof cat2 === "string" ? cat2 : cat2?.id || "";
  if (known[id]) return known[id];
  const hash3 = [...id].reduce((n, c) => Math.imul(n, 31) + c.charCodeAt(0), 17);
  return (hash3 >>> 0) % 2 ? "male" : "female";
}

// public/family-system.js
var FAMILY_REVIEW_DAYS = 14;
var FAMILY_SHARE = 4;
var clone = (value) => structuredClone(value);
var idValid = (id) => typeof id === "string" && /^[\w-]{1,40}$/.test(id);
var integer = (n) => Number.isSafeInteger(n) && n >= 0;
var dateFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Europe/Kyiv",
  year: "numeric",
  month: "2-digit",
  day: "2-digit"
});
var dayFormatter = new Intl.DateTimeFormat("uk-UA", {
  day: "numeric",
  month: "long",
  timeZone: "UTC"
});
var kyivDate = (now) => dateFormatter.format(now);
function newFamily(day, now = Date.now()) {
  return {
    version: 1,
    calendar: { startDay: day, startedAt: now, startDate: kyivDate(now) },
    lastReviewDay: day - 1,
    couples: {}
  };
}
function familySnapshotValid(family) {
  if (family == null) return true;
  if (family.version !== 1 || !integer(family.calendar?.startDay) || !Number.isFinite(family.calendar.startedAt) || !/^\d{4}-\d{2}-\d{2}$/.test(family.calendar.startDate || "") || !Number.isFinite(Date.parse(family.calendar.startDate + "T12:00:00Z")) || !Number.isSafeInteger(family.lastReviewDay) || !family.couples || typeof family.couples !== "object" || Array.isArray(family.couples))
    return false;
  const members = /* @__PURE__ */ new Set();
  for (const [id, pair] of Object.entries(family.couples)) {
    if (!pair || id !== pair.id || id !== `family-${pair.male}-${pair.female}` || !idValid(pair.male) || !idValid(pair.female) || pair.male === pair.female || catSex(pair.male) !== "male" || catSex(pair.female) !== "female" || members.has(pair.male) || members.has(pair.female) || !integer(pair.formedDay) || !Number.isFinite(pair.formedAt) || pair.source !== "ai" || typeof pair.reason !== "string" || pair.reason.length > 160)
      return false;
    members.add(pair.male);
    members.add(pair.female);
  }
  return true;
}
function normalizeFamily(raw) {
  if (raw == null) return null;
  if (!familySnapshotValid(raw)) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u043E \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043D\u044F \u0441\u0456\u043C\u0435\u0439");
  return clone(raw);
}
function ensureFamily(game, day, now = Date.now()) {
  if (!game.jobCity || game.family) return game;
  return { ...game, family: newFamily(day, now) };
}
function familyPartners(game) {
  const partners = /* @__PURE__ */ new Map();
  for (const pair of Object.values(game.family?.couples || {})) {
    partners.set(pair.male, pair.female);
    partners.set(pair.female, pair.male);
  }
  return partners;
}
var familyLimit = (profiles) => Math.min(
  profiles.filter((p) => catSex(p) === "male").length,
  profiles.filter((p) => catSex(p) === "female").length
);
var familyReviewLimit = (profiles) => Math.max(1, Math.floor(profiles.length / (FAMILY_SHARE * 2)));
function validateFamilyProposals(proposals, profiles, slots = familyReviewLimit(profiles)) {
  if (!Array.isArray(proposals) || proposals.length > slots)
    throw Error("\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0438\u0439 \u0432\u0438\u0431\u0456\u0440 \u0441\u0456\u043C\u0435\u0439");
  const people = new Map(profiles.map((p) => [p.id, p]));
  const used = /* @__PURE__ */ new Set();
  return proposals.map((pair) => {
    const male = people.get(pair?.male), female = people.get(pair?.female);
    if (!male || !female || catSex(male) !== "male" || catSex(female) !== "female" || male.partner || female.partner || used.has(male.id) || used.has(female.id))
      throw Error("AI \u043C\u0430\u0454 \u0432\u0438\u0431\u0440\u0430\u0442\u0438 \u0434\u0432\u043E\u0445 \u0432\u0456\u043B\u044C\u043D\u0438\u0445 \u0441\u0443\u043C\u0456\u0441\u043D\u0438\u0445 \u043A\u043E\u0442\u0438\u043A\u0456\u0432");
    used.add(male.id);
    used.add(female.id);
    return {
      male: male.id,
      female: female.id,
      reason: String(pair.reason || "\u041F\u043E\u0434\u043E\u0431\u0430\u044E\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u043E\u0434\u043D\u043E\u043C\u0443").slice(0, 160)
    };
  });
}
function firstFamilyHome(game, members) {
  let first = null;
  for (const home of Object.values(game.housing?.homes || {}))
    if (members.includes(home.owner) && (!first || home.at < first.at || home.at === first.at && home.id < first.id)) first = home;
  return first;
}
function reconcileFamilyHomes(game) {
  if (!game.family || !game.housing) return game;
  const housing = game.housing;
  for (const pair of Object.values(game.family.couples)) {
    const members = [pair.male, pair.female], home = firstFamilyHome(game, members);
    if (!home) continue;
    for (const old of Object.values(housing.homes)) {
      if (old.id === home.id) continue;
      if (members.includes(old.owner)) {
        housing.retiredHomes ||= {};
        housing.retiredHomes[old.id] ||= { ...clone(old), replacedBy: home.id };
        delete housing.homes[old.id];
        for (const [cat2, id] of Object.entries(housing.residences))
          if (id === old.id) delete housing.residences[cat2];
      } else if (members.includes(old.roommate)) old.roommate = null;
    }
    const spouse = members.find((id) => id !== home.owner);
    if (home.roommate && home.roommate !== spouse && housing.residences[home.roommate] === home.id)
      delete housing.residences[home.roommate];
    home.roommate = spouse;
    for (const id of members) housing.residences[id] = home.id;
  }
  return game;
}
function mergeFamily(base, current, incoming) {
  if (!incoming) return current ? clone(current) : null;
  if (!current) return normalizeFamily(incoming);
  if (!familySnapshotValid(incoming) || !familySnapshotValid(current))
    throw Error("\u041D\u0435\u043F\u043E\u0432\u043D\u0430 \u0441\u0456\u043C'\u044F \u0443 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043D\u0456");
  const next = clone(current), members = familyPartners({ family: current });
  for (const [id, pair] of Object.entries(incoming.couples)) {
    if (next.couples[id]) {
      if (JSON.stringify(next.couples[id]) !== JSON.stringify(pair))
        throw Error("\u041F\u043E\u0441\u0442\u0456\u0439\u043D\u0443 \u0441\u0456\u043C'\u044E \u0432\u0436\u0435 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E \u0437 \u0456\u043D\u0448\u0438\u043C\u0438 \u0434\u0430\u043D\u0438\u043C\u0438");
      continue;
    }
    if (members.has(pair.male) || members.has(pair.female))
      throw Error("\u041F\u0430\u0440\u0442\u043D\u0435\u0440\u0430 \u0432\u0436\u0435 \u043E\u0431\u0440\u0430\u043D\u043E \u043D\u0430 \u0456\u043D\u0448\u043E\u043C\u0443 \u043F\u0440\u0438\u0441\u0442\u0440\u043E\u0457");
    next.couples[id] = clone(pair);
    members.set(pair.male, pair.female);
    members.set(pair.female, pair.male);
  }
  next.lastReviewDay = Math.max(current.lastReviewDay, incoming.lastReviewDay);
  return next;
}
function checkFamilyPace(current, merged, profiles) {
  if (!current) return;
  const before = Object.values(current?.couples || {}), after = Object.values(merged?.couples || {}), limit = familyReviewLimit(profiles);
  for (const pair of after) {
    const inWindow = (p) => p.formedDay <= pair.formedDay && p.formedDay > pair.formedDay - FAMILY_REVIEW_DAYS;
    if (after.filter(inWindow).length > Math.max(limit, before.filter(inWindow).length))
      throw Error(
        "\u041D\u043E\u0432\u0456 \u0441\u0456\u043C\u2019\u0457 \u0432\u0436\u0435 \u043E\u0431\u0440\u0430\u043D\u043E \u043D\u0430 \u0456\u043D\u0448\u043E\u043C\u0443 \u043F\u0440\u0438\u0441\u0442\u0440\u043E\u0457. \u041D\u0430\u0441\u0442\u0443\u043F\u043D\u0456 \u0437\u043D\u0430\u0439\u043E\u043C\u0441\u0442\u0432\u0430 \u2014 \u0447\u0435\u0440\u0435\u0437 14 \u0456\u0433\u0440\u043E\u0432\u0438\u0445 \u0434\u043D\u0456\u0432."
      );
  }
}

// public/housing-system.js
var clone2 = (v) => structuredClone(v);
var equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
var validId = (v) => typeof v === "string" && /^[\w-]{1,90}$/.test(v);
var integer2 = (v) => Number.isSafeInteger(v) && v >= 0;
var newHousing = () => ({ version: 1, homes: {}, residences: {} });
function housingSnapshotValid(raw) {
  if (raw == null) return true;
  if (typeof raw !== "object" || raw.version !== 1 || !raw.homes || typeof raw.homes !== "object" || Array.isArray(raw.homes) || !raw.residences || typeof raw.residences !== "object" || Array.isArray(raw.residences))
    return false;
  const normalized = normalizeHousing(raw);
  return Object.keys(normalized.homes).length === Object.keys(raw.homes).length && Object.keys(normalized.residences).length === Object.keys(raw.residences).length && Object.keys(normalized.retiredHomes || {}).length === Object.keys(raw.retiredHomes || {}).length;
}
function nextHousingPlot(housing) {
  const used = new Set(Object.values(housing.homes).map((h) => h.plot));
  let index = 0;
  while (used.has(index)) index++;
  return index;
}
function normalizeHousing(raw, profiles = {}) {
  if (!raw || raw.version !== 1) return null;
  const h = newHousing(), used = /* @__PURE__ */ new Set();
  for (const [id, home] of Object.entries(raw.homes || {})) {
    if (!validId(id) || !home || typeof home !== "object" || home.id !== id || !validId(home.owner) || !houseType(home.type) || !validId(home.purchaseId) || !integer2(home.sequence) || home.sequence < 1 || !integer2(home.price) || !integer2(home.plot) || !Number.isFinite(home.at))
      continue;
    const plot = used.has(home.plot) ? nextHousingPlot(h) : home.plot;
    used.add(plot);
    const roommate = validId(home.roommate) && home.roommate !== home.owner ? home.roommate : null;
    h.homes[id] = {
      id,
      owner: home.owner,
      type: home.type,
      purchaseId: home.purchaseId,
      sequence: home.sequence,
      price: home.price,
      at: home.at,
      plot,
      source: home.source === "ai" ? "ai" : "manual",
      aiDay: integer2(home.aiDay) ? home.aiDay : null,
      roommate
    };
  }
  for (const [cat2, id] of Object.entries(raw.residences || {})) {
    const home = h.homes[id];
    if (validId(cat2) && home && (home.owner === cat2 || home.roommate === cat2))
      h.residences[cat2] = id;
  }
  if (raw.retiredHomes != null) {
    const archived = normalizeHousing({ version: 1, homes: raw.retiredHomes, residences: {} });
    h.retiredHomes = {};
    for (const [id, home] of Object.entries(archived.homes)) {
      const replacedBy = raw.retiredHomes[id].replacedBy;
      if (!h.homes[id] && validId(replacedBy) && replacedBy !== id && h.homes[replacedBy])
        h.retiredHomes[id] = { ...home, replacedBy };
    }
  }
  return h;
}
var housingOffers = () => HOUSE_TYPES.map(({ id, name, price }) => ({ id, name, price }));
function mergeHousing(base, current, incoming) {
  if (!incoming) return clone2(current);
  if (!current) return clone2(incoming);
  const result2 = clone2(current), added = /* @__PURE__ */ new Set();
  const retired2 = { ...clone2(current.retiredHomes || {}), ...clone2(incoming.retiredHomes || {}) };
  if (Object.keys(retired2).length) result2.retiredHomes = retired2;
  for (const id of Object.keys(retired2)) delete result2.homes[id];
  for (const [id, h] of Object.entries(incoming.homes || {})) {
    if (retired2[id]) {
      if (!["id", "owner", "type", "purchaseId", "sequence", "price", "at"].every((k) => equal(h[k], retired2[id][k])))
        throw Error("\u0410\u0440\u0445\u0456\u0432\u043D\u0430 \u043F\u043E\u043A\u0443\u043F\u043A\u0430 \u0431\u0443\u0434\u0438\u043D\u043A\u0443 \u043C\u0430\u0454 \u0456\u043D\u0448\u0456 \u0434\u0430\u043D\u0456");
      continue;
    }
    const old = base?.homes?.[id], actual = current.homes?.[id];
    if (!old && !actual) {
      const occupied = Object.values(result2.homes).some(
        (x) => x.plot === h.plot
      );
      result2.homes[id] = {
        ...clone2(h),
        plot: occupied ? nextHousingPlot(result2) : h.plot
      };
      added.add(id);
    } else if (actual) {
      const immutable2 = [
        "id",
        "owner",
        "type",
        "purchaseId",
        "sequence",
        "price",
        "at",
        "source",
        "aiDay"
      ];
      if (!immutable2.every((k) => equal(h[k], actual[k])))
        throw Error("\u041F\u043E\u043A\u0443\u043F\u043A\u0443 \u0431\u0443\u0434\u0438\u043D\u043A\u0443 \u0432\u0436\u0435 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E \u0437 \u0456\u043D\u0448\u0438\u043C\u0438 \u0434\u0430\u043D\u0438\u043C\u0438");
      if (old && old.roommate !== h.roommate) {
        if (actual.roommate !== old.roommate && actual.roommate !== h.roommate)
          throw Error("\u0421\u043F\u0456\u0432\u043C\u0435\u0448\u043A\u0430\u043D\u0446\u044F \u0432\u0436\u0435 \u0437\u043C\u0456\u043D\u0438\u043B\u0438 \u043D\u0430 \u0456\u043D\u0448\u043E\u043C\u0443 \u043F\u0440\u0438\u0441\u0442\u0440\u043E\u0457");
        result2.homes[id].roommate = h.roommate;
      }
    }
  }
  for (const [cat2, id] of Object.entries(incoming.residences || {})) {
    const old = base?.residences?.[cat2], actual = current.residences?.[cat2];
    if (old === id || actual === id) continue;
    if (actual && actual !== old) {
      if (base?.homes?.[id])
        throw Error("\u0410\u043A\u0442\u0438\u0432\u043D\u0438\u0439 \u0434\u0456\u043C \u043A\u043E\u0442\u0438\u043A\u0430 \u0432\u0436\u0435 \u0437\u043C\u0456\u043D\u0438\u043B\u0438 \u043D\u0430 \u0456\u043D\u0448\u043E\u043C\u0443 \u043F\u0440\u0438\u0441\u0442\u0440\u043E\u0457");
      continue;
    }
    if (result2.homes[id]) result2.residences[cat2] = id;
  }
  for (const [cat2, id] of Object.entries(base?.residences || {}))
    if (!incoming.residences?.[cat2] && current.residences?.[cat2] === id && incoming.homes?.[id]?.roommate !== cat2 && base.homes?.[id]?.roommate === cat2)
      delete result2.residences[cat2];
  for (const id of added) {
    const h = result2.homes[id];
    if (h.roommate && result2.residences[h.roommate] !== id) h.roommate = null;
  }
  for (const [cat2, id] of Object.entries(result2.residences)) {
    const h = result2.homes[id];
    if (!h || h.owner !== cat2 && h.roommate !== cat2) delete result2.residences[cat2];
  }
  return result2;
}

// public/cat-vacation.js
var VACATION_MIN_DAYS = 2;
var VACATION_MAX_DAYS = 7;
function normalizeCatVacation(raw) {
  if (raw == null) return null;
  const { startDay, endDay, previousJob } = raw;
  if (!Number.isSafeInteger(startDay) || startDay < 0 || !Number.isSafeInteger(endDay) || endDay - startDay < VACATION_MIN_DAYS || endDay - startDay > VACATION_MAX_DAYS || !JOB_KINDS.includes(previousJob)) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0438\u0439 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0438\u0439 \u0442\u0435\u0440\u043C\u0456\u043D \u0432\u0456\u0434\u043F\u0443\u0441\u0442\u043A\u0438 \u043A\u043E\u0442\u0438\u043A\u0430.");
  return { startDay, endDay, previousJob };
}
function catOnVacation(profile, clock) {
  const v = profile?.vacation;
  if (!v) return false;
  if (typeof clock === "number") return clock >= v.startDay && clock < v.endDay;
  return clock.absolute >= v.startDay * JOB_DAY_MINUTES + JOB_START && clock.absolute < v.endDay * JOB_DAY_MINUTES + JOB_START;
}
function reconcileCatVacation(base, current, incoming) {
  const old = normalizeCatVacation(base), actual = normalizeCatVacation(current), proposed = normalizeCatVacation(incoming);
  const same2 = (a, b) => a.startDay === b.startDay && a.endDay === b.endDay && a.previousJob === b.previousJob;
  if (old && actual && old.startDay === actual.startDay && !same2(old, actual)) throw Error("\u0417\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0438\u0439 \u0442\u0435\u0440\u043C\u0456\u043D \u0432\u0456\u0434\u043F\u0443\u0441\u0442\u043A\u0438 \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0437\u043C\u0456\u043D\u044E\u0432\u0430\u0442\u0438.");
  const known2 = !old ? actual : !actual ? old : actual.startDay >= old.startDay ? actual : old;
  if (!proposed) return known2;
  if (!known2) return proposed;
  if (proposed.startDay < known2.startDay) return known2;
  if (proposed.startDay === known2.startDay) {
    if (!same2(proposed, known2)) throw Error("\u0417\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0438\u0439 \u0442\u0435\u0440\u043C\u0456\u043D \u0432\u0456\u0434\u043F\u0443\u0441\u0442\u043A\u0438 \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u043F\u0440\u043E\u0434\u043E\u0432\u0436\u0443\u0432\u0430\u0442\u0438.");
    return known2;
  }
  if (proposed.startDay < known2.endDay + 14) throw Error("\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u044F \u0432\u0456\u0434\u043F\u0443\u0441\u0442\u043A\u0430 \u0442\u0430 \u043F\u0435\u0440\u0435\u0440\u0432\u0430 \u043C\u0456\u0436 \u0432\u0456\u0434\u043F\u0443\u0441\u0442\u043A\u0430\u043C\u0438 \u0449\u0435 \u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0456.");
  return proposed;
}

// public/mall-system.js
var newMallProfile = () => ({ version: 1, receipts: {}, used: {}, equipped: null, goal: null, visited: [] });
function normalizeMallProfile(raw) {
  if (raw == null) return newMallProfile();
  if (raw.version !== 1 || !raw.receipts || Array.isArray(raw.receipts) || Object.keys(raw.receipts).length > 1e4) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0430 \u0456\u0441\u0442\u043E\u0440\u0456\u044F \u043F\u043E\u043A\u0443\u043F\u043E\u043A \u0422\u0420\u0426");
  const m = newMallProfile();
  for (const [id, r] of Object.entries(raw.receipts)) {
    const product = mallProduct(r?.product);
    if (!/^[\w-]{8,80}$/.test(id) || !product || !Number.isSafeInteger(r.sequence) || r.sequence < 1 || r.price !== product.price || !Number.isFinite(r.at) || r.at < 0) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0438\u0439 \u0447\u0435\u043A \u0422\u0420\u0426");
    m.receipts[id] = { product: r.product, sequence: r.sequence, price: r.price, at: r.at };
  }
  for (const [id, n] of Object.entries(raw.used || {})) {
    if (!mallProduct(id) || !Number.isSafeInteger(n) || n < 0 || n > Object.values(m.receipts).filter((r) => r.product === id).length) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0438\u0439 \u0456\u043D\u0432\u0435\u043D\u0442\u0430\u0440 \u0422\u0420\u0426");
    m.used[id] = n;
  }
  m.equipped = mallProduct(raw.equipped)?.use === "wear" ? raw.equipped : null;
  m.visited = [...new Set((raw.visited || []).filter((id) => mallStore(id)))];
  if (raw.goal && mallStore(raw.goal.storeId) && Number.isFinite(raw.goal.at)) {
    const product = mallProduct(raw.goal.productId), receipt = raw.goal.receipt && m.receipts[raw.goal.receipt];
    if (raw.goal.productId && (!product || product.storeId !== raw.goal.storeId)) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0430 \u043C\u0435\u0442\u0430 \u0432\u0456\u0437\u0438\u0442\u0443 \u0422\u0420\u0426");
    if (raw.goal.receipt && (!receipt || receipt.product !== raw.goal.productId)) throw Error("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0438\u0439 \u043E\u043F\u043B\u0430\u0447\u0435\u043D\u0438\u0439 \u0432\u0456\u0437\u0438\u0442 \u0422\u0420\u0426");
    m.goal = { layoutVersion: raw.goal.layoutVersion === 2 ? 2 : 1, storeId: raw.goal.storeId, at: raw.goal.at, productId: product?.id || null, receipt: receipt ? raw.goal.receipt : null, purchased: !!receipt, used: !!receipt && raw.goal.used === true };
  }
  return m;
}
function validateMallEconomy(game) {
  const totals = /* @__PURE__ */ new Map();
  for (const p of Object.values(game.jobCity?.profiles || {})) {
    if (!p.mall && !Object.keys(p.inventory || {}).some(mallProduct)) continue;
    const m = normalizeMallProfile(p.mall), seq = /* @__PURE__ */ new Set(), counts = /* @__PURE__ */ new Map();
    for (const r of Object.values(m.receipts)) {
      if (r.sequence > p.purchaseCount || seq.has(r.sequence)) throw Error("\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0430 \u043F\u043E\u0441\u043B\u0456\u0434\u043E\u0432\u043D\u0456\u0441\u0442\u044C \u0447\u0435\u043A\u0456\u0432 \u0422\u0420\u0426");
      seq.add(r.sequence);
      counts.set(r.product, (counts.get(r.product) || 0) + 1);
      totals.set(r.product, (totals.get(r.product) || 0) + 1);
    }
    for (const item2 of MALL_PRODUCTS) if ((counts.get(item2.id) || 0) - (m.used[item2.id] || 0) !== (p.inventory?.[item2.id] || 0)) throw Error("\u041F\u043E\u043A\u0443\u043F\u043A\u0430 \u0422\u0420\u0426 \u043D\u0435 \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0454 \u0456\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044E");
  }
  for (const item2 of MALL_PRODUCTS) if ((totals.get(item2.id) || 0) > item2.stock) throw Error("\u041E\u0441\u0442\u0430\u043D\u043D\u0456\u0439 \u0442\u043E\u0432\u0430\u0440 \u0443\u0436\u0435 \u043A\u0443\u043F\u0438\u043B\u0438. \u041E\u043D\u043E\u0432\u0456\u0442\u044C \u043A\u0430\u0442\u0430\u043B\u043E\u0433.");
  return game;
}

// public/crypto-trading.js
var CRYPTO_RULES = Object.freeze({
  intervalDays: 7,
  durationMs: 45e3,
  minCoins: 30,
  maxLeverage: 3,
  feeRate: 2e-3,
  pathPoints: 65,
  moonshotChance: 0.05,
  moonshotMin: 8,
  moonshotMax: 25
});
var hash = (s) => [...String(s)].reduce((h, c) => Math.imul(h, 31) + c.charCodeAt(0) >>> 0, 7);
var cryptoClock = (state, now = Date.now()) => {
  const absolute = JOB_CLOCK_ORIGIN + Math.max(0, (now - (state?.epoch ?? now)) / JOB_MINUTE_MS);
  return { day: Math.floor(absolute / JOB_DAY_MINUTES), minute: absolute % JOB_DAY_MINUTES };
};
function validateCryptoForecast(value) {
  if (!value || !["BTC", "ETH"].includes(value.asset) || !["up", "down"].includes(value.direction) || !Number.isFinite(value.strength) || value.strength < 0.01 || value.strength > 0.12 || !Number.isFinite(value.confidence) || value.confidence < 0 || value.confidence > 1 || typeof value.reason !== "string" || !value.reason.trim() || value.reason.length > 180) throw Error("Invalid crypto forecast");
  return { asset: value.asset, direction: value.direction, strength: value.strength, confidence: value.confidence, reason: value.reason.trim() };
}
function localCryptoForecast(id) {
  return {
    asset: hash(id) % 2 ? "BTC" : "ETH",
    direction: hash(id + "direction") % 2 ? "up" : "down",
    strength: 0.02 + hash(id + "strength") % 70 / 1e3,
    confidence: 0.45 + hash(id + "confidence") % 40 / 100,
    reason: "\u041C\u0456\u0441\u0446\u0435\u0432\u0438\u0439 \u0456\u0433\u0440\u043E\u0432\u0438\u0439 \u043F\u0440\u043E\u0433\u043D\u043E\u0437: \u0440\u0438\u043D\u043E\u043A \u043C\u043E\u0436\u0435 \u0440\u0443\u0445\u0430\u0442\u0438\u0441\u044F \u0432 \u043E\u0431\u0438\u0434\u0432\u0430 \u0431\u043E\u043A\u0438."
  };
}
var terminal = (t) => ["closed", "liquidated", "skipped"].includes(t?.status);
function validTrade(t) {
  if (!t || typeof t.id !== "string" || t.id.length > 160 || !Number.isSafeInteger(t.day) || t.day < 0 || !["waiting", "open", "closed", "liquidated", "skipped"].includes(t.status) || !Number.isFinite(t.at) || t.at < 0) return false;
  if (t.status === "waiting" || t.status === "skipped") return true;
  if (t.marketEvent != null && (!t.marketEvent || t.marketEvent.kind !== "moonshot" || !Number.isInteger(t.marketEvent.multiplier) || t.marketEvent.multiplier < CRYPTO_RULES.moonshotMin || t.marketEvent.multiplier > CRYPTO_RULES.moonshotMax || !Number.isFinite(t.marketEvent.startsAt) || t.marketEvent.startsAt < 0.2 || t.marketEvent.startsAt > 0.4)) return false;
  return ["BTC", "ETH"].includes(t.asset) && ["LONG", "SHORT"].includes(t.action) && [t.margin, t.leverage, t.entryPrice, t.startedAt, t.endAt, t.durationMs, t.fee].every(Number.isFinite) && Number.isSafeInteger(t.margin) && t.margin > 0 && Number.isSafeInteger(t.fee) && t.fee >= 0 && t.fee <= t.margin && Number.isInteger(t.leverage) && t.leverage >= 1 && t.leverage <= CRYPTO_RULES.maxLeverage && t.entryPrice > 0 && t.durationMs >= 1e4 && t.durationMs <= 6e4 && t.endAt >= t.startedAt && t.endAt <= t.startedAt + t.durationMs && Array.isArray(t.path) && t.path.length === 65 && t.path.every((p) => Number.isFinite(p) && p > 0) && (t.status === "open" || Number.isSafeInteger(t.pnl) && t.pnl >= -t.margin && Number.isFinite(t.exitPrice) && t.exitPrice > 0 && t.closedAt === t.endAt);
}
function investmentsSnapshotValid(raw) {
  if (raw == null) return true;
  if (!raw || raw.version !== 1 || !Number.isSafeInteger(raw.lastAttemptDay) || raw.lastAttemptDay < -1 || !Number.isSafeInteger(raw.nextAttemptDay) || raw.nextAttemptDay < 0 || !Number.isSafeInteger(raw.totalPNL) || raw.current && !validTrade(raw.current) || !Array.isArray(raw.history)) return false;
  const seen = /* @__PURE__ */ new Set();
  if (raw.history.some((t) => !validTrade(t) || !terminal(t) || seen.has(t.id) || (seen.add(t.id), false))) return false;
  return true;
}
function cryptoSnapshotValid(state) {
  return Object.values(state?.profiles || {}).every((p) => investmentsSnapshotValid(p?.investments));
}

// public/cat-roster.js
function venueCatHome(game, profile, now = Date.now()) {
  if (!profile.venue) return null;
  return (game.placements || []).filter(
    (p) => p.item === profile.venue && game.unlocked.includes(p.biome) && (!p.readyAt || p.readyAt <= now)
  ).sort((a, b) => a.id.localeCompare(b.id))[0] || null;
}
function catAvailable(game, profile) {
  if (profile.venue)
    return !!venueCatHome(game, profile) || game.unlocked.includes(game.catDestinations?.[profile.id]);
  return profile.adoption ? (game.adoption?.cats || []).some((c) => c.id === profile.id) : game.unlocked.includes(profile.biome) || isRetiredBiome(profile.biome) && game.unlocked.includes(game.catDestinations?.[profile.id]);
}
function activeCats(game) {
  return NEIGHBORS.filter((n) => catAvailable(game, n)).map((n) => {
    const home = venueCatHome(game, n), moved = game.unlocked.includes(game.catDestinations?.[n.id]);
    return {
      ...n,
      biome: moved ? game.catDestinations[n.id] : home?.biome || game.adoption?.cats?.find((c) => c.id === n.id)?.homeBiome || n.biome,
      ...home ? { homeVenueId: home.id, ...!moved ? { venueHome: home } : {} } : {}
    };
  });
}

// public/progression.js
var MAX_LEVEL = 30;
var DAILY_XP_LIMIT = 1800;
var dayFormatter2 = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Europe/Kyiv",
  year: "numeric",
  month: "2-digit",
  day: "2-digit"
});
var xpForLevel = (level) => level <= 1 ? 0 : Math.round(80 * (level - 1) ** 1.55 + 40 * (level - 1));
function levelForXP(xp = 0) {
  let level = 1;
  while (level < MAX_LEVEL && xp >= xpForLevel(level + 1)) level++;
  return level;
}

// public/island-construction.js
var projects = COTTON_OBJECTS.filter((o) => !o.type.startsWith("ride-pig-"));
function normalizeIslandConstruction(raw) {
  const state = {};
  for (const id of [
    "clockwork",
    ...COURT_VENUES.filter((o) => o.requiresBuild).map((o) => o.id)
  ]) {
    const t = raw?.[id];
    if (Number.isSafeInteger(t) && t > 0 && t < 1e15) state[id] = t;
  }
  return state;
}
function mergeIslandConstruction(...states) {
  const out = {};
  for (const state of states)
    for (const [id, t] of Object.entries(normalizeIslandConstruction(state)))
      out[id] = Math.min(out[id] || t, t);
  return out;
}

// public/world-objects.js
var PARK_RIDES = [
  {
    id: "royal-rainbow",
    type: "coaster-rainbow-launch",
    biome: "aquapark",
    x: 8,
    z: 6
  },
  {
    id: "royal-cascade",
    type: "slide-royal-cascade",
    biome: "aquapark",
    x: 9,
    z: -7
  },
  {
    id: "royal-vortex",
    type: "slide-vortex-bowl",
    biome: "aquapark",
    x: -10,
    z: -8
  }
];
function permanentObjects(biomes) {
  biomes = biomes.filter((id) => BIOMES.some((b) => b.id === id));
  const objects = [];
  if (biomes.includes(ZOO_ID)) objects.push(...ZOO_EXHIBITS);
  objects.push(...MAGIC_FARM_OBJECTS.filter((o) => biomes.includes(o.biome)));
  if (biomes.includes("jobcity")) objects.push(...JOB_BUSINESSES);
  if (biomes.includes("aquarium")) objects.push(...AQUARIUM_TANKS);
  if (biomes.includes("bikini"))
    objects.push(BIKINI_RESTAURANT, ...BIKINI_FRIENDS, ...BIKINI_POOLS);
  if (biomes.includes("foodcourt"))
    objects.push(...COURT_VENUES, COURT_FOUNTAIN);
  if (biomes.includes("sakura")) objects.push(...CHILL_OBJECTS);
  if (biomes.includes("water")) objects.push(...SPA_OBJECTS);
  for (const b of BIOMES) {
    if (!biomes.includes(b.id)) continue;
    if (["foodcourt", "bikini", "aquarium", "jobcity", "cat-homes", ZOO_ID].includes(b.id))
      continue;
    if (b.id === "autumn") {
      objects.push(...MOSA_OBJECTS);
      continue;
    }
    if (RENEWED_ISLANDS[b.id]) {
      objects.push(...ISLAND_RIDES.filter((r) => r.biome === b.id));
      const upper = RENEWED_ISLANDS[b.id].upper;
      objects.push({
        id: "lake-" + b.id + "-upper",
        type: "swim-lagoon",
        biome: b.id,
        x: upper[0],
        z: upper[1],
        rx: upper[2],
        rz: upper[3],
        surfaceY: 2.555,
        shoreY: 2.55,
        name: "\u041A\u0430\u0441\u043A\u0430\u0434\u043D\u0430\u044F \u043B\u0430\u0433\u0443\u043D\u0430 \xB7 " + b.name
      });
    }
    const river = BIOME_STYLES[b.id]?.river;
    if (river)
      objects.push({
        id: "lake-" + b.id + "-river",
        type: "swim-lagoon",
        biome: b.id,
        x: river[0],
        z: river[1],
        rx: river[2],
        rz: river[3],
        surfaceY: 0.155,
        name: "\u0420\u0435\u0447\u043D\u043E\u0439 \u043A\u0430\u0441\u043A\u0430\u0434 \xB7 " + b.name
      });
    const w = BIOME_STYLES[b.id]?.water;
    if (w)
      objects.push({
        id: "lake-" + b.id,
        type: "swim-lagoon",
        biome: b.id,
        x: w[0],
        z: w[1],
        rx: w[2],
        rz: w[3],
        surfaceY: 0.155,
        name: "\u041B\u0430\u0433\u0443\u043D\u0430 \xB7 " + b.name
      });
  }
  if (biomes.includes("summer"))
    objects.push(
      ...CAPYBARA_OBJECTS,
      ...CAPYBARA_POOLS.map((p) => ({
        ...p,
        biome: "summer",
        type: "swim-lagoon",
        surfaceY: p.y + 0.155,
        shoreY: p.y + 0.16
      }))
    );
  if (biomes.includes("clockwork"))
    objects.push(
      ...COTTON_OBJECTS,
      ...COTTON_POOLS.map((p) => ({
        ...p,
        biome: "clockwork",
        type: "swim-lagoon",
        surfaceY: p.y + 0.155,
        shoreY: p.y + 0.16
      }))
    );
  if (biomes.includes("aquapark"))
    objects.push(...PARK_RIDES, {
      id: "lake-aquapark-upper",
      type: "swim-lagoon",
      biome: "aquapark",
      x: -3,
      z: -4.4,
      rx: 3.7,
      rz: 1.25,
      surfaceY: 3.455,
      shoreY: 3.15,
      name: "\u0412\u0435\u0440\u0445\u043D\u044F\u044F \u043A\u043E\u0440\u043E\u043B\u0435\u0432\u0441\u043A\u0430\u044F \u043B\u0430\u0433\u0443\u043D\u0430"
    });
  return objects;
}

// public/social-system.js
var SOCIAL_INTENTS = [
  "greet",
  "play",
  "relax",
  "cuddle",
  "best_friend"
];
function bestEligible(r) {
  return !!r && r.points >= 80 && r.meetings >= 16 && r.plays >= 7;
}
function relationshipStage(r, best = false) {
  return !r?.meetings ? "unknown" : best ? "best" : r.points >= 65 && r.meetings >= 12 && r.plays >= 5 ? "close" : r.points >= 35 && r.meetings >= 6 && r.plays >= 2 ? "friend" : "acquaintance";
}

// public/interactions.js
var DECISION_PROTOCOL = "living-cat-world-v4";
var MAX_DECISION_BYTES = 49152;
var HOME_OBJECTS = [
  {
    id: "chichi-bed",
    type: "bed",
    biome: "moon",
    x: -6,
    z: -4,
    name: "\u041F\u043E\u0434\u0443\u0448\u043A\u0430 \u0427\u0438\u0447\u0438 \u0443 \u0434\u043E\u043C\u0438\u043A\u0430"
  },
  {
    id: "chichi-food",
    type: "picnic",
    biome: "moon",
    x: -2,
    z: 5,
    name: "\u041E\u0431\u0449\u0430\u044F \u043C\u0438\u0441\u043A\u0430 \u043A\u043E\u0442\u0438\u043A\u043E\u0432"
  }
];
function activityLocation(action, type) {
  return action === "swim" ? "pond" : action === "rest" ? "home" : action === "eat" ? "picnic" : type === "pond" ? "pond" : "garden";
}
function activityActions(object) {
  return (byItem(object?.type)?.actions || []).filter(
    (a) => !Array.isArray(object.actions) || object.actions.includes(a)
  );
}
function resolveInteraction(world, value, { historical = false } = {}) {
  const action = value?.action;
  if (action === "meet") {
    if (value.activityId || !world.friends.some((f2) => f2.id === value.friendId))
      throw Error("Friend is unavailable");
    const f = world.friends.find((f2) => f2.id === value.friendId);
    if (value.socialIntent !== void 0 && (!SOCIAL_INTENTS.includes(value.socialIntent) || value.socialIntent === "best_friend" && !f.bestEligible))
      throw Error("Choose a compatible friendship intent");
    return {
      action,
      friendId: value.friendId,
      target: "garden",
      ...value.socialIntent ? { socialIntent: value.socialIntent } : {}
    };
  }
  if (value?.friendId) throw Error("Choose exactly one physical target");
  const object = world.activities.find((a) => a.id === value?.activityId);
  if (!object) throw Error("Choose an available physical object");
  if (!activityActions(object).includes(action))
    throw Error("Activity is unavailable");
  if (!historical && action === "eat" && Number.isFinite(object.foodPortions) && object.foodPortions <= 0)
    throw Error(
      object.id === "spa-bar" ? "\u041D\u0435 \u0432\u0438\u0441\u0442\u0430\u0447\u0430\u0454 \u043C\u043E\u043D\u0435\u0442 \u043D\u0430 \u043E\u0431\u0440\u0430\u043D\u0438\u0439 \u043D\u0430\u043F\u0456\u0439 \u0443 SPA-\u0431\u0430\u0440\u0456." : "\u041C\u0438\u0441\u043A\u0430 \u043F\u0443\u0441\u0442\u0430\u044F. \u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0443\u0440\u043E\u0436\u0430\u0439 \u0441\u043E \u0441\u043A\u043B\u0430\u0434\u0430 \u0444\u0435\u0440\u043C\u044B."
    );
  const character = bikiniFriend(object.id);
  if (value.characterAction !== void 0 && (!character || !BIKINI_ACTIONS[character.kind].some(
    ([id]) => id === value.characterAction
  )))
    throw Error("\u042D\u0442\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E \u044D\u0442\u043E\u043C\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u0436\u0443.");
  return {
    action,
    activityId: object.id,
    target: activityLocation(action, object.type),
    ...action === "farm" && object.type === "farm-magic-fruits" && Number.isInteger(value.bedCell) && value.bedCell >= 0 && value.bedCell < 12 ? { bedCell: value.bedCell } : {},
    ...character && value.characterAction ? { characterAction: value.characterAction } : {}
  };
}
function cleanRecent(recent, world) {
  if (!Array.isArray(recent)) return [];
  const result2 = [];
  for (const entry of recent.slice(-8)) {
    try {
      const choice = resolveInteraction(world, entry, { historical: true });
      result2.push({
        ...choice,
        source: ["manual", "demo", "care"].includes(entry.source) ? entry.source : "ai"
      });
    } catch {
    }
  }
  return result2;
}

// public/care-system.js
var NEEDS_MINUTE = 6e4;
var BOWL_CAPACITY = 160;
var clamp = (n) => Math.max(0, Math.min(100, n));
var foodNutrition = (crop) => 18 + Math.min(12, Math.floor(crop.value / 25));
var bowlPortions = (game) => (game.care?.bowl || []).reduce((n, b) => n + b.portions, 0);
function consume(next, id, now, offline = false) {
  const needs = id === "chichi" ? next.cat : next.care.residents[id], batch = next.care.bowl[0];
  if (!needs || !batch) return null;
  const crop = CROPS.find((c) => c.id === batch.crop);
  batch.portions--;
  if (batch.portions === 0) next.care.bowl.shift();
  needs.hunger = clamp(needs.hunger - foodNutrition(crop));
  needs.happiness = clamp(needs.happiness + 4);
  if (id !== "chichi") needs.lastMealAt = now;
  const meal = {
    id: ++next.care.mealId,
    cat: id,
    crop: crop.id,
    at: now,
    offline
  };
  next.care.recentMeals = [...next.care.recentMeals || [], meal].slice(-12);
  return meal;
}
function advanceCare(game, now = Date.now(), { offline = false } = {}) {
  const elapsed = Math.floor(
    Math.max(0, now - game.care.lastTick) / NEEDS_MINUTE
  );
  if (!elapsed) return game;
  const next = structuredClone(game), ticks = Math.min(elapsed, 4320), residents = activeCats(next).map((n) => n.id);
  for (let i = 1; i <= ticks; i++) {
    const time = next.care.lastTick + (elapsed - ticks + i) * NEEDS_MINUTE;
    if (next.care.resting && next.care.resting.activityId !== "chichi-bed" && !next.placements.some(
      (p) => p.id === next.care.resting.activityId && (!p.readyAt || p.readyAt <= time)
    ))
      next.care.resting = null;
    const resting = !!next.care.resting;
    next.cat.hunger = clamp(next.cat.hunger + (resting ? 0.65 : 1.8));
    next.cat.energy = clamp(next.cat.energy + (resting ? 3.2 : -0.8));
    next.cat.happiness = clamp(
      next.cat.happiness + (next.cat.hunger > 75 ? -1.2 : resting ? 0.3 : -0.1)
    );
    if (next.cat.energy >= 99 && resting) next.care.resting = null;
    for (const id of residents) {
      const pet = next.care.residents[id];
      pet.hunger = clamp(pet.hunger + 1.4);
      pet.happiness = clamp(
        pet.happiness + (pet.hunger > 75 ? -1.1 : pet.hunger < 25 ? 0.15 : -0.08)
      );
    }
    if (offline) {
      const ids = ["chichi", ...residents], turn = Math.floor(time / NEEDS_MINUTE) % ids.length;
      for (let j = 0; j < ids.length; j++) {
        const id = ids[(j + turn) % ids.length], needs = id === "chichi" ? next.cat : next.care.residents[id];
        if (needs.hunger >= 45 && bowlPortions(next) > 0 && !(id === "chichi" && next.care.resting))
          consume(next, id, time, true);
      }
    }
  }
  next.care.lastTick += elapsed * NEEDS_MINUTE;
  return next;
}

// public/leisure-data.js
var priorities = [
  "eat",
  "ride",
  "swim",
  "play",
  "rest",
  "explore",
  "farm",
  "party"
];
function validateLeisureOffers(raw = []) {
  if (!Array.isArray(raw) || raw.length > 1024)
    throw Error("Invalid leisure catalogue");
  const seen = /* @__PURE__ */ new Set();
  return raw.map((o) => {
    if (!o || typeof o.id !== "string" || !/^[\w-]{1,90}$/.test(o.id) || seen.has(o.id) || !BIOMES.some((b) => b.id === o.biome) || !(mallStore(o.id) ? mallOffers({ unlocked: ["autumn"] }).find((p) => p.id === o.id)?.action === o.action && o.type === o.id && o.biome === "autumn" : activityActions(o).includes(o.action)) || !priorities.includes(o.action))
      throw Error("Invalid leisure offer");
    seen.add(o.id);
    return {
      id: o.id,
      type: o.type,
      biome: o.biome,
      name: String(o.name || mallStore(o.id)?.name || byItem(o.type)?.name || o.id).slice(0, 80),
      action: o.action
    };
  });
}

// public/jobcity-system.js
var clone3 = (v) => structuredClone(v);
var hash2 = (s) => [...String(s)].reduce(
  (h, c) => Math.imul(h, 31) + c.charCodeAt(0) >>> 0,
  7
);
var cityCats = (game) => [
  { id: "chichi", name: "\u0427\u0438\u0447\u0456", preferredJob: "estate" },
  ...activeCats(game)
];
function cityClock(state, now = Date.now()) {
  const absolute = JOB_CLOCK_ORIGIN + Math.max(0, (now - (state?.epoch ?? now)) / JOB_MINUTE_MS);
  const day = Math.floor(absolute / JOB_DAY_MINUTES), minute = absolute % JOB_DAY_MINUTES;
  return {
    absolute,
    day,
    minute,
    hour: Math.floor(minute / 60),
    label: String(Math.floor(minute / 60)).padStart(2, "0") + ":" + String(Math.floor(minute % 60)).padStart(2, "0"),
    working: minute >= JOB_START && minute < JOB_END
  };
}
function newJobProfile(cat2) {
  const seed = hash2(cat2.id), favorite = cat2.preferredJob || JOB_KINDS[seed % 6];
  return {
    id: cat2.id,
    name: cat2.name,
    sex: catSex(cat2),
    coins: 0,
    investments: null,
    purchaseCount: 0,
    lastHousingAIDay: -1,
    lastEveningDay: -1,
    lastWishDay: -1,
    manualUntil: 0,
    parkedAt: null,
    parkedCar: null,
    earnedTotal: 0,
    spentTotal: 0,
    profession: null,
    careerAIPending: true,
    careerAIRequestedDay: -1,
    professionChanges: 0,
    professionSinceDay: -1,
    professionReason: "",
    professionSource: "local",
    career: [],
    personality: ["\u0422\u043E\u0432\u0430\u0440\u0438\u0441\u044C\u043A\u0438\u0439", "\u0414\u043E\u043F\u0438\u0442\u043B\u0438\u0432\u0438\u0439", "\u0412\u0438\u043D\u0430\u0445\u0456\u0434\u043B\u0438\u0432\u0438\u0439", "\u0421\u043F\u043E\u043A\u0456\u0439\u043D\u0438\u0439"][seed % 4],
    preferences: [
      favorite,
      JOB_KINDS[(JOB_KINDS.indexOf(favorite) + 1 + seed % 4) % 6]
    ],
    skills: Object.fromEntries(
      JOB_KINDS.map((k, i) => [k, 1 + (seed + i * 3) % 4])
    ),
    wishes: [JOB_CARS[seed % JOB_CARS.length].id, seed % 2 ? "yarn" : "bed"],
    status: "rest",
    schedule: null,
    attendance: null,
    lastPaidDay: -1,
    inventory: {},
    mall: newMallProfile(),
    transactions: [],
    shifts: [],
    trip: null
  };
}
function ensureJobCity(game, now = Date.now(), { forMall = false } = {}) {
  if (!game.unlocked.includes(JOB_CITY_ID) && !(forMall && game.unlocked.includes("autumn"))) return game;
  const cats = cityCats(game);
  if (game.jobCity && cats.every((c) => game.jobCity.profiles[c.id]))
    return ensureFamily(game, cityClock(game.jobCity, now).day, now);
  const next = clone3(game);
  if (!next.jobCity)
    next.jobCity = {
      version: 1,
      epoch: now,
      requestedDay: -1,
      eveningAIRequestedDay: -1,
      eveningAIAppliedDay: -1,
      plan: null,
      profiles: {}
    };
  for (const c of cats) next.jobCity.profiles[c.id] ||= newJobProfile(c);
  return ensureFamily(next, cityClock(next.jobCity, now).day, now);
}
function localJobPlan(profiles, day) {
  const counts = Object.fromEntries(JOB_KINDS.map((k) => [k, 0]));
  return [...profiles].sort(
    (a, b) => (a.lastPaidDay ?? -1) - (b.lastPaidDay ?? -1) || Number(b.id.startsWith("jobcat-")) - Number(a.id.startsWith("jobcat-")) || a.id.localeCompare(b.id)
  ).map((p) => {
    const returned = p.vacation && day >= p.vacation.endDay && p.lastPaidDay < p.vacation.endDay;
    const work = !catOnVacation(p, day) && (returned || p.id.startsWith("jobcat-") || hash2(p.id + day) % 5 !== 0);
    const options = JOB_KINDS.filter(
      (k) => (!p.profession || p.profession === k) && counts[k] < JOB_CAPACITY
    ).sort(
      (a, b) => (p.preferences.includes(b) ? 8 : 0) + p.skills[b] - ((p.preferences.includes(a) ? 8 : 0) + p.skills[a])
    );
    const job = work && options.length ? options[0] : "rest";
    if (job !== "rest") counts[job]++;
    return {
      id: p.id,
      job,
      profession: p.profession || (job === "rest" ? p.preferences[0] : job),
      reason: p.professionReason || "\u0412\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0454 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0443 \u0442\u0430 \u0437\u0434\u0456\u0431\u043D\u043E\u0441\u0442\u044F\u043C",
      evening: (p.hasCar || Object.keys(p.inventory || {}).some(jobCar)) && hash2(p.id + day) % 3 === 0 ? "drive" : hash2(p.id + day) % 2 ? "walk" : "rest"
    };
  });
}
function validateJobAssignments(raw, profiles) {
  if (!raw || !Array.isArray(raw.assignments) || raw.assignments.length !== profiles.length || profiles.length > 256)
    throw Error("\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0438\u0439 \u043F\u043B\u0430\u043D \u0440\u043E\u0431\u043E\u0442\u0438");
  const ids = new Set(profiles.map((p) => p.id)), seen = /* @__PURE__ */ new Set(), counts = {};
  return raw.assignments.map((a) => {
    if (!ids.has(a?.id) || seen.has(a.id) || ![...JOB_KINDS, "rest"].includes(a.job) || !["rest", "walk", "drive"].includes(a.evening))
      throw Error("\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u043A\u043E\u0442\u0438\u043A\u0430");
    seen.add(a.id);
    if (a.job !== "rest" && (counts[a.job] = (counts[a.job] || 0) + 1) > JOB_CAPACITY)
      throw Error("\u0420\u043E\u0431\u043E\u0447\u0456 \u043C\u0456\u0441\u0446\u044F \u0437\u0430\u0439\u043D\u044F\u0442\u0456");
    const p = profiles.find((p2) => p2.id === a.id), profession = a.profession ?? p.profession ?? (a.job === "rest" ? p.preferences[0] : a.job), reason = String(a.reason || "\u0412\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0454 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0443 \u0442\u0430 \u0437\u0434\u0456\u0431\u043D\u043E\u0441\u0442\u044F\u043C").slice(
      0,
      160
    );
    if (!JOB_KINDS.includes(profession) || a.job !== "rest" && a.job !== profession)
      throw Error("\u0420\u043E\u0431\u043E\u0442\u0430 \u043D\u0435 \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0454 \u043F\u0440\u043E\u0444\u0435\u0441\u0456\u0457");
    let house = null;
    if (a.house) {
      if (!houseType(a.house.type) || a.house.roommate != null && (!ids.has(a.house.roommate) || a.house.roommate === a.id))
        throw Error("\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0430 \u043F\u043E\u043A\u0443\u043F\u043A\u0430 \u0431\u0443\u0434\u0438\u043D\u043A\u0443");
      house = { type: a.house.type, roommate: a.house.roommate || null };
    }
    if (a.outings !== void 0 && (!Array.isArray(a.outings) || a.outings.length > 3 || new Set(a.outings).size !== a.outings.length || a.outings.some(
      (id) => typeof id !== "string" || !/^[\w-]{1,90}$/.test(id)
    )))
      throw Error("\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0438\u0439 \u043F\u043B\u0430\u043D \u0432\u0456\u0434\u043F\u043E\u0447\u0438\u043D\u043A\u0443");
    return {
      id: a.id,
      job: a.job,
      evening: a.evening,
      profession,
      reason,
      ...house ? { house } : {},
      ...a.outings !== void 0 ? { outings: [...a.outings] } : {}
    };
  });
}

// jobcity-ai.mjs
var JOB_AI_LIMIT = 192 * 1024;
function validateCityAIState(s) {
  if (!Number.isSafeInteger(s?.day) || s.day < 0 || !Array.isArray(s.cats) || s.cats.length < 1 || s.cats.length > 256)
    throw Error("Invalid job plan request");
  const seen = /* @__PURE__ */ new Set();
  const cats = s.cats.map((c) => {
    if (typeof c.id !== "string" || !/^[\w-]{1,40}$/.test(c.id) || seen.has(c.id) || typeof c.name !== "string" || c.name.length > 60 || !Number.isSafeInteger(c.coins) || c.coins < 0 || c.coins > Number.MAX_SAFE_INTEGER || !JOB_KINDS.every(
      (k) => Number.isFinite(c.skills?.[k]) && c.skills[k] >= 0 && c.skills[k] <= 100
    ) || !Array.isArray(c.preferences) || c.preferences.length > 6 || c.preferences.some((k) => !JOB_KINDS.includes(k)) || c.profession !== null && !JOB_KINDS.includes(c.profession))
      throw Error("Invalid worker profile");
    seen.add(c.id);
    return {
      id: c.id,
      name: c.name,
      sex: catSex(c.id),
      partner: typeof c.partner === "string" ? c.partner : null,
      coins: c.coins,
      needs: Array.from({ length: 3 }, (_, i) => Math.max(0, Math.min(100, Math.round(Number(c.needs?.[i] ?? [100, 0, 75][i]) || 0)))),
      mallVisited: Array.isArray(c.mallVisited) ? [...new Set(c.mallVisited.filter((id) => mallStore(id)))].slice(0, 34) : [],
      ownedHomes: Number.isSafeInteger(c.ownedHomes) && c.ownedHomes >= 0 ? c.ownedHomes : 0,
      activeHome: typeof c.activeHome === "string" ? c.activeHome.slice(0, 90) : null,
      personality: String(c.personality || "").slice(0, 60),
      preferences: c.preferences,
      skills: c.skills,
      profession: c.profession,
      canChangeProfession: c.canChangeProfession === true,
      professionChanges: Math.max(0, Math.min(3, c.professionChanges || 0)),
      wishes: (c.wishes || []).slice(0, 3).map((x) => String(x).slice(0, 40)),
      previous: c.previous || null,
      lastPaidDay: Number.isSafeInteger(c.lastPaidDay) ? c.lastPaidDay : -1,
      recentWorkedDays: Array.isArray(c.recentWorkedDays) ? c.recentWorkedDays.filter(Number.isSafeInteger).slice(-5) : [],
      hasCar: !!c.hasCar,
      scheduleJob: JOB_KINDS.includes(c.scheduleJob) ? c.scheduleJob : "rest",
      scheduleEvening: ["rest", "walk", "drive"].includes(c.scheduleEvening) ? c.scheduleEvening : "rest",
      scheduleOutings: Array.isArray(c.scheduleOutings) ? c.scheduleOutings.filter((id) => typeof id === "string").slice(0, 3) : void 0,
      lastHousingAIDay: Number.isSafeInteger(c.lastHousingAIDay) ? c.lastHousingAIDay : -1
    };
  });
  for (const cat2 of cats)
    if (cat2.partner && (!seen.has(cat2.partner) || cat2.partner === cat2.id))
      throw Error("Invalid partner");
  return {
    day: s.day,
    ...s.phase !== void 0 ? validateCityEvent(s, cats) : {},
    cats,
    housingOffers: housingOffers(),
    leisureOffers: validateLeisureOffers(s.leisureOffers),
    familyReview: {
      due: s.familyReview?.due === true,
      slots: Math.max(
        0,
        Math.min(
          familyReviewLimit(cats),
          Math.floor(Number(s.familyReview?.slots) || 0)
        )
      )
    }
  };
}
function validateCityEvent(s, cats) {
  if (!["careers", "evening"].includes(s.phase) || !Number.isFinite(s.epoch) || s.epoch < 0 || !Number.isFinite(s.minute) || s.minute < 0 || s.minute >= 1440 || !Array.isArray(s.initialIds) || new Set(s.initialIds).size !== s.initialIds.length || s.initialIds.some(
    (id) => !cats.some((p) => p.id === id && p.profession === null)
  ) || s.phase === "evening" && (s.minute < JOB_END || s.initialIds.length))
    throw Error("Invalid city AI event");
  return {
    phase: s.phase,
    epoch: s.epoch,
    minute: s.minute,
    initialIds: s.initialIds
  };
}
async function requestCityPlan(state, run, timeout = 1e5) {
  let timer;
  const inference = run(cityPlanInput(state));
  let result2;
  try {
    result2 = await Promise.race([
      inference,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(Error("AI timeout")), timeout);
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
  let raw = result2?.response ?? result2;
  if (typeof raw === "string")
    raw = JSON.parse(
      raw.trim().replace(/^```(?:json)?\s*/, "").replace(/\s*```$/, "")
    );
  if (Array.isArray(raw?.assignments) && raw.assignments.length > state.cats.length && raw.assignments.length <= state.cats.length + 16) {
    const ids = new Set(state.cats.map((p) => p.id));
    const key = (row2) => Array.isArray(row2) ? Number.isSafeInteger(row2[0]) && state.cats[row2[0]]?.id : ids.has(row2?.id) ? row2.id : null;
    const actual = raw.assignments.filter((row2) => key(row2));
    if (actual.length === state.cats.length && new Set(actual.map(key)).size === state.cats.length)
      raw = { ...raw, assignments: actual };
  }
  const expanded = expandCityPlan(raw, state);
  const valid = validateJobAssignments(
    limitCityWorkplaces(expanded, state),
    state.cats
  );
  for (const a of valid) {
    const p = state.cats.find((c) => c.id === a.id);
    if (p.profession && p.profession !== a.profession && !p.canChangeProfession)
      throw Error("AI changed a permanent career");
    if (a.evening === "drive" && !p.hasCar)
      throw Error("AI chose an unavailable car");
    if (a.outings?.some((id) => !state.leisureOffers.some((o) => o.id === id)))
      throw Error("AI chose an unavailable outing");
  }
  const families = [];
  if (state.familyReview?.due) {
    for (const pair of expanded.families || []) {
      if (families.length >= state.familyReview.slots) break;
      try {
        const [valid2] = validateFamilyProposals([pair], state.cats, 1);
        if (!families.some(
          (p) => p.male === valid2.male || p.female === valid2.female
        ))
          families.push(valid2);
      } catch {
      }
    }
  }
  return {
    day: state.day,
    assignments: valid,
    ...state.familyReview?.due ? { families } : {}
  };
}
function cityPlanInput(state) {
  const houses = housingOffers();
  const cats = state.cats.map((p, i) => [
    i,
    p.name,
    p.personality,
    p.coins,
    JOB_KINDS.indexOf(p.profession),
    p.canChangeProfession ? 1 : 0,
    p.professionChanges,
    JOB_KINDS.map((k) => p.skills[k]),
    p.preferences.map((k) => JOB_KINDS.indexOf(k)),
    p.lastPaidDay ?? -1,
    p.recentWorkedDays || [],
    p.hasCar ? 1 : 0,
    p.ownedHomes || 0,
    p.activeHome ? 1 : 0,
    p.wishes,
    p.sex === "male" ? 0 : 1,
    state.cats.findIndex((c) => c.id === p.partner)
  ]);
  const places2 = state.leisureOffers || [], types = [...new Set(places2.map((p) => p.type))], islands = [...new Set(places2.map((p) => p.biome))];
  return {
    messages: [
      {
        role: "system",
        content: `Plan ONE fictional cat day. Output ONLY compact JSON {"assignments":[[catIndex,job,profession,evening,house,roommate,reason,outings],...],"families":[[maleIndex,femaleIndex,"short Ukrainian reason"],...]}.
Include ALL ${state.cats.length} cat indices from 0 through ${state.cats.length - 1} exactly once, including resting cats. ${state.cats.length} is NOT a cat index. Job/profession indices: ${JOB_KINDS.map((k, i) => i + "=" + k).join(", ")}. Job -1 means off work; profession must be 0..5. At most ${JOB_CAPACITY} workers per job: the rest keep their profession and take a day off. Rotate seats fairly: oldest lastPaidDay first; avoid permanently unemployed cats. Work ${JOB_HOURS}.
Profession is permanent, NOT a daily random job. Keep existing profession unless changeAllowed=1; at most 3 lifetime changes. If profession=-1 choose a first career using personality, skills and preferences. Give a short Ukrainian reason only for changing an established profession; omit reason for an initial or unchanged career.
Evening: 0=rest/home,1=walk/visit friends,2=drive. Choose 2 ONLY if hasCar=1. Give cats varied free-time choices. Outings is an array of 1-3 DIFFERENT place indices for free time; [] if resting. All offered places are real and available, across all islands. Choose varied food cafes, Krusty Krab, lemonade, art, swimming, rides and rest by personality. Partners share their outings outside work; retain their separate careers. No invented indices. reason is "" for initial/unchanged careers.
House: -1=no purchase, otherwise its index in houses. Buy only if affordable from that cat's coins; prioritize a first home when saving permits, single cats may occasionally buy another home. A permanent couple may own ONE shared home: if either partner has a home/hasActiveHome=1, choose -1 for both. Roommate: -1=none or another catIndex with hasActiveHome=0. An owner keeps their existing active home on another purchase.
Families: ${state.familyReview?.due ? `this is the rare 14-game-day review; choose up to ${state.familyReview.slots} new mutual lifelong couples, male + female, both partner=-1. Pick compatible personalities gradually. Choose the male index ONLY from familyCandidates.males and female ONLY from familyCandidates.females; these lists exclude taken cats. Do NOT repeat existing pairs. Keep every existing partner forever. Every cat may eventually form a family; the limit applies ONLY to new couples in THIS review, never to the total number of families.` : "NO review today: output families:[]; never form or change a pair."}
Input cat columns: [index,name,personality,coins,profession,changeAllowed,careerChanges,skillsByJob,preferredJobs,lastPaidDay,recentWorkedDays,hasCar,ownedHomes,hasActiveHome,wishes,sex(0male/1female),partnerIndex(-1none)]. House columns: [index,id,name,price]. Place columns: [index,typeIndex,islandIndex,action]; types and islands give their names. Keep every row compact: numbers, no repeated names or keys. One batch for the whole day, no follow-up requests.` + CITY_PLAN_PACKING_HINT
      },
      {
        role: "user",
        content: JSON.stringify(packCityPayload({
          day: state.day,
          houses: houses.map((h, i) => [i, h.id, h.name, h.price]),
          cats,
          ...state.familyReview?.due ? {
            familyCandidates: {
              males: state.cats.flatMap(
                (p, i) => !p.partner && p.sex === "male" ? [i] : []
              ),
              females: state.cats.flatMap(
                (p, i) => !p.partner && p.sex === "female" ? [i] : []
              )
            }
          } : {},
          types: types.map((t, i) => [
            i,
            places2.find((p) => p.type === t).name
          ]),
          islands: islands.map((id, i) => [i, id]),
          places: places2.map((p, i) => [
            i,
            types.indexOf(p.type),
            islands.indexOf(p.biome),
            p.action
          ])
        }, CITY_PLAN_TEXT_COLUMNS))
      }
    ],
    max_tokens: Math.min(6500, Math.max(1500, state.cats.length * 34 + 700)),
    temperature: 0.3
  };
}
function expandCityPlan(raw, state) {
  if (!Array.isArray(raw?.assignments)) return raw;
  const houses = housingOffers();
  return {
    ...raw,
    families: Array.isArray(raw.families) ? raw.families.map((p) => {
      if (!Array.isArray(p)) return p;
      if (!Number.isSafeInteger(p[0]) || !Number.isSafeInteger(p[1]) || !state.cats[p[0]] || !state.cats[p[1]])
        throw Error("Invalid family indices");
      return {
        male: state.cats[p[0]].id,
        female: state.cats[p[1]].id,
        reason: p[2]
      };
    }) : [],
    assignments: raw.assignments.map((a) => {
      if (!Array.isArray(a)) return a;
      if (a.length < 6 || a.length > 8 || !a.slice(0, 6).every(Number.isSafeInteger) || a[0] < 0 || a[0] >= state.cats.length || a[1] < -1 || a[1] >= 6 || a[2] < 0 || a[2] >= 6 || a[3] < 0 || a[3] > 2 || a[4] < -1 || a[4] >= houses.length || a[5] < -1 || a[5] >= state.cats.length)
        throw Error("Invalid compact city plan");
      if (a[7] !== void 0 && (!Array.isArray(a[7]) || a[7].length > 3 || !a[7].every(
        (i) => Number.isSafeInteger(i) && i >= 0 && i < (state.leisureOffers?.length || 0)
      )))
        throw Error("Invalid outing indices");
      return {
        id: state.cats[a[0]].id,
        job: a[1] === -1 ? "rest" : JOB_KINDS[a[1]],
        profession: JOB_KINDS[a[2]],
        evening: ["rest", "walk", "drive"][a[3]],
        ...a[4] >= 0 ? {
          house: {
            type: houses[a[4]].id,
            roommate: a[5] >= 0 ? state.cats[a[5]].id : null
          }
        } : {},
        ...a[6] ? { reason: String(a[6]).slice(0, 160) } : {},
        ...a[7] ? { outings: a[7].map((i) => state.leisureOffers[i].id) } : {}
      };
    })
  };
}
function limitCityWorkplaces(raw, state) {
  if (!Array.isArray(raw?.assignments)) return raw;
  const profiles = new Map(state.cats.map((p) => [p.id, p]));
  const rows4 = raw.assignments.map((a) => {
    if (!a || ![...JOB_KINDS, "rest"].includes(a.job))
      throw Error("Invalid work choice");
    const p = profiles.get(a.id), profession = p?.profession && !p.canChangeProfession ? p.profession : a.profession ?? p?.profession ?? (a.job === "rest" ? p?.preferences[0] : a.job);
    return {
      ...a,
      profession,
      job: a.job === "rest" ? "rest" : profession,
      // Walking is the existing safe alternative when no owned car exists.
      evening: a.evening === "drive" && !p?.hasCar ? "walk" : a.evening
    };
  });
  const working = /* @__PURE__ */ new Map();
  for (const kind of JOB_KINDS) {
    const candidates = rows4.filter((a) => {
      const p = profiles.get(a.id), initial = p?.profession === null, overdue = state.day - (p?.lastPaidDay ?? -1) >= 3;
      return a.job === kind || a.job === "rest" && a.profession === kind && (initial || overdue);
    }).sort(
      (a, b) => (profiles.get(a.id)?.lastPaidDay ?? -1) - (profiles.get(b.id)?.lastPaidDay ?? -1) || a.id.localeCompare(b.id)
    );
    for (const row2 of candidates.slice(0, JOB_CAPACITY))
      working.set(row2.id, kind);
  }
  return {
    assignments: rows4.map((a) => ({
      ...a,
      job: working.get(a.id) || "rest"
    }))
  };
}

// ai.mjs
var moods = ["sleep", "crazy hungry", "happy"];
var places = ["home", "pond", "garden", "tree", "picnic"];
var ChoiceMismatch = class extends Error {
  constructor(decision, reason) {
    super(
      "\u0412\u044B\u0431\u0435\u0440\u0438 \u0440\u043E\u0432\u043D\u043E \u043E\u0434\u0438\u043D \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0439 \u043F\u0440\u0435\u0434\u043C\u0435\u0442 \u0441 activityId \u0438\u043B\u0438 \u043A\u043E\u0442\u0438\u043A\u0430 \u0441 friendId \u0438 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435. " + reason
    );
    this.decision = decision;
  }
};
var NeedsMismatch = class extends Error {
  constructor(decision, reason) {
    super(reason + " \u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u0438\u0435: " + decision.mood + ".");
    this.name = "NeedsMismatch";
    this.decision = decision;
  }
};
function checkNeeds(decision, state) {
  if (!state) return;
  let reason;
  if (state.energy <= 15 && state.hunger <= 30 && decision.mood !== "sleep")
    reason = "\u0427\u0438\u0447\u0438 \u0441\u044B\u0442\u0430 \u0438 \u043F\u043E\u0447\u0442\u0438 \u0431\u0435\u0437 \u0441\u0438\u043B: \u0435\u0439 \u043D\u0443\u0436\u0435\u043D \u0441\u043E\u043D, \u0430 \u043D\u0435 \u0433\u043E\u043B\u043E\u0434 \u0438\u043B\u0438 \u0431\u043E\u0434\u0440\u043E\u0441\u0442\u044C.";
  else if (state.hunger >= 85 && state.energy >= 30 && decision.mood !== "crazy hungry")
    reason = "\u0427\u0438\u0447\u0438 \u043A\u0440\u0430\u0439\u043D\u0435 \u0433\u043E\u043B\u043E\u0434\u043D\u0430 \u0438 \u0443 \u043D\u0435\u0451 \u0435\u0441\u0442\u044C \u0441\u0438\u043B\u044B: \u0441\u0440\u043E\u0447\u043D\u0430\u044F \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u2014 \u0435\u0434\u0430.";
  else if (state.energy >= 70 && state.hunger <= 20 && state.happiness >= 70 && decision.mood !== "happy")
    reason = "\u0427\u0438\u0447\u0438 \u0441\u044B\u0442\u0430, \u0431\u043E\u0434\u0440\u0430 \u0438 \u0434\u043E\u0432\u043E\u043B\u044C\u043D\u0430: \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0438\u0441\u0442\u043E\u0449\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u0441\u0438\u043B\u044C\u043D\u043E\u0433\u043E \u0433\u043E\u043B\u043E\u0434\u0430 \u043D\u0435\u0442.";
  if (reason) throw new NeedsMismatch(decision, reason);
}
function parseDecision(response2, state = null) {
  let value = response2?.response ?? response2;
  if (typeof value === "string") {
    const match = value.match(/\{[\s\S]*\}/);
    if (!match) throw new Error("AI returned no decision");
    value = JSON.parse(match[0]);
  }
  if (!value || typeof value !== "object")
    throw new Error("AI returned no decision");
  if (!state?.world && !places.includes(value.target) || !moods.includes(value.mood) || typeof value.thought !== "string")
    throw new Error("Invalid AI decision");
  const decision = {
    target: value.target,
    mood: value.mood,
    thought: value.thought.slice(0, 180)
  };
  if (state?.world) {
    try {
      Object.assign(decision, resolveInteraction(state.world, value));
    } catch (error) {
      throw new ChoiceMismatch(value, error.message);
    }
  } else if (value.action !== void 0) {
    if (!ACTIONS.includes(value.action)) throw new Error("Invalid AI activity");
    decision.action = value.action;
  }
  checkNeeds(decision, state);
  if (state?.world) checkAvailableChoice(decision, state);
  return decision;
}
function decisionOptions(state) {
  if (!state.world) return null;
  const recent = state.world.recent || [], last = recent.at(-1);
  let activities = state.world.activities.map((a) => ({
    ...a,
    actions: activityActions(a).filter((action) => {
      if (action === "eat")
        return !Number.isFinite(a.foodPortions) || a.foodPortions > 0;
      if (action === "farm" && a.farmStateKnown !== false)
        return (a.harvestReady || 0) > 0 || (a.emptyPlots || 0) > 0 && a.seedAffordable !== false;
      return true;
    })
  }));
  const hasLeisure = state.world.friends.length > 0 || activities.some(
    (a) => a.actions.some(
      (action) => ["play", "ride", "swim", "party"].includes(action)
    )
  );
  const lastWasFarm = last?.action === "farm" || byItem(activities.find((a) => a.id === last?.activityId)?.type)?.category === "farm";
  const farmBreak = lastWasFarm && hasLeisure && state.energy > 20 && state.hunger < 80;
  if (farmBreak)
    activities = activities.filter((a) => byItem(a.type).category !== "farm");
  activities = activities.filter((a) => a.actions.length);
  const counts = {};
  for (const a of activities)
    for (const action of a.actions) counts[action] = (counts[action] || 0) + 1;
  counts.meet = state.world.friends.length;
  return { activities, counts, farmBreak };
}
function checkAvailableChoice(decision, state) {
  if (decision.action === "meet") return;
  const options = decisionOptions(state), object = options.activities.find((a) => a.id === decision.activityId);
  if (object?.actions.includes(decision.action)) return;
  throw new ChoiceMismatch(
    decision,
    options.farmBreak && byItem(
      state.world.activities.find((a) => a.id === decision.activityId)?.type
    )?.category === "farm" ? "\u0427\u0438\u0447\u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E \u0431\u044B\u043B\u0430 \u043D\u0430 \u0444\u0435\u0440\u043C\u0435. \u0421\u0435\u0439\u0447\u0430\u0441 \u043D\u0435\u0442 \u0441\u0440\u043E\u0447\u043D\u043E\u0439 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u0432 \u0435\u0434\u0435 \u0438\u043B\u0438 \u0441\u043D\u0435: \u0432\u044B\u0431\u0435\u0440\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0443\u044E \u0438\u0433\u0440\u0443, \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u0443\u044E \u0433\u043E\u0440\u043A\u0443, \u0432\u043E\u0434\u0443 \u0438\u043B\u0438 \u043A\u043E\u0442\u0438\u043A\u0430." : "\u041D\u0430 \u044D\u0442\u043E\u0439 \u0444\u0435\u0440\u043C\u0435 \u043D\u0435\u0447\u0435\u0433\u043E \u0441\u043E\u0431\u0438\u0440\u0430\u0442\u044C \u0438 \u043D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0441\u0430\u0434\u0438\u0442\u044C \u0443\u0440\u043E\u0436\u0430\u0439. \u0412\u044B\u0431\u0435\u0440\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0438\u0437 \u0441\u043F\u0438\u0441\u043A\u0430; \u043D\u0435 \u0436\u0434\u0438 \u043D\u0430 \u0440\u0430\u0441\u0442\u0443\u0449\u0435\u0439 \u0433\u0440\u044F\u0434\u043A\u0435."
  );
}
async function requestDecision(state, run) {
  let correction;
  for (let attempt = 0; attempt < 2; attempt++) {
    const input = {
      messages: messages(state),
      temperature: state.world && state.energy > 20 && state.hunger < 80 ? 0.35 : 0.1,
      max_tokens: 384,
      response_format: { type: "json_object" }
    };
    if (correction) {
      input.messages.push(
        { role: "assistant", content: JSON.stringify(correction.decision) },
        {
          role: "user",
          content: "\u041F\u0435\u0440\u0435\u043F\u0440\u043E\u0432\u0435\u0440\u044C \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0435 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0446\u0435\u043B\u0438. \u0412\u044B\u0434\u0430\u0439 \u043D\u043E\u0432\u043E\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 JSON. " + correction.message
        }
      );
    }
    const result2 = await run(input);
    try {
      return parseDecision(result2, state);
    } catch (error) {
      if ((error instanceof NeedsMismatch || error instanceof ChoiceMismatch) && attempt === 0) {
        correction = error;
        continue;
      }
      const invalid = new Error("AI returned an invalid decision", {
        cause: error
      });
      invalid.code = "AI_INVALID_DECISION";
      throw invalid;
    }
  }
}
function messages(state) {
  const options = decisionOptions(state);
  const worldRules = "\u0412 \u0438\u0433\u0440\u043E\u0432\u043E\u043C \u043C\u0438\u0440\u0435 \u0432\u044B\u0431\u0438\u0440\u0430\u0439 \u0422\u041E\u041B\u042C\u041A\u041E \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0435 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B \u0438\u043B\u0438 \u043A\u043E\u0442\u0438\u043A\u043E\u0432. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0446\u0435\u043D\u0438, \u0447\u0435\u0433\u043E \u0442\u0435\u0431\u0435 \u0445\u043E\u0447\u0435\u0442\u0441\u044F: \u043F\u043E\u043A\u043E\u044F, \u0435\u0434\u044B, \u0438\u0433\u0440\u044B, \u043F\u0440\u0438\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F, \u043E\u0431\u0449\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u0440\u0430\u0431\u043E\u0442\u044B \u043D\u0430 \u0433\u0440\u044F\u0434\u043A\u0430\u0445. \u0417\u0430\u0442\u0435\u043C \u0432\u044B\u0431\u0435\u0440\u0438 \u0440\u043E\u0432\u043D\u043E \u043E\u0434\u043D\u0443 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0446\u0435\u043B\u044C \u0438\u0437 world.activities \u0438\u043B\u0438 world.friends. \u0414\u043B\u044F \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u0430 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0439 mood, action, activityId, thought. \u0414\u043B\u044F \u043A\u043E\u0442\u0438\u043A\u0430 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0439 mood, action=meet, friendId, thought. \u0414\u043B\u044F swim \u0432\u044B\u0431\u0438\u0440\u0430\u0439 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u0443\u044E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0443\u044E \u043B\u0430\u0433\u0443\u043D\u0443 \u0438\u0437 activities; \u043F\u043B\u0430\u0432\u0430\u0439 \u0442\u043E\u043B\u044C\u043A\u043E \u0435\u0441\u043B\u0438 \u043D\u0435 \u0443\u0441\u0442\u0430\u043B\u0430 \u0438 \u043D\u0435 \u0441\u0438\u043B\u044C\u043D\u043E \u0433\u043E\u043B\u043E\u0434\u043D\u0430. \u041A\u0430\u0436\u0434\u0430\u044F \u0433\u043E\u0440\u043A\u0430 \u2014 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0446\u0435\u043B\u044C. \u041D\u0435 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0439 \u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442\u044B \u0438\u043B\u0438 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u043B\u044C\u043D\u0443\u044E \u043B\u043E\u043A\u0430\u0446\u0438\u044E: \u043C\u0438\u0440 \u0441\u0430\u043C \u043D\u0430\u043F\u0440\u0430\u0432\u0438\u0442 \u0442\u0435\u0431\u044F \u043A \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C\u0443 \u043E\u0431\u044A\u0435\u043A\u0442\u0443. activityId \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u0435\u043D \u0434\u043B\u044F \u0412\u0421\u0415\u0425 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043D\u044B\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439, \u0432\u043A\u043B\u044E\u0447\u0430\u044F explore, rest \u0438 eat. friendId \u0438 activityId \u0432\u0437\u0430\u0438\u043C\u043E\u0438\u0441\u043A\u043B\u044E\u0447\u0430\u044E\u0449\u0438\u0435. \u0422\u043E\u043B\u044C\u043A\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0438\u0437 actions \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u0430. \u0414\u043B\u044F \u0441\u043D\u0430 \u0432\u0441\u0435\u0433\u0434\u0430 \u0435\u0441\u0442\u044C \u043F\u043E\u0434\u0443\u0448\u043A\u0430 chichi-bed, \u0434\u043B\u044F \u0435\u0434\u044B \u043E\u0431\u0449\u0430\u044F \u043C\u0438\u0441\u043A\u0430 chichi-food. \u041F\u0440\u0435\u0434\u043C\u0435\u0442\u044B \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0442; \u0415\u0414\u0410 \u041A\u041E\u041D\u0415\u0427\u041D\u0410: eat \u043C\u043E\u0436\u043D\u043E \u0432\u044B\u0431\u0438\u0440\u0430\u0442\u044C \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438 foodPortions>0. \u0415\u0441\u043B\u0438 \u043C\u0438\u0441\u043A\u0430 \u043F\u0443\u0441\u0442\u0430, \u043D\u0435\u043B\u044C\u0437\u044F \u0435\u0441\u0442\u044C: \u043C\u043E\u0436\u043D\u043E \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u0433\u043E\u0442\u043E\u0432\u044B\u0439 \u0443\u0440\u043E\u0436\u0430\u0439 \u043D\u0430 \u0444\u0435\u0440\u043C\u0435 \u0438\u043B\u0438 \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u0434\u0440\u0443\u0433\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435. \u0427\u0435\u043B\u043E\u0432\u0435\u043A \u043F\u043E\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u043C\u0438\u0441\u043A\u0443 \u0432\u044B\u0440\u0430\u0449\u0435\u043D\u043D\u044B\u043C \u0443\u0440\u043E\u0436\u0430\u0435\u043C. \u041D\u0435 \u043F\u0440\u0438\u0434\u0443\u043C\u044B\u0432\u0430\u0439 ID \u0438 \u043D\u0435 \u0432\u044B\u0431\u0438\u0440\u0430\u0439 \u0441\u0442\u0440\u043E\u044F\u0449\u0438\u0435\u0441\u044F/\u0443\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u0432\u0435\u0449\u0438. world.recent \u2014 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u044F \u0441 \u043F\u043E\u043C\u0435\u0442\u043A\u043E\u0439 ai/manual/demo. \u0423\u0447\u0438\u0442\u044B\u0432\u0430\u0439 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0435 \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u0438 \u043E\u043F\u044B\u0442 \u0438\u0433\u0440 \u0441 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u043E\u043C, \u043D\u0435 \u0437\u0430\u0446\u0438\u043A\u043B\u0438\u0432\u0430\u0439\u0441\u044F \u0431\u0435\u0437 \u043F\u0440\u0438\u0447\u0438\u043D\u044B. \u041D\u0435 \u0434\u0435\u043B\u0430\u0439 \u0441\u043B\u0443\u0447\u0430\u0439\u043D\u044B\u0439 \u0432\u044B\u0431\u043E\u0440 \u0440\u0430\u0434\u0438 \u0440\u0430\u0437\u043D\u043E\u043E\u0431\u0440\u0430\u0437\u0438\u044F: \u0441\u0438\u043B\u044C\u043D\u0430\u044F \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u044C \u0438\u043B\u0438 \u0433\u043E\u043B\u043E\u0434 \u043E\u043F\u0440\u0430\u0432\u0434\u044B\u0432\u0430\u044E\u0442 \u043F\u043E\u0432\u0442\u043E\u0440 \u043D\u0443\u0436\u043D\u043E\u0433\u043E \u0443\u0445\u043E\u0434\u0430. \u0422\u044B \u043B\u0430\u0441\u043A\u043E\u0432\u0430\u044F, \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u043D\u0430\u044F; \u043B\u044E\u0431\u0438\u0448\u044C \u043E\u0445\u043E\u0442\u0443 \u0437\u0430 \u0438\u0433\u0440\u0443\u0448\u043A\u0430\u043C\u0438, \u043D\u043E\u0432\u044B\u0435 \u043F\u0440\u0438\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F \u0438 \u0434\u0440\u0443\u0436\u0431\u0443, \u043D\u043E \u043F\u0440\u0438 \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u0438 \u0446\u0435\u043D\u0438\u0448\u044C \u043F\u043E\u043A\u043E\u0439. \u0423 \u043A\u043E\u0442\u0438\u043A\u043E\u0432 \u0435\u0441\u0442\u044C \u0438\u043C\u044F, personality, closeness, meetings, plays, stage, hunger, happiness. \u041D\u0443\u043B\u0435\u0432\u044B\u0435 meetings \u043E\u0437\u043D\u0430\u0447\u0430\u044E\u0442, \u0447\u0442\u043E \u0432\u044B \u0435\u0449\u0451 \u041D\u0415 \u0437\u043D\u0430\u043A\u043E\u043C\u044B. \u0421\u0430\u043C\u0430 \u0432\u044B\u0431\u0438\u0440\u0430\u0439 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E\u0433\u043E \u043A\u043E\u0442\u0438\u043A\u0430 \u0438 \u0434\u043B\u044F action=meet \u0434\u043E\u0431\u0430\u0432\u044C socialIntent: greet (\u043F\u0435\u0440\u0432\u043E\u0435 \u0437\u043D\u0430\u043A\u043E\u043C\u0441\u0442\u0432\u043E), play (\u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u0430\u044F \u0438\u0433\u0440\u0430), relax (\u043F\u043E\u0441\u0438\u0434\u0435\u0442\u044C \u0440\u044F\u0434\u043E\u043C), cuddle (\u043B\u0430\u0441\u043A\u043E\u0432\u043E\u0435 \u043E\u0431\u0449\u0435\u043D\u0438\u0435). \u041E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u044F \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u0435\u0437 \u0437\u0430\u043A\u043E\u043D\u0447\u0435\u043D\u043D\u044B\u0435 \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F, \u0431\u0435\u0437 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0434\u0440\u0443\u0436\u0431\u044B \u0441\u043E \u0432\u0441\u0435\u043C\u0438. \u0415\u0441\u043B\u0438 bestEligible=true \u0438 \u0442\u0435\u0431\u0435 \u0445\u043E\u0447\u0435\u0442\u0441\u044F \u0438\u043C\u0435\u043D\u043D\u043E \u044D\u0442\u043E\u0433\u043E \u0431\u043B\u0438\u0437\u043A\u043E\u0433\u043E \u0434\u0440\u0443\u0433\u0430, \u043C\u043E\u0436\u0435\u0448\u044C \u0432\u044B\u0431\u0440\u0430\u0442\u044C socialIntent=best_friend: \u0442\u043E\u0433\u0434\u0430 \u043E\u043D \u0441\u0442\u0430\u043D\u0435\u0442 \u0442\u0432\u043E\u0438\u043C \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C \u043B\u0443\u0447\u0448\u0438\u043C \u0434\u0440\u0443\u0436\u043A\u043E\u043C \u0438 \u0431\u0443\u0434\u0435\u0442 \u0445\u043E\u0434\u0438\u0442\u044C \u0441 \u0442\u043E\u0431\u043E\u0439. \u041D\u0435 \u043D\u0430\u0437\u044B\u0432\u0430\u0439 \u043D\u0435\u0437\u043D\u0430\u043A\u043E\u043C\u044B\u0445 \u043B\u0443\u0447\u0448\u0438\u043C\u0438 \u0434\u0440\u0443\u0437\u044C\u044F\u043C\u0438 \u0438 \u043D\u0435 \u0432\u044B\u0431\u0438\u0440\u0430\u0439 best_friend, \u043F\u043E\u043A\u0430 bestEligible=false. \u041F\u0440\u0438 \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u0438 \u0432\u044B\u0431\u0435\u0440\u0438 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u043E\u0435 \u043E\u0431\u0449\u0435\u043D\u0438\u0435, \u043F\u0440\u0438 \u0431\u043E\u0434\u0440\u043E\u0441\u0442\u0438 \u2014 \u0432\u0435\u0441\u0451\u043B\u0443\u044E \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u0443\u044E \u0438\u0433\u0440\u0443. \u0412 thought \u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438, \u0441 \u043A\u0435\u043C \u0438 \u0447\u0442\u043E \u0445\u043E\u0447\u0435\u0442\u0441\u044F \u0434\u0435\u043B\u0430\u0442\u044C. \u0414\u043B\u044F farm \u0441\u043C\u043E\u0442\u0440\u0438 harvestReady \u0438 emptyPlots; \u0440\u0430\u0441\u0442\u0443\u0449\u0438\u0439 \u0443\u0440\u043E\u0436\u0430\u0439 \u0441\u0430\u043C \u043F\u043E \u0441\u0435\u0431\u0435 \u043D\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u0430 \u0441\u043D\u043E\u0432\u0430 \u0438\u0434\u0442\u0438 \u043D\u0430 \u0442\u0443 \u0436\u0435 \u0444\u0435\u0440\u043C\u0443. \u041F\u0440\u0438 \u043D\u0438\u0437\u043A\u043E\u043C \u043A\u043E\u043C\u0444\u043E\u0440\u0442\u0435 \u043F\u043E\u0434\u0443\u043C\u0430\u0439 \u043E\u0431 \u043E\u0431\u0449\u0435\u043D\u0438\u0438 \u0438\u043B\u0438 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u043E\u0439 \u0437\u043D\u0430\u043A\u043E\u043C\u043E\u0439 \u0438\u0433\u0440\u0443\u0448\u043A\u0435. \u0412 thought \u043E\u0442 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u043B\u0438\u0446\u0430 \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u043E\u043C \u043D\u0430\u0437\u043E\u0432\u0438 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0439 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u043F\u0440\u0435\u0434\u043C\u0435\u0442/\u043A\u043E\u0442\u0438\u043A\u0430 \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u0443 \u0436\u0435\u043B\u0430\u043D\u0438\u044F. \u042D\u0442\u043E \u0442\u0432\u043E\u0438 \u0436\u0435\u043B\u0430\u043D\u0438\u044F, \u0430 \u043D\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u0441\u043B\u0443\u0447\u0430\u0439\u043D\u043E \u0447\u0435\u0440\u0435\u0434\u043E\u0432\u0430\u0442\u044C \u043C\u0435\u0441\u0442\u0430. \u041F\u0440\u0438 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0435 \u0441 \u043F\u0440\u0435\u0436\u043D\u0438\u043C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435\u043C \u0443\u0447\u0438\u0442\u044B\u0432\u0430\u0439 \u0442\u0435\u043A\u0443\u0449\u0438\u0435 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438.";
  const physicalExamples = state.world ? "\n\u041F\u0440\u0438\u043C\u0435\u0440\u044B \u0424\u041E\u0420\u041C\u0410\u0422\u0410, \u043D\u0435 \u0433\u043E\u0442\u043E\u0432\u044B\u0439 \u0432\u044B\u0431\u043E\u0440 \u0432\u043C\u0435\u0441\u0442\u043E \u0442\u0432\u043E\u0435\u0433\u043E \u0440\u0435\u0448\u0435\u043D\u0438\u044F: " + JSON.stringify([
    {
      mood: "sleep",
      action: "rest",
      activityId: "chichi-bed",
      thought: "\u042F \u0441\u044B\u0442\u0430\u044F, \u043D\u043E \u0443\u0441\u0442\u0430\u043B\u0430. \u041F\u043E\u0441\u043F\u043B\u044E \u043D\u0430 \u0441\u0432\u043E\u0435\u0439 \u043F\u043E\u0434\u0443\u0448\u043A\u0435."
    },
    {
      mood: "crazy hungry",
      action: "eat",
      activityId: "chichi-food",
      thought: "\u0416\u0438\u0432\u043E\u0442\u0438\u043A \u0433\u043E\u043B\u043E\u0434\u043D\u044B\u0439. \u041F\u043E\u0435\u043C \u0438\u0437 \u043E\u0431\u0449\u0435\u0439 \u043C\u0438\u0441\u043A\u0438, \u0435\u0441\u043B\u0438 \u0432 \u043D\u0435\u0439 \u0435\u0441\u0442\u044C \u0435\u0434\u0430."
    }
  ]) + " \u0412 \u043A\u0430\u0436\u0434\u043E\u043C \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u043D\u043E\u043C \u043E\u0442\u0432\u0435\u0442\u0435 activityId \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u0435\u043D, \u0434\u0430\u0436\u0435 \u0435\u0441\u043B\u0438 target=home \u0438 action=rest. \u0412\u043C\u0435\u0441\u0442\u043E \u043F\u0440\u0438\u043C\u0435\u0440\u0430 \u0432\u044B\u0431\u0438\u0440\u0430\u0439 \u043F\u043E \u0442\u0435\u043A\u0443\u0449\u0438\u043C \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044F\u043C \u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u043C \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C." : "";
  const needsRules = "\u0422\u044B \u0427\u0438\u0447\u0438, \u0441\u0435\u0440\u0435\u0431\u0440\u0438\u0441\u0442\u043E-\u0441\u0435\u0440\u0430\u044F \u043A\u043E\u0448\u0435\u0447\u043A\u0430 \u0441 \u043E\u043B\u0438\u0432\u043A\u043E\u0432\u044B\u043C\u0438 \u0433\u043B\u0430\u0437\u0430\u043C\u0438 \u0432 \u0441\u043A\u0430\u0437\u043E\u0447\u043D\u043E\u043C \u043C\u0438\u0440\u0435. energy: 0 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0443\u0441\u0442\u0430\u043B\u0430, 100 \u043F\u043E\u043B\u043D\u0430 \u0441\u0438\u043B. hunger \u2014 \u0413\u041E\u041B\u041E\u0414, \u043D\u0435 \u0437\u0430\u043F\u0430\u0441 \u0435\u0434\u044B: 0 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0441\u044B\u0442\u0430, 100 \u043A\u0440\u0430\u0439\u043D\u0435 \u0433\u043E\u043B\u043E\u0434\u043D\u0430. satiety=100-hunger, fatigue=100-energy. hunger=10 \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442 \u0441\u044B\u0442\u043E\u0441\u0442\u044C 90%, energy=5 \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u044C 95%. happiness: 0 \u0442\u0440\u0435\u0432\u043E\u0436\u043D\u0430, 100 \u0434\u043E\u0432\u043E\u043B\u044C\u043D\u0430. mood \u2014 \u041F\u0420\u0415\u0414\u042B\u0414\u0423\u0429\u0415\u0415 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435, \u043E\u043D\u043E \u043D\u0435 \u0437\u0430\u0434\u0430\u0451\u0442 \u043E\u0442\u0432\u0435\u0442. \u0412\u044B\u0431\u0435\u0440\u0438 \u0440\u043E\u0432\u043D\u043E \u043E\u0434\u043D\u043E: sleep, crazy hungry, happy. \u0414\u043B\u044F \u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0445 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0439: energy<=15,hunger<=30 -> sleep; hunger>=85,energy>=30 -> crazy hungry; energy>=70,hunger<=20,happiness>=70 -> happy. \u0412 \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0445 \u0441\u043B\u0443\u0447\u0430\u044F\u0445 \u0441\u0430\u043C\u0430 \u043E\u0446\u0435\u043D\u0438 \u0432\u0441\u0435 \u0442\u0440\u0438 \u0444\u0430\u043A\u0442\u043E\u0440\u0430 \u0438 \u0441\u0440\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0435\u0439. \u041D\u0438\u0437\u043A\u0438\u0439 \u043A\u043E\u043C\u0444\u043E\u0440\u0442 \u043D\u0435 \u0441\u043E\u0437\u0434\u0430\u0451\u0442 \u0447\u0435\u0442\u0432\u0451\u0440\u0442\u043E\u0433\u043E \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u0438\u044F \u0438 \u043D\u0435 \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442 \u0433\u043E\u043B\u043E\u0434. \u0412\u0435\u0440\u043D\u0438 \u0442\u043E\u043B\u044C\u043A\u043E JSON. \u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0439 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 \u0438\u0437 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F.";
  return [
    {
      role: "system",
      content: needsRules + "\n" + (state.world ? worldRules + physicalExamples + " \u0422\u044B \u0436\u0438\u0432\u043E\u0439 \u043A\u043E\u0442\u0438\u043A, \u0430 \u043D\u0435 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0444\u0435\u0440\u043C\u0435\u0440. \u0420\u0430\u0431\u043E\u0442\u0430 \u043D\u0430 \u0433\u0440\u044F\u0434\u043A\u0430\u0445 \u2014 \u043E\u0434\u0438\u043D \u0432\u0430\u0440\u0438\u0430\u043D\u0442 \u043D\u0430\u0440\u0430\u0432\u043D\u0435 \u0441 \u0438\u0433\u0440\u0430\u043C\u0438, \u043A\u0430\u0442\u0430\u043D\u0438\u0435\u043C, \u043A\u0443\u043F\u0430\u043D\u0438\u0435\u043C \u0438 \u0434\u0440\u0443\u0437\u044C\u044F\u043C\u0438. \u0423\u0447\u0438\u0442\u044B\u0432\u0430\u0439 availableChoices: \u0444\u0435\u0440\u043C\u0430 \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u0442\u0441\u044F \u0434\u043B\u044F \u0440\u0430\u0431\u043E\u0442\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u0435\u0441\u043B\u0438 \u0435\u0441\u0442\u044C \u0433\u043E\u0442\u043E\u0432\u044B\u0439 \u0443\u0440\u043E\u0436\u0430\u0439 \u0438\u043B\u0438 \u0441\u0432\u043E\u0431\u043E\u0434\u043D\u0430\u044F \u0433\u0440\u044F\u0434\u043A\u0430 \u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0435 \u0441\u0435\u043C\u0435\u043D\u0430. \u041F\u043E\u0441\u043B\u0435 \u0440\u0430\u0431\u043E\u0442\u044B, \u043A\u043E\u0433\u0434\u0430 \u0441\u044B\u0442\u0430 \u0438 \u0435\u0441\u0442\u044C \u0441\u0438\u043B\u044B, \u0432\u044B\u0431\u0438\u0440\u0430\u0439 \u0441\u0432\u043E\u0451 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0435 \u0436\u0435\u043B\u0430\u043D\u0438\u0435 \u0441\u0440\u0435\u0434\u0438 \u0440\u0430\u0437\u0432\u043B\u0435\u0447\u0435\u043D\u0438\u0439 \u0438 \u043E\u0431\u0449\u0435\u043D\u0438\u044F. \u041F\u0440\u0435\u0434\u043F\u043E\u0447\u0438\u0442\u0430\u0439 \u0435\u0449\u0451 \u043D\u0435 \u0438\u0441\u043F\u044B\u0442\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0435 \u043F\u0440\u0435\u0434\u043C\u0435\u0442\u044B \u0438 \u0440\u0430\u0437\u043D\u044B\u0445 \u043A\u043E\u0442\u0438\u043A\u043E\u0432, \u0435\u0441\u043B\u0438 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u0443\u0445\u043E\u0434\u0430. \u041D\u0435 \u043F\u0440\u0438\u0434\u0443\u043C\u044B\u0432\u0430\u0439 \u043D\u0435\u043A\u0443\u043F\u043B\u0435\u043D\u043D\u044B\u0435 \u0438\u043B\u0438 \u0437\u0430\u043A\u0440\u044B\u0442\u044B\u0435 \u0430\u0442\u0442\u0440\u0430\u043A\u0446\u0438\u043E\u043D\u044B." : "\u0412\u0435\u0440\u043D\u0438 target, mood, thought. \u0421\u0442\u0430\u0440\u044B\u0435 \u043B\u043E\u043A\u0430\u0446\u0438\u0438: home (\u043E\u0442\u0434\u044B\u0445), picnic (\u0435\u0434\u0430), pond (\u043F\u0440\u0443\u0434), garden (\u0446\u0432\u0435\u0442\u044B), tree (\u0434\u0435\u0440\u0435\u0432\u043E).")
    },
    {
      role: "user",
      content: JSON.stringify(
        state.world ? {
          ...state,
          needs: needSummary(state),
          world: {
            ...state.world,
            availableChoices: options.counts,
            farmBreak: options.farmBreak,
            activities: options.activities.map((a) => ({
              ...a,
              name: a.name || HOME_OBJECTS.find((o) => o.id === a.id)?.name || byItem(a.type).name,
              description: byItem(a.type).description,
              actions: a.actions,
              recentlyUsed: (state.world.recent || []).some(
                (r) => r.activityId === a.id
              )
            })),
            friends: state.world.friends.map((f) => ({
              ...f,
              name: NEIGHBORS.find((n) => n.id === f.id).name,
              personality: NEIGHBORS.find((n) => n.id === f.id).personality
            }))
          }
        } : { ...state, needs: needSummary(state) }
      )
    }
  ];
}
function needSummary(state) {
  return {
    satiety: 100 - state.hunger,
    fatigue: 100 - state.energy,
    energyMeaning: state.energy <= 15 ? "\u043F\u043E\u0447\u0442\u0438 \u043D\u0435\u0442 \u0441\u0438\u043B" : state.energy >= 70 ? "\u0431\u043E\u0434\u0440\u0430" : "\u0435\u0441\u0442\u044C \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u044C",
    hungerMeaning: state.hunger <= 30 ? "\u0441\u044B\u0442\u0430" : state.hunger >= 85 ? "\u043A\u0440\u0430\u0439\u043D\u0435 \u0433\u043E\u043B\u043E\u0434\u043D\u0430" : "\u0433\u043E\u043B\u043E\u0434 \u0443\u043C\u0435\u0440\u0435\u043D\u043D\u044B\u0439",
    comfortMeaning: state.happiness >= 70 ? "\u0434\u043E\u0432\u043E\u043B\u044C\u043D\u0430" : state.happiness <= 30 ? "\u0442\u0440\u0435\u0432\u043E\u0436\u043D\u0430" : "\u0441\u043F\u043E\u043A\u043E\u0439\u043D\u0430"
  };
}
function validateState(value) {
  if (!value || !places.includes(value.location))
    throw new Error("Invalid location");
  for (const k of ["hunger", "energy"])
    if (!Number.isFinite(value[k]) || value[k] < 0 || value[k] > 100)
      throw new Error("Invalid needs");
  const happiness = value.happiness ?? 75, mood = value.mood ?? "happy";
  if (!Number.isFinite(happiness) || happiness < 0 || happiness > 100 || !moods.includes(mood))
    throw new Error("Invalid mood factors");
  const state = {
    location: value.location,
    hunger: value.hunger,
    energy: value.energy,
    happiness,
    mood
  };
  if (value.world !== void 0) {
    const rawWorld = value.world;
    const world = rawWorld && {
      ...rawWorld,
      biomes: Array.isArray(rawWorld.biomes) ? rawWorld.biomes.map((id) => id === "wizard" ? "moon" : id) : rawWorld.biomes,
      activities: Array.isArray(rawWorld.activities) ? rawWorld.activities.map(
        (a) => a?.biome === "wizard" ? { ...a, biome: "moon" } : a
      ) : rawWorld.activities
    };
    if (!world || !Array.isArray(world.activities) || world.activities.length > HOME_OBJECTS.length + permanentObjects(BIOMES.map((b) => b.id)).length + 60 || !Array.isArray(world.friends) || world.friends.length > NEIGHBORS.length || !Array.isArray(world.biomes) || world.biomes.length > BIOMES.length)
      throw new Error("Invalid world");
    const biomes = [
      .../* @__PURE__ */ new Set([
        "moon",
        ...world.biomes.filter((b) => BIOMES.some((x) => x.id === b))
      ])
    ];
    const activities = HOME_OBJECTS.map(({ id, type, biome }) => {
      const a = world.activities.find((a2) => a2?.id === id);
      return {
        id,
        type,
        biome,
        ...Number.isFinite(a?.foodPortions) ? {
          foodPortions: Math.max(
            0,
            Math.min(160, Math.floor(a.foodPortions))
          )
        } : {}
      };
    });
    const permanent = permanentObjects(biomes).filter(
      (object) => world.activities.some((activity) => activity?.id === object.id)
    );
    for (const o of permanent) {
      const raw = world.activities.find((a) => a.id === o.id);
      activities.push({
        ...o,
        ...activityActions(o).includes("eat") && Number.isFinite(raw?.foodPortions) ? {
          foodPortions: Math.max(
            0,
            Math.min(160, Math.floor(raw.foodPortions))
          )
        } : {}
      });
    }
    for (const a of world.activities) {
      if (!a || typeof a.id !== "string" || !/^[\w-]{1,40}$/.test(a.id) || !byItem(a.type) || !biomes.includes(a.biome) || activities.some((x) => x.id === a.id) && ![...HOME_OBJECTS, ...permanent].some(
        (x) => x.id === a.id && x.type === a.type && x.biome === a.biome
      ))
        throw new Error("Invalid world activity");
      if ([...HOME_OBJECTS, ...permanent].some((x) => x.id === a.id)) continue;
      activities.push({
        id: a.id,
        type: a.type,
        biome: a.biome,
        ...byItem(a.type).actions.includes("eat") && Number.isFinite(a.foodPortions) ? {
          foodPortions: Math.max(
            0,
            Math.min(160, Math.floor(a.foodPortions))
          )
        } : {},
        ...byItem(a.type).category === "farm" ? {
          harvestReady: Math.max(
            0,
            Math.min(3, Number(a.harvestReady) || 0)
          ),
          emptyPlots: Math.max(0, Math.min(3, Number(a.emptyPlots) || 0)),
          seedAffordable: a.seedAffordable !== false,
          farmStateKnown: Number.isFinite(a.harvestReady) && Number.isFinite(a.emptyPlots)
        } : {}
      });
    }
    const friends = [];
    for (const f of world.friends) {
      const profile = NEIGHBORS.find(
        (n) => n.id === f?.id && biomes.includes(n.biome)
      );
      if (!profile || !Number.isFinite(f.closeness) || f.closeness < 0 || f.closeness > 100 || friends.some((n) => n.id === f.id))
        throw new Error("Invalid friend");
      if (f.biome !== void 0 && !biomes.includes(f.biome))
        throw new Error("Invalid friend location");
      const bounded = (v, max) => Math.max(0, Math.min(max, Math.floor(Number(v) || 0)));
      const r = {
        points: f.closeness,
        meetings: bounded(f.meetings, 1e4),
        plays: bounded(f.plays, 1e4)
      };
      friends.push({
        id: profile.id,
        biome: f.biome || profile.biome,
        closeness: r.points,
        meetings: r.meetings,
        plays: Math.min(r.plays, r.meetings),
        stage: relationshipStage(r, f.stage === "best" && bestEligible(r)),
        bestEligible: bestEligible(r),
        hunger: bounded(f.hunger, 100),
        happiness: bounded(f.happiness, 100)
      });
    }
    state.world = { activities, friends, biomes };
    state.world.recent = cleanRecent(world.recent, state.world);
  }
  return state;
}

// public/recovery-award-data.js
var RECOVERY_WORLD_HASH = "c6d2e2f94d67c747c2c548e1c02027fc0592b1e4499a94f79e6dcd9441739d59";
var RECOVERY_AWARD_ID = "player-recovery-20261118";
var RECOVERY_TARGET = { coins: 4381984, diamonds: 240, catCoins: 1e4 };

// recovery-award.mjs
async function applyRecoveryAward(transaction, now = Date.now()) {
  const current = await transaction.get("current");
  if (!current?.game) throw Error("\u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u043C\u0438\u0440\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E.");
  if (await transaction.get(RECOVERY_AWARD_ID)) return { game: current.game, revision: current.revision, alreadyApplied: true };
  for (const source of ["current", "previous", "older"]) {
    const snapshot = await transaction.get(source);
    if (snapshot) await transaction.put(RECOVERY_AWARD_ID + ":before:" + source, snapshot);
  }
  let game = structuredClone(current.game);
  const delta = Math.max(0, RECOVERY_TARGET.coins - game.coins);
  game.coins += delta;
  game.diamonds = Math.max(game.diamonds || 0, RECOVERY_TARGET.diamonds);
  game.totalEarned = (game.totalEarned || 0) + delta;
  game.unlocked = [.../* @__PURE__ */ new Set([...game.unlocked, "autumn"])];
  game = ensureJobCity(game, now, { forMall: true });
  for (const [id, p] of Object.entries(game.jobCity?.profiles || {})) {
    const amount = Math.max(0, RECOVERY_TARGET.catCoins - p.coins);
    if (!amount) continue;
    p.coins += amount;
    p.earnedTotal = (p.earnedTotal || 0) + amount;
    p.transactions = [...p.transactions || [], { id: RECOVERY_AWARD_ID + "-" + id, kind: "recovery", amount, at: now }].slice(-12);
  }
  const previous = await transaction.get("previous");
  if (previous) await transaction.put("older", previous);
  await transaction.put("previous", current);
  const save = { game, revision: current.revision + 1, savedAt: now, lastMutationId: RECOVERY_AWARD_ID };
  await transaction.put("current", save);
  await transaction.put(RECOVERY_AWARD_ID, { at: now, revision: save.revision });
  return { game, revision: save.revision, alreadyApplied: false };
}

// public/retired-attractions.js
var RETIRED_ATTRACTIONS = { "ride-water-jungle-coaster": 225e3, "ride-water-crystal-vortex": 185e3 };
var quantity = (v) => Number.isSafeInteger(v) && v >= 0 && v <= 1e5 ? v : 0;
function retiredCount(game, id) {
  const placed = new Set((game?.placements || []).filter((p) => p.item === id).map((p) => p.id)).size;
  return Math.max(quantity(game?.retiredAttractions?.[id]?.count), quantity(game?.referenceOwnership?.[id]?.count), quantity(game?.inventory?.[id]) + placed, game?.progression?.discoveries?.includes(id) ? 1 : 0);
}
function retirementPurchaseAdvanced(base, incoming) {
  const live = (g, id) => Math.max(quantity(g?.referenceOwnership?.[id]?.count), quantity(g?.inventory?.[id]) + new Set((g?.placements || []).filter((p) => p.item === id).map((p) => p.id)).size);
  return Object.keys(RETIRED_ATTRACTIONS).some((id) => live(incoming, id) > live(base, id) || retiredCount(incoming, id) > retiredCount(base, id));
}
function retirementSnapshotValid(raw) {
  return raw == null || !Array.isArray(raw) && typeof raw === "object" && Object.entries(raw).every(([id, r]) => RETIRED_ATTRACTIONS[id] && r && quantity(r.count) === r.count && r.count > 0 && Number.isSafeInteger(r.credited) && r.credited >= 0 && r.credited <= r.count * RETIRED_ATTRACTIONS[id]);
}
function inheritRetirement(base, incoming) {
  let result2 = incoming;
  for (const [id, r] of Object.entries(base?.retiredAttractions || {})) {
    const n = result2.retiredAttractions?.[id];
    if ((n?.count || 0) >= r.count && (n?.credited || 0) >= r.credited) continue;
    result2 = { ...result2, retiredAttractions: { ...result2.retiredAttractions, [id]: { count: Math.max(r.count, n?.count || 0), credited: Math.max(r.credited, n?.credited || 0) } } };
  }
  return result2;
}
function migrateRetiredAttractions(raw) {
  let result2 = raw;
  for (const [id, price] of Object.entries(RETIRED_ATTRACTIONS)) {
    const count = retiredCount(result2, id);
    if (!count) continue;
    const old = result2.retiredAttractions?.[id], credited = old?.credited || 0, credit = Math.max(0, Math.min(count * price - credited, 1e7 - result2.coins)), active = (result2.placements || []).some((p) => p.item === id) || id in (result2.inventory || {}) || id in (result2.builtInventory || {}) || !!result2.referenceOwnership?.[id] || (result2.relocatedPurchases || []).some((p) => p.item === id) || result2.progression?.discoveries?.includes(id);
    if (!active && old?.count === count && !credit) continue;
    if (result2 === raw) result2 = structuredClone(raw);
    const removed = new Set((result2.placements || []).filter((p) => p.item === id).map((p) => p.id));
    result2.placements = (result2.placements || []).filter((p) => p.item !== id);
    for (const key of ["inventory", "builtInventory", "referenceOwnership"]) if (result2[key]) delete result2[key][id];
    result2.relocatedPurchases = (result2.relocatedPurchases || []).filter((p) => p.item !== id);
    if (result2.progression?.discoveries) result2.progression.discoveries = result2.progression.discoveries.filter((item2) => item2 !== id);
    for (const key of ["accounts", "levels"]) for (const pid of removed) if (result2.business?.[key]) delete result2.business[key][pid];
    result2.retiredAttractions = { ...result2.retiredAttractions, [id]: { count, credited: credited + credit } };
    result2.coins += credit;
  }
  return result2;
}
function mergeRetirement(base, current, incoming, result2) {
  let overlap = 0;
  const records = {};
  for (const [id, price] of Object.entries(RETIRED_ATTRACTIONS)) {
    const count = Math.max(retiredCount(base, id), retiredCount(current, id), retiredCount(incoming, id));
    if (!count) continue;
    const b = base?.retiredAttractions?.[id]?.credited || 0, c = Math.max(b, current?.retiredAttractions?.[id]?.credited || 0), n = Math.max(b, incoming?.retiredAttractions?.[id]?.credited || 0), sum = c + n - b, credited = Math.min(count * price, sum);
    overlap += sum - credited;
    records[id] = { count, credited };
  }
  if (Object.keys(records).length) result2.retiredAttractions = records;
  result2.coins -= overlap;
  return result2;
}

// public/purchase-preservation.js
function referenceOwnership(game, now = Date.now()) {
  const result2 = {};
  for (const [id, v] of Object.entries(game.referenceOwnership || {})) if (byItem(id)?.referenceSlide && Number.isSafeInteger(v?.count) && v.count > 0 && v.count <= 1e5) result2[id] = { count: v.count, built: Math.min(v.count, Math.max(0, Number.isSafeInteger(v.built) ? v.built : 0)) };
  for (const id of game.progression?.discoveries || []) if (byItem(id)?.referenceSlide) result2[id] ||= { count: 1, built: 0 };
  const placed = /* @__PURE__ */ new Map(), seen = /* @__PURE__ */ new Set();
  for (const p of game.placements || []) if (byItem(p.item)?.referenceSlide && !seen.has(p.id)) {
    seen.add(p.id);
    const v = placed.get(p.item) || { count: 0, built: 0 };
    v.count++;
    if (!p.readyAt || p.readyAt <= now) v.built++;
    placed.set(p.item, v);
  }
  for (const id of /* @__PURE__ */ new Set([...Object.keys(result2), ...Object.keys(game.inventory || {}), ...placed.keys()])) if (byItem(id)?.referenceSlide) {
    const bag = Math.max(0, Math.floor(game.inventory?.[id] || 0)), p = placed.get(id) || { count: 0, built: 0 }, count = Math.max(result2[id]?.count || 0, bag + p.count);
    if (count) result2[id] = { count, built: Math.min(count, Math.max(result2[id]?.built || 0, Math.min(bag, game.builtInventory?.[id] || 0) + p.built)) };
  }
  return result2;
}
function preserveReferenceOwnership(game, now = Date.now(), { repair = true, sources = [] } = {}) {
  const records = referenceOwnership(game, now), epoch = game.jobCity?.epoch;
  if (epoch) {
    for (const source of sources) if (source?.jobCity?.epoch === epoch) {
      const evidence = referenceOwnership(source, now);
      for (const [id, v] of Object.entries(evidence)) if (game.progression?.discoveries?.includes(id)) records[id] = { count: Math.max(records[id]?.count || 0, v.count), built: Math.max(records[id]?.built || 0, v.built) };
    }
  }
  const old = game.referenceOwnership || {}, same2 = Object.keys(records).length === Object.keys(old).length && Object.entries(records).every(([id, v]) => old[id]?.count === v.count && old[id]?.built === v.built);
  let result2 = same2 ? game : { ...game, referenceOwnership: records };
  if (!repair) return result2;
  for (const [id, receipt] of Object.entries(records)) {
    const placed = (result2.placements || []).filter((p) => p.item === id), bag = result2.inventory?.[id] || 0, missing = receipt.count - bag - placed.length;
    if (missing <= 0) continue;
    const built = (result2.builtInventory?.[id] || 0) + placed.filter((p) => !p.readyAt || p.readyAt <= now).length, finished = Math.min(missing, Math.max(0, receipt.built - built));
    result2 = { ...result2, inventory: { ...result2.inventory, [id]: bag + missing }, builtInventory: { ...result2.builtInventory, [id]: (result2.builtInventory?.[id] || 0) + finished } };
  }
  return result2;
}

// public/magic-bed-state.js
function magicBedSnapshotValid(game) {
  const valid = (cells) => Array.isArray(cells) && cells.length === MAGIC_BED_SLOTS.length && cells.every((c, i) => c && Number.isSafeInteger(c.cycle) && c.cycle >= 0 && (c.crop === null && c.plantedAt === 0 && c.readyAt === 0 || magicBedCrop(c.crop)?.row === MAGIC_BED_SLOTS[i].row && Number.isFinite(c.plantedAt) && c.plantedAt >= 0 && Number.isFinite(c.readyAt) && c.readyAt > c.plantedAt));
  for (const p of game?.placements || []) if (p.item === MAGIC_BED_ID && !valid(game.farm?.fields?.[p.id])) return false;
  for (const r of game?.relocatedPurchases || []) if (r.item === MAGIC_BED_ID && r.fieldCells && !valid(r.fieldCells)) return false;
  return true;
}

// public/magic-farm-state.js
function orchardSnapshotValid(raw) {
  if (raw === void 0) return true;
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return false;
  for (const f of MAGIC_FARMS) {
    const o = raw[f.id];
    if (!o) continue;
    if (!Number.isFinite(o.openedAt) || o.openedAt < 0 || !o.plants) return false;
    for (const p of magicFarmLayout(f.id).plants) {
      const s = o.plants[p.id];
      if (!s || !Number.isSafeInteger(s.cycle) || s.cycle < 0 || !Number.isFinite(s.readyAt) || s.readyAt < 0) return false;
    }
  }
  return true;
}

// public/mall-pressure.js
var top = MALL_LAYOUT.y + MALL_LAYOUT.rise * 6 + 7.7;

// public/submarine-controls.js
var SUBMARINE_AIR_LEVEL = MOSA_SEA.surfaceY + 0.15;

// public/mosasaur-seabed-patch-data.js
var SEABED_REEF_PATCH = Object.freeze({ x: 0, z: -95, rx: 10, rz: 8, corals: 64, grass: 1024 });
var SEABED_REEF_GARDENS = Object.freeze([
  SEABED_REEF_PATCH,
  ...[[-135, -105], [-65, -175], [65, -145], [135, -105], [-165, -20], [-85, -40], [85, -40], [165, -20], [-130, 75], [130, 75], [-135, 145], [135, 145]].map(([x, z]) => Object.freeze({ x, z, rx: 28, rz: 24, corals: 96, grass: 1536 }))
]);

// public/mall-reef-fit.js
var MALL_REEF_OFFSETS = Object.freeze([
  {
    "dx": 5.973058941829145,
    "dz": 0.5679497138258772
  },
  {
    "dx": 59.99583969515474,
    "dz": -0.706554508367297
  },
  {
    "dx": 4.148176576589264,
    "dz": -243.96473644994154
  },
  {
    "dx": -202.79191959932524,
    "dz": -90.32960392485298
  },
  {
    "dx": -86.82568010504751,
    "dz": -40.95486874958772
  },
  null,
  null,
  null,
  null,
  null,
  null,
  null
]);

// public/mosasaur-reef-data.js
var forms = [
  { volumes: [[-1, 7, 0, 18, 12, 15], [-2, 22, -1, 12, 23, 11], [1, 36, -1, 10, 5.5, 9], [-7, 25, 5, 10, 6, 9], [9, 16, -5, 7, 18, 7]], caves: [[6, 17, 10, 7, 5.3, 12]] },
  { volumes: [[-2, 6, 1, 17, 12, 17], [-5, 21, -2, 10, 21, 11], [-6, 36, -2, 8, 6, 9], [7, 25, 1, 8, 15, 9], [9, 37, 2, 6, 4.5, 7], [-7, 15, 10, 10, 7, 7]], caves: [[0, 20, 0, 4.5, 5.5, 22]] },
  { volumes: [[0, 7, 0, 18, 13, 15], [1, 22, 0, 13, 21, 12], [0, 36, 1, 11, 5, 9], [-12, 16, -1, 7, 15, 9], [10, 26, -6, 7, 7, 9], [4, 16, 10, 12, 6, 8]], caves: [[7, 16, 12, 7, 6, 13], [-8, 11, -10, 6, 4.5, 10]] }
];
function rawField(x, y, z, kind) {
  const authoredX = x, authoredZ = z;
  x += 0.55 * Math.sin(y * 0.16 + z * 0.18);
  z += 0.48 * Math.cos(authoredX * 0.19 - y * 0.11);
  let d = 1e6;
  for (const v of forms[kind].volumes) {
    const q = (Math.hypot((x - v[0]) / v[3], (y - v[1]) / v[4], (z - v[2]) / v[5]) - 1) * Math.min(v[3], v[4], v[5]), k = 1.25, h = Math.max(0, Math.min(1, 0.5 + 0.5 * (q - d) / k));
    d = q * (1 - h) + d * h - k * h * (1 - h);
  }
  d += 0.38 * Math.sin(x * 0.73 + Math.sin(y * 0.24)) * Math.cos(z * 0.61 - y * 0.16) + 0.14 * Math.sin(y * 2.1 + x * 0.43) * Math.cos(z * 1.3 - x * 0.2);
  for (let j = 0; j < 7; j++) {
    const a = j * Math.PI * 2 / 7 + kind * 0.37, limit = 12.8 + j % 3 * 1.2 + 1.1 * Math.sin(y * 0.19 + j * 1.7) + 0.22 * Math.sin(y * 1.1 + j);
    d = Math.max(d, (x * Math.cos(a) + z * Math.sin(a) - limit) * 0.82);
  }
  d = Math.max(d, y - 40 - 0.32 * Math.sin(x * 0.4) * Math.cos(z * 0.3));
  for (const c of forms[kind].caves) {
    const cut = (1 - Math.hypot((x - c[0] + 0.45 * Math.sin(z * 0.22)) / c[3], (y - c[1] + 0.32 * Math.sin(x * 0.31)) / c[4], (z - c[2]) / c[5])) * Math.min(c[3], c[4], c[5]);
    d = Math.max(d, cut);
  }
  return d;
}
var MOSA_REEF_AUTHORED_INSTANCES = MOSA_REEF_TERRACES.map((c, i) => {
  let base = mosaNaturalBedY(c.x, c.z);
  for (let j = 0; j < 12; j++) base = Math.min(base, mosaNaturalBedY(c.x + Math.cos(j * Math.PI / 6) * c.radius * 1.9, c.z + Math.sin(j * Math.PI / 6) * c.radius * 1.9));
  base -= 2;
  const depth = [7, 28, 53, 17, 8, 43, 66, 26, 9, 54, 34, 23][i], radius = c.radius * [1.42, 1.18, 1.54, 1.3, 1.43, 1.28, 1.46, 1.39, 1.37, 1.44, 1.47, 1.32][i], top2 = MOSA_SEA.surfaceY - depth;
  return { ...c, depth, radius, kind: i % 3, base, top: top2, scaleXZ: radius / 10, scaleY: (top2 - base) / 40, yaw: Math.atan2(-c.x, -c.z) };
});
var MOSA_REEF_INSTANCES = MOSA_REEF_AUTHORED_INSTANCES.map((c, i) => {
  const f = MALL_REEF_OFFSETS[i];
  return f ? { ...c, x: c.x + f.dx, z: c.z + f.dz } : c;
});
function reefSolidDistance(c, x, y, z) {
  const dx = x - c.x, dz = z - c.z, cs = Math.cos(c.yaw), sn = Math.sin(c.yaw);
  return rawField((dx * cs - dz * sn) / c.scaleXZ, (y - c.base) / c.scaleY, (dx * sn + dz * cs) / c.scaleXZ, c.kind) * Math.min(c.scaleXZ, c.scaleY);
}
function mosaReefDistance(x, y, z) {
  let d = Infinity;
  for (const c of MOSA_REEF_INSTANCES) {
    const bx = Math.max(0, Math.abs(x - c.x) - c.radius * 2.2), bz = Math.max(0, Math.abs(z - c.z) - c.radius * 2.2), by = Math.max(0, c.base - c.scaleY * 6 - y, y - c.top - c.scaleY * 7), bound = Math.hypot(bx, by, bz);
    d = Math.min(d, bound > 4 ? bound : reefSolidDistance(c, x, y, z));
  }
  return d;
}
function mosaReefClearance(x, y, z) {
  const d = mosaReefDistance(x, y, z);
  if (d >= 4) return d;
  const e = 0.05, gx = (mosaReefDistance(x + e, y, z) - mosaReefDistance(x - e, y, z)) / (2 * e), gy = (mosaReefDistance(x, y + e, z) - mosaReefDistance(x, y - e, z)) / (2 * e), gz = (mosaReefDistance(x, y, z + e) - mosaReefDistance(x, y, z - e)) / (2 * e);
  return d / Math.max(0.15, Math.hypot(gx, gy, gz)) * 0.8;
}
function mosaReefSurfaceY(x, z) {
  let highest = mosaBedY(x, z);
  for (const c of MOSA_REEF_INSTANCES) {
    if (Math.hypot(x - c.x, z - c.z) > c.radius * 2.2) continue;
    let y = c.top + c.scaleY * 7;
    for (let i = 0; i < 180 && y > highest; i++) {
      const d = reefSolidDistance(c, x, y, z);
      if (d < 0.02) {
        highest = y;
        break;
      }
      y -= Math.min(3, Math.max(0.015, d * 0.45));
    }
  }
  return highest;
}
var MOSA_OPTICAL_GRID_EXTENT = 116 * MOSA_HORIZONTAL_EXPANSION;

// public/mosasaur-floor-stones-data.js
var MOSA_FLOOR_STONES = Object.freeze(SEABED_REEF_GARDENS.flatMap((garden, gardenIndex) => Array.from({ length: 18 }, (_, i) => {
  const side = i % 2 ? 1 : -1, row2 = Math.floor(i / 2), x = garden.x + garden.rx / 10 * side * (row2 < 3 ? 8 : 4.8 + row2 % 3 * 1 + (row2 >= 6 ? 0.8 : 0)), z = garden.z + garden.rz / 8 * (row2 < 3 ? (row2 - 1) * 3 : (row2 % 3 - 1) * 5.6 + (row2 >= 6 ? 0.8 : 0)), r = row2 < 3 ? 0.75 + i % 3 * 0.2 : 0.18 + i % 4 * 0.07, e = 0.05;
  const dx = (mosaBedY(x + e, z) - mosaBedY(x - e, z)) / (2 * e), dz = (mosaBedY(x, z + e) - mosaBedY(x, z - e)) / (2 * e), length = Math.hypot(dx, 1, dz), nx = -dx / length, ny = 1 / length, nz = -dz / length;
  return Object.freeze({ id: gardenIndex ? "seabed-stone-g" + gardenIndex + "-" + i : "seabed-stone-" + i, x: Math.fround(x + nx * r * 0.15), y: Math.fround(mosaBedY(x, z) + ny * r * 0.15), z: Math.fround(z + nz * r * 0.15), nx, ny, nz, r, kind: i % 4, yaw: i * 2.399963 });
}).filter((p) => !gardenIndex || p.ny > 0.5 && mosaWaterRadius(p.x, p.z) < 0.95 && mosaReefClearance(p.x, p.y + p.r * 0.4, p.z) > p.r * 1.25 + 1.2)));

// public/mosasaur-collision.js
var MOSA_CAVES = MOSA_CAVE_LAYOUT.map((c) => ({ ...c, y: mosaNaturalBedY(c.x, c.z) + 0.7 }));
var MOSA_RUINS = [{ id: "sunken-temple", x: -39, z: -56, y: mosaBedY(-39, -56) + 0.3 }, { id: "abyss-gate", x: 12, z: -49, y: mosaBedY(12, -49) + 0.3 }];
var MOSA_REEF_ARCHES = MOSA_REEF_TERRACES.filter((_, i) => i % 4 === 0).map((c, i) => ({ id: "living-reef-arch-" + i, x: c.x, z: c.z, radius: 8.5, depth: 3.5, y: mosaBedY(c.x, c.z) + 0.25 }));
var MOSA_GUARDIAN = (() => {
  const c = MOSA_REEF_TERRACES[3];
  return { id: "sunken-guardian", x: c.x + 2, z: c.z - 2, y: mosaReefSurfaceY(c.x + 2, c.z - 2), radius: 3.5, height: 9 };
})();

// public/submarine-physics.js
var SUBMARINE_DOCK = Object.freeze({ x: -6, y: -0.85, z: 92, yaw: Math.PI });
var SUBMARINE_BOARDING_POINT = Object.freeze({ x: 0, y: 0.16, z: 96 });

// public/scenery-data.js
var SCENERY_TYPES = Object.fromEntries([
  ...[
    ["enchanted", "\u041B\u0443\u043D\u043D\u043E\u0435 \u0434\u0435\u0440\u0435\u0432\u043E", "\u{1F333}"],
    ["willow", "\u0421\u043A\u0430\u0437\u043E\u0447\u043D\u0430\u044F \u0438\u0432\u0430", "\u{1F33F}"],
    ["maple", "\u041C\u0435\u0434\u043E\u0432\u044B\u0439 \u043A\u043B\u0451\u043D", "\u{1F341}"],
    ["apple", "\u042F\u0431\u043B\u043E\u043D\u044F \u0441 \u0444\u043E\u043D\u0430\u0440\u0438\u043A\u0430\u043C\u0438", "\u{1F34E}"],
    ["snow", "\u0421\u043D\u0435\u0436\u043D\u0430\u044F \u0435\u043B\u044C", "\u{1F332}"],
    ["crystal", "\u041A\u0440\u0438\u0441\u0442\u0430\u043B\u044C\u043D\u043E\u0435 \u0434\u0435\u0440\u0435\u0432\u043E", "\u{1F48E}"],
    ["palm", "\u041B\u0430\u0433\u0443\u043D\u043D\u0430\u044F \u043F\u0430\u043B\u044C\u043C\u0430", "\u{1F334}"],
    ["sakura", "\u0426\u0432\u0435\u0442\u0443\u0449\u0430\u044F \u0441\u0430\u043A\u0443\u0440\u0430", "\u{1F338}"],
    ["mushroom", "\u0413\u0440\u0438\u0431\u043D\u043E\u0435 \u0434\u0435\u0440\u0435\u0432\u043E", "\u{1F344}"],
    ["bamboo", "\u0411\u0430\u043C\u0431\u0443\u043A\u043E\u0432\u0430\u044F \u0440\u043E\u0449\u0438\u0446\u0430", "\u{1F38B}"]
  ].map(([kind, name, icon]) => [
    "scenery-tree-" + kind,
    { kind, name, icon, category: "tree", footprint: [2.7, 2.7] }
  ]),
  [
    "scenery-cottage",
    {
      name: "\u0414\u043E\u043C\u0438\u043A \u0432\u043E\u043B\u0448\u0435\u0431\u043D\u0438\u043A\u0430",
      icon: "\u{1F3E1}",
      category: "house",
      footprint: [3.4, 3.8]
    }
  ],
  [
    "scenery-mushroom",
    {
      name: "\u0413\u0440\u0438\u0431\u043D\u043E\u0439 \u0434\u043E\u043C\u0438\u043A",
      icon: "\u{1F344}",
      category: "house",
      footprint: [3.1, 3.1]
    }
  ],
  [
    "scenery-tea",
    {
      name: "\u0427\u0430\u0439\u043D\u0430\u044F \u0431\u0435\u0441\u0435\u0434\u043A\u0430",
      icon: "\u{1F375}",
      category: "house",
      footprint: [3.3, 3.3]
    }
  ],
  [
    "scenery-boulder",
    {
      name: "\u041C\u0448\u0438\u0441\u0442\u044B\u0439 \u0432\u0430\u043B\u0443\u043D",
      icon: "\u{1FAA8}",
      category: "rock",
      footprint: [1.8, 1.6]
    }
  ],
  [
    "scenery-landmark",
    {
      name: "\u0427\u0443\u0434\u043E \u043E\u0441\u0442\u0440\u043E\u0432\u0430",
      icon: "\u2728",
      category: "landmark",
      footprint: [4.8, 4.8]
    }
  ]
]);
var byScenery = (type) => SCENERY_TYPES[type];
function sceneryFootprint(record, rotation = record.rotation || 0) {
  const spec = byScenery(record.type), footprint2 = record.originBiome === "summer" && spec.category === "tree" ? [1.9, 1.9] : spec.footprint, size = footprint2.map((v) => v * (record.scale || 1));
  return rotation % 2 ? size.reverse() : size;
}
function sceneryBounds(record) {
  const [w, d] = sceneryFootprint(record);
  return { ...record, w, d };
}
var layouts2 = {
  "atoll-park": [[-340, 90, "palm", 1.1], [335, -70, "palm", 0.95]],
  aquapark: [
    [-14, 0, "palm", 1.15],
    [-7, 14, "palm", 1.23],
    [5, 15, "palm", 1.31],
    [15, 1, "palm", 1.39],
    [1, -16, "palm", 1.47]
  ],
  moon: [
    [-1, -8, "enchanted", 1],
    [6, -3, "willow", 1.08],
    [-5, 6, "enchanted", 0.82]
  ],
  autumn: [
    [-4, 5, "maple", 1.12],
    [5, -5, "maple", 0.91],
    [7, 3, "apple", 0.76]
  ],
  winter: [
    [-4, 5, "snow", 1.13],
    [5, -4, "crystal", 0.92],
    [7, 4, "snow", 0.72]
  ],
  beach: [
    [-8, 3, "palm", 1.1],
    [6, 5, "palm", 1.04]
  ],
  water: [
    [6, -4, "willow", 1.15],
    [5, 6, "palm", 0.9]
  ],
  wizard: [
    [-3, 6, "mushroom", 1.12],
    [6, -4, "enchanted", 1.03],
    [7, 3, "mushroom", 0.74]
  ],
  summer: [
    [-5, 4, "apple", 1.1],
    [5, -5, "apple", 0.84],
    [7, 2, "willow", 0.9]
  ],
  nature: [
    [-5, 4, "willow", 1.12],
    [5, -5, "apple", 0.94],
    [7, 2, "enchanted", 0.76]
  ],
  sakura: [
    [6, -5, "sakura", 1.12],
    [1, 7, "sakura", 0.95],
    [-7, 3, "willow", 0.8]
  ],
  clouds: [
    [-4, 5, "crystal", 0.96],
    [6.5, -3.5, "enchanted", 0.9]
  ],
  desert: [
    [4, -5, "palm", 1.05],
    [-3, 7, "palm", 0.8]
  ],
  stars: [
    [-5, 4, "enchanted", 1.04],
    [6, -3, "crystal", 0.81]
  ],
  volcano: [
    [-5, 4, "maple", 0.91],
    [5, -3, "mushroom", 0.84]
  ],
  crystal: [
    [-4, 5, "crystal", 1.15],
    [6, -4, "crystal", 0.87],
    [7, 3, "enchanted", 0.72]
  ],
  candy: [
    [-5, 4, "sakura", 0.97],
    [5, -4, "apple", 1.02],
    [7, 3, "mushroom", 0.77]
  ],
  rainbow: [
    [-4, 5, "sakura", 1.08],
    [5, -4, "willow", 0.99],
    [7, 3, "crystal", 0.72]
  ],
  bamboo: [
    [-5, 4, "bamboo", 1.13],
    [5, -5, "bamboo", 0.98],
    [7, 2, "willow", 0.78]
  ],
  mushrooms: [
    [-4, 5, "mushroom", 1.17],
    [6, -4, "mushroom", 0.9],
    [6, 5, "enchanted", 0.76]
  ],
  galaxy: [
    [-5, 4, "crystal", 1.03],
    [6, -3, "mushroom", 0.92]
  ],
  coral: [
    [-7.8, 2.3, "palm", 1.14],
    [5.8, 6.2, "palm", 1.07]
  ],
  lotus: [
    [6, -4, "willow", 1.16],
    [4, 7, "bamboo", 0.91]
  ],
  ice: [
    [-4, 5, "crystal", 1.16],
    [6, -4, "snow", 0.92]
  ],
  clockwork: [
    [-5, 4, "maple", 1.03],
    [5, -4, "apple", 0.91],
    [7, 3, "enchanted", 0.74]
  ],
  dusk: [
    [-4, 5, "willow", 1.12],
    [6, -4, "enchanted", 1],
    [7, 3, "mushroom", 0.74]
  ]
};
layouts2.bikini = [
  [-25, -9, "palm", 1.1],
  [15, -24, "palm", 0.95],
  [26, 7, "palm", 1.03]
];
layouts2.foodcourt = [
  [-27, -8, "palm", 1.1],
  [24, 22, "palm", 0.95],
  [-4, -28, "apple", 1.02]
];
Object.assign(layouts2, {
  winter: [
    [-11, -8, "palm", 1.22],
    [9, 9, "palm", 1.08],
    [-4, 12, "crystal", 0.9]
  ],
  autumn: [
    [-9, 4, "sakura", 1.18],
    [6, -5, "apple", 1.02],
    [6, 7, "sakura", 0.94]
  ],
  ice: [
    [-9, 4, "sakura", 1.12],
    [6, -5, "crystal", 1.05],
    [6, 7, "sakura", 0.94]
  ],
  galaxy: [
    [-9, 4, "willow", 1.2],
    [6, -5, "enchanted", 0.96],
    [6, 7, "willow", 0.92]
  ],
  volcano: [
    [-9, 4, "palm", 1.28],
    [6, -5, "palm", 1.04],
    [6, 7, "bamboo", 1.1]
  ]
});

// public/mosasaur-retained-land.js
function wasMosaShore(x, z) {
  const radius = Math.hypot(x, z), a = Math.atan2(z / 100, x / 105);
  const released = MOSA_RELEASED_SEA, ra = Math.atan2(z / released.rz, x / released.rx);
  return Math.hypot(x / 21.5, z / 20.5) >= 1 && radius < MOSA_OLD_RADIUS + 0.01 || Math.hypot(x / 105, z / 100) >= mosaCoastFactor(a) && radius < MOSA_PREVIOUS_RADIUS + 0.01 || Math.hypot(x / released.rx, z / released.rz) >= mosaCoastFactor(ra) && radius < released.radius + 0.01;
}

// public/cat-locations.js
function mergeCatLocations(current, incoming) {
  const result2 = structuredClone(current || {});
  for (const [id, p] of Object.entries(incoming || {}))
    if (p && Number.isFinite(p.at) && (!result2[id] || p.at >= result2[id].at)) result2[id] = structuredClone(p);
  return result2;
}
function reconcileMergedCatLocations(base, incoming, result2) {
  for (const [id, p] of Object.entries(result2.catLocations || {})) {
    if (id === "chichi") {
      if (p.biome !== result2.catPosition?.biome || JSON.stringify(base.catPosition) !== JSON.stringify(incoming.catPosition) && !incoming.catLocations?.chichi) delete result2.catLocations[id];
    } else if (result2.catDestinations?.[id] && p.biome !== result2.catDestinations[id]) delete result2.catLocations[id];
  }
  return result2;
}

// public/world-migration.js
var WORLD_REVISION = 5;
function relocatedPlot(p, occupied) {
  const spec = byItem(p.item), size = spec?.footprint || [2, 2], [w, d] = p.rotation % 2 ? [size[1], size[0]] : size, limit = byBiome("homestead").radius - 0.7;
  const clear = (x, z) => Math.hypot(Math.abs(x) + w / 2, Math.abs(z) + d / 2) <= limit && !occupied.some((q) => q.rx && q.rz ? (Math.max(0, Math.abs(x - q.x) - w / 2) / q.rx) ** 2 + (Math.max(0, Math.abs(z - q.z) - d / 2) / q.rz) ** 2 < 1 : Math.abs(x - q.x) < (w + q.w) / 2 + 0.2 && Math.abs(z - q.z) < (d + q.d) / 2 + 0.2);
  if (clear(p.x, p.z)) return { x: p.x, z: p.z, w, d };
  for (let r = 4; r <= limit * 2; r += 4) {
    const count = Math.ceil(Math.PI * 2 * r / 4);
    for (let i = 0; i < count; i++) {
      const angle = i * Math.PI * 2 / count, x = Math.round((p.x + Math.sin(angle) * r) * 1e6) / 1e6, z = Math.round((p.z + Math.cos(angle) * r) * 1e6) / 1e6;
      if (clear(x, z)) return { x, z, w, d };
    }
  }
  return null;
}
function migrateRetiredIsland(raw, now = Date.now()) {
  raw = migrateRetiredAttractions(raw);
  let saved = raw.worldRevision >= 2 ? raw : migrateWizard(raw);
  if (saved.worldRevision >= WORLD_REVISION && !saved.unlocked?.some(isRetiredBiome) && !saved.placements?.some((p) => isRetiredBiome(p.biome)) && !saved.scenery?.some((p) => isRetiredBiome(p.biome)) && !Object.values(saved.catLocations || {}).some((p) => isRetiredBiome(p?.biome))) return saved;
  saved = structuredClone(saved);
  const oldUnlocked = new Set(saved.unlocked || []), moving = (saved.placements || []).some((p) => isRetiredBiome(p.biome)), needsLand = moving || [...oldUnlocked].some(isRetiredBiome);
  const farms = [...oldUnlocked].filter((id) => id.startsWith("farm-") && isRetiredBiome(id));
  if (farms.length) saved.withdrawnMagicFarms = [.../* @__PURE__ */ new Set([...saved.withdrawnMagicFarms || [], ...farms])];
  saved.worldRevision = WORLD_REVISION;
  saved.unlocked = (saved.unlocked || []).filter((id) => !isRetiredBiome(id));
  if (needsLand && !saved.unlocked.includes("homestead")) saved.unlocked.push("homestead");
  const occupied = (saved.placements || []).filter((p) => p.biome === "homestead").map((p) => {
    const size = byItem(p.item)?.footprint || [2, 2], [w, d] = p.rotation % 2 ? [size[1], size[0]] : size;
    return { ...p, w, d };
  });
  occupied.push(...(saved.scenery || []).filter((p) => p?.biome === "homestead" && !p.stored && byScenery(p.type)).map(sceneryBounds));
  const stored = /* @__PURE__ */ new Set();
  for (const p of saved.placements || []) if (isRetiredBiome(p.biome)) {
    const offset = retiredDistrict(p.biome);
    p.x += offset.x;
    p.z += offset.z;
    p.biome = "homestead";
    const free = relocatedPlot(p, occupied);
    if (free) {
      p.x = free.x;
      p.z = free.z;
      occupied.push(free);
    } else {
      saved.inventory ||= {};
      saved.builtInventory ||= {};
      saved.relocatedPurchases ||= [];
      if (!saved.relocatedPurchases.some((r) => r.id === p.id)) {
        saved.inventory[p.item] = (saved.inventory[p.item] || 0) + 1;
        if (!p.readyAt || p.readyAt <= now) saved.builtInventory[p.item] = (saved.builtInventory[p.item] || 0) + 1;
        saved.relocatedPurchases.push({ ...p, businessLevel: saved.business?.levels?.[p.id] || 1, fieldCells: saved.farm?.fields?.[p.id], businessAccount: saved.business?.accounts?.[p.id] });
      }
      stored.add(p.id);
    }
  }
  if (stored.size) saved.placements = saved.placements.filter((p) => !stored.has(p.id));
  for (const r of saved.scenery || []) if (isRetiredBiome(r.biome)) {
    r.biome = "homestead";
    r.stored = true;
  }
  saved.catDestinations ||= {};
  for (const n of NEIGHBORS) if (isRetiredBiome(n.originBiome) && oldUnlocked.has(n.originBiome))
    saved.catDestinations[n.id] = "homestead";
  for (const [id, biome] of Object.entries(saved.catDestinations))
    if (isRetiredBiome(biome)) saved.catDestinations[id] = "homestead";
  for (const a of saved.adoption?.cats || []) if (isRetiredBiome(a.homeBiome)) a.homeBiome = "homestead";
  if (isRetiredBiome(saved.catPosition?.biome)) {
    const offset = retiredDistrict(saved.catPosition.biome);
    saved.catPosition = {
      ...saved.catPosition,
      biome: "homestead",
      x: saved.catPosition.x + offset.x,
      z: saved.catPosition.z + offset.z
    };
  }
  for (const p of Object.values(saved.catLocations || {})) if (isRetiredBiome(p?.biome)) {
    const offset = retiredDistrict(p.biome);
    p.biome = "homestead";
    p.x += offset.x;
    p.z += offset.z;
  }
  return saved;
}
function migrateWizard(raw) {
  const saved = structuredClone(raw);
  saved.worldRevision = 2;
  if (Array.isArray(saved.unlocked) && saved.unlocked.includes("wizard")) {
    saved.coins = Math.min(1e7, saved.coins + 3630);
    saved.retiredIslandRefund = 3630;
  }
  saved.unlocked = (Array.isArray(saved.unlocked) ? saved.unlocked : []).filter(
    (id) => id !== "wizard"
  );
  saved.inventory ||= {};
  saved.builtInventory ||= {};
  saved.relocatedPurchases ||= [];
  const removed = (Array.isArray(saved.placements) ? saved.placements : []).filter((p) => p.biome === "wizard" && byItem(p.item));
  for (const p of removed) {
    saved.inventory[p.item] = (saved.inventory[p.item] || 0) + 1;
    saved.relocatedPurchases.push({
      ...p,
      fieldCells: saved.farm?.fields?.[p.id] || null
    });
    if (saved.farm?.fields) delete saved.farm.fields[p.id];
  }
  saved.placements = (Array.isArray(saved.placements) ? saved.placements : []).filter((p) => p.biome !== "wizard");
  for (const r of Array.isArray(saved.scenery) ? saved.scenery : [])
    if (r && (r.biome === "wizard" || r.originBiome === "wizard")) {
      r.biome = "moon";
      r.originBiome = "moon";
      r.stored = true;
    }
  for (const [id, destination] of Object.entries(saved.catDestinations || {}))
    if (destination === "wizard") saved.catDestinations[id] = "moon";
  if (saved.catPosition?.biome === "wizard") saved.catPosition = null;
  return saved;
}

// public/business.js
var premiumIncomeIDs = new Set(ATOLL_SLIDES.map((s) => s.id));

// public/economy.js
var PLACEMENT_LIMIT = 80;
var HOUR = 36e5;
var HOURLY_COINS = 60;
var LOGIN_COINS = 70;
var ATTENTION_COINS = 10;
var ATTENTION_COOLDOWN = 6e5;
function footprint(item2, rotation = 0) {
  const [w, d] = (byItem(item2) || byScenery(item2))?.footprint || [2, 2];
  return rotation % 2 ? [d, w] : [w, d];
}
function canPlace(game, item2, biome, x, z, rotation = 0, ignoreId = null, { allowLocked = false, ignoreTerrain = false } = {}) {
  if (byItem(item2)?.seed) return { ok: false, reason: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043D\u0430\u0441\u0456\u043D\u043D\u044F \u0432 \u0441\u0443\u043C\u0446\u0456 \u0442\u0430 \u043F\u043E\u0441\u0430\u0434\u0456\u0442\u044C \u0439\u043E\u0433\u043E \u0443 \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A \u043C\u0430\u0433\u0456\u0447\u043D\u043E\u0457 \u0433\u0440\u044F\u0434\u043A\u0438." };
  if (biome === HOUSING_ID)
    return {
      ok: false,
      reason: "\u0411\u0443\u0434\u0438\u043D\u043A\u0438 \u043A\u043E\u0442\u0438\u043A\u0456\u0432 \u043A\u0443\u043F\u0443\u044E\u0442\u044C\u0441\u044F \u0432 \u0440\u043E\u0437\u0434\u0456\u043B\u0456 \xAB\u041D\u0435\u0440\u0443\u0445\u043E\u043C\u0456\u0441\u0442\u044C\xBB. \u0414\u0456\u043B\u044F\u043D\u043A\u0438 \u0434\u043E\u0434\u0430\u044E\u0442\u044C\u0441\u044F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u043D\u043E."
    };
  if (!(byItem(item2) || byScenery(item2)) || !byBiome(biome) || !allowLocked && !game.unlocked.includes(biome))
    return { ok: false, reason: "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u044D\u0442\u043E\u0442 \u0431\u0438\u043E\u043C." };
  if (!Number.isFinite(x) || !Number.isFinite(z) || !Number.isInteger(rotation) || rotation < 0 || rotation > 3)
    return { ok: false, reason: "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u043F\u043E\u0437\u0438\u0446\u0438\u044F." };
  const record = game.scenery?.find((p) => p.id === ignoreId);
  const [w, d] = record ? sceneryFootprint(record, rotation) : footprint(item2, rotation);
  if (Math.hypot(Math.abs(x) + w / 2, Math.abs(z) + d / 2) > (byBiome(biome).radius ? byBiome(biome).radius - 0.7 : 10.8))
    return {
      ok: false,
      reason: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0434\u043E\u043B\u0436\u0435\u043D \u0446\u0435\u043B\u0438\u043A\u043E\u043C \u043F\u043E\u043C\u0435\u0441\u0442\u0438\u0442\u044C\u0441\u044F \u043D\u0430 \u043E\u0441\u0442\u0440\u043E\u0432\u0435."
    };
  const rectangles = game.placements.filter((p) => p.biome === biome && p.id !== ignoreId).map((p) => {
    const [w2, d2] = footprint(p.item, p.rotation);
    return { ...p, w: w2, d: d2 };
  });
  const retained = biome === "autumn" && ignoreId && [...game.placements, ...game.scenery || []].some((p) => p.id === ignoreId && (p.item || p.type) === item2 && p.x === x && p.z === z && (p.rotation || 0) === rotation && wasMosaShore(x, z));
  if (!ignoreTerrain && !retained) rectangles.push(...biomeReservations(biome));
  rectangles.push(
    ...(game.scenery || []).filter((p) => !p.stored && p.biome === biome && p.id !== ignoreId).map(sceneryBounds)
  );
  if (rectangles.some(
    (p) => p.rx && p.rz ? (Math.max(0, Math.abs(x - p.x) - w / 2) / p.rx) ** 2 + (Math.max(0, Math.abs(z - p.z) - d / 2) / p.rz) ** 2 < 1 : Math.abs(x - p.x) < (w + p.w) / 2 + 0.2 && Math.abs(z - p.z) < (d + p.d) / 2 + 0.2
  ))
    return { ok: false, reason: "\u042D\u0442\u043E \u043C\u0435\u0441\u0442\u043E \u0437\u0430\u043D\u044F\u0442\u043E. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0440\u0443\u0433\u043E\u0435." };
  return { ok: true, reason: "\u041A\u0440\u0430\u0441\u0438\u0432\u043E\u0435 \u043C\u0435\u0441\u0442\u043E. \u041C\u043E\u0436\u043D\u043E \u0440\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u0442\u044C!" };
}

// crypto-ai.mjs
var response = (body, status = 200) => ({ body, status });
function validateCryptoRequest(raw) {
  if (!raw || typeof raw.catId !== "string" || !/^[-\w]{1,90}$/.test(raw.catId) || typeof raw.attemptId !== "string" || !/^[-\w]{1,160}$/.test(raw.attemptId) || !Number.isFinite(raw.epoch) || raw.epoch < 0) throw Error("Invalid trading attempt");
  return { catId: raw.catId, attemptId: raw.attemptId, epoch: raw.epoch };
}
function forecastAnswer(answer) {
  let raw = answer?.response ?? answer;
  if (typeof raw === "string") raw = JSON.parse(raw.trim().replace(/^```(?:json)?\s*/, "").replace(/\s*```$/, ""));
  return validateCryptoForecast(raw);
}
function cryptoForecastInput(profile) {
  return {
    messages: [
      { role: "system", content: "Return one forecast for a fictional cat trading simulation, NOT real markets. Prices and money are fictional. JSON only: asset BTC or ETH, direction up or down, strength 0.01 to 0.12, confidence 0 to 1, reason a short Ukrainian explanation. The cat independently chooses LONG, SHORT or skipping; your forecast never guarantees profit. No prices, orders, exchange links or real financial advice." },
      { role: "user", content: JSON.stringify({ personality: profile.personality, skill: profile.skills?.crypto || 1 }) }
    ],
    max_tokens: 200,
    temperature: 0.5,
    response_format: { type: "json_schema", json_schema: { name: "cat_crypto_forecast", strict: true, schema: { type: "object", additionalProperties: false, required: ["asset", "direction", "strength", "confidence", "reason"], properties: { asset: { type: "string", enum: ["BTC", "ETH"] }, direction: { type: "string", enum: ["up", "down"] }, strength: { type: "number", minimum: 0.01, maximum: 0.12 }, confidence: { type: "number", minimum: 0, maximum: 1 }, reason: { type: "string", maxLength: 180 } } } } }
  };
}
var CryptoAIRequestLedger = class {
  constructor(storage, run, { clock = Date.now, timeout = 1e5 } = {}) {
    this.storage = storage;
    this.run = run;
    this.clock = clock;
    this.timeout = timeout;
    this.inflight = /* @__PURE__ */ new Map();
  }
  async forecast(input) {
    const key = input.catId + ":" + input.attemptId;
    if (this.inflight.has(key)) return this.inflight.get(key);
    const pending = this.execute(input);
    this.inflight.set(key, pending);
    try {
      return await pending;
    } finally {
      this.inflight.delete(key);
    }
  }
  async execute(input) {
    const slot = "crypto-ai:" + input.catId, local = () => response({ attemptId: input.attemptId, forecast: localCryptoForecast(input.attemptId), source: "local" });
    const reservation = await this.storage.transaction(async (t) => {
      const old = await t.get(slot);
      if (old?.attemptId === input.attemptId) {
        if (old.result) return { cached: old.result };
        const cached = local();
        await t.put(slot, { ...old, result: cached });
        return { cached };
      }
      const saved = await t.get("current"), state = saved?.game?.jobCity, p = state?.profiles[input.catId], attempt = p?.investments?.current, clock = cryptoClock(state, this.clock());
      if (!state || state.epoch !== input.epoch || p?.profession !== "crypto" || attempt?.id !== input.attemptId || attempt.status !== "waiting" || !Number.isSafeInteger(attempt.day) || attempt.day > clock.day || p.coins < CRYPTO_RULES.minCoins || p.investments.lastAttemptDay !== attempt.day || p.investments.nextAttemptDay !== attempt.day + CRYPTO_RULES.intervalDays)
        return { cached: response({ error: "Trading attempt not reserved in the saved world" }, 409) };
      if (old?.epoch === input.epoch && attempt.day < old.day + CRYPTO_RULES.intervalDays) return { cached: response({ error: "Trading cycle already used" }, 409) };
      await t.put(slot, { epoch: input.epoch, attemptId: input.attemptId, day: attempt.day, reservedAt: this.clock(), result: null });
      return { profile: p };
    });
    if (reservation.cached) return reservation.cached;
    let result2, timer;
    try {
      const answer = await Promise.race([this.run(cryptoForecastInput(reservation.profile), forecastAnswer), new Promise((_, reject) => {
        timer = setTimeout(() => reject(Error("Forecast timeout")), this.timeout);
      })]);
      result2 = response({ attemptId: input.attemptId, forecast: forecastAnswer(answer), source: "ai" });
    } catch {
      result2 = local();
    } finally {
      clearTimeout(timer);
    }
    return this.storage.transaction(async (t) => {
      const record = await t.get(slot);
      if (record?.attemptId !== input.attemptId) return local();
      if (record.result) return record.result;
      await t.put(slot, { ...record, result: result2 });
      return result2;
    });
  }
};

// chunked-save-store.mjs
var CHUNK_BYTES = 6e4;
var INLINE_BYTES = 512 * 1024;
function adapter(raw) {
  return {
    async get(key) {
      const value = await raw.get(key);
      if (value?.__chichiSnapshotChunks !== 1) return value;
      const bytes = new Uint8Array(value.bytes);
      let offset = 0;
      for (const part of value.keys) {
        const chunk = await raw.get(part);
        if (!(chunk instanceof Uint8Array) || offset + chunk.length > bytes.length)
          throw Error("Incomplete save snapshot");
        bytes.set(chunk, offset);
        offset += chunk.length;
      }
      if (offset !== bytes.length) throw Error("Incomplete save snapshot");
      return JSON.parse(new TextDecoder().decode(bytes));
    },
    async put(key, value) {
      const old = await raw.get(key), bytes = new TextEncoder().encode(JSON.stringify(value));
      if (bytes.length <= INLINE_BYTES) await raw.put(key, value);
      else {
        const prefix = key + ":snapshot:" + crypto.randomUUID(), keys = [];
        for (let i = 0; i < bytes.length; i += CHUNK_BYTES) {
          const part = prefix + ":" + keys.length;
          await raw.put(part, bytes.slice(i, i + CHUNK_BYTES));
          keys.push(part);
        }
        await raw.put(key, {
          __chichiSnapshotChunks: 1,
          bytes: bytes.length,
          keys
        });
      }
      if (old?.__chichiSnapshotChunks === 1 && raw.delete)
        await raw.delete(old.keys);
    }
  };
}
function chunkedSaveStorage(storage) {
  return {
    ...adapter(storage),
    transaction: (fn) => storage.transaction((raw) => fn(adapter(raw)))
  };
}

// shared-world.mjs
var SharedConflict = class extends Error {
  constructor(message = "\u042D\u0442\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0443\u0436\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u043E \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u043C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435. \u041C\u0438\u0440 \u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D; \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435.") {
    super(message);
    this.code = "SHARED_CONFLICT";
  }
};
var equal2 = (a, b) => JSON.stringify(a) === JSON.stringify(b);
var changed = (a, b) => !equal2(a, b);
var clone4 = (value) => value === void 0 ? void 0 : structuredClone(value);
var levelCoins = (before, after) => {
  let total = 0;
  for (let level = levelForXP(before) + 1; level <= levelForXP(after); level++)
    total += 30 + level * 15;
  return total;
};
var additive = (path) => /^(coins|diamonds|totalEarned|inventory\.[\w-]+|builtInventory\.[\w-]+|referenceOwnership\.[\w-]+\.count|farm\.stock\.[\w-]+|farm\.harvests|business\.(?:totalCollected|totalDiamonds)|care\.mealId)$/.test(
  path
);
var transient = (path) => /^(cat\.|catPosition(?:\.|$)|catDestinations\.|care\.(?:lastTick$|resting(?:\.|$)|residents\.[\w-]+\.(?:hunger|happiness|lastMealAt|lastSwimAt)$)|friendship\.)/.test(
  path
);
var guarded = (path) => /^(lastVisit|lastHourly|lastAttention|farm\.fields\.[\w-]+\.\d+|farm\.orchards\.[\w-]+\.plants\.[\w-]+|business\.(?:accounts|levels)\.[\w-]+|social\.relationships\.[\w-]+)$/.test(
  path
);
function merge(base, current, incoming, path = "", depth = 0) {
  if (path === "retiredAttractions") return clone4(current || incoming || base);
  if (path === "zoo") {
    try {
      return mergeZoo(base, current, incoming);
    } catch (e) {
      throw new SharedConflict(e.message);
    }
  }
  if (/^referenceOwnership\.[\w-]+\.built$/.test(path)) return Math.max(current || 0, incoming || 0);
  if (path === "withdrawnMagicFarms") return [.../* @__PURE__ */ new Set([...current || [], ...incoming || []])];
  if (path === "farm.orchards" && incoming === void 0) return clone4(current);
  if (path === "catLocations") return mergeCatLocations(current, incoming);
  if (depth > 40) throw new SharedConflict("\u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0441\u043B\u043E\u0436\u043D\u043E\u0435.");
  if (path === "family") {
    try {
      return mergeFamily(base, current, incoming);
    } catch (error) {
      throw new SharedConflict(error.message);
    }
  }
  if (path === "housing") {
    try {
      return mergeHousing(base, current, incoming);
    } catch (e) {
      throw new SharedConflict(e.message);
    }
  }
  if (path === "jobCity") {
    if (!incoming) return clone4(current);
    if (!current) return clone4(incoming);
    if (!base) {
      const result3 = clone4(current);
      for (const [id, p] of Object.entries(incoming.profiles || {}))
        if (!result3.profiles[id]) result3.profiles[id] = clone4(p);
      return result3;
    }
    const result2 = clone4(current);
    for (const [id, p] of Object.entries(incoming.profiles || {})) {
      const old = base.profiles?.[id], actual = current.profiles?.[id];
      if (equal2(old, p) || equal2(actual, p)) continue;
      if (!old || !actual) {
        result2.profiles[id] = clone4(p);
        continue;
      }
      const groups = [
        [
          "coins",
          "investments",
          "earnedTotal",
          "spentTotal",
          "purchaseCount",
          "mall",
          "inventory",
          "transactions",
          "lastPaidDay",
          "shifts"
        ],
        [
          "profession",
          "professionChanges",
          "professionSinceDay",
          "professionReason",
          "professionSource",
          "career"
        ],
        ["trip", "parkedAt", "parkedCar"],
        ["vacation"]
      ];
      for (const keys of groups) {
        const incomingChanged = keys.some((k) => (k !== "investments" || !!p.investments) && (k !== "vacation" || !!p.vacation) && changed(old[k], p[k])), currentChanged = keys.some((k) => changed(old[k], actual[k]));
        if (incomingChanged && currentChanged && !keys.every((k) => equal2(p[k], actual[k])))
          throw new SharedConflict(
            "\u0413\u0430\u043C\u0430\u043D\u0435\u0446\u044C \u0430\u0431\u043E \u043F\u0440\u043E\u0444\u0435\u0441\u0456\u044E \u0446\u044C\u043E\u0433\u043E \u043A\u043E\u0442\u0438\u043A\u0430 \u0432\u0436\u0435 \u0437\u043C\u0456\u043D\u0438\u043B\u0438 \u043D\u0430 \u0456\u043D\u0448\u043E\u043C\u0443 \u043F\u0440\u0438\u0441\u0442\u0440\u043E\u0457. \u041F\u043E\u0432\u0442\u043E\u0440\u0456\u0442\u044C \u0434\u0456\u044E \u043F\u0456\u0441\u043B\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0456\u0437\u0430\u0446\u0456\u0457."
          );
      }
      const profile = clone4(actual);
      for (const key of Object.keys(p))
        if (changed(old[key], p[key])) {
          if (key === "investments" && !p[key] && actual[key]) continue;
          if (key === "vacation" && !p[key] && actual[key]) continue;
          if (key === "lastHousingAIDay")
            profile[key] = Math.max(actual[key] ?? -1, p[key] ?? -1);
          else if (key === "careerAIRequestedDay")
            profile[key] = Math.max(actual[key] ?? -1, p[key] ?? -1);
          else if (key === "careerAIPending")
            profile[key] = actual[key] === false ? false : p[key];
          else if (key === "manualUntil")
            profile[key] = Math.max(actual[key] || 0, p[key] || 0);
          else if (key === "leisureProgress") {
            const other = actual[key];
            profile[key] = !other || p[key]?.day > other.day ? clone4(p[key]) : p[key]?.day === other.day ? { day: other.day, done: Math.max(other.done, p[key].done) } : clone4(other);
          } else if (key === "attendance") {
            if (p[key] && profile.lastPaidDay >= p[key].day) continue;
            if (actual[key] && p[key] && changed(old[key], actual[key]) && actual[key].at > p[key].at)
              continue;
            profile[key] = clone4(p[key]);
          } else profile[key] = clone4(p[key]);
        }
      if (profile.attendance && profile.lastPaidDay >= profile.attendance.day)
        profile.attendance = null;
      result2.profiles[id] = profile;
    }
    if (!equal2(base.plan, incoming.plan)) {
      if (!current.plan || incoming.plan?.day > current.plan.day || equal2(base.plan, current.plan))
        result2.plan = clone4(incoming.plan);
      else if (!equal2(current.plan, incoming.plan))
        throw new SharedConflict(
          "\u041F\u043B\u0430\u043D \u043A\u043E\u0442\u0438\u043A\u0456\u0432 \u0443\u0436\u0435 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0438\u0439 \u043D\u0430 \u0456\u043D\u0448\u043E\u043C\u0443 \u043F\u0440\u0438\u0441\u0442\u0440\u043E\u0457."
        );
    }
    result2.requestedDay = Math.max(
      current.requestedDay ?? -1,
      incoming.requestedDay ?? -1
    );
    result2.eveningAIRequestedDay = Math.max(
      current.eveningAIRequestedDay ?? -1,
      incoming.eveningAIRequestedDay ?? -1
    );
    result2.eveningAIAppliedDay = Math.max(current.eveningAIAppliedDay ?? -1, incoming.eveningAIAppliedDay ?? -1);
    return result2;
  }
  if (path === "builderBoosts") {
    const added = normalizeBuilderBoosts(incoming).filter(
      (e) => !(base || []).some((b) => b.id === e.id)
    );
    const others = normalizeBuilderBoosts(current).filter(
      (e) => !(base || []).some((b) => b.id === e.id)
    );
    if (added.some(
      (e) => others.some(
        (o) => e.id !== o.id && e.startedAt < o.until && o.startedAt < e.until
      )
    ))
      throw new SharedConflict(
        "\u0423\u0441\u043A\u043E\u0440\u0435\u043D\u0438\u0435 \u0443\u0436\u0435 \u0432\u043A\u043B\u044E\u0447\u0438\u043B\u0438 \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u043C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435. \u0410\u043B\u043C\u0430\u0437\u044B \u043D\u0435 \u0441\u043F\u0438\u0441\u0430\u043D\u044B \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E."
      );
    return normalizeBuilderBoosts([...current || [], ...added]);
  }
  if (path === "islandConstruction") {
    for (const id of Object.keys(incoming || {}))
      if (id.startsWith("court-") && !base?.[id] && current?.[id] && incoming[id])
        throw new SharedConflict(
          "\u042D\u0442\u043E \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u0435 \u0443\u0436\u0435 \u0441\u0442\u0440\u043E\u0438\u0442\u0441\u044F. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u043F\u043B\u0430\u0442\u0430 \u043E\u0442\u043C\u0435\u043D\u0435\u043D\u0430."
        );
    return mergeIslandConstruction(base, current, incoming);
  }
  if (path === "spa.receipts")
    return [.../* @__PURE__ */ new Set([...current || [], ...incoming || []])].slice(-96);
  if (/^spa\.visits\.[\w-]+$/.test(path))
    return Math.max(current || 0, incoming || 0);
  if (path === "spa.selectedDrink") return clone4(incoming);
  if (equal2(base, incoming)) return clone4(current);
  if (guarded(path) && changed(base, current)) throw new SharedConflict();
  if (additive(path)) {
    const value = (current ?? 0) + (incoming ?? 0) - (base ?? 0);
    if (!Number.isSafeInteger(value) || value < 0 && path !== "coins" || path === "coins" && value > 1e7)
      throw new SharedConflict(
        "\u0411\u0430\u043B\u0430\u043D\u0441 \u0443\u0436\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u043C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435. \u041C\u0438\u0440 \u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043C\u043E\u043D\u0435\u0442\u044B \u0438\u043B\u0438 \u0441\u043A\u043B\u0430\u0434."
      );
    return value;
  }
  if (equal2(base, current)) return clone4(incoming);
  if (transient(path) || /^(placements|scenery)\.[\w-]+\.(x|z|rotation)$/.test(path))
    return clone4(incoming);
  if (Array.isArray(incoming) && Array.isArray(current) && Array.isArray(base)) {
    if (["unlocked", "progression.discoveries"].includes(path)) {
      const added = incoming.filter((x) => !base.includes(x));
      if (path === "unlocked" && added.some((x) => x !== "cat-homes" && x !== ATOLL_PARK_ID && current.includes(x)))
        throw new SharedConflict(
          "\u042D\u0442\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u0443\u0436\u0435 \u0441\u0434\u0435\u043B\u0430\u043D\u043E \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u043C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435."
        );
      return [
        .../* @__PURE__ */ new Set([
          ...current.filter((x) => !base.includes(x) || incoming.includes(x)),
          ...added
        ])
      ];
    }
    if (["placements", "scenery", "adoption.cats"].includes(path)) {
      const result2 = new Map(current.map((x) => [x.id, clone4(x)]));
      for (const old of base)
        if (!incoming.some((x) => x.id === old.id)) {
          if (changed(old, result2.get(old.id))) throw new SharedConflict();
          result2.delete(old.id);
        }
      for (const entry of incoming) {
        const old = base.find((x) => x.id === entry.id);
        if (equal2(old, entry)) continue;
        if (!old && result2.has(entry.id))
          throw new SharedConflict("\u042D\u0442\u043E\u0442 \u043A\u043E\u0442\u0438\u043A \u0438\u043B\u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442 \u0443\u0436\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D.");
        result2.set(
          entry.id,
          merge(
            old,
            result2.get(entry.id),
            entry,
            path + "." + entry.id,
            depth + 1
          )
        );
      }
      return [...result2.values()];
    }
    if (path === "care.bowl") {
      const b = Object.fromEntries(base.map((x) => [x.crop, x.portions])), c = Object.fromEntries(current.map((x) => [x.crop, x.portions])), n = Object.fromEntries(incoming.map((x) => [x.crop, x.portions]));
      return [.../* @__PURE__ */ new Set([...Object.keys(c), ...Object.keys(n)])].map((crop) => {
        const portions = (c[crop] || 0) + (n[crop] || 0) - (b[crop] || 0);
        if (portions < 0)
          throw new SharedConflict("\u042D\u0442\u0443 \u043F\u043E\u0440\u0446\u0438\u044E \u0443\u0436\u0435 \u0441\u044A\u0435\u043B\u0438. \u041C\u0438\u0441\u043A\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430.");
        return { crop, portions };
      }).filter((x) => x.portions > 0);
    }
    if ([
      "recentActivities",
      "care.recentMeals",
      "social.events",
      "farm.sales"
    ].includes(path)) {
      const added = incoming.filter((x) => !base.some((y) => equal2(x, y)));
      return [
        ...current,
        ...added.filter((x) => !current.some((y) => equal2(x, y)))
      ].slice(
        -{
          recentActivities: 12,
          "care.recentMeals": 12,
          "social.events": 24,
          "farm.sales": 8
        }[path]
      );
    }
    if (path.startsWith("farm.fields."))
      return incoming.map(
        (x, i) => merge(base[i], current[i], x, path + "." + i, depth + 1)
      );
    if (equal2(current, incoming)) return clone4(current);
    throw new SharedConflict();
  }
  if (incoming && current && typeof incoming === "object" && typeof current === "object" && !Array.isArray(incoming) && !Array.isArray(current)) {
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const key of /* @__PURE__ */ new Set([
      ...Object.keys(base || {}),
      ...Object.keys(current),
      ...Object.keys(incoming)
    ])) {
      if (["__proto__", "constructor", "prototype"].includes(key))
        throw new SharedConflict();
      const value = merge(
        base?.[key],
        current[key],
        incoming[key],
        path ? path + "." + key : key,
        depth + 1
      );
      if (value !== void 0) result2[key] = value;
    }
    return result2;
  }
  if (path === "nextId") return Math.max(current, incoming);
  if (equal2(current, incoming)) return clone4(current);
  throw new SharedConflict();
}
function mergeSharedWorld(base, current, incoming) {
  if (base?.jobCity && incoming?.jobCity) {
    incoming = clone4(incoming);
    for (const [id, p] of Object.entries(incoming.jobCity.profiles || {})) {
      const old = base.jobCity.profiles[id];
      if (!old) continue;
      try {
        const vacation2 = reconcileCatVacation(old.vacation, current?.jobCity?.profiles[id]?.vacation, p.vacation);
        if (vacation2) p.vacation = vacation2;
      } catch (error) {
        throw new SharedConflict(error.message);
      }
      const vacation = current?.jobCity?.profiles[id]?.vacation || old.vacation;
      if (vacation) {
        const prior = new Set((old.transactions || []).map((t) => t.id));
        if ((p.transactions || []).some((t) => t.kind === "wage" && !prior.has(t.id) && t.day >= vacation.startDay && t.day < vacation.endDay)) throw new SharedConflict("\u041A\u043E\u0442\u0438\u043A \u0443 \u0432\u0456\u0434\u043F\u0443\u0441\u0442\u0446\u0456; \u043E\u043D\u043E\u0432\u0456\u0442\u044C \u0433\u0440\u0443 \u043F\u0435\u0440\u0435\u0434 \u043D\u0430\u0440\u0430\u0445\u0443\u0432\u0430\u043D\u043D\u044F\u043C \u0437\u043C\u0456\u043D\u0438.");
        if (p.schedule?.day >= vacation.startDay && p.schedule.day < vacation.endDay && p.profession !== vacation.previousJob) throw new SharedConflict("\u041F\u0440\u043E\u0444\u0435\u0441\u0456\u044F \u043A\u043E\u0442\u0438\u043A\u0430 \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u0454\u0442\u044C\u0441\u044F \u0434\u043E \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043D\u044F \u0432\u0456\u0434\u043F\u0443\u0441\u0442\u043A\u0438.");
      }
      if (!Object.hasOwn(p, "mall")) p.mall = clone4(old.mall);
      for (const item2 of MALL_PRODUCTS) if (!Object.hasOwn(p.inventory || {}, item2.id) && old.inventory?.[item2.id]) {
        if (!p.mall?.used?.[item2.id] || p.mall.used[item2.id] === old.mall?.used?.[item2.id]) {
          p.inventory ||= {};
          p.inventory[item2.id] = old.inventory[item2.id];
        }
      }
    }
  }
  if (base?.mosasaurSubmarine && incoming && !Object.hasOwn(incoming, "mosasaurSubmarine")) incoming = { ...incoming, mosasaurSubmarine: base.mosasaurSubmarine };
  if (base?.mosasaurSubmarine && (base.mosasaurSubmarine.explorerVersion === 1 || current?.mosasaurSubmarine?.explorerVersion === 1) && incoming?.mosasaurSubmarine?.explorerVersion !== 1) {
    const old = base.mosasaurSubmarine, legacy = incoming.mosasaurSubmarine;
    if (["x", "y", "z", "yaw", "pitch", "active", "mode"].some((k) => !equal2(old[k], legacy?.[k]))) throw new SharedConflict("\u041E\u043D\u043E\u0432\u0456\u0442\u044C \u0433\u0440\u0443 \u043F\u0435\u0440\u0435\u0434 \u043A\u0435\u0440\u0443\u0432\u0430\u043D\u043D\u044F\u043C \u0427\u0456\u0447\u0456 \u0430\u0431\u043E \u0441\u0443\u0431\u043C\u0430\u0440\u0438\u043D\u043E\u044E.");
    incoming = { ...incoming, mosasaurSubmarine: clone4(old) };
  }
  for (const game of [base, current, incoming]) for (const p of Object.values(game?.jobCity?.profiles || {})) if (p.vacation) try {
    normalizeCatVacation(p.vacation);
  } catch (error) {
    throw new SharedConflict(error.message);
  }
  for (const game of [base, current, incoming]) if (!retirementSnapshotValid(game?.retiredAttractions)) throw new SharedConflict("\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0438\u0439 \u0437\u0430\u043F\u0438\u0441 \u043F\u043E\u0432\u0435\u0440\u043D\u0435\u043D\u043D\u044F \u043F\u043E\u043A\u0443\u043F\u043A\u0438. \u0417\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0442\u0435 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0438\u0439 \u0441\u0432\u0456\u0442.");
  if (base && incoming && retirementPurchaseAdvanced(base, incoming)) throw new SharedConflict("\u0426\u0435\u0439 \u0430\u0442\u0440\u0430\u043A\u0446\u0456\u043E\u043D \u043F\u0440\u0438\u0431\u0440\u0430\u043D\u043E \u0437 \u0433\u0440\u0438. \u041E\u043D\u043E\u0432\u0456\u0442\u044C \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0443; \u043D\u043E\u0432\u0430 \u043F\u043E\u043A\u0443\u043F\u043A\u0430 \u043D\u0435 \u0441\u043F\u0438\u0441\u0430\u043D\u0430.");
  if (base && incoming) incoming = inheritRetirement(base, incoming);
  if (base) base = migrateRetiredIsland(base);
  if (current) current = migrateRetiredIsland(current);
  if (incoming) incoming = migrateRetiredIsland(incoming);
  if (base) base = preserveReferenceOwnership(base, Date.now(), { repair: false });
  if (current) current = preserveReferenceOwnership(current, Date.now(), { repair: false });
  if (incoming) incoming = preserveReferenceOwnership(incoming, Date.now(), { repair: false });
  if (base && incoming) {
    let receipts = incoming.referenceOwnership;
    for (const [id, v] of Object.entries(base.referenceOwnership || {})) if ((receipts?.[id]?.count || 0) < v.count || (receipts?.[id]?.built || 0) < v.built) receipts = { ...receipts, [id]: { count: Math.max(v.count, receipts?.[id]?.count || 0), built: Math.max(v.built, receipts?.[id]?.built || 0) } };
    if (receipts !== incoming.referenceOwnership) incoming = { ...incoming, referenceOwnership: receipts };
  }
  if (!base || !current) return clone4(incoming);
  if (current.unlocked.includes(ZOO_ID) && !incoming.unlocked.includes(ZOO_ID)) incoming = { ...incoming, unlocked: [...incoming.unlocked, ZOO_ID] };
  let permanentZoo;
  try {
    permanentZoo = mergeZoo(base.zoo, current.zoo, incoming.zoo);
  } catch (error) {
    throw new SharedConflict(error.message);
  }
  for (const seed of MAGIC_BED_SEEDS) if (base.inventory?.[seed.id] !== void 0 && !(seed.id in incoming.inventory)) incoming = { ...incoming, inventory: { ...incoming.inventory, [seed.id]: base.inventory[seed.id] } };
  for (const crop of MAGIC_BED_CROPS) if (base.farm?.stock?.[crop.id] !== void 0 && !(crop.id in incoming.farm.stock)) incoming = { ...incoming, farm: { ...incoming.farm, stock: { ...incoming.farm.stock, [crop.id]: base.farm.stock[crop.id] } } };
  if (current.withdrawnMagicFarms) {
    incoming = { ...incoming, withdrawnMagicFarms: [.../* @__PURE__ */ new Set([...current.withdrawnMagicFarms, ...incoming.withdrawnMagicFarms || []])] };
    for (const id of current.withdrawnMagicFarms) if (current.farm?.orchards?.[id] && !incoming.farm?.orchards?.[id]) incoming = { ...incoming, farm: { ...incoming.farm, orchards: { ...incoming.farm?.orchards, [id]: base.farm?.orchards?.[id] || current.farm.orchards[id] } } };
  }
  if (current.jobCity && base.unlocked?.includes("jobcity") && !incoming.unlocked.includes("jobcity"))
    incoming = { ...incoming, unlocked: [...incoming.unlocked, "jobcity"] };
  if (current.housing && !incoming.unlocked.includes("cat-homes"))
    incoming = { ...incoming, unlocked: [...incoming.unlocked, "cat-homes"] };
  if (current.unlocked?.includes(ATOLL_PARK_ID) && !incoming.unlocked.includes(ATOLL_PARK_ID))
    incoming = { ...incoming, unlocked: [...incoming.unlocked, ATOLL_PARK_ID] };
  for (const f of MAGIC_FARMS) if (base.unlocked?.includes(f.id) && current.unlocked?.includes(f.id) && !incoming.unlocked.includes(f.id)) incoming = { ...incoming, unlocked: [...incoming.unlocked, f.id] };
  if (current.farm?.orchards && !incoming.farm?.orchards) {
    const stock = { ...incoming.farm.stock };
    for (const f of MAGIC_FRUITS) if (!(f.id in stock) && base.farm?.stock?.[f.id] !== void 0) stock[f.id] = base.farm.stock[f.id];
    incoming = { ...incoming, farm: { ...incoming.farm, orchards: base.farm?.orchards || {}, stock } };
  }
  const b = clone4(base), n = clone4(incoming);
  const owned = (game, item2) => (game.inventory[item2] || 0) + game.placements.filter((p) => p.item === item2).length;
  for (const p of b.placements) {
    const expanded = BUILDING_EXPANSIONS[p.biome] || (p.biome === "homestead" ? HOMESTEAD_EXPANSION : p.biome === "autumn" ? { originalRadius: MOSA_OLD_RADIUS } : null), newSlide = !!byItem(p.item)?.referenceSlide || p.item === MAGIC_BED_ID;
    if (!expanded && !newSlide || n.placements.some((v) => v.id === p.id))
      continue;
    const [w, d] = footprint(p.item, p.rotation);
    if (!newSlide && Math.hypot(Math.abs(p.x) + w / 2, Math.abs(p.z) + d / 2) <= expanded.originalRadius - 0.7 || owned(n, p.item) >= owned(b, p.item))
      continue;
    n.placements.push(clone4(p));
    for (const [old, next] of [
      [b.farm.fields, n.farm.fields],
      [b.business.accounts, n.business.accounts],
      [b.business.levels || {}, n.business.levels ||= {}]
    ])
      if (old[p.id] !== void 0 && next[p.id] === void 0)
        next[p.id] = clone4(old[p.id]);
  }
  for (const [item2, count] of Object.entries(b.inventory)) {
    if (!byItem(item2)?.referenceSlide && item2 !== MAGIC_BED_ID) continue;
    const missing = owned(b, item2) - owned(n, item2);
    if (missing <= 0) continue;
    n.inventory[item2] = (n.inventory[item2] || 0) + missing;
    n.builtInventory ||= {};
    n.builtInventory[item2] = Math.min(
      n.inventory[item2],
      Math.max(n.builtInventory[item2] || 0, b.builtInventory?.[item2] || 0)
    );
    const old = (b.relocatedPurchases || []).filter((p) => p.item === item2);
    n.relocatedPurchases ||= [];
    const retained = n.relocatedPurchases.filter((p) => p.item === item2).length;
    n.relocatedPurchases.push(...clone4(old.slice(retained)));
  }
  if (n.diamonds === void 0) n.diamonds = b.diamonds || 0;
  if (n.business.totalDiamonds === void 0)
    n.business.totalDiamonds = b.business.totalDiamonds || 0;
  if (b.business?.levels) {
    n.business.levels ||= {};
    for (const [id, level] of Object.entries(b.business.levels)) {
      const retained = id.startsWith("job-") ? n.unlocked.includes("jobcity") : id.startsWith("court-") ? n.unlocked.includes("foodcourt") : id === "spa-bar" ? n.unlocked.includes("water") : n.placements.some((p) => p.id === id);
      if (retained && !(n.business.levels[id] >= level))
        n.business.levels[id] = level;
    }
  }
  const newSpaReceipts = (n.spa?.receipts || []).filter(
    (id) => !b.spa?.receipts?.includes(id)
  );
  if (newSpaReceipts.some((id) => current.spa?.receipts?.includes(id)))
    throw new SharedConflict(
      "\u0426\u0435\u0439 \u0432\u0456\u0437\u0438\u0442 \u0434\u043E SPA \u0432\u0436\u0435 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E. \u041C\u043E\u043D\u0435\u0442\u0438 \u043D\u0435 \u0441\u043F\u0438\u0441\u0430\u043D\u0456 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E."
    );
  let c = clone4(current), duplicateVisitXP = 0, duplicateAdventureXP = 0;
  if (n.care.lastTick > b.care.lastTick && c.care.lastTick > b.care.lastTick) {
    const automatic = advanceCare(b, n.care.lastTick);
    const target = Math.max(n.care.lastTick, c.care.lastTick);
    c = advanceCare(c, target);
    const needs = (old, proposed, actual) => {
      if (!old || !proposed || !actual) return;
      for (const key of ["hunger", "energy", "happiness"])
        if (Number.isFinite(old[key]) && Number.isFinite(proposed[key]) && Number.isFinite(actual[key]))
          proposed[key] = Math.max(
            0,
            Math.min(100, actual[key] + (proposed[key] - old[key]))
          );
    };
    needs(automatic.cat, n.cat, c.cat);
    for (const id of Object.keys(n.care.residents))
      needs(
        automatic.care.residents[id],
        n.care.residents[id],
        c.care.residents[id]
      );
    if (equal2(n.care.resting, automatic.care.resting))
      n.care.resting = clone4(c.care.resting);
    n.care.lastTick = target;
  }
  if (n.lastHourly > b.lastHourly && c.lastHourly > b.lastHourly) {
    const hours = Math.min(
      24,
      Math.floor((Math.min(n.lastHourly, c.lastHourly) - b.lastHourly) / HOUR)
    );
    n.coins -= Math.max(0, hours) * HOURLY_COINS;
    n.totalEarned -= Math.max(0, hours) * HOURLY_COINS;
    n.lastHourly = Math.max(n.lastHourly, c.lastHourly);
    b.lastHourly = c.lastHourly;
  }
  if (n.lastVisit !== b.lastVisit && c.lastVisit !== b.lastVisit && n.lastVisit === c.lastVisit) {
    n.coins -= LOGIN_COINS;
    n.totalEarned -= LOGIN_COINS;
    duplicateVisitXP = Math.min(
      40,
      Math.max(0, n.progression.xp - b.progression.xp)
    );
    b.lastVisit = c.lastVisit;
    n.progression.visits = b.progression.visits;
  }
  if (n.lastAttention > b.lastAttention && c.lastAttention > b.lastAttention) {
    if (Math.abs(n.lastAttention - c.lastAttention) < ATTENTION_COOLDOWN) {
      n.coins -= ATTENTION_COINS;
      n.totalEarned -= ATTENTION_COINS;
    }
    n.lastAttention = Math.max(n.lastAttention, c.lastAttention);
    b.lastAttention = c.lastAttention;
  }
  if (n.progression.lastAdventureAt > b.progression.lastAdventureAt && c.progression.lastAdventureAt > b.progression.lastAdventureAt) {
    if (Math.abs(n.progression.lastAdventureAt - c.progression.lastAdventureAt) < 18e4)
      duplicateAdventureXP = 16;
    n.progression.lastAdventureAt = Math.max(
      n.progression.lastAdventureAt,
      c.progression.lastAdventureAt
    );
    b.progression.lastAdventureAt = c.progression.lastAdventureAt;
  }
  const duplicateDiscoveries = n.progression.discoveries.filter(
    (id) => !b.progression.discoveries.includes(id) && c.progression.discoveries.includes(id)
  );
  const duplicateXP = duplicateDiscoveries.reduce((sum, id) => {
    const product = byItem(id);
    return sum + (product ? Math.max(25, Math.min(240, Math.round(product.price * 0.08))) : 0);
  }, 0);
  const businessGain = Math.min(
    Math.max(0, n.progression.xp - b.progression.xp),
    Math.max(
      0,
      (n.progression.businessXP || 0) - (b.progression.businessXP || 0)
    )
  );
  const xpGain = Math.max(
    0,
    n.progression.xp - b.progression.xp - businessGain - duplicateXP - duplicateVisitXP - duplicateAdventureXP
  );
  const day = [c.progression.xpDay, n.progression.xpDay].filter(Boolean).sort().at(-1) || null;
  const daily = c.progression.xpDay === day ? c.progression.dailyXP : 0;
  const activityGain = n.progression.xpDay === day ? Math.min(xpGain, DAILY_XP_LIMIT - daily) : 0;
  const room = Math.max(0, xpForLevel(MAX_LEVEL) - c.progression.xp), earnedBusiness = Math.min(businessGain, room), earnedActivity = Math.min(activityGain, room - earnedBusiness), gain = earnedBusiness + earnedActivity;
  const localBonus = levelCoins(b.progression.xp, n.progression.xp);
  n.coins -= localBonus;
  n.totalEarned -= localBonus;
  for (const field of ["xp", "businessXP", "dailyXP", "xpDay"])
    n.progression[field] = b.progression[field];
  const result2 = mergeRetirement(b, c, n, reconcileMergedCatLocations(b, n, merge(b, c, n)));
  result2.islandConstruction = mergeIslandConstruction(
    b.islandConstruction,
    c.islandConstruction,
    n.islandConstruction
  );
  result2.progression.xp = c.progression.xp + gain;
  result2.progression.businessXP = (c.progression.businessXP || 0) + earnedBusiness;
  result2.progression.dailyXP = daily + earnedActivity;
  result2.progression.xpDay = day;
  const bonus = levelCoins(c.progression.xp, result2.progression.xp);
  if (result2.care.bowl.reduce((sum, batch) => sum + batch.portions, 0) > BOWL_CAPACITY)
    throw new SharedConflict(
      "\u041C\u0438\u0441\u043A\u0430 \u0443\u0436\u0435 \u043D\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0430 \u0441 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430. \u0423\u0440\u043E\u0436\u0430\u0439 \u043E\u0441\u0442\u0430\u043B\u0441\u044F \u043D\u0430 \u0441\u043A\u043B\u0430\u0434\u0435."
    );
  result2.coins += bonus;
  result2.totalEarned += bonus;
  const incomingIds = new Set(
    incoming.placements.filter((p) => !base.placements.some((b2) => b2.id === p.id)).map((p) => p.id)
  );
  for (const p of [...result2.placements]) {
    const old = base.placements.find((x) => x.id === p.id);
    const proposed = incoming.placements.find((x) => x.id === p.id);
    const moved = old && proposed && ["x", "z", "biome", "rotation"].some((k) => old[k] !== proposed[k]);
    if (!incomingIds.has(p.id) && !moved) continue;
    const check = canPlace(
      result2,
      p.item,
      p.biome,
      p.x,
      p.z,
      p.rotation,
      p.id,
      { ignoreTerrain: true }
    );
    if (!check.ok) {
      if (moved)
        throw new SharedConflict(
          "\u041C\u0435\u0441\u0442\u043E \u0443\u0436\u0435 \u0437\u0430\u043D\u044F\u0442\u043E \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u043C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435. \u041F\u0440\u0435\u0434\u043C\u0435\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u043B\u0441\u044F; \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0435\u0440\u0435\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0443."
        );
      result2.placements = result2.placements.filter((x) => x.id !== p.id);
      result2.inventory[p.item] = (result2.inventory[p.item] || 0) + 1;
      result2.relocatedPurchases = [
        ...result2.relocatedPurchases || [],
        {
          item: p.item,
          readyAt: p.readyAt || 0,
          ...p.startedAt ? { startedAt: p.startedAt } : {},
          ...p.boostBaseReadyAt ? { boostBaseReadyAt: p.boostBaseReadyAt } : {},
          businessLevel: result2.business.levels?.[p.id] || 1,
          fieldCells: result2.farm.fields[p.id]
        }
      ];
      delete result2.farm.fields[p.id];
      delete result2.business.accounts[p.id];
      delete result2.business.levels?.[p.id];
    }
  }
  for (const p of result2.scenery || []) {
    const old = base.scenery?.find((x) => x.id === p.id), proposed = incoming.scenery?.find((x) => x.id === p.id);
    if (!old || !proposed || p.stored || !["x", "z", "biome", "rotation", "stored"].some(
      // Early saves omit `stored` for visible decorations. Normalization
      // writes false; that is not a player move into the replacement lake.
      (k) => k === "stored" ? !!old.stored !== !!proposed.stored : old[k] !== proposed[k]
    ))
      continue;
    if (!canPlace(result2, p.type, p.biome, p.x, p.z, p.rotation, p.id, {
      allowLocked: true
    }).ok)
      throw new SharedConflict(
        "\u041C\u0435\u0441\u0442\u043E \u0434\u043B\u044F \u0434\u0435\u043A\u043E\u0440\u0430 \u0443\u0436\u0435 \u0437\u0430\u043D\u044F\u0442\u043E \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u043C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435. \u0414\u0435\u0440\u0435\u0432\u043E \u0438\u043B\u0438 \u043A\u0430\u043C\u0435\u043D\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0441\u044C \u043D\u0430 \u043F\u0440\u0435\u0436\u043D\u0435\u043C \u043C\u0435\u0441\u0442\u0435."
      );
  }
  if (result2.placements.length > PLACEMENT_LIMIT || result2.placements.filter((p) => !byItem(p.item)?.premiumWater).length > 60 || result2.unlocked.length > BIOMES.length || result2.coins > 1e7 || result2.coins < 0 || !Number.isSafeInteger(result2.diamonds) || result2.diamonds < 0 || result2.diamonds > 1e6)
    throw new SharedConflict("\u041E\u0431\u0449\u0438\u0439 \u043C\u0438\u0440 \u0434\u043E\u0441\u0442\u0438\u0433 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F.");
  for (const p of result2.placements)
    if (!byItem(p.item))
      throw new SharedConflict("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0440\u0435\u0434\u043C\u0435\u0442 \u0432 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0438.");
  try {
    checkFamilyPace(
      current.family,
      result2.family,
      Object.values(result2.jobCity?.profiles || {})
    );
  } catch (error) {
    throw new SharedConflict(error.message);
  }
  for (const pair of Object.values(result2.family?.couples || {})) {
    const homes = Object.values(result2.housing?.homes || {}).filter((h) => h.owner === pair.male || h.owner === pair.female);
    if (homes.length > 1 && homes.some((h) => !base.housing?.homes[h.id] && !current.housing?.homes[h.id]))
      throw new SharedConflict("\u0423 \u0446\u0456\u0454\u0457 \u0441\u0456\u043C'\u0457 \u0432\u0436\u0435 \u0454 \u0441\u043F\u0456\u043B\u044C\u043D\u0438\u0439 \u0434\u0456\u043C. \u041C\u043E\u043D\u0435\u0442\u043A\u0438 \u0437\u0430 \u0434\u0440\u0443\u0433\u0438\u0439 \u0431\u0443\u0434\u0438\u043D\u043E\u043A \u043D\u0435 \u0441\u043F\u0438\u0441\u0430\u043D\u0456.");
  }
  for (const [id, p] of Object.entries(current.jobCity?.profiles || {})) for (const [receipt, value] of Object.entries(p.mall?.receipts || {})) {
    if (!equal2(result2.jobCity?.profiles[id]?.mall?.receipts?.[receipt], value)) throw new SharedConflict("\u0427\u0435\u043A \u0422\u0420\u0426 \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0432\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0430\u0431\u043E \u0437\u043C\u0456\u043D\u0438\u0442\u0438.");
  }
  try {
    validateMallEconomy(result2);
  } catch (error) {
    throw new SharedConflict(error.message);
  }
  result2.zoo = permanentZoo;
  return preserveReferenceOwnership(resolveConstructionBoosts(reconcileFamilyHomes(result2)));
}

// city-life-ai.mjs
function cityLifeChoices(s) {
  const houses = housingOffers(), minimum = Math.min(...houses.map((h) => h.price)), byId = new Map(s.cats.map((p) => [p.id, p]));
  return {
    careers: s.phase === "careers" ? s.cats.flatMap((p, i) => s.initialIds.includes(p.id) ? [i] : []) : [],
    evenings: s.phase === "evening" ? s.cats.flatMap((p, i) => p.scheduleJob !== "rest" ? [i] : []) : [],
    buyers: s.phase === "evening" ? s.cats.flatMap(
      (p, i) => p.coins >= minimum && p.lastHousingAIDay < s.day && (!p.partner || !(p.ownedHomes || p.activeHome || byId.get(p.partner)?.ownedHomes || byId.get(p.partner)?.activeHome)) ? [i] : []
    ) : [],
    family: s.phase === "evening" && s.familyReview.due && s.familyReview.slots > 0 && familyLimit(s.cats.filter((p) => !p.partner)) > 0
  };
}
function eveningResponseFormat(s, choices) {
  const properties = {};
  if (choices.evenings.length) {
    const variants = [false, true].flatMap((hasCar) => {
      const cats = choices.evenings.filter((i) => !!s.cats[i].hasCar === hasCar);
      if (!cats.length) return [];
      return [{
        type: "object",
        additionalProperties: false,
        required: ["cat", "mode", "outings"],
        properties: {
          cat: { type: "integer", enum: cats },
          mode: { type: "integer", enum: hasCar ? [0, 1, 2] : [0, 1] },
          outings: {
            type: "array",
            maxItems: Math.min(3, s.leisureOffers.length),
            uniqueItems: true,
            items: {
              type: "integer",
              minimum: 0,
              maximum: Math.max(0, s.leisureOffers.length - 1)
            }
          }
        }
      }];
    });
    properties.evenings = {
      type: "array",
      minItems: choices.evenings.length,
      maxItems: choices.evenings.length,
      items: variants.length === 1 ? variants[0] : { anyOf: variants }
    };
  }
  if (choices.buyers.length) properties.houses = {
    type: "array",
    minItems: choices.buyers.length,
    maxItems: choices.buyers.length,
    items: {
      type: "object",
      additionalProperties: false,
      required: ["cat", "house", "roommate"],
      properties: {
        cat: { type: "integer", enum: choices.buyers },
        house: { type: ["integer", "null"], enum: [null, ...housingOffers().map((_, i) => i)] },
        roommate: { type: ["integer", "null"], enum: [null, ...s.cats.flatMap((p, i) => !p.activeHome ? [i] : [])] }
      }
    }
  };
  if (choices.family) properties.families = {
    type: "array",
    minItems: 1,
    maxItems: s.familyReview.slots,
    items: {
      type: "object",
      additionalProperties: false,
      required: ["male", "female", "reason"],
      properties: {
        male: { type: "integer", enum: s.cats.flatMap((p, i) => !p.partner && p.sex === "male" ? [i] : []) },
        female: { type: "integer", enum: s.cats.flatMap((p, i) => !p.partner && p.sex === "female" ? [i] : []) },
        reason: { type: "string", maxLength: 64 }
      }
    }
  };
  return { type: "json_schema", json_schema: {
    name: "cat_life",
    strict: true,
    schema: { type: "object", properties, required: Object.keys(properties), additionalProperties: false }
  } };
}
function cityLifeInput(s) {
  const c = cityLifeChoices(s), houses = housingOffers();
  const places2 = s.leisureOffers || [], types = [...new Set(places2.map((p) => p.type))], islands = [...new Set(places2.map((p) => p.biome))];
  const initial = s.phase === "careers";
  const fields = [
    ...c.evenings.length ? ['"evenings":[{"cat":catIndex,"mode":mode,"outings":placeIndices}]'] : [],
    ...c.buyers.length ? ['"houses":[{"cat":catIndex,"house":houseIndex,"roommate":null}]'] : [],
    ...c.family ? ['"families":[{"male":maleIndex,"female":femaleIndex,"reason":"3 Ukrainian words"}]'] : []
  ];
  return {
    messages: [
      {
        role: "system",
        content: initial ? `Choose a lifelong profession for each requested fictional cat. Return ONLY compact JSON {"careers":[[catIndex,professionIndex]]} without indentation, line breaks, prose or other keys. Exactly one numeric pair for every index provided in careers; no extra rows. Profession indices ${JOB_KINDS.map((k, i) => i + "=" + k).join(",")}. Each input row is [catIndex,personality,preferredProfessionIndices,skillPerProfession]. Choose by personality, preferences and skills. This is initial career selection only. Do not choose evening plans, purchases, houses or families.` + CITY_LIFE_PACKING_HINT : `Choose ONLY requested fictional cat life events. Return ONLY compact JSON {${fields.join(",")}} without indentation, line breaks, prose or other keys. Never select or change professions. Evening input rows are [catIndex,personality,ownsCar,partnerIndex,privateCoins,needs(energy/hunger/happiness),wishes,visitedMallStores]; ownsCar is a permission, not the chosen activity. Place rows are [placeIndex,typeIndex,islandIndex,action,minimumPrivatePrice]. Mall visits use private coins; select affordable purchases or free browsing. Prefer food when hungry, rest when tired, and varied stores based on wishes, personality and previous visits. Choose for every index in evenings, mode 0=rest/home,1=walk/friends,2=owned car; 1-3 different real place indices, or [] for rest. Choose varied rides, meals, water, games or peaceful rest by personality. Partners spend free time together. Housing input rows are [catIndex,coins,ownedHomes,hasActiveHome,partnerIndex,personality]. Make exactly one personal buy-or-wait decision for EVERY buyer. house=null means wait and spends nothing. Consider a first cozy home for financially secure homeless cats, especially partners without a shared home; choose the house by personality while keeping a sensible reserve. Buying remains voluntary, not every cat must buy. Only buyers, only affordable; roommate=null for no roommate, otherwise a different free cat index; never the buyer or a cat with an active home. Single cats may buy additional homes without moving their active residence. A permanent couple keeps ONE shared home; if either partner has any home, do not buy another. If both partners are homeless, at most one of them buys in this batch. Families: ${c.family ? `This is the scheduled 14-day introduction. Return at least 1 and AT MOST ${s.familyReview.slots} rows in families (never pair the entire singles list). Choose compatible lifelong male+female couples from the offered singles, using their personalities. Each singles row is [catIndex,name,sex,personality]; male and female indices must refer to different free cats. Do not return an empty review when compatible singles are available. Every cat can eventually pair.` : "none today"} Return a housing row for every buyer even when waiting; do not omit this decision. No family choices outside a scheduled review. No work schedule or career review.` + CITY_LIFE_PACKING_HINT
      },
      {
        role: "user",
        content: JSON.stringify(packCityPayload({
          day: s.day,
          careers: c.careers.map((i) => {
            const p = s.cats[i];
            return [
              i,
              p.personality,
              p.preferences.map((k) => JOB_KINDS.indexOf(k)),
              JOB_KINDS.map((k) => p.skills[k])
            ];
          }),
          ...!initial ? {
            evenings: c.evenings.map((i) => {
              const p = s.cats[i];
              return [
                i,
                p.personality,
                p.hasCar ? 1 : 0,
                s.cats.findIndex((q) => q.id === p.partner),
                p.coins,
                p.needs || [100, 0, 75],
                p.wishes || [],
                p.mallVisited || []
              ];
            }),
            buyers: c.buyers.map((i) => [
              i,
              s.cats[i].coins,
              s.cats[i].ownedHomes,
              s.cats[i].activeHome ? 1 : 0,
              s.cats.findIndex((p) => p.id === s.cats[i].partner),
              s.cats[i].personality
            ]),
            houses: c.buyers.length ? houses.map((h, i) => [i, h.name, h.price]) : [],
            roommates: c.buyers.length ? s.cats.flatMap(
              (p, i) => !p.activeHome ? [[i, p.name]] : []
            ) : [],
            familyCoupleLimit: c.family ? s.familyReview.slots : 0,
            singles: c.family ? s.cats.flatMap(
              (p, i) => !p.partner ? [[i, p.name, p.sex, p.personality]] : []
            ) : [],
            types: c.evenings.length ? types.map((t, i) => [
              i,
              places2.find((p) => p.type === t).name
            ]) : [],
            islands: c.evenings.length ? islands : [],
            places: c.evenings.length ? places2.map((p, i) => [
              i,
              types.indexOf(p.type),
              islands.indexOf(p.biome),
              p.action,
              mallStore(p.id) ? Math.min(...MALL_PRODUCTS.filter((x) => x.storeId === p.id).map((x) => x.price), Infinity) === Infinity ? 0 : Math.min(...MALL_PRODUCTS.filter((x) => x.storeId === p.id).map((x) => x.price)) : 0
            ]) : []
          } : {}
        }, CITY_LIFE_TEXT_COLUMNS))
      }
    ],
    max_tokens: Math.min(
      8192,
      Math.max(
        256,
        c.careers.length * 9 + c.evenings.length * 30 + c.buyers.length * 24 + (c.family ? s.familyReview.slots * 48 : 0) + 128
      )
    ),
    temperature: 0.3,
    response_format: initial ? { type: "json_object" } : eveningResponseFormat(s, c)
  };
}
async function requestCityLife(s, run) {
  const choices = cityLifeChoices(s);
  let answer = { response: {}, provider: "none" };
  if (choices.careers.length || choices.evenings.length || choices.buyers.length || choices.family) {
    answer = await run(
      cityLifeInput(s),
      (result2) => expandCityLife(s, result2)
    );
  }
  return expandCityLife(s, answer);
}
function expandCityLife(s, result2) {
  const choices = cityLifeChoices(s), houses = housingOffers(), provider = result2?.provider || "cloudflare";
  let raw = result2?.response ?? result2;
  if (typeof raw === "string")
    raw = JSON.parse(
      raw.trim().replace(/^```(?:json)?\s*/, "").replace(/\s*```$/, "")
    );
  const assignments = localJobPlan(s.cats, s.day).map((a) => {
    const p = s.cats.find((p2) => p2.id === a.id);
    return {
      ...a,
      job: p.scheduleJob,
      evening: p.scheduleEvening,
      ...p.scheduleOutings ? { outings: p.scheduleOutings } : {}
    };
  });
  const byIndex = (i) => assignments.find((a) => a.id === s.cats[i]?.id);
  const rows4 = (name, allowed, required = false) => {
    let a = raw?.[name] ?? [];
    const seen = /* @__PURE__ */ new Set();
    if (!Array.isArray(a)) throw Error("Invalid life choices");
    if (name === "evenings") a = a.map((row2) => Array.isArray(row2) ? row2 : [row2?.cat, row2?.mode, row2?.outings]);
    if (name === "houses") a = a.map((row2) => Array.isArray(row2) ? [row2[0], row2[1], row2[2] ?? -1] : [row2?.cat, row2?.house, row2?.roommate ?? -1]);
    for (const row2 of a) {
      if (!Array.isArray(row2) || !allowed.includes(row2[0]) || seen.has(row2[0]))
        throw Error("Unrequested AI choice");
      seen.add(row2[0]);
    }
    if (required && seen.size !== allowed.length)
      throw Error("Missing AI life choices");
    return a;
  };
  for (const [i, k] of rows4("careers", choices.careers, true)) {
    if (!Number.isSafeInteger(k) || !JOB_KINDS[k])
      throw Error("Invalid initial profession");
    const a = byIndex(i);
    a.profession = JOB_KINDS[k];
    a.job = a.profession;
  }
  for (const [i, mode, outings] of rows4("evenings", choices.evenings, true)) {
    if (!Number.isSafeInteger(mode) || mode < 0 || mode > 2 || mode === 2 && !s.cats[i].hasCar || !Array.isArray(outings) || outings.length > 3 || new Set(outings).size !== outings.length || outings.some((j) => !Number.isSafeInteger(j) || !s.leisureOffers[j]))
      throw Error("Invalid evening choice");
    Object.assign(byIndex(i), {
      evening: ["rest", "walk", "drive"][mode],
      outings: outings.map((j) => s.leisureOffers[j].id)
    });
  }
  const purchaseWarnings = [];
  for (const [i, h, r] of rows4("houses", choices.buyers)) {
    if (h === null) continue;
    const house = houses[h];
    if (!Number.isSafeInteger(h) || !house || s.cats[i].coins < house.price) {
      purchaseWarnings.push({
        cat: s.cats[i].id,
        reason: !Number.isSafeInteger(h) || !house ? "unknown_house" : "unaffordable"
      });
      continue;
    }
    const available = Number.isSafeInteger(r) && r >= -1 && (r === -1 || s.cats[r] && !s.cats[r].activeHome && r !== i);
    if (!available) purchaseWarnings.push({ cat: s.cats[i].id, reason: "roommate_unavailable" });
    byIndex(i).house = {
      type: house.id,
      roommate: available && r >= 0 ? s.cats[r].id : null
    };
  }
  const proposals = raw?.families ?? [];
  if (!Array.isArray(proposals) || !choices.family && proposals.length)
    throw Error("Unrequested family review");
  if (choices.family && !proposals.length)
    throw Error("Missing family choice");
  const families = validateFamilyProposals(
    proposals.map((row2) => {
      const [m, f, reason] = Array.isArray(row2) ? row2 : [row2?.male, row2?.female, row2?.reason];
      return { male: s.cats[m]?.id, female: s.cats[f]?.id, reason };
    }),
    s.cats,
    choices.family ? s.familyReview.slots : 0
  );
  const counts = Object.fromEntries(
    JOB_KINDS.map((k) => [
      k,
      assignments.filter((a) => a.job === k && !s.initialIds.includes(a.id)).length
    ])
  );
  for (const i of choices.careers) {
    const a = byIndex(i);
    a.job = counts[a.profession] < JOB_CAPACITY ? a.profession : "rest";
    if (a.job !== "rest") counts[a.job]++;
  }
  const final = assignments;
  return {
    day: s.day,
    phase: s.phase,
    provider,
    assignments: validateJobAssignments({ assignments: final }, s.cats),
    families,
    ...purchaseWarnings.length ? { purchaseWarnings } : {}
  };
}

// city-ai-vault.mjs
var quotaError = (e) => /4006|daily free allocation|daily.*neurons/i.test(String(e?.message || e));
var result = (body, status = 200) => ({ body, status });
function failureReason(error) {
  const message = String(error?.message || "");
  const http = /^OpenRouter backup unavailable: HTTP (\d{3})$/.exec(message);
  if (http) return "reserve_http_" + http[1];
  if (message === "OpenRouter backup returned no answer")
    return "reserve_empty";
  if (error?.name === "SyntaxError") return "invalid_json";
  const known2 = {
    "Unrequested AI choice": "unrequested_choice",
    "Missing AI life choices": "missing_choices",
    "Missing family choice": "missing_family",
    "Invalid initial profession": "invalid_profession",
    "Invalid evening choice": "invalid_evening",
    "Invalid house choice": "invalid_house",
    "AI event timeout": "timeout"
  };
  return known2[message] || "provider_or_contract";
}
var CityAIRequestLedger = class {
  constructor(storage, ai) {
    this.storage = storage;
    this.ai = ai;
    this.inflight = /* @__PURE__ */ new Map();
  }
  async status() {
    const ledger = await this.storage.get("city-ai-ledger");
    return {
      epoch: ledger?.epoch ?? null,
      events: [...ledger?.records || [], ...ledger?.familyReceipt && !ledger.records.some((r) => r.key === ledger.familyReceipt.key) ? [ledger.familyReceipt] : []].flatMap((record) => {
        let event;
        try {
          event = JSON.parse(record.key);
        } catch {
          return [];
        }
        const [epoch, phase, day] = event;
        if (!Number.isFinite(epoch) || !Number.isSafeInteger(day) || !["careers", "evening"].includes(phase)) return [];
        return [{
          epoch,
          phase,
          day,
          pending: !record.result,
          status: record.result?.status ?? 409,
          ...record.result ? { body: record.result.body } : {}
        }];
      })
    };
  }
  async plan(state) {
    const key = JSON.stringify([
      state.epoch,
      state.phase,
      state.day,
      [...state.initialIds].sort()
    ]);
    if (this.inflight.has(key)) return this.inflight.get(key);
    const promise = this.execute(state, key);
    this.inflight.set(key, promise);
    try {
      return await promise;
    } finally {
      this.inflight.delete(key);
    }
  }
  async execute(state, key) {
    const now = Date.now();
    const reserved = await this.storage.transaction(async (t) => {
      const ledger = await t.get("city-ai-ledger") || {
        records: [],
        careers: {},
        careerAttempts: {},
        eveningDay: -1,
        epoch: state.epoch,
        blockedUntil: 0
      };
      if (ledger.epoch !== state.epoch) {
        const current = await t.get("current");
        if (current?.game?.jobCity?.epoch !== state.epoch)
          return { cached: result({ code: "AI_WORLD_EPOCH_MISMATCH" }, 409) };
        const shift = Math.round((ledger.epoch - state.epoch) / 144e4);
        if (ledger.eveningDay >= 0) ledger.eveningDay = Math.max(-1, ledger.eveningDay + shift);
        for (const id of Object.keys(ledger.careerAttempts))
          ledger.careerAttempts[id] = Math.max(-1, ledger.careerAttempts[id] + shift);
        ledger.epoch = state.epoch;
        await t.put("city-ai-ledger", ledger);
      }
      const old = ledger.records.find((r) => r.key === key);
      if (old)
        return {
          cached: old.result || result({ code: "AI_EVENT_PENDING" }, 409)
        };
      const initialIds = state.initialIds.filter((id) => !ledger.careers[id]);
      if (state.phase === "careers" && !initialIds.length)
        return { replay: ledger.careers };
      if (ledger.blockedUntil > now && !this.ai.reserveConfigured)
        return {
          cached: result(
            { code: "AI_DAILY_LIMIT", retryAt: ledger.blockedUntil },
            429
          )
        };
      if (state.phase === "evening" && ledger.eveningDay >= state.day || state.phase === "careers" && initialIds.some(
        (id) => (ledger.careerAttempts[id] ?? -1) >= state.day
      ))
        return { cached: result({ code: "AI_EVENT_ALREADY_REQUESTED" }, 409) };
      if (state.phase === "evening") ledger.eveningDay = state.day;
      for (const id of initialIds) ledger.careerAttempts[id] = state.day;
      ledger.records = [...ledger.records, { key, reservedAt: now }].slice(-2);
      await t.put("city-ai-ledger", ledger);
      return { careers: ledger.careers, initialIds };
    });
    if (reserved.cached) return reserved.cached;
    const replay = async (choices) => requestCityLife(state, async () => ({
      response: {
        careers: state.initialIds.map((id) => [
          state.cats.findIndex((p) => p.id === id),
          JOB_KINDS.indexOf(choices[id])
        ])
      }
    }));
    if (reserved.replay)
      return result({ ...await replay(reserved.replay), provider: "cached" });
    let response2, timer;
    try {
      let body = await Promise.race([
        requestCityLife(
          { ...state, initialIds: reserved.initialIds },
          (input, validate) => this.ai.run("@cf/meta/llama-3.3-70b-instruct-fp8-fast", input, validate)
        ),
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(Error("AI event timeout")), 1e5);
        })
      ]);
      if (state.phase === "careers") {
        const provider = body.provider;
        const choices = { ...reserved.careers };
        for (const a of body.assignments)
          if (reserved.initialIds.includes(a.id)) choices[a.id] = a.profession;
        body = await replay(choices);
        body.provider = provider;
      }
      response2 = result(body);
    } catch (e) {
      response2 = quotaError(e) ? result(
        {
          code: "AI_DAILY_LIMIT",
          retryAt: Math.floor(now / 864e5) * 864e5 + 864e5
        },
        429
      ) : result({ code: "AI_EVENT_FAILED", reason: failureReason(e) }, 502);
    } finally {
      clearTimeout(timer);
    }
    await this.storage.transaction(async (t) => {
      const ledger = await t.get("city-ai-ledger"), record = ledger.records.find((r) => r.key === key);
      if (record) record.result = response2;
      if (response2.status === 200 && state.phase === "evening" && response2.body.families?.length)
        ledger.familyReceipt = { key, result: result({ phase: "evening", day: state.day, families: response2.body.families }) };
      if (response2.status === 200 && state.phase === "careers") {
        for (const a of response2.body.assignments)
          if (state.initialIds.includes(a.id))
            ledger.careers[a.id] = a.profession;
      }
      if (response2.body.retryAt) ledger.blockedUntil = response2.body.retryAt;
      await t.put("city-ai-ledger", ledger);
    });
    return response2;
  }
};

// ai-provider-router.mjs
var PRIMARY_AI_MODEL = "@cf/meta/llama-3.3-70b-instruct-fp8-fast";
var BACKUP_AI_MODEL = "dots-studio/dots-3-note-preview:free";
var routers = /* @__PURE__ */ new WeakMap();
function aiProviderRouter(env, { fetcher = fetch, clock = Date.now } = {}) {
  if (routers.has(env)) return routers.get(env);
  let primaryBlockedUntil = 0;
  const router = {
    async run(input, validate) {
      let failure = Error("Primary AI unavailable");
      if (env.AI && clock() >= primaryBlockedUntil) {
        try {
          const format = input.response_format;
          const primaryInput = format?.type === "json_schema" && format.json_schema?.schema ? { ...input, response_format: { type: "json_schema", json_schema: format.json_schema.schema } } : input;
          const answer2 = await env.AI.run(PRIMARY_AI_MODEL, primaryInput);
          await validate?.(answer2);
          return answer2;
        } catch (error) {
          failure = error;
          primaryBlockedUntil = /4006|daily free allocation|daily.*neurons/i.test(
            String(error?.message)
          ) ? (Math.floor(clock() / 864e5) + 1) * 864e5 : clock() + 6e4;
        }
      }
      if (!env.BACKUP_AI_API_KEY) throw failure;
      const response2 = await fetcher(
        "https://openrouter.ai/api/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + env.BACKUP_AI_API_KEY,
            "HTTP-Referer": "https://arturmal2805-netizen.github.io/ai-cat-game/",
            "X-Title": "Chichi Cat World"
          },
          body: JSON.stringify({
            ...input,
            model: env.BACKUP_AI_MODEL || BACKUP_AI_MODEL,
            // The game budgets answer tokens, not hidden reasoning. A random
            // free reasoner can exhaust that small budget with null content.
            reasoning: { enabled: false },
            provider: { require_parameters: true }
          }),
          signal: AbortSignal.timeout(35e3)
        }
      );
      if (!response2.ok) {
        throw Error("OpenRouter backup unavailable: HTTP " + response2.status);
      }
      const data = await response2.json(), content = data?.choices?.[0]?.message?.content;
      if (typeof content !== "string" || !content.trim())
        throw Error("OpenRouter backup returned no answer");
      const answer = {
        response: content,
        usage: data.usage,
        provider: "openrouter"
      };
      await validate?.(answer);
      return answer;
    }
  };
  routers.set(env, router);
  return router;
}

// save-vault.mjs
var SAVE_LIMIT = 8 * 1024 * 1024;
var EDITOR_LEASE_MS = 25e3;
var sessionValid = (value) => /^[a-zA-Z0-9-]{8,64}$/.test(value || "");
var json = (data, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
async function readJSON(request, limit) {
  if (Number(request.headers.get("content-length")) > limit)
    throw Error("SAVE_TOO_LARGE");
  const stream = request.headers.get("Content-Encoding") === "gzip" && request.body ? request.body.pipeThrough(new DecompressionStream("gzip")) : request.body;
  const reader = stream?.getReader();
  if (!reader) throw Error("SAVE_INVALID");
  const chunks = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > limit) {
      await reader.cancel();
      throw Error("SAVE_TOO_LARGE");
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return JSON.parse(new TextDecoder().decode(bytes));
}
async function readSaveBody(request) {
  const value = await readJSON(request, SAVE_LIMIT * 2 + 2048);
  if (new TextEncoder().encode(JSON.stringify(value.game || {})).length > SAVE_LIMIT || value.baseGame && new TextEncoder().encode(JSON.stringify(value.baseGame)).length > SAVE_LIMIT)
    throw Error("SAVE_TOO_LARGE");
  if (!/^[a-zA-Z0-9-]{8,64}$/.test(value.mutationId || "") || !Number.isSafeInteger(value.expectedRevision) || value.expectedRevision < 0 || value.cooperative && value.clientId !== void 0 && (!sessionValid(value.clientId) || !Number.isSafeInteger(value.sequence) || value.sequence < 1) || value.sessionId !== void 0 && !sessionValid(value.sessionId) || !value.game || !housingSnapshotValid(value.game.housing) || !familySnapshotValid(value.game.family) || !cryptoSnapshotValid(value.game.jobCity) || !orchardSnapshotValid(value.game.farm?.orchards) || !magicBedSnapshotValid(value.game) || !zooSnapshotValid(value.game.zoo) || !retirementSnapshotValid(value.game.retiredAttractions) || value.game.version !== 2 || !Number.isSafeInteger(value.game.coins) || value.game.coins < 0 || value.game.coins > 1e7 || value.game.diamonds !== void 0 && (!Number.isSafeInteger(value.game.diamonds) || value.game.diamonds < 0 || value.game.diamonds > 1e6) || !Array.isArray(value.game.placements) || value.game.placements.length > PLACEMENT_LIMIT || value.game.placements.filter((p) => !byItem(p?.item)?.premiumWater && !RETIRED_ATTRACTIONS[p?.item]).length > 60 || !Array.isArray(value.game.unlocked) || new Set(value.game.unlocked).size !== value.game.unlocked.length || value.game.unlocked.length > BIOMES.length + RETIRED_BIOME_IDS.length)
    throw Error("SAVE_INVALID");
  return value;
}
var SaveVault = class {
  constructor(state, env = {}) {
    this.storage = chunkedSaveStorage(state.storage);
    this.cryptoAI = new CryptoAIRequestLedger(this.storage, (input, validate) => aiProviderRouter(env).run(input, validate));
    this.cityAI = new CityAIRequestLedger(this.storage, {
      reserveConfigured: !!env.BACKUP_AI_API_KEY,
      run: (_model, input, validate) => aiProviderRouter(env).run(input, validate)
    });
  }
  async fetch(request) {
    if (new URL(request.url).pathname === "/internal-crypto-ai" && request.method === "POST") {
      let input2;
      try {
        input2 = validateCryptoRequest(await readJSON(request, 2048));
      } catch {
        return json({ error: "Invalid trading attempt" }, 400);
      }
      const result3 = await this.cryptoAI.forecast(input2);
      return json(result3.body, result3.status);
    }
    if (new URL(request.url).pathname === "/internal-city-ai-status" && request.method === "GET")
      return json(await this.cityAI.status());
    if (new URL(request.url).pathname === "/internal-city-ai" && request.method === "POST") {
      let state;
      try {
        state = validateCityAIState(await readJSON(request, JOB_AI_LIMIT));
        if (!state.phase) throw Error();
      } catch {
        return json({ code: "INVALID_AI_EVENT" }, 400);
      }
      const r = await this.cityAI.plan(state);
      return json(r.body, r.status);
    }
    if (new URL(request.url).pathname === "/internal-account" && request.method === "POST") {
      let input2;
      try {
        input2 = await readJSON(request, 1024);
      } catch {
        return json({ error: "INVALID_ACCOUNT" }, 400);
      }
      if (!["limit", "create", "login"].includes(input2.action))
        return json({ error: "INVALID_ACCOUNT" }, 400);
      return json(await new AccountVault(this.storage).handle(input2));
    }
    if (request.method === "GET") {
      if (new URL(request.url).searchParams.get("copies") === "1") {
        const copies = [];
        for (const source of ["current", "previous", "older", ...["current", "previous", "older"].map((k) => RECOVERY_AWARD_ID + ":before:" + k)]) {
          const value = await this.storage.get(source);
          if (value?.game) copies.push({ source, revision: value.revision, savedAt: value.savedAt, game: value.game });
        }
        return json({ copies });
      }
      const save = await this.storage.get("current");
      const editor = await this.storage.get("editor");
      const { submittedGame, ...visible } = save || {};
      return json({
        ...save ? visible : { revision: 0, game: null, savedAt: null },
        editor: editor?.expiresAt > Date.now() ? editor : null
      });
    }
    if (request.method === "POST") {
      let input2;
      try {
        input2 = await readJSON(request, 1024);
      } catch {
        return json({ error: "INVALID_SESSION" }, 400);
      }
      if (input2.action === "recovery-compensation") {
        const token = request.headers.get("X-Chichi-Save-Token");
        if (!/^[a-f0-9]{64}$/.test(token || "") || await hashText(token) !== RECOVERY_WORLD_HASH) return json({ error: "\u041D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u0440\u0435\u0434\u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043E \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u043C\u0438\u0440\u0430." }, 403);
        try {
          return json(await this.storage.transaction((t) => applyRecoveryAward(t)));
        } catch (error) {
          return json({ error: error.message }, 409);
        }
      }
      if (!sessionValid(input2.sessionId) || !["claim", "release"].includes(input2.action))
        return json({ error: "INVALID_SESSION" }, 400);
      const result3 = await this.storage.transaction(async (t) => {
        const now = Date.now(), old = await t.get("editor");
        if (input2.action === "release") {
          if (old?.sessionId === input2.sessionId)
            await t.put("editor", { ...old, expiresAt: 0 });
          return { granted: false };
        }
        if (old?.expiresAt > now && old.sessionId !== input2.sessionId)
          return { granted: false, editor: old };
        const editor = {
          sessionId: input2.sessionId,
          expiresAt: now + EDITOR_LEASE_MS
        };
        await t.put("editor", editor);
        return { granted: true, editor };
      });
      return json(result3);
    }
    if (request.method !== "PUT")
      return json({ error: "Method not allowed" }, 405);
    let input;
    try {
      input = await readSaveBody(request);
    } catch (e) {
      return json(
        { error: e.message },
        e.message === "SAVE_TOO_LARGE" ? 413 : 400
      );
    }
    const requestDigest = input.cooperative ? await hashText(JSON.stringify(input.game)) : null;
    const result2 = await this.storage.transaction(async (transaction) => {
      const current = await transaction.get("current"), revision = current?.revision || 0;
      if (current?.game?.jobCity?.epoch && input.game.jobCity?.epoch !== current.game.jobCity.epoch && (Object.keys(input.game.jobCity?.profiles || {}).length < Object.keys(current.game.jobCity.profiles || {}).length || current.game.unlocked.some((id) => !input.game.unlocked.includes(id))))
        return { conflict: true, revision, savedAt: current.savedAt, game: current.game, error: "\u041F\u043E\u0434\u043C\u0435\u043D\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u043C\u0438\u0440\u0430 \u043D\u043E\u0432\u044B\u043C \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430. \u0421\u043A\u0430\u0447\u0430\u0439\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u044B\u0435 \u043A\u043E\u043F\u0438\u0438 \u0434\u043B\u044F \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F." };
      if (input.expectedRevision > revision)
        return {
          unavailable: true,
          error: "\u0421\u0435\u0440\u0432\u0435\u0440\u043D\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043F\u043E\u043A\u0430 \u0441\u0442\u0430\u0440\u0435\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0439. \u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430; \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u043E\u0437\u0436\u0435."
        };
      const editor = await transaction.get("editor");
      const receipts = input.cooperative ? await transaction.get("receipts") || [] : [];
      const previousWrite = input.cooperative && input.clientId ? await transaction.get("writer:" + input.clientId) : null;
      if (previousWrite && input.sequence <= previousWrite.sequence) {
        if (input.sequence === previousWrite.sequence && previousWrite.digest !== requestDigest)
          return {
            conflict: true,
            revision,
            savedAt: current.savedAt,
            game: current.game,
            error: "\u041F\u043E\u0432\u0442\u043E\u0440 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043E\u0442\u043B\u0438\u0447\u0430\u0435\u0442\u0441\u044F \u043E\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E."
          };
        return { revision, savedAt: current.savedAt, game: current.game };
      }
      const receipt = receipts.find((r) => r.id === input.mutationId);
      if (receipt)
        return receipt.digest === requestDigest ? { revision, savedAt: current.savedAt, game: current.game } : {
          conflict: true,
          revision,
          savedAt: current.savedAt,
          game: current.game,
          error: "\u041F\u043E\u0432\u0442\u043E\u0440 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043E\u0442\u043B\u0438\u0447\u0430\u0435\u0442\u0441\u044F \u043E\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E."
        };
      if (!input.cooperative && editor?.expiresAt > Date.now() && editor.sessionId !== input.sessionId)
        return { locked: true, revision, savedAt: current?.savedAt };
      if (!input.cooperative && input.sessionId && (!editor || editor.expiresAt <= Date.now()))
        return { locked: true, revision, savedAt: current?.savedAt };
      if (current?.lastMutationId === input.mutationId) {
        if (JSON.stringify(current.submittedGame || current.game) === JSON.stringify(input.game))
          return {
            revision,
            savedAt: current.savedAt,
            ...input.cooperative ? { game: current.game } : {}
          };
        return {
          conflict: true,
          revision,
          savedAt: current.savedAt,
          ...input.cooperative ? {
            game: current.game,
            error: "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0434\u0440\u0443\u0433\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F. \u041F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u043A\u043E\u043F\u0438\u044F \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430, \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E."
          } : {}
        };
      }
      if (!input.cooperative && input.expectedRevision !== revision)
        return { conflict: true, revision, savedAt: current?.savedAt };
      if (!input.cooperative && current && retirementPurchaseAdvanced(current.game, input.game)) return { conflict: true, revision, savedAt: current.savedAt, game: current.game, error: "\u0426\u0435\u0439 \u0430\u0442\u0440\u0430\u043A\u0446\u0456\u043E\u043D \u043F\u0440\u0438\u0431\u0440\u0430\u043D\u043E \u0437 \u0433\u0440\u0438. \u041E\u043D\u043E\u0432\u0456\u0442\u044C \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0443; \u043D\u043E\u0432\u0430 \u043F\u043E\u043A\u0443\u043F\u043A\u0430 \u043D\u0435 \u0441\u043F\u0438\u0441\u0430\u043D\u0430." };
      let game = migrateRetiredIsland(input.cooperative ? input.game : inheritRetirement(current?.game, input.game)), notice = null;
      if (input.cooperative && current) {
        if (!input.baseGame || input.baseGame.version !== 2 || !Array.isArray(input.baseGame.placements) || !input.baseGame.progression)
          return {
            conflict: true,
            revision,
            savedAt: current.savedAt,
            game: current.game,
            error: "\u041D\u0443\u0436\u043D\u043E \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043E\u0431\u0449\u0438\u0439 \u043C\u0438\u0440."
          };
        try {
          game = mergeSharedWorld(input.baseGame, current.game, input.game);
          if (input.game.placements.some(
            (p) => !input.baseGame.placements.some((b) => b.id === p.id) && !game.placements.some((g) => g.id === p.id)
          ))
            notice = "\u041D\u0430 \u044D\u0442\u043E \u043C\u0435\u0441\u0442\u043E \u0443\u0436\u0435 \u043F\u043E\u0441\u0442\u0430\u0432\u0438\u043B\u0438 \u043F\u0440\u0435\u0434\u043C\u0435\u0442 \u0441 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430. \u0412\u0430\u0448\u0430 \u043F\u043E\u043A\u0443\u043F\u043A\u0430 \u0432 \u0441\u0443\u043C\u043A\u0435, \u0441\u0440\u043E\u043A \u0441\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D.";
        } catch (e) {
          if (!(e instanceof SharedConflict)) throw e;
          return {
            conflict: true,
            revision,
            savedAt: current.savedAt,
            game: current.game,
            error: e.message
          };
        }
      }
      game = preserveReferenceOwnership(game);
      const save = {
        revision: revision + 1,
        savedAt: Date.now(),
        game,
        lastMutationId: input.mutationId,
        ...input.cooperative ? { submittedGame: input.game } : {}
      };
      if (current) {
        const previous = await transaction.get("previous");
        if (previous) await transaction.put("older", previous);
        await transaction.put("previous", current);
      }
      await transaction.put("current", save);
      if (input.cooperative && input.clientId)
        await transaction.put("writer:" + input.clientId, {
          sequence: input.sequence,
          digest: requestDigest
        });
      if (input.cooperative)
        await transaction.put(
          "receipts",
          [...receipts, { id: input.mutationId, digest: requestDigest }].slice(
            -256
          )
        );
      return {
        revision: save.revision,
        savedAt: save.savedAt,
        ...input.cooperative ? { game, ...notice ? { notice } : {} } : {}
      };
    });
    return json(
      result2,
      result2.unavailable ? 503 : result2.locked ? 423 : result2.conflict ? 409 : 200
    );
  }
};
async function cloudSave(request, env) {
  if (!env.SAVE_VAULT) return json({ error: "CLOUD_SAVE_UNAVAILABLE" }, 503);
  const token = request.headers.get("X-Chichi-Save-Token");
  if (!/^[a-f0-9]{64}$/.test(token || ""))
    return json({ error: "INVALID_RECOVERY_CODE" }, 401);
  const hash3 = Array.from(
    new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token))
    )
  ).map((n) => n.toString(16).padStart(2, "0")).join("");
  return env.SAVE_VAULT.get(env.SAVE_VAULT.idFromName(hash3)).fetch(request);
}
var AccountVault = class {
  constructor(storage) {
    this.storage = storage;
  }
  async handle(input) {
    return this.storage.transaction(async (t) => {
      if (input.action === "limit") {
        const now = Date.now(), saved = await t.get("attempts");
        const attempts = saved?.until > now ? saved : { count: 0, until: now + 6e4 };
        if (attempts.count >= 6) return { limited: true };
        await t.put("attempts", { ...attempts, count: attempts.count + 1 });
        return { ok: true };
      }
      const account = await t.get("account");
      if (input.action === "create") {
        if (account) return { exists: true };
        await t.put("account", { token: input.token, createdAt: Date.now() });
        return { token: input.token };
      }
      return account ? { token: account.token } : { missing: true };
    });
  }
};
var hashText = async (text2) => Array.from(
  new Uint8Array(
    await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text2))
  )
).map((n) => n.toString(16).padStart(2, "0")).join("");
async function accountAccess(request, env) {
  if (!env.SAVE_VAULT) return json({ error: "\u041E\u0431\u043B\u0430\u043A\u043E \u043F\u043E\u043A\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E." }, 503);
  let input;
  try {
    input = await readJSON(request, 1024);
  } catch {
    return json({ error: "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441." }, 400);
  }
  if (!/^\d{4,12}$/.test(input.code || "") || !["create", "login"].includes(input.action))
    return json({ error: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043A\u043E\u0434 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430: \u043E\u0442 4 \u0434\u043E 12 \u0446\u0438\u0444\u0440." }, 400);
  if (input.action === "create" && !/^[a-f0-9]{64}$/.test(input.token || ""))
    return json({ error: "\u041D\u0435\u0442 \u043A\u043E\u0434\u0430 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u043C\u0438\u0440\u0430." }, 400);
  const stub = async (name, body) => env.SAVE_VAULT.get(env.SAVE_VAULT.idFromName(name)).fetch(
    new Request("https://vault/internal-account", {
      method: "POST",
      body: JSON.stringify(body)
    })
  );
  const ip = request.headers.get("CF-Connecting-IP") || "local";
  const limit = await (await stub("account-limit:" + await hashText(ip), { action: "limit" })).json();
  if (limit.limited)
    return json({ error: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u043F\u043E\u043F\u044B\u0442\u043E\u043A. \u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u043C\u0438\u043D\u0443\u0442\u0443." }, 429);
  if (input.action === "create") {
    const world = await cloudSave(
      new Request(request.url, {
        headers: { "X-Chichi-Save-Token": input.token }
      }),
      env
    );
    if (!(await world.json()).game)
      return json(
        { error: "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u043E\u0436\u0434\u0438\u0442\u0435\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u043C\u0438\u0440\u0430 \u0432 \u043E\u0431\u043B\u0430\u043A\u0435." },
        409
      );
  }
  const result2 = await (await stub(
    "account:" + await hashText("chichi-account-v1:" + input.code),
    { action: input.action, token: input.token }
  )).json();
  if (result2.exists)
    return json(
      {
        error: "\u042D\u0442\u043E\u0442 \u043A\u043E\u0434 \u0443\u0436\u0435 \u0441\u0432\u044F\u0437\u0430\u043D \u0441 \u043C\u0438\u0440\u043E\u043C. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0412\u043E\u0439\u0442\u0438\xBB, \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0435\u0433\u043E; \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430."
      },
      409
    );
  if (result2.missing)
    return json({ error: "\u0410\u043A\u043A\u0430\u0443\u043D\u0442 \u0441 \u0442\u0430\u043A\u0438\u043C \u043A\u043E\u0434\u043E\u043C \u043F\u043E\u043A\u0430 \u043D\u0435 \u0441\u043E\u0437\u0434\u0430\u043D." }, 404);
  return json({ token: result2.token });
}

// worker.mjs
var sourceRevision = false ? null : "0d21c0f0773d756790facf75cc35574376263f60";
var deployedRevision = (env) => sourceRevision || env.GAME_RELEASE || "development";
var json2 = (data, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
var worker_default = {
  async fetch(request, env) {
    const origin = request.headers.get("Origin");
    const allowed = origin === "https://arturmal2805-netizen.github.io";
    if (request.method === "OPTIONS")
      return new Response(null, {
        status: allowed ? 204 : 403,
        headers: allowed ? {
          "Access-Control-Allow-Origin": origin,
          "Access-Control-Allow-Methods": "GET, POST, PUT, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Content-Encoding, X-Chichi-Save-Token",
          Vary: "Origin"
        } : {}
      });
    const response2 = await this.handle(request, env);
    const api = new URL(request.url).pathname.startsWith("/api/");
    if (!allowed && !api) return response2;
    const headers = new Headers(response2.headers);
    if (api) {
      headers.set("X-Chichi-Release", deployedRevision(env));
      headers.set("X-Chichi-Protocol", DECISION_PROTOCOL);
    }
    if (allowed) {
      headers.set("Access-Control-Allow-Origin", origin);
      headers.set(
        "Access-Control-Expose-Headers",
        "X-Chichi-Release, X-Chichi-Protocol"
      );
      headers.set("Vary", "Origin");
    }
    return new Response(response2.body, { status: response2.status, headers });
  },
  async handle(request, env) {
    const path = new URL(request.url).pathname;
    if (path === "/api/status" && request.method === "GET")
      return json2({
        configured: !!(env.AI || env.BACKUP_AI_API_KEY),
        backupConfigured: !!env.BACKUP_AI_API_KEY,
        backupProvider: env.BACKUP_AI_API_KEY ? "openrouter" : null,
        backupModel: env.BACKUP_AI_API_KEY ? env.BACKUP_AI_MODEL || BACKUP_AI_MODEL : null,
        protocol: DECISION_PROTOCOL,
        release: deployedRevision(env),
        versionId: env.CF_VERSION_METADATA?.id || null,
        cloudSave: !!env.SAVE_VAULT
      });
    if (path === "/api/account" && request.method === "POST")
      return accountAccess(request, env);
    if (path === "/api/save" && ["GET", "PUT", "POST"].includes(request.method))
      return cloudSave(request, env);
    if (path === "/api/crypto/forecast" && request.method === "POST") {
      if (Number(request.headers.get("content-length")) > 2048) return json2({ error: "Request too large" }, 413);
      return cloudSave(new Request(new URL("/internal-crypto-ai", request.url), request), env);
    }
    if (path === "/api/jobcity/status" && request.method === "GET")
      return cloudSave(new Request(new URL("/internal-city-ai-status", request.url), {
        headers: { "X-Chichi-Save-Token": request.headers.get("X-Chichi-Save-Token") || "" }
      }), env);
    if (path === "/api/jobcity/plan" && request.method === "POST") {
      if (!env.AI && !env.BACKUP_AI_API_KEY)
        return json2({ error: "AI unavailable" }, 503);
      if (Number(request.headers.get("content-length")) > JOB_AI_LIMIT)
        return json2({ error: "Request too large" }, 413);
      let state;
      try {
        const reader = request.body?.getReader();
        if (!reader) throw Error("Missing body");
        const chunks = [];
        let size = 0;
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          size += value.length;
          if (size > JOB_AI_LIMIT) {
            await reader.cancel();
            return json2({ error: "Request too large" }, 413);
          }
          chunks.push(value);
        }
        const bytes = new Uint8Array(size);
        let offset = 0;
        for (const c of chunks) {
          bytes.set(c, offset);
          offset += c.length;
        }
        state = validateCityAIState(
          JSON.parse(new TextDecoder().decode(bytes))
        );
      } catch {
        return json2({ error: "Invalid work profiles" }, 400);
      }
      try {
        if (state.phase) {
          if (env.SAVE_VAULT) {
            const internal = new Request(
              new URL("/internal-city-ai", request.url),
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "X-Chichi-Save-Token": request.headers.get("X-Chichi-Save-Token") || ""
                },
                body: JSON.stringify(state)
              }
            );
            return cloudSave(internal, env);
          }
          return json2(
            await requestCityLife(
              state,
              (input, validate) => aiProviderRouter(env).run(input, validate)
            )
          );
        }
        if (state.cats.every((p) => p.profession))
          return json2({
            day: state.day,
            assignments: localJobPlan(state.cats, state.day)
          });
        return json2(
          await requestCityPlan(
            state,
            (input) => aiProviderRouter(env).run(input)
          )
        );
      } catch {
        return json2(
          { error: "Daily AI plan unavailable; use the local plan" },
          502
        );
      }
    }
    if (path === "/api/decide" && request.method === "POST") {
      if (!env.AI && !env.BACKUP_AI_API_KEY)
        return json2({ error: "Cloudflare AI \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D." }, 503);
      if (Number(request.headers.get("content-length")) > MAX_DECISION_BYTES)
        return json2({ error: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0437\u0430\u043F\u0440\u043E\u0441" }, 413);
      const reader = request.body?.getReader();
      if (!reader) return json2({ error: "\u041D\u0435\u0442 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F" }, 400);
      let size = 0, chunks = [];
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.length;
        if (size > MAX_DECISION_BYTES) {
          await reader.cancel();
          return json2({ error: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0437\u0430\u043F\u0440\u043E\u0441" }, 413);
        }
        chunks.push(value);
      }
      let state;
      try {
        const bytes = new Uint8Array(size);
        let offset = 0;
        for (const chunk of chunks) {
          bytes.set(chunk, offset);
          offset += chunk.length;
        }
        state = validateState(JSON.parse(new TextDecoder().decode(bytes)));
      } catch {
        return json2({ error: "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043A\u043E\u0442\u0438\u043A\u0430" }, 400);
      }
      try {
        return json2(
          await requestDecision(
            state,
            (input) => aiProviderRouter(env).run(input)
          )
        );
      } catch (error) {
        if (error.code === "AI_INVALID_DECISION") {
          console.error(
            "Cloudflare AI returned an invalid decision:",
            String(error.cause?.message || "Invalid response").slice(0, 300)
          );
          return json2(
            {
              code: "AI_INVALID_DECISION",
              error: "\u0418\u0418 \u0432\u0435\u0440\u043D\u0443\u043B \u043D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u043E\u043F\u044B\u0442\u043A\u0443."
            },
            502
          );
        }
        console.error(
          "Cloudflare AI inference failed:",
          String(error?.message || "Unknown error").slice(0, 500)
        );
        return json2(
          {
            code: "AI_INFERENCE_FAILED",
            error: "Cloudflare AI \u043D\u0435 \u0441\u043C\u043E\u0433 \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0437\u0430\u043F\u0440\u043E\u0441. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043B\u0438\u043C\u0438\u0442 \u0438 \u0434\u043E\u0441\u0442\u0443\u043F \u043A Workers AI."
          },
          502
        );
      }
    }
    if (path.startsWith("/api/")) return json2({ error: "Not found" }, 404);
    return env.ASSETS.fetch(request);
  }
};
export {
  SaveVault,
  worker_default as default
};
