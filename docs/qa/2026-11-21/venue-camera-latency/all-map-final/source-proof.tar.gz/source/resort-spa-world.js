import {venueButton} from './venue-buttons.js';
import {spaV7Service} from './resort-spa-services-v7.js';
import {createSpaInvitations} from './resort-spa-invitations.js';
import {resortPalaceRecovery,resolvePalaceRecovery,prunePalaceRecovery,palaceProcedureSavePositions} from './resort-spa-layout-recovery.js';
import {spaPalaceContains} from './resort-spa-layout-v7.js';
import {resortTicketService} from './resort-spa-ticket-compatibility.js';
import {createResortAppointments} from './resort-spa-appointments.js';
import {createResortTransit} from './resort-spa-transit.js';
import {RESORT_LIFT} from './resort-spa-lift.js';
import {resortPaidTicket} from './resort-spa-economy.js';
import {updateResortPoolRipples} from './resort-spa-pool-effects.js';
import {courtFood} from './foodcourt-assets.js';
import {placeCourtFood} from './court-food-pose.js';
import {mosaPierClear} from './resort-pier-link-data.js';
import {MOSA_SHORE_GATE} from './mosasaur-data.js';
import {resortLiftRecovery} from './resort-spa-recovery.js';
import {prepareResortExpression} from './resort-spa-dry-performance.js';
import {resortSpaStaffSteps,updateResortStaff,disposeResortStaff} from './resort-spa-staff.js';
import {prepareResortReflections} from './resort-spa-reflections.js';
import {prepareMallArt} from './mall-art.js';
import {prepareMosaWaterReflection} from './mosasaur-water-probe.js';
import * as T from 'three';
import {resortSpaModelSteps} from './resort-spa-model.js';
import {createResortSpaNavigation} from './resort-spa-navigation.js';
import {RESORT_SPA as L,RESORT_ACTIVE_ZONES,resortZone,resortSpaOrigin} from './resort-spa-data.js';
import {byBiome} from './game-data.js';
// Independent scene/camera owner. Mall's floors, selection and guest camera
// remain untouched; only the world coordinator performs the hand-off.
export function createResortSpaWorld({scene,container,getGame,getFocused,getOverview,prepare,prepareModel,onCamera,onExit,onRecovery=()=>{},onError=()=>{},getActors=()=>[],getAccessSurfaces=()=>[],accessClear=()=>true,registerCat=()=>{},canSimulate=()=>true,blocked=()=>false,onPurchase,onUse,onGoal,onComplete,onCall=()=>false,callBusy=()=>false,onInvitationArrive=()=>{},getInvitees=()=>[],guestFree=()=>false,onRecallGuest=()=>false,onGuestPark=()=>{},onGuestRelease=()=>{},onGuestReserve=()=>true,onGuestHold=()=>{}}){
 const centre=resortSpaOrigin(byBiome('autumn').center),controller=new AbortController(),buttons=new Map(),journeys=new Map(),heldFoods=new Map(),recovering=resortLiftRecovery(getGame()),layoutRecovery=resortPalaceRecovery(getGame());for(const id of recovering.keys())layoutRecovery.delete(id);let root=null,pending=null,disposed=false,inspection=false,selected=null,navigation=null,appointments=null,transit=null,invitations=null,staff=[],nextPreparation=0,watched=null;
 const access=venueButton('spa');access.classList.add('resort-spa-access');access.hidden=true;access.onclick=()=>inspect();(container.querySelector('.map-controls')||container).append(access);
 const panel=document.createElement('nav');panel.className='resort-spa-zones';panel.hidden=true;panel.setAttribute('aria-label','Зоны подводного SPA');container.append(panel);
 for(const zone of [null,...RESORT_ACTIVE_ZONES]){const b=document.createElement('button');b.textContent=zone?.name||'Общий вид';b.onclick=()=>inspect(zone?.id);panel.append(b);buttons.set(zone?.id||'overview',b);}
 const callButton=document.createElement('button');callButton.className='resort-spa-call';callButton.textContent='🐈 Позвать Чичи в SPA';callButton.title='Бесплатный вызов ко входу. Процедуры выбираются отдельно.';let calling=false;callButton.onclick=async()=>{if(calling||callBusy())return;calling=true;callButton.disabled=true;try{await onCall();}catch(e){onError(e.message);}finally{calling=false;callButton.disabled=false;}};panel.append(callButton);
 const callAll=document.createElement('button');callAll.className='resort-spa-call-all';callAll.textContent='🐾 Позвать свободных котиков в SPA';callAll.title='Бесплатное приглашение свободных котиков. Входят по очереди через лифт; процедуры отдельно.';let callingAll=false;callAll.onclick=async()=>{if(callingAll)return;callingAll=true;try{if(!canSimulate()||!await ensure())return;const count=invitations.invite(getInvitees());onError(count?'Приглашено котиков: '+count+'. Они придут в SPA по очереди. Вызов бесплатный.':'Свободных котиков для нового приглашения сейчас нет.');}catch(e){onError(e.message);}finally{callingAll=false;}};panel.append(callAll);
 const close=document.createElement('button');close.textContent='Выйти из обзора';close.onclick=()=>exit();panel.append(close);
 const liftButton=document.createElement('button');liftButton.className='resort-spa-lift';liftButton.hidden=true;(container.querySelector('.map-controls')||container).append(liftButton);
 const serviceFor=id=>root?.userData.serviceContract?.zone(id)||spaV7Service(id)||resortZone(id);
 const finish=(id,result)=>{journeys.delete(id);onComplete?.(id,result);};
 function start(id,zone){if(invitations?.has(id)){if(invitations.frame(id)?.phase!=='spa-invitation-parked')return false;invitations.cancel(id);}zone=resortTicketService(getGame(),id,zone,root?.userData.serviceContract);const service=serviceFor(zone),profile=getGame().jobCity?.profiles[id];if(pending||!appointments||!service||!profile||journeys.has(id)||transit?.has(id)||((service.retired||profile.coins<service.price)&&!resortPaidTicket(getGame(),id,zone)))return false;const actor=getActors().find(a=>a.id===id);if(!actor)return false;
  if(Math.abs(actor.position.y-RESORT_LIFT.upperY)<.65){if(blocked(id)||!transit.start(id,1))return false;journeys.set(id,{zone,result:null});return true;}
  return appointments.start(id,zone);
 }
 function ride(id,target,purpose='manual'){return !!transit&&!appointments?.has(id)&&!journeys.has(id)&&transit.start(id,target,{purpose});}
 liftButton.onclick=()=>{const actor=getActors().find(a=>a.id==='chichi');if(actor)ride('chichi',actor.position.y>-80?1:0);};
 async function ensure(){if(pending)return pending;if(root)return root;if(disposed)return null;pending=(async()=>{let model;try{await Promise.all([prepareMallArt(),prepareMosaWaterReflection(),prepareResortReflections()]);model=await prepare(resortSpaModelSteps({layoutVersion:7}),controller.signal);if(disposed){model.userData.dispose();return null;}model.position.x=centre[0];model.position.z=centre[1];model.userData.biomeId='autumn';
   // Navigation is evaluated in ocean-local coordinates; prepare before the
   // world translation, retaining the authored floor and pool triangles.
   model.position.x=0;model.position.z=0;navigation=createResortSpaNavigation(model,{externalSurfaces:getAccessSurfaces,externalContains:p=>Math.abs(p.x)<1.1&&p.z+L.offsetZ>=23&&p.z+L.offsetZ<=MOSA_SHORE_GATE.z+1,externalClear:(p,r)=>{const q={x:p.x,y:p.y+L.y,z:p.z+L.offsetZ};return mosaPierClear(q,r,MOSA_SHORE_GATE.z)&&accessClear(q,r);}});model.position.x=centre[0];model.position.z=centre[1];model.updateWorldMatrix(true,true);
   await prepareModel(model);if(disposed){model.userData.dispose();return null;}scene.add(model);root=model;if(root.userData.layoutVersion!==7)layoutRecovery.clear();if(root.userData.layoutVersion===7){for(const b of buttons.values())b.remove();buttons.clear();for(const zone of [null,...root.userData.serviceContract.zones]){const b=document.createElement('button');b.textContent=zone?.name||'Общий вид';b.onclick=()=>inspect(zone?.id);panel.insertBefore(b,close);buttons.set(zone?.id||'overview',b);}}staff=await prepare(resortSpaStaffSteps(centre,registerCat,root.userData.serviceContract),controller.signal);if(disposed){disposeResortStaff(staff);staff=[];return null;}for(const s of staff){await prepareModel(s.carrier);if(disposed)break;scene.add(s.carrier);}if(disposed){disposeResortStaff(staff);staff=[];return null;}
   await prepareModel(courtFood('coffee'));await prepareModel(courtFood('cookie'));if(disposed)return null;
   function* posePreparation(){for(const actor of getActors()){prepareResortExpression(actor.model);yield;}}await prepare(posePreparation(),controller.signal);if(disposed)return null;
   transit=createResortTransit({navigation,geometry:root.userData.accessGeometry,getActors,centre,canSimulate,blocked:(id,purpose)=>!['manual','recovery'].includes(purpose)&&blocked(id),onCancel:(id)=>{invitations?.cancel(id);finish(id,{completed:false});},onArrive:(id,{floor,purpose})=>{if(purpose==='manual')return;if(purpose==='group-invitation'){invitations?.arrived(id);return;}if(purpose==='invitation'){onInvitationArrive(id);return;}if(purpose==='recovery'){if(serviceFor(getGame().jobCity?.profiles[id]?.mall?.goal?.storeId))onGoal?.(id,null,{completed:false});finish(id,{completed:false,recovered:true});return;}const journey=journeys.get(id);if(!journey)return;if(floor===1){if(!appointments.start(id,journey.zone)){journey.result={completed:false};if(!transit.start(id,0))finish(id,journey.result);}}else finish(id,journey.result||{completed:false});}});
   invitations=createSpaInvitations({actors:getActors,free:guestFree,recall:onRecallGuest,ride,transit,navigation,origin:{x:centre[0],y:L.y,z:centre[1]},contract:root.userData.serviceContract,onPark:onGuestPark,onRelease:onGuestRelease,onReserve:onGuestReserve,onHold:onGuestHold,allow:canSimulate});
   appointments=createResortAppointments({contract:root.userData.serviceContract,getGame,getActors,getNavigation:()=>navigation,centre,canSimulate,blocked,onPurchase,onUse,onGoal,onComplete:(id,result)=>{const journey=journeys.get(id);if(!journey){onComplete?.(id,result);return;}journey.result=result;if(!transit.start(id,0))finish(id,result);},getStaff:()=>staff});
   if(layoutRecovery.size&&root.userData.layoutVersion===7){prunePalaceRecovery(layoutRecovery,getGame());const repairs=resolvePalaceRecovery(layoutRecovery,navigation,getActors());for(const[id,p]of repairs){const actor=getActors().find(a=>a.id===id);Object.assign(actor.position,{x:centre[0]+p.x,y:p.y,z:centre[1]+p.z});layoutRecovery.delete(id);onGoal?.(id,null,{completed:false,recovered:true});}if(layoutRecovery.size)onError('Не найдена безопасная опора для прежней позиции SPA. Исходная позиция сохранена.');}
   if(recovering.size){for(const[id,saved]of recovering){const actor=getActors().find(a=>a.id===id);if(actor)Object.assign(actor.position,{x:centre[0]+saved.local.x,y:saved.y,z:centre[1]+saved.local.z});}if(transit.restore([...recovering.keys()]))recovering.clear();else onError('Не удалось восстановить согласованные места в лифте SPA. Сохранение не изменено.');}return root;
  }catch(e){if(root===model){scene.remove(root);root=null;model.userData.dispose();}else if(model&&!disposed)model.userData.dispose();disposeResortStaff(staff);staff=[];appointments=null;if(!disposed)onError(e.message);return null;}finally{pending=null;}})();return pending;}
 let inspectionVersion=0;
 async function inspect(id=null){
  if(disposed||!getGame().unlocked.includes('autumn'))return false;
  let zone=id?serviceFor(id):null;if(root&&id&&!zone)return false;
  watched=null;onCamera(zone,!inspection);
  const version=++inspectionVersion;inspection=true;selected=id;panel.hidden=false;
  root?.userData.setInspectionLevel?.(zone?.level??null);
  for(const[key,b]of buttons)b.setAttribute('aria-pressed',String(key===(id||'overview')));
  const model=await ensure();
  if(version!==inspectionVersion||!inspection||disposed)return false;
  if(!model){exit();return false;}
  const preview=zone;zone=id?serviceFor(id):null;if(id&&!zone){exit();return false;}
  if(model.userData.layoutVersion===7&&zone){id=zone.roomId;zone=serviceFor(id);}
  // Resolve legacy room aliases only for the latest request after preparation.
  if(zone!==preview)onCamera(zone,false);
  selected=id;model.userData.setInspectionLevel?.(zone?.level??null);
  for(const[key,b]of buttons)b.setAttribute('aria-pressed',String(key===(id||'overview')));
  return true;
 }
 function exit(restore=true){inspectionVersion++;if(!inspection)return;watched=null;inspection=false;root?.userData.setInspectionLevel?.(null);panel.hidden=true;selected=null;onExit(restore);}
 function updateHeld(){const active=new Set();for(const v of appointments?.runtime.visits.values()||[]){if(v.zone.key!=='cafe'||v.phase!=='procedure')continue;const actor=getActors().find(a=>a.id===v.catId);if(!actor)continue;const action=appointments.frame(v.catId)?.action,kind=action==='drink'?'coffee':['taste-treat','satisfied-chew'].includes(action)?'cookie':null;if(!kind)continue;const key=v.catId+':'+kind;active.add(key);let prop=heldFoods.get(key);if(!prop){prop=courtFood(kind);prop.userData.biomeId='autumn';scene.add(prop);heldFoods.set(key,prop);}prop.visible=!!root?.visible;placeCourtFood(prop,actor.model,actor.carrier,{kind,drinking:kind==='coffee',time:v.elapsed});}for(const[key,prop]of heldFoods)if(!active.has(key)){prop.removeFromParent();heldFoods.delete(key);}}
 const recoveryFrame=id=>{const legacy=layoutRecovery.get(id);if(legacy){const p=legacy.saved;return{position:{x:centre[0]+p.x,y:p.y,z:centre[1]+p.z-L.offsetZ},yaw:p.yaw,walking:false,phase:'restoring-spa-layout',reaction:null};}const p=recovering.get(id);return p?{position:{x:centre[0]+p.local.x,y:p.y,z:centre[1]+p.local.z},yaw:p.yaw,walking:false,phase:'restoring-lift',reaction:{ride:true}}:null;};
 if(recovering.size||layoutRecovery.size)queueMicrotask(()=>{if(disposed)return;if(recovering.has('chichi')||layoutRecovery.has('chichi'))onRecovery();void ensure();});
 return{safePositions(){if(root?.userData.layoutVersion!==7||!appointments)return new Map();return new Map([...palaceProcedureSavePositions(appointments.runtime.visits,navigation,getActors())].map(([id,p])=>[id,p?{x:p.x+centre[0],y:p.y,z:p.z+centre[1]}:null]));},locationStamp(id,position){if(root?.userData.layoutVersion!==7||layoutRecovery.has(id))return undefined;const p={x:position.x-centre[0],y:position.y-L.y,z:position.z-centre[1]};if(!spaPalaceContains(p.x,p.z,.1))return undefined;return appointments?.has(id)||navigation?.support(p,.571)?7:undefined;},ensure,inspect,exit,ride,updateHeld,invitationReady:id=>invitations?.ready(id),get invited(){return invitations?.size||0;},get recovering(){return recovering.size>0||layoutRecovery.size>0;},get root(){return root;},get ready(){return!!root&&!pending&&!!appointments;},get appointments(){return appointments;},get transit(){return transit;},has:id=>recovering.has(id)||layoutRecovery.has(id)||transit?.has(id)||appointments?.has(id)||!!(invitations?.has(id)&&invitations.frame(id)?.phase!=='spa-invitation-parked')||false,cancel:id=>{const a=transit?.cancel(id),b=appointments?.cancel(id),c=invitations?.cancel(id);return a||b||c;},frame:id=>recoveryFrame(id)||transit?.frame(id)||appointments?.frame(id)||invitations?.frame(id),transportFrame:id=>transit?.frame(id),startReady:start,get inspection(){return inspection;},get navigation(){return navigation;},get selected(){return selected;},
  pick(ray,occluder=null){if(!root?.visible)return false;const hits=ray.intersectObject(root,true);if(!hits.length)return false;if(occluder){const front=ray.intersectObject(occluder,true)[0];if(front&&front.distance<hits[0].distance)return false;}void inspect();return true;},
  update(dt,time,reduced=false){callAll.disabled=callingAll||pending||!canSimulate();callAll.textContent=invitations?.size?'🐾 В SPA приглашено: '+invitations.size:'🐾 Позвать свободных котиков в SPA';callButton.disabled=calling||callBusy();callButton.textContent=callBusy()?'🐾 Чичи идёт в SPA…':'🐈 Позвать Чичи в SPA';if(inspection&&watched){const actor=getActors().find(a=>a.id===watched);if(actor)onCamera(null,false,{follow:actor.position});else watched=null;}const active=getFocused()==='autumn',visible=active||getOverview(),unlocked=getGame().unlocked.includes('autumn');access.hidden=!active||!unlocked;if(active&&unlocked&&!root&&!pending&&time>=nextPreparation){nextPreparation=time+30;void ensure();}transit?.update(dt);invitations?.update(dt);appointments?.update(dt);const actor=getActors().find(a=>a.id==='chichi'),near=actor&&Math.hypot(actor.position.x-centre[0]-RESORT_LIFT.x,actor.position.z-centre[1]-RESORT_LIFT.z)<14&&(Math.abs(actor.position.y-RESORT_LIFT.upperY)<.65||Math.abs(actor.position.y-RESORT_LIFT.lowerY)<.65);liftButton.hidden=!active||!transit||!near||!!transit.has('chichi')||!!appointments?.has('chichi');liftButton.textContent=actor?.position.y>-80?'🪷 Спуститься в SPA':'🪷 Подняться на причал';updateResortStaff(staff,appointments,time,reduced,visible&&!pending);if(root){root.visible=visible&&!pending;if(visible){root.userData.update(time,reduced);if(appointments)updateResortPoolRipples(root,appointments.runtime.visits,time,reduced);}}},
  dispose(){disposed=true;controller.abort();access.remove();panel.remove();liftButton.remove();for(const prop of heldFoods.values())prop.removeFromParent();heldFoods.clear();journeys.clear();invitations?.clear();transit?.clear();appointments?.clear();disposeResortStaff(staff);staff=[];if(root){scene.remove(root);root.userData.dispose();root=null;}},
 };
}
