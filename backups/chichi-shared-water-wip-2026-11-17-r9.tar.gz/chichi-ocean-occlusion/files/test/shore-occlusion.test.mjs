import test from 'node:test';import assert from 'node:assert/strict';import {shoreOccludesBox} from '../public/shore-occlusion.js';import {MOSA_RADIUS,mosaWaterRadius} from '../public/mosasaur-data.js';
const box={min:{x:-130,y:-166,z:-6},max:{x:130,y:-98,z:137}};
test('only a proven solid shore footprint hides deep Mall floors',()=>{
 assert.equal(shoreOccludesBox({x:295,y:7,z:-25},box),true);
 for(const camera of [{x:245,y:7,z:-25},{x:0,y:25,z:0},{x:295,y:-1,z:-25},{x:450,y:2,z:0}])assert.equal(shoreOccludesBox(camera,box),false);
 assert.equal(shoreOccludesBox({x:295,y:7,z:-25},{min:box.min,max:{...box.max,y:1}}),false,'surface bridges/lift stay visible');
 assert.equal(shoreOccludesBox({x:0,y:100,z:0},{min:{x:-440,y:-100,z:-320},max:{x:440,y:-100,z:320}}),false,'shore corners cannot conceal an ocean opening inside their convex hull');
});
test('every accepted box projection lies on the real solid shore, including boundary views',()=>{
 let accepted=0;for(let angle=0;angle<Math.PI*2;angle+=.19)for(const y of [1,7,20,60,140])for(const radius of [240,260,280,310,335]){
  const camera={x:Math.cos(angle)*radius,y,z:Math.sin(angle)*radius};if(!shoreOccludesBox(camera,box))continue;accepted++;
  for(let ix=0;ix<=4;ix++)for(let iy=0;iy<=4;iy++)for(let iz=0;iz<=4;iz++){
   const x=box.min.x+(box.max.x-box.min.x)*ix/4,py=box.min.y+(box.max.y-box.min.y)*iy/4,z=box.min.z+(box.max.z-box.min.z)*iz/4,t=(camera.y-.14)/(camera.y-py),px=camera.x+(x-camera.x)*t,pz=camera.z+(z-camera.z)*t;
   assert.ok(Math.hypot(px,pz)<MOSA_RADIUS);assert.ok(mosaWaterRadius(px,pz)>1);
  }
 }assert.ok(accepted>50);
});

test('only opaque unlit fixtures skip colour draws; lit surfaces, glass and native shadows remain',async()=>{
 const {installShoreDrawFilter,registerShoreRenderOwner}=await import('../public/shore-occlusion.js');
 const calls=[],native=function(...args){calls.push({context:this,args});return 'drawn';};
 const renderer={renderBufferDirect:native},owner={userData:{renderOccluded:true}},mesh={},geometry={};registerShoreRenderOwner(mesh,owner);
 const filter=installShoreDrawFilter(renderer),basic={isMeshBasicMaterial:true,depthTest:true,depthWrite:true},args=['camera','scene',geometry,basic,mesh,null];
 assert.equal(renderer.renderBufferDirect(...args),undefined);assert.equal(calls.length,0);
 for(const material of [{isMeshStandardMaterial:true,depthTest:true,depthWrite:true},{...basic,transparent:true},{...basic,depthTest:false},{...basic,depthWrite:false},{isMeshDepthMaterial:true},{isMeshDistanceMaterial:true}])assert.equal(renderer.renderBufferDirect(...args.slice(0,3),material,mesh,null),'drawn');
 assert.equal(renderer.renderBufferDirect(...args.slice(0,4),{},null),'drawn');owner.userData.renderOccluded=false;assert.equal(renderer.renderBufferDirect(...args),'drawn');assert.equal(calls.length,8);assert.equal(calls[0].context,renderer);
 filter.dispose();assert.equal(renderer.renderBufferDirect,native);owner.userData.renderOccluded=true;assert.equal(renderer.renderBufferDirect(...args),'drawn');
});
