import {MOSA_RADIUS,MOSA_SEA} from './mosasaur-data.js';

// The real shore is an opaque extruded annulus at y=.14. Its water opening
// fits inside this larger ellipse, and this smaller circle fits inside the
// authored outer polygon. A positive result therefore proves solid ground,
// rather than assuming that every view from land hides the underwater world.
const outer=MOSA_RADIUS*Math.cos(Math.PI/64)-.05,ex=MOSA_SEA.rx*1.054+.05,ez=MOSA_SEA.rz*1.054+.05;
const cross=(a,b,c)=>(b.x-a.x)*(c.z-a.z)-(b.z-a.z)*(c.x-a.x);
export function shoreOccludesBox(camera,box){
 const plane=.14;if(!box||camera.y<=plane+.05||box.max.y>=plane-.05)return false;
 const points=[];
 for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){
  const t=(camera.y-plane)/(camera.y-y),px=camera.x+(x-camera.x)*t,pz=camera.z+(z-camera.z)*t;
  if(px*px+pz*pz>=outer*outer)return false;points.push({x:px/ex,z:pz/ez});
 }
 points.sort((a,b)=>a.x-b.x||a.z-b.z);const hull=[];
 for(const p of points){while(hull.length>1&&cross(hull.at(-2),hull.at(-1),p)<=0)hull.pop();hull.push(p);}
 const lower=hull.length;
 for(let i=points.length-2;i>=0;i--){const p=points[i];while(hull.length>lower&&cross(hull.at(-2),hull.at(-1),p)<=0)hull.pop();hull.push(p);}hull.pop();
 if(hull.length<3)return false;
 // Convex-hull intersection, not just eight clear corners. The opening may
 // cross the interior of a projected box whose corners all happen to be land.
 let inside=true,min=Infinity;const origin={x:0,z:0};
 for(let i=0;i<hull.length;i++){
  const a=hull[i],b=hull[(i+1)%hull.length],dx=b.x-a.x,dz=b.z-a.z,t=Math.max(0,Math.min(1,-(a.x*dx+a.z*dz)/(dx*dx+dz*dz||1)));
  min=Math.min(min,Math.hypot(a.x+dx*t,a.z+dz*t));if(cross(a,b,origin)<0)inside=false;
 }
 return !inside&&min>1.00001;
}

const renderOwners=new WeakMap();
export function registerShoreRenderOwner(mesh,owner){renderOwners.set(mesh,owner);}
// Only the Mall's opaque unlit fixtures have passed exact native-frame
// validation so far. Retain lit/custom/glass draws and every shadow; adding
// another material family requires its own equal-frame native audit.
export function installShoreDrawFilter(renderer){
 const native=renderer.renderBufferDirect;let active=true;
 function draw(camera,scene,geometry,material,object,group){
  if(active&&material.isMeshBasicMaterial&&!material.transparent&&material.depthTest&&material.depthWrite&&renderOwners.get(object)?.userData.renderOccluded)return;
  return native.call(this,camera,scene,geometry,material,object,group);
 }
 renderer.renderBufferDirect=draw;
 return {dispose(){active=false;if(renderer.renderBufferDirect===draw)renderer.renderBufferDirect=native;}};
}
